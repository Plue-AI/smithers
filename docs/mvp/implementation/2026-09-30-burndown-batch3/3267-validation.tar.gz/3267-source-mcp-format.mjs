import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { mcpInitialize } from '/private/tmp/smithers-burndown-20260930/scripts/release-mcp-handshake.mjs'
const home = await mkdtemp('/private/tmp/smithers-json-mcp-')
try {
  const info = await mcpInitialize(process.execPath, ['--no-warnings', '/private/tmp/smithers-burndown-20260930/packages/smithers/src/bin.ts', '--mcp', '--format=json'], {
    cwd: home, env: { HOME: home, XDG_CONFIG_HOME: home, XDG_DATA_HOME: home, PATH: process.env.PATH, TMPDIR: '/private/tmp' }
  })
  assert.equal(info.version, '1.0.0-rc.1')
  console.log(JSON.stringify({ sourceMcp: info, args: ['--mcp', '--format=json'] }))
} finally { await rm(home, { recursive: true, force: true }) }
