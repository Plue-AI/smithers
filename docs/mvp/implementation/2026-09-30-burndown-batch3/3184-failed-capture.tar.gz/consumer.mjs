import {readFileSync,writeFileSync,mkdirSync,symlinkSync,existsSync} from "node:fs";
import {gunzipSync} from "node:zlib";
import {join} from "node:path";
import {createRequire} from "node:module";
import {spawnSync} from "node:child_process";
const root="/private/tmp/smithers-burndown-20260930", receipts="/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2/3184-qualification";
const packages=JSON.parse(readFileSync(join(receipts,"fresh-surface.json"))).packages;
const texts=JSON.parse(gunzipSync(readFileSync(join(receipts,"fresh-declarations.json.gz"))));
const directory=join(receipts,"declaration-consumer");mkdirSync(directory,{recursive:true});
if(!existsSync(join(directory,"node_modules")))symlinkSync(join(root,"node_modules"),join(directory,"node_modules"),"dir");
writeFileSync(join(directory,"package.json"),JSON.stringify({private:true,type:"module"}));
const paths={},imports=[];
let index=0;
for(const[name,p]of Object.entries(packages)){
 for(const[file]of Object.entries(p.declarations)){const text=texts[name+"/"+file].raw, dest=join(directory,"declarations",name,file);mkdirSync(join(dest,".."),{recursive:true});writeFileSync(dest,text);}
 for(const[entry,exp]of Object.entries(p.exports)){
  const type=exp?.import?.types;
  if(!type||entry.includes("*"))continue;
  const file=type.replace(/^\.\/dist\/esm\//,"");
  const specifier=entry==="."?name:name+entry.slice(1);
  paths[specifier]=[join(directory,"declarations",name,file)];
  imports.push(`import type * as Public${index} from ${JSON.stringify(specifier)}; type PublicUse${index} = typeof Public${index};`);index++;
 }
}
const probe=`
import type * as AgentAction from "@smthrs/agent/AgentAction";
import type * as NodeControl from "@smthrs/cli/NodeControl";
import type * as Atomic from "@smthrs/kernel/FileSystem";
import type * as Install from "@smthrs/targets/Install";
import type * as Review from "@smthrs/targets/LlmLint";
import type * as Harness from "@smthrs/harness/HarnessError";
import type * as Scorers from "@smthrs/scorers/Scorers";
import type * as Consensus from "@smthrs/journal/Consensus";
import type * as SqlConsensus from "@smthrs/journal/SqlConsensus";
import type * as StepCacheFold from "@smthrs/engine-store/StepCacheFold";
import type {Effect} from "effect";
type Equal<A,B> = (<T>()=>T extends A?1:2) extends (<T>()=>T extends B?1:2)?true:false;
type Expect<T extends true> = T;
type Success<F> = F extends Effect.Effect<infer A,infer E,infer R>?A:never;
type Stance = Expect<Equal<ReturnType<typeof AgentAction.supervisorStance>, "careful"|"paranoid">>;
type Model = Expect<Equal<Success<ReturnType<typeof NodeControl.accountPoolDefaultModel>>, "openai:gpt-6-luna"|"anthropic:claude-sonnet-4-6"|undefined>>;
type Resolve = Expect<Equal<Atomic.AtomicResults["resolve"],Atomic.Resolution>>;
declare const legacyAtomic: Omit<Atomic.AtomicHandlers,"resolve">;
// @ts-expect-error A custom executor must implement no-follow resolve.
const missingResolve:Atomic.AtomicHandlers=legacyAtomic;
const workspaceManifest:keyof Install.Attrs="workspaceManifest";
// @ts-expect-error Standalone patches were removed in favor of workspaceManifest.
const removedPatches:keyof Install.Attrs="patches";
type Usage=typeof Review.RunRecord.Type["usage"];
const usage:Usage={modelCalls:1,promptTokens:4,elapsedMs:0,legacyElapsedUnknown:true};
// @ts-expect-error Only the persisted legacy reader may upgrade a missing elapsed measurement.
const missingElapsed:Usage={modelCalls:1,promptTokens:4};
const approvalCode:typeof Harness.HarnessErrorCode.Type="approval_unavailable";
const testsOptions:Scorers.TestsPassOptions["command"]="npm test";
const diffOptions:Scorers.DiffOptions={max:1};
type ConsensusLayer=typeof Consensus.layerLocal;
type SqlConsensusLayer=typeof SqlConsensus.layer;
type CacheFold=typeof StepCacheFold.rebuild;
`;
writeFileSync(join(directory,"consumer.ts"),imports.join("\n")+"\n"+probe);
const config={compilerOptions:{strict:true,noEmit:true,skipLibCheck:false,target:"ES2022",module:"NodeNext",moduleResolution:"NodeNext",lib:["ES2022","DOM","DOM.Iterable"],types:["node"],paths},files:["consumer.ts"]};
writeFileSync(join(directory,"tsconfig.json"),JSON.stringify(config,null,2)+"\n");
const req=createRequire(join(root,"packages/smithers/flows/kernel/package.json"));
const compiler=req.resolve("typescript/bin/tsc");
const result=spawnSync(process.execPath,[compiler,"-p",join(directory,"tsconfig.json"),"--listFiles"],{cwd:directory,encoding:"utf8",maxBuffer:30*1024*1024});
writeFileSync(join(receipts,"declaration-consumer.log"),(result.stdout??"")+(result.stderr??""));
console.log(JSON.stringify({entrypoints:index,compiler,exitCode:result.status,signal:result.signal,error:result.error?.message}));
process.exit(result.status??1);
