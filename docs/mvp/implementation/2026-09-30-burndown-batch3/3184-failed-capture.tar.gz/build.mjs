import { readFileSync, writeFileSync, readdirSync, mkdirSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { createRequire } from "node:module";
import { join, dirname } from "node:path";
import { execFileSync } from "node:child_process";
import { gzipSync } from "node:zlib";
import { apiSurface, canonicalDeclaration, withDeclarationBuild } from "/private/tmp/smithers-burndown-20260930/scripts/check-api-baseline.mjs";
import { libraryPackages } from "/private/tmp/smithers-burndown-20260930/scripts/workspace-packages.mjs";
const root="/private/tmp/smithers-burndown-20260930", receipts="/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2/3184-qualification";
const sha=bytes=>createHash("sha256").update(bytes).digest("hex");
const head=execFileSync("git",["rev-parse","HEAD"],{cwd:root,encoding:"utf8"}).trim();
if(head!=="2f19595137c67388f3228d3031410abd14735731")throw new Error("Wrong frozen candidate");
const packages=libraryPackages(root).filter(p=>!p.manifest.private);
const tracked=execFileSync("git",["ls-files","-z"],{cwd:root,encoding:"utf8"}).split("\0").filter(Boolean);
const inputs=tracked.filter(f=> (f.startsWith("packages/")&&(f.includes("/src/")||/\/(package\.json|tsconfig[^/]*\.json|PACKAGE\.ts)$/.test(f)))||/^(package\.json|pnpm-lock\.yaml|pnpm-workspace\.yaml|tsconfig[^/]*\.json|\.node-version|\.npmrc)$/.test(f)||["scripts/check-api-baseline.mjs","scripts/workspace-packages.mjs","packages/repo-targets/scripts/build-library.mjs"].includes(f));
const files=Object.fromEntries(inputs.map(f=>[f,sha(readFileSync(join(root,f)))]));
const compilerFiles={};
const compilers=packages.map(p=>{const req=createRequire(join(root,p.dir,"package.json"));const manifest=req.resolve("typescript/package.json");const base=dirname(manifest);const contents=JSON.parse(readFileSync(manifest));for(const entry of ["package.json","bin/tsc",...readdirSync(join(base,"lib")).filter(f=>f.endsWith(".js")||f.endsWith(".d.ts")).map(f=>"lib/"+f)]){const path=join(base,entry);compilerFiles[path]=sha(readFileSync(path));}return {name:p.name,dir:p.dir,version:contents.version,compiler:join(base,"bin/tsc"),manifestHash:sha(readFileSync(manifest))};});
writeFileSync(join(receipts,"frozen-inputs.json"),JSON.stringify({head,files,compilerFiles,compilers,node:process.version,startedAt:new Date().toISOString()},null,2)+"\n");
const baseline=JSON.parse(readFileSync(join(root,"scripts/fixtures/public-api-baseline.json")));
writeFileSync(join(receipts,"baseline-before.json"),JSON.stringify(baseline,null,2)+"\n");
const existing={};
for(const p of packages)for(const [file,hash]of Object.entries(baseline.packages[p.name]?.declarations??{})){const path=join(root,p.dir,"dist/esm",file);if(!existsSync(path))continue;const text=canonicalDeclaration(readFileSync(path,"utf8").replace(/\r\n/g,"\n").replace(/^\/\/# sourceMappingURL=.*$/gm,"").trim());if(sha(text)===hash)existing[p.name+"/"+file]=text;}
writeFileSync(join(receipts,"verified-prior-declarations.json.gz"),gzipSync(JSON.stringify(existing)));
console.log(JSON.stringify({head,publicPackages:packages.length,inputFiles:inputs.length,compilerVersions:[...new Set(compilers.map(c=>c.version))],verifiedPriorDeclarations:Object.keys(existing).length,start:new Date().toISOString()}));
await withDeclarationBuild(root, async output=>{
 const surface=apiSurface(root,output), texts={};
 const walk=(dir,prefix="")=>readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(dir,e.name),prefix+e.name+"/"):e.name.endsWith(".d.ts")?[prefix+e.name]:[]);
 for(const p of packages)for(const file of walk(join(output,p.dir,"dist/esm"))){const raw=readFileSync(join(output,p.dir,"dist/esm",file),"utf8");texts[p.name+"/"+file]={raw,normalized:canonicalDeclaration(raw.replace(/\r\n/g,"\n").replace(/^\/\/# sourceMappingURL=.*$/gm,"").trim())};}
 writeFileSync(join(receipts,"fresh-surface.json"),JSON.stringify({format:2,packages:surface},null,2)+"\n");
 writeFileSync(join(receipts,"fresh-declarations.json.gz"),gzipSync(JSON.stringify(texts)));
 const drift=Object.keys(surface).filter(n=>JSON.stringify(surface[n])!==JSON.stringify(baseline.packages[n])).map(n=>({name:n,exportsChanged:JSON.stringify(surface[n].exports)!==JSON.stringify(baseline.packages[n]?.exports),files:[...new Set([...Object.keys(surface[n].declarations),...Object.keys(baseline.packages[n]?.declarations??{})])].filter(f=>surface[n].declarations[f]!==baseline.packages[n]?.declarations[f]).map(f=>({file:f,before:baseline.packages[n]?.declarations[f],after:surface[n].declarations[f],priorTextVerified:existing[n+"/"+f]!==undefined}))}));
 writeFileSync(join(receipts,"declaration-drift.json"),JSON.stringify(drift,null,2)+"\n");
 for(const[f,hash]of Object.entries(files))if(sha(readFileSync(join(root,f)))!==hash)throw new Error("Frozen input changed: "+f);
 console.log(JSON.stringify({finishedAt:new Date().toISOString(),declarations:Object.keys(texts).length,changedPackages:drift.map(p=>p.name),changedDeclarations:drift.reduce((n,p)=>n+p.files.length,0),frozenInputsUnchanged:true}));
});
