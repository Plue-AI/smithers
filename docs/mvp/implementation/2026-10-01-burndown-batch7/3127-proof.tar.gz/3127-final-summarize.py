import pathlib,json,gzip,collections,hashlib,statistics
out=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2')
def decode(pool):
 cache={}
 def slot(n):
  if n in cache:return cache[n]
  x=pool[n]
  if isinstance(x,str):cache[n]=x;return x
  z=[] if isinstance(x,list) else {} if isinstance(x,dict) else x;cache[n]=z
  def v(y):return slot(int(y)) if isinstance(y,str) and y.isdigit() else y
  if isinstance(x,list):z.extend(v(y) for y in x)
  elif isinstance(x,dict):z.update({k:v(y) for k,y in x.items()})
  return z
 return slot(0)
def tests(files):
 states=collections.Counter(); failures=[];skips=[];stale=[]
 def walk(t,prefix=''):
  full=(prefix+' > '+t.get('name','')).strip(' >')
  if t.get('type')=='test':
   state=(t.get('result')or{}).get('state',t.get('mode'));states[state]+=1
   if state=='fail':failures.append(full)
   if state=='skip':skips.append(full)
   if 'StaleSweepBackoff' in t.get('file',{}).get('name','') or 'forgets a refusal once its row leaves the stale window' in full:stale.append({'test':full,'state':state,'durationMs':(t.get('result')or{}).get('duration')})
  for c in t.get('tasks',[]):walk(c,full)
 for f in files:walk(f)
 return {'files':len(files),'testStates':dict(states),'failures':failures,'skips':skips,'targetRegression':stale}
records=[];covs={}
for n in (1,2):
 p=out/f'3127-final-2e7753c158-attempt-{n}';r=json.loads((p/'run.json').read_text()); legs={}
 for c in r['captures']:
  if c['file'].endswith('blobs_sqlite.json.gz')or c['file'].endswith('blobs_postgres.json.gz'):
   dialect='postgres' if 'postgres' in c['file'] else 'sqlite';d=decode(json.loads(gzip.decompress((p/c['file']).read_bytes()))); legs[dialect]=tests(d[1]);legs[dialect]['errors']=d[2]
  if n==2 and c['file'].endswith('coverage-final.json.gz'):
   dialect='postgres' if 'postgres' in c['file'] else 'sqlite';covs[dialect]=json.loads(gzip.decompress((p/c['file']).read_bytes()))
 (p/'leg-results.json').write_text(json.dumps(legs,indent=2)+'\n')
 samples=r['samples'];util=[]
 for a,b in zip(samples,samples[1:]):
  deltas={k:sum(y[k]-x[k] for x,y in zip(a['cpuTimes'],b['cpuTimes'])) for k in a['cpuTimes'][0]};total=sum(deltas.values());util.append(100*(total-deltas['idle'])/total if total else 0)
 host={'logicalCpuCount':r['cpus'],'samples':len(samples),'loadOneMin':{'min':min(x['load'][0] for x in samples),'max':max(x['load'][0] for x in samples)},'hostCpuBusyPercent':{'mean':statistics.mean(util),'max':max(util)},'canonicalDescendantsMax':max(len(x['descendants']) for x in samples),'observedOtherCpuPercentMax':max((y['cpu'] for x in samples for y in x['topOtherCpu']),default=0),'hostProcessCount':{'min':min(x['processCount'] for x in samples),'max':max(x['processCount'] for x in samples)},'syntheticLoad':False,'limit':'Genuine concurrent host workload; no saturated-host or portable performance claim. Percent uses aggregate OS CPU time deltas; process percent may exceed100 across cores.'}
 (p/'host-load-summary.json').write_text(json.dumps(host,indent=2)+'\n');records.append({'attempt':n,'exit':r['code'],'seconds':r['durationSeconds'],'sourceCount':r['sourceCount'],'sourceDrift':r['sourceDrift'],'legs':legs,'host':host,'retentionLimit':'PostgreSQL/merged raw files missed stock cleanup; actual unchanged strict100 canonical result retained' if n==1 else 'Both storage leg blobs and coverage retained; canonical stdout/stderr live output is capped by existing runner'})
merged={};maps=[]
for path in set(covs['sqlite'])|set(covs['postgres']):
 a=covs['sqlite'].get(path);b=covs['postgres'].get(path)
 if not a or not b:maps.append({'file':path,'error':'missing one leg'});continue
 if any(a[k]!=b[k] for k in ['statementMap','fnMap','branchMap']):maps.append({'file':path,'error':'map mismatch'});continue
 merged[path]={'s':{k:a['s'][k]+b['s'][k] for k in a['s']},'f':{k:a['f'][k]+b['f'][k] for k in a['f']},'b':{k:[x+y for x,y in zip(a['b'][k],b['b'][k])] for k in a['b']}}
coverage={}
for k in ['s','f','b']:
 values=[z for v in merged.values() for y in v[k].values() for z in (y if isinstance(y,list)else[y])];coverage[k]={'total':len(values),'covered':sum(x>0 for x in values),'percent':100*sum(x>0 for x in values)/len(values),'uncovered':len([x for x in values if not x])}
a=json.loads((out/'3127-final-2e7753c158-attempt-1/source-before.json').read_text())['hashes'];b=json.loads((out/'3127-final-2e7753c158-attempt-2/source-before.json').read_text())['hashes'];drift=[p for p in a.keys()|b.keys() if a.get(p)!=b.get(p)]
summary={'issue':3127,'canonicalAttempts':records,'betweenRunInputDrift':drift,'independentRawMergedCoverage':coverage,'coverageMapErrors':maps,'coverageLimit':'Independent identical-Istanbul-map summation from real leg artifacts, not relabeled as canonical merged artifact; both canonical exits0 prove unchanged configured100 lines/statements/branches/functions gate','noThirdRun':'Two predeclared attempts passed with identical captured inputs; no third required'}
(out/'3127-final-cohort-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
