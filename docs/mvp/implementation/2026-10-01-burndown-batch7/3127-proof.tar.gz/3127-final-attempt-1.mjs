import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import ts from '/private/tmp/smithers-burndown-20260930/packages/smithers/flows/engine-store/node_modules/typescript/lib/typescript.js';
const root='/private/tmp/smithers-burndown-20260930';
const receipt='/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2/3127-final-2e7753c158-attempt-1';
fs.mkdirSync(receipt,{recursive:true});
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const original=JSON.parse(fs.readFileSync('/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2/3325-canonical-source-before.json','utf8'));
const inputs=new Set(Object.keys(original.hashes).filter(p=>fs.existsSync(p)));
const configFile=path.join(root,'packages/smithers/flows/engine-store/tsconfig.test.json');
const read=ts.readConfigFile(configFile,ts.sys.readFile);
if(read.error) throw Error('Compiler configuration could not be read');
const config=ts.parseJsonConfigFileContent(read.config,ts.sys,path.dirname(configFile));
if(config.errors.length) throw Error('Compiler configuration errors');
const program=ts.createProgram(config.fileNames,config.options);
for(const f of program.getSourceFiles())if(fs.existsSync(f.fileName))inputs.add(path.resolve(f.fileName));
const walk=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(/\.(ts|mjs|json)$/.test(p))inputs.add(p);}};
for(const scope of ['packages/smithers/src','packages/repo-targets/src','packages/smithers/build/targets/src','packages/smithers/flows/engine-store/test','packages/smithers/flows/database/scripts'])if(fs.existsSync(path.join(root,scope)))walk(path.join(root,scope));
const snapshot=()=>Object.fromEntries([...inputs].sort().map(p=>[p,hash(p)]));
const before=snapshot();
fs.writeFileSync(path.join(receipt,'source-before.json'),JSON.stringify({head:spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim(),scope:'Fresh complete engine-store test compiler program plus prior canonical runtime/build inputs and current CLI/target sources; not an assertion that every workspace declaration is in this subset',compiler:ts.version,hashes:before},null,2)+'\n');
const args=['packages/smithers/src/bin.ts','test','//packages/smithers/flows/engine-store:test','--jobs','2','--no-cache','--verbose','--format','json'];
const env={...process.env,PATH:'/Users/williamcory/.nvm/versions/node/v26.5.0/bin:/Users/williamcory/.bun/bin:'+process.env.PATH,TMPDIR:'/private/tmp',SMITHERS_WORKSPACE_JJ_EXPORT_BINARY:'/Users/williamcory/smithers/target/release/smithers-jj-export',SMITHERS_TEST_PG_URL:'postgres://williamcory@127.0.0.1:55491/postgres?sslmode=disable',NO_COLOR:'1'};
for(const key of ['SMITHERS_CACHE_TOKEN','SMITHERS_CACHE_READ_TOKEN','SMITHERS_CACHE_WRITE_TOKEN'])delete env[key];
const files=['stdout.log','stderr.log'].map(p=>fs.openSync(path.join(receipt,p),'w'));
const start=Date.now();
const child=spawn(process.execPath,args,{cwd:root,env,stdio:['ignore',...files]});
const samples=[];const captures=new Map();const reportDirs=new Set();const coverageDirs=new Set();
const record={issue:3127,status:'running',args,head:spawnSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).stdout.trim(),node:process.version,nodeHash:hash(process.execPath),startedAt:new Date(start).toISOString(),pid:child.pid,cpus:os.cpus().length,syntheticLoad:false,declaredPostgres:'Existing credential-free PG55491 via canonical PACKAGE.ts env declaration; no initdb or new PG server',samples,captures:[],sourceCount:inputs.size,stockCoverageThresholds:'100 branches/functions/lines/statements; unchanged canonical matrix merge',outerBoundSeconds:1500};
const persist=()=>{record.captures=[...captures.values()];fs.writeFileSync(path.join(receipt,'run.json'),JSON.stringify(record,null,2)+'\n');};
function observe(){
 const raw=spawnSync('ps',['-A','-o','pid=,ppid=,pcpu=,comm='],{encoding:'utf8'}).stdout;
 const rows=raw.trim().split('\n').map(line=>{const match=line.trim().match(/^(\d+)\s+(\d+)\s+([\d.]+)\s+(.*)$/);return match?{pid:+match[1],ppid:+match[2],cpu:+match[3],command:match[4]}:undefined;}).filter(Boolean);
 const descendants=new Set([child.pid]);let changed=true;while(changed){changed=false;for(const row of rows)if(descendants.has(row.ppid)&&!descendants.has(row.pid)){descendants.add(row.pid);changed=true;}}
 const sample={time:new Date().toISOString(),load:os.loadavg(),cpuTimes:os.cpus().map(c=>c.times),processCount:rows.length,descendants:rows.filter(r=>descendants.has(r.pid)),topOtherCpu:rows.filter(r=>!descendants.has(r.pid)).sort((a,b)=>b.cpu-a.cpu).slice(0,10)};samples.push(sample);
 // Read only our descendant argv in memory; persist no arbitrary host argv/credentials.
 for(const pid of descendants){const cmd=spawnSync('ps',['-p',String(pid),'-o','args='],{encoding:'utf8'}).stdout;for(const m of cmd.matchAll(/\/private\/tmp\/smithers-sql-reports-[A-Za-z0-9_-]+/g))reportDirs.add(m[0]);if(cmd.includes('--merge-reports='))coverageDirs.add('/private/tmp/flows-engine-store-coverage-'+pid);}
 for(const dir of [...reportDirs,...coverageDirs]){
  if(!fs.existsSync(dir))continue;
  const pending=[dir];while(pending.length){const d=pending.pop();let entries;try{entries=fs.readdirSync(d,{withFileTypes:true});}catch{continue;}
   for(const e of entries){const p=path.join(d,e.name);if(e.isDirectory()){if(e.name!=='.tmp')pending.push(p);continue;}if(!['sqlite.json','postgres.json','coverage-final.json','coverage-summary.json'].includes(e.name))continue;
    try{const stat=fs.statSync(p);if(stat.size>60000000)continue;const bytes=fs.readFileSync(p);JSON.parse(bytes);const digest=createHash('sha256').update(bytes).digest('hex');if(captures.get(p)?.rawSha256===digest)continue;const name=path.basename(dir)+'-'+path.relative(dir,p).replaceAll('/','_')+'.gz';fs.writeFileSync(path.join(receipt,name),gzipSync(bytes));captures.set(p,{source:p,file:name,rawSha256:digest,compressedSha256:hash(path.join(receipt,name)),rawBytes:bytes.length,retainedAt:sample.time});}catch{}
   }
  }
 }
 persist();
}
const timer=setInterval(observe,2000);observe();const bound=setTimeout(()=>{record.outerBoundReached=true;child.kill('SIGTERM');},1500000);
const outcome=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',(code,signal)=>resolve({code,signal}));});
clearInterval(timer);clearTimeout(bound);files.forEach(fd=>fs.closeSync(fd));observe();
const after=snapshot();const drift=Object.keys(before).filter(p=>after[p]!==before[p]);fs.writeFileSync(path.join(receipt,'source-after.json'),JSON.stringify({hashes:after,drift},null,2)+'\n');
Object.assign(record,outcome,{durationSeconds:(Date.now()-start)/1000,finishedAt:new Date().toISOString(),sourceDrift:drift,status:outcome.code===0&&drift.length===0?'exit0-without-captured-input-drift':'FAILED: retained original gate outcome, no retry-to-green',reportsCleaned:[...reportDirs].map(directory=>({directory,exists:fs.existsSync(directory)})),stdoutSha256:hash(path.join(receipt,'stdout.log')),stderrSha256:hash(path.join(receipt,'stderr.log'))});persist();
console.log(JSON.stringify({receipt,status:record.status,code:record.code,durationSeconds:record.durationSeconds,capturedArtifacts:record.captures.length,sourceDrift:drift}));
