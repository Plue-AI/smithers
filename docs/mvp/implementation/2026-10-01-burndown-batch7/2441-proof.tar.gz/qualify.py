import pathlib,json,hashlib,subprocess,os,time,datetime
r=pathlib.Path('/private/tmp/smithers-burndown-20260930');o=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch5/redaction-2441');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=subprocess.check_output(['rg','--files','packages/backend'],cwd=r,text=True).splitlines();paths=sorted(p for p in paths if (r/p).is_file());env=dict(os.environ,PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+os.environ['PATH'],TMPDIR='/private/tmp',SMITHERS_TEST_DATABASE_URL='postgres://williamcory@127.0.0.1:55491/postgres?sslmode=disable',SMITHERS_REQUIRE_DATABASE_TESTS='1')
def cap():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(r/p) for p in paths}}
b=cap();(o/'canonical-inputs-before.json').write_text(json.dumps(b,indent=2)+'\n');checks=[('canonical-encrypted-claim-bash-pg','^TestNixCIStreamEncryptedMultilineSecretsReachOnlyRedactedReplay$'),('existing-independent-redaction-controls','TestInvokedFlow(LogRedact|ProjectionRedacts|Redaction|JournalAndFailureReachTheRunLog|RefusedBeforeStartLogsItsReason)|TestNixCIStream_|TestNixCILogLines_|TestRedactSecretValues_|TestWorkflowSandboxSchedulerWorker_RedactsSecretsInRunLogs')];results=[]
for name,pattern in checks:
 argv=['go','test','-count=1','-json','-timeout=3m','./internal/services','-run',pattern];log=o/(name+'.jsonl');s=time.monotonic()
 with log.open('w') as f:p=subprocess.run(argv,cwd=r/'packages/backend',env=env,stdout=f,stderr=subprocess.STDOUT)
 es=[]
 for l in log.read_text().splitlines():
  try:es.append(json.loads(l))
  except:pass
 d={'name':name,'argv':argv,'cwd':str(r/'packages/backend'),'exitCode':p.returncode,'seconds':round(time.monotonic()-s,2),'passed':[e['Test'] for e in es if e.get('Action')=='pass' and 'Test' in e],'failed':[e['Test'] for e in es if e.get('Action')=='fail' and 'Test' in e],'skipped':[e['Test'] for e in es if e.get('Action')=='skip' and 'Test' in e],'receipt':str(log),'sha256':sha(log)};(o/(name+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');results.append(d);print(json.dumps(d),flush=True)
 if p.returncode:break
a=cap();(o/'canonical-inputs-after.json').write_text(json.dumps(a,indent=2)+'\n');result={'issue':2441,'candidate':b['head'],'headAfter':a['head'],'checks':results,'changedDuringChecks':[p for p in paths if b['files'][p]!=a['files'][p]],'environment':{k:env[k] for k in ['PATH','TMPDIR','SMITHERS_TEST_DATABASE_URL','SMITHERS_REQUIRE_DATABASE_TESTS']},'sourceInputCount':len(paths)};(o/'canonical-result.json').write_text(json.dumps(result,indent=2)+'\n')
