import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
const root='/private/tmp/smithers-burndown-20260930';
const out='/tmp/smithers-burndown-20260930-receipts/api-batch5/main-reds-2742';
const old='/tmp/smithers-burndown-20260930-receipts/api-batch3/incremental-8820709eb8/retained-canonical-output/packages/smithers/dist/esm';
const {canonicalDeclaration}=await import(join(root,'scripts/check-api-baseline.mjs'));
const result=JSON.parse(readFileSync(join(out,'current-cli-declaration-result.json'),'utf8'));
const normalized=t=>canonicalDeclaration(t.replace(/\r\n/g,'\n').replace(/^\/\/# sourceMappingURL=.*$/gm,'').trim());
const h=t=>createHash('sha256').update(t).digest('hex');
const authenticated=[];
for(const d of result.differences){
 const fresh=readFileSync(join(out,'actual-cli-dist/esm',d.file),'utf8');
 writeFileSync(join(out,'current-'+d.file.replaceAll('/','-')),normalized(fresh));
 if(d.expected){
  const original=readFileSync(join(old,d.file),'utf8');const actual=h(normalized(original));
  if(actual!==d.expected)throw new Error(d.file+' old text mismatch '+actual+' != '+d.expected);
  writeFileSync(join(out,'authenticated-old-'+d.file.replaceAll('/','-')),normalized(original));
  authenticated.push({file:d.file,path:join(old,d.file),expected:d.expected,actual,authenticated:true});
 }else authenticated.push({file:d.file,newFile:true});
}
writeFileSync(join(out,'authenticated-old-dts.json'),JSON.stringify(authenticated,null,2)+'\n');
console.log(JSON.stringify(authenticated,null,2));
