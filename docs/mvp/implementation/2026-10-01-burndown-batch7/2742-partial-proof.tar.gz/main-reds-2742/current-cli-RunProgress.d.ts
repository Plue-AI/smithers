/**
 * Observational progress for attached durable runs. The same watch that waits
 * for settlement feeds a projection with bounded display labels; no second subscriber, polling,
 * journal write, or terminal rendering is involved in deciding run state.
 *
 * @since 1.0.0
 */
import * as Audience from "@smthrs/build-cli/Audience";
import type { ControlSchema } from "@smthrs/control";
import { Context, HashMap, HashSet, Stream } from "effect";
import type { Writable } from "node:stream";
/**
 * Invocation-scoped display settings, independent of document encoding.
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    readonly policy: Audience.Policy;
    readonly output?: Writable | undefined;
}
/**
 * The public CLI and compatibility entrypoint provide the same policy here.
 * Embedders can replace the stderr sink without changing process globals.
 *
 * @category services
 * @since 1.0.0
 */
export declare const Configuration: Context.Reference<Options | undefined>;
/**
 * Immutable run projection. Eight active labels are retained, plus compact
 * call lifecycle identities for exact replay deduplication; no event payloads
 * or task results are retained.
 *
 * @category models
 * @since 1.0.0
 */
export interface State {
    readonly turns: number;
    readonly started: number;
    readonly completed: number;
    readonly failed: number;
    readonly skipped: number;
    /** Skipped or deferred nodes that had been scheduled, so they no longer run. */
    readonly skippedStarted: number;
    readonly active: ReadonlyArray<string>;
    /** Identities aligned with the bounded active-label window. */
    readonly activeCallIds: ReadonlyArray<string | undefined>;
    /** A persistent set keeps incremental duplicate checks cheap and pure. */
    readonly reportedCalls: HashSet.HashSet<string>;
    /** Native facts can correct an earlier telemetry result without counting twice. */
    readonly nativeCalls: HashSet.HashSet<string>;
    readonly callFailures: HashMap.HashMap<string, boolean>;
    /** Engine actions scheduled and not yet settled, by execution and node. */
    readonly engineNodes: HashSet.HashSet<string>;
    /** Spawned executions already reported started, and those reported settled. */
    readonly executionsStarted: HashSet.HashSet<string>;
    readonly executionsSettled: HashSet.HashSet<string>;
    readonly status: string;
    readonly settled: boolean;
}
/**
 * One bounded, already-sanitized human log line.
 *
 * @category models
 * @since 1.0.0
 */
export interface Line {
    readonly level: "error" | "info" | "step" | "success" | "warn";
    readonly text: string;
}
/**
 * Initial projection for a newly attached run.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const initial: () => State;
/**
 * Sanitizes untrusted journal text before clipping it; terminal commands and
 * recognized credentials cannot survive in labels, logs, or failure text.
 *
 * @category rendering
 * @since 1.0.0
 */
export declare const text: (value: unknown, maximum?: number) => string;
/**
 * Projects only deliberate lifecycle/log fields, never arbitrary inputs,
 * generated code, model reasoning, or complete task result payloads.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const project: (state: State, event: ControlSchema.ControlEvent) => { readonly lines: ReadonlyArray<Line>; readonly state: State; };
/**
 * Started work that has not settled yet.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const running: (state: State) => number;
/**
 * A renderer's bounded lifetime. Closing it never cancels the durable run.
 *
 * @category models
 * @since 1.0.0
 */
export interface Renderer {
    readonly event: (event: ControlSchema.ControlEvent) => void;
    /**
     * `caught-up` is a read of the recorded events that stops at the newest one
     * without following the run.
     */
    readonly close: (reason: "caught-up" | "ended" | "failed" | "interrupted") => void;
}
/**
 * Clack owns the live indicator; plain human sessions receive stable lines,
 * and agent/silent sessions allocate no timer or terminal listener.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const make: (runId: string, options: Options) => Renderer;
/**
 * Taps the existing settlement stream and releases progress on success,
 * failure, or interruption. It never changes events or error semantics.
 *
 * @category combinators
 * @since 1.0.0
 */
export declare const observe: <E, R>(events: Stream.Stream<ControlSchema.ControlEvent, E, R>, runId: string, silent?: boolean) => Stream.Stream<ControlSchema.ControlEvent, E, R>;