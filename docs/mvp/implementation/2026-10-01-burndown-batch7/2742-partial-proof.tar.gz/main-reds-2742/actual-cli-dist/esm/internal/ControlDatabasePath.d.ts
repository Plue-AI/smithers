/**
 * Pure database location shared with the public NodeControl projection.
 * @since 1.0.0
 */
/**
 * Resolves the project's control.db without opening it.
 * @category constructors
 * @since 1.0.0
 */
export declare const databasePath: (root: string) => string;
