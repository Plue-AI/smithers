/**
 * The gateway's `Run.Fork` and `Run.Verify`, served by the host that owns the
 * project's stores over the same history library `smthrs runs fork` and
 * `smthrs runs verify` use, so every surface forks one way and reads one
 * report.
 *
 * @since 1.0.0
 */
import * as RunHistory from "@smthrs/gateway/RunHistory";
import { Layer } from "effect";
import * as History from "./History.ts";
import * as Verify from "./Verify.ts";
/**
 * How long a served verification may take to stop replaying. A person is
 * waiting on the answer through a relay, so it is shorter than the CLI's.
 *
 * @since 1.0.0
 * @category constants
 */
export declare const verifyWithin = "2 minutes";
/**
 * The history library the service calls: `smthrs runs fork` and
 * `smthrs runs verify`'s own entry points unless a test supplies others.
 *
 * @since 1.0.0
 * @category models
 */
export interface Ports {
    readonly mutate: typeof History.mutate;
    readonly verify: typeof Verify.verify;
}
/**
 * The history service over the project at `root`.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const make: (root: string, options?: Verify.Options, ports?: Ports) => RunHistory.Service;
/**
 * The history service over the project at `root`, as the layer `smthrs serve`
 * provides to its gateway.
 *
 * @since 1.0.0
 * @category layers
 */
export declare const layer: (root: string, options?: Verify.Options) => Layer.Layer<RunHistory.RunHistory>;
