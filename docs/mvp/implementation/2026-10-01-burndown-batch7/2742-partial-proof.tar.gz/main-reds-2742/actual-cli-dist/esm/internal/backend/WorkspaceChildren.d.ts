/**
 * `smthrs workspace children`: spawn, list and stop a workspace's children
 * (#2802). Outside a workspace it uses the signed-in account; inside one it
 * uses the workspace's own children credential, which reaches only these
 * routes of that workspace.
 * @since 1.0.0
 */
import type { Handler } from "./Resources.ts";
/** Where the control plane writes the workspace's identity and credential.
 * @private
 * @since 1.0.0
 */
export declare const guest: {
    config: string;
    token: string;
};
/** @private
 * @since 1.0.0
 */
export declare const workspaceChildren: Record<string, Handler>;
