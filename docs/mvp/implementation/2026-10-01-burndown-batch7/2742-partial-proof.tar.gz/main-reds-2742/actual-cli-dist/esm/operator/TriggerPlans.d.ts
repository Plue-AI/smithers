/**
 * Durable trigger launch handles that retain the exact plan awaiting approval.
 *
 * @since 1.0.0
 */
import * as Control from "@smthrs/control/Control";
import * as Scheduler from "@smthrs/triggers/Scheduler";
import { TriggerError } from "@smthrs/triggers/TriggerError";
import { Layer, Schema } from "effect";
declare const stored: Schema.Struct<{
    readonly handle: Schema.String;
    readonly idempotencyKey: Schema.String;
    readonly plan: Schema.Struct<{
        readonly planId: Schema.String;
        readonly flowId: Schema.String;
        readonly digest: Schema.String;
        readonly inputSummary: Schema.String;
        readonly envelope: Schema.Struct<{
            readonly capabilities: Schema.$Array<Schema.String>;
            readonly hostImports: Schema.optional<Schema.$Array<Schema.String>>;
            readonly flows: Schema.$Array<Schema.String>;
            readonly budget: Schema.Struct<{
                readonly tokens: Schema.optional<Schema.Number>;
                readonly milliseconds: Schema.optional<Schema.Number>;
                readonly usd: Schema.optional<Schema.Number>;
                readonly onExceeded: Schema.optional<Schema.Literals<readonly ["fail", "warn", "skip-remaining", "park"]>>;
                readonly deadline: Schema.optional<Schema.Int>;
            }>;
            readonly host: Schema.optional<Schema.String>;
        }>;
        readonly deployClass: Schema.Boolean;
        readonly executionDigest: Schema.optional<Schema.String>;
        readonly plan: Schema.optional<Schema.Struct<{
            readonly planId: Schema.NonEmptyString;
            readonly flow: Schema.NonEmptyString;
            readonly generation: Schema.Int;
            readonly baseDigest: Schema.brand<Schema.String, "@smthrs/keys/Key">;
            readonly digest: Schema.brand<Schema.String, "@smthrs/keys/Key">;
            readonly nodes: Schema.$Array<Schema.Struct<{
                readonly id: Schema.NonEmptyString;
                readonly kind: Schema.Literals<readonly ["step", "agent", "merge"]>;
                readonly key: Schema.brand<Schema.String, "@smthrs/keys/Key">;
                readonly material: Schema.Struct<{
                    readonly version: Schema.Literal<"flows/key-material/v2">;
                    readonly kind: Schema.Literals<readonly ["sealed", "compensable", "irreversible"]>;
                    readonly nondeterministic: Schema.optional<Schema.Literal<true>>;
                    readonly body: Schema.Unknown;
                    readonly inputs: Schema.$Array<Schema.Union<readonly [Schema.TaggedStruct<"Literal", {
                        readonly value: Schema.Unknown;
                    }>, Schema.TaggedStruct<"Ref", {
                        readonly from: Schema.NonEmptyString;
                        readonly path: Schema.$Array<Schema.String>;
                    }>, Schema.TaggedStruct<"Pending", {
                        readonly from: Schema.NonEmptyString;
                    }>]>>;
                    readonly layers: Schema.$Array<Schema.String>;
                    readonly capabilities: Schema.$Array<Schema.String>;
                    readonly effects: Schema.optional<Schema.Unknown>;
                    readonly placement: Schema.optional<Schema.Unknown>;
                }>;
                readonly effects: Schema.Struct<{
                    readonly reads: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                        readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                        readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                    }>]>, Schema.TaggedStruct<"Filegroup", {
                        readonly name: Schema.NonEmptyString;
                        readonly entries: Schema.$Array<Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                            readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                            readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                        }>]>>;
                    }>]>>;
                    readonly writes: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                        readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                        readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                    }>, Schema.TaggedStruct<"TreeArtifact", {
                        readonly path: Schema.NonEmptyString;
                    }>]>, Schema.TaggedStruct<"Filegroup", {
                        readonly name: Schema.NonEmptyString;
                        readonly entries: Schema.$Array<Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                            readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                            readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                        }>, Schema.TaggedStruct<"TreeArtifact", {
                            readonly path: Schema.NonEmptyString;
                        }>]>>;
                    }>]>>;
                    readonly removes: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                    readonly boundaryMode: Schema.Literals<readonly ["hard", "expected"]>;
                }>;
                readonly dependsOn: Schema.$Array<Schema.NonEmptyString>;
                readonly conflicts: Schema.$Array<Schema.Struct<{
                    readonly with: Schema.NonEmptyString;
                    readonly paths: Schema.$Array<Schema.String>;
                    readonly strategy: Schema.Literals<readonly ["serialize", "lane", "fail"]>;
                    readonly runtime: Schema.Literals<readonly ["delay-rebase", "stop-merge"]>;
                }>>;
                readonly strategy: Schema.Literals<readonly ["serialize", "lane", "fail"]>;
                readonly runtime: Schema.Literals<readonly ["delay-rebase", "stop-merge"]>;
                readonly priority: Schema.Int;
                readonly generation: Schema.Int;
            }>>;
        }>>;
        readonly nodes: Schema.$Array<Schema.Struct<{
            readonly status: Schema.Literals<readonly ["cached", "run"]>;
            readonly id: Schema.NonEmptyString;
            readonly kind: Schema.Literals<readonly ["step", "agent", "merge"]>;
            readonly key: Schema.brand<Schema.String, "@smthrs/keys/Key">;
            readonly material: Schema.Struct<{
                readonly version: Schema.Literal<"flows/key-material/v2">;
                readonly kind: Schema.Literals<readonly ["sealed", "compensable", "irreversible"]>;
                readonly nondeterministic: Schema.optional<Schema.Literal<true>>;
                readonly body: Schema.Unknown;
                readonly inputs: Schema.$Array<Schema.Union<readonly [Schema.TaggedStruct<"Literal", {
                    readonly value: Schema.Unknown;
                }>, Schema.TaggedStruct<"Ref", {
                    readonly from: Schema.NonEmptyString;
                    readonly path: Schema.$Array<Schema.String>;
                }>, Schema.TaggedStruct<"Pending", {
                    readonly from: Schema.NonEmptyString;
                }>]>>;
                readonly layers: Schema.$Array<Schema.String>;
                readonly capabilities: Schema.$Array<Schema.String>;
                readonly effects: Schema.optional<Schema.Unknown>;
                readonly placement: Schema.optional<Schema.Unknown>;
            }>;
            readonly effects: Schema.Struct<{
                readonly reads: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                    readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                    readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                }>]>, Schema.TaggedStruct<"Filegroup", {
                    readonly name: Schema.NonEmptyString;
                    readonly entries: Schema.$Array<Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                        readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                        readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                    }>]>>;
                }>]>>;
                readonly writes: Schema.$Array<Schema.Union<readonly [Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                    readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                    readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                }>, Schema.TaggedStruct<"TreeArtifact", {
                    readonly path: Schema.NonEmptyString;
                }>]>, Schema.TaggedStruct<"Filegroup", {
                    readonly name: Schema.NonEmptyString;
                    readonly entries: Schema.$Array<Schema.Union<readonly [Schema.NonEmptyString, Schema.TaggedStruct<"Glob", {
                        readonly include: Schema.NonEmptyArray<Schema.NonEmptyString>;
                        readonly exclude: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                    }>, Schema.TaggedStruct<"TreeArtifact", {
                        readonly path: Schema.NonEmptyString;
                    }>]>>;
                }>]>>;
                readonly removes: Schema.optional<Schema.$Array<Schema.NonEmptyString>>;
                readonly boundaryMode: Schema.Literals<readonly ["hard", "expected"]>;
            }>;
            readonly dependsOn: Schema.$Array<Schema.NonEmptyString>;
            readonly conflicts: Schema.$Array<Schema.Struct<{
                readonly with: Schema.NonEmptyString;
                readonly paths: Schema.$Array<Schema.String>;
                readonly strategy: Schema.Literals<readonly ["serialize", "lane", "fail"]>;
                readonly runtime: Schema.Literals<readonly ["delay-rebase", "stop-merge"]>;
            }>>;
            readonly strategy: Schema.Literals<readonly ["serialize", "lane", "fail"]>;
            readonly runtime: Schema.Literals<readonly ["delay-rebase", "stop-merge"]>;
            readonly priority: Schema.Int;
            readonly generation: Schema.Int;
        }>>;
        readonly graph: Schema.optional<Schema.Struct<{
            readonly edges: Schema.$Array<Schema.Struct<{
                readonly from: Schema.NonEmptyString;
                readonly to: Schema.NonEmptyString;
                readonly reason: Schema.Literals<readonly ["value", "continuation", "failure", "conflict", "lane-merge"]>;
            }>>;
            readonly nodes: Schema.optional<Schema.$Array<Schema.Struct<{
                readonly id: Schema.NonEmptyString;
                readonly declaredAt: Schema.optionalKey<Schema.Struct<{
                    readonly path: Schema.NonEmptyString;
                    readonly line: Schema.Int;
                }>>;
            }>>>;
            readonly sourceRevision: Schema.optional<Schema.NonEmptyString>;
        }>>;
        readonly approval: Schema.Struct<{
            readonly target: Schema.Union<readonly [Schema.TaggedStruct<"Plan", {
                readonly planId: Schema.String;
                readonly digest: Schema.String;
                readonly envelope: Schema.Struct<{
                    readonly capabilities: Schema.$Array<Schema.String>;
                    readonly hostImports: Schema.optional<Schema.$Array<Schema.String>>;
                    readonly flows: Schema.$Array<Schema.String>;
                    readonly budget: Schema.Struct<{
                        readonly tokens: Schema.optional<Schema.Number>;
                        readonly milliseconds: Schema.optional<Schema.Number>;
                        readonly usd: Schema.optional<Schema.Number>;
                        readonly onExceeded: Schema.optional<Schema.Literals<readonly ["fail", "warn", "skip-remaining", "park"]>>;
                        readonly deadline: Schema.optional<Schema.Int>;
                    }>;
                    readonly host: Schema.optional<Schema.String>;
                }>;
            }>, Schema.TaggedStruct<"Node", {
                readonly runId: Schema.String;
                readonly requestId: Schema.String;
                readonly digest: Schema.String;
                readonly envelope: Schema.Struct<{
                    readonly capabilities: Schema.$Array<Schema.String>;
                    readonly hostImports: Schema.optional<Schema.$Array<Schema.String>>;
                    readonly flows: Schema.$Array<Schema.String>;
                    readonly budget: Schema.Struct<{
                        readonly tokens: Schema.optional<Schema.Number>;
                        readonly milliseconds: Schema.optional<Schema.Number>;
                        readonly usd: Schema.optional<Schema.Number>;
                        readonly onExceeded: Schema.optional<Schema.Literals<readonly ["fail", "warn", "skip-remaining", "park"]>>;
                        readonly deadline: Schema.optional<Schema.Int>;
                    }>;
                    readonly host: Schema.optional<Schema.String>;
                }>;
            }>]>;
            readonly scope: Schema.Literals<readonly ["once", "run", "remembered"]>;
            readonly idempotencyKey: Schema.String;
        }>;
    }>;
    readonly status: Schema.Literals<readonly ["waiting-approval", "launching", "running", "cancelling", "completed", "cancelled", "failed"]>;
    readonly runId: Schema.NullOr<Schema.String>;
    readonly error: Schema.NullOr<Schema.String>;
}>;
/**
 * The original approval card and eventual Control run behind a scheduler handle.
 * @category models
 * @since 1.0.0
 */
export type StoredPlan = typeof stored.Type;
/**
 * Reads the unchanged approval payload and launch state for a scheduler handle.
 * @category queries
 * @since 1.0.0
 */
export declare const inspect: (root: string, handle: string) => Promise<StoredPlan | null>;
/**
 * Provides recoverable scheduled launches without approving or timing out a plan.
 *
 * The stable handle is recorded as the trigger's active run. Its monitor can
 * restart in another process, re-offer the persisted card, and attach the real
 * run only after Control accepts it. Control's durable plan and run keys close
 * the crash gaps on either side of this adapter's own writes.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layer: (root: string) => Layer.Layer<Scheduler.Runner, import("effect/PlatformError").PlatformError | import("effect/unstable/sql/SqlError").SqlError | import("effect/unstable/sql/Migrator").MigrationError | TriggerError, Control.Control>;
export {};
