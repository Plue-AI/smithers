/**
 * `smthrs bug`: a report an operator can send without pasting their secrets
 * into a browser.
 *
 * The value of the command is that it collects the context a maintainer always
 * asks for: versions, platform, and optionally the named run and its event
 * digest. A report is a diagnostic that leaves the machine, so the collected
 * value takes the shared diagnostic redaction rules before it does.
 *
 * @since 1.0.0
 */
/**
 * Where reports are posted when the environment names no other endpoint.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const defaultEndpoint = "https://bug.smithers.sh/api/bugs";
/**
 * Redacts secret-looking material inside free text.
 *
 * Reach for this when report prose must take the diagnostic rule set
 * (`Redaction.redactDiagnostic`). It is total for strings and returns the
 * shared journal markers for matched text.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const scrubText: (text: string) => string;
/**
 * Recursively scrubs a JSON-safe value with the diagnostic rules and the retained
 * report-only `dsn` and `connection` key coverage. It refuses accessors,
 * executable `toJSON` hooks, excessive depth, and excessive walk size before
 * redaction so no partial report can be posted.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const scrub: (value: unknown) => unknown;
/**
 * The report body.
 *
 * @category models
 * @since 1.0.0
 */
export interface Report {
    readonly summary: string;
    readonly version: string;
    readonly platform: string;
    readonly node: string;
    readonly runs: unknown;
    readonly digest?: unknown;
}
/**
 * Assembles a scrubbed report for the bug endpoint. It throws before returning
 * when the value cannot be walked safely within the journal's bounds, which
 * prevents the caller from posting a partially inspected body.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const report: (input: Report) => Report;
/**
 * How long the post is allowed to take before the command gives up.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const timeoutMs = 15000;
