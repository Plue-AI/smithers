/**
 * Persistent history reads and mutation/control reconciliation.
 * @since 1.0.0
 */
import type { Entry } from "@smthrs/journal/JournalEvent";
import type { StepOverride } from "@smthrs/time-travel/TimeTravelStore";
import { type Schema } from "effect";
import type * as NativeControl from "../internal/NativeControl.ts";
/**
 * Local history address and resource limits.
 * @since 1.0.0
 * @category models
 */
export interface Options {
    readonly root?: string | undefined;
    readonly remote?: string | undefined;
    readonly sequence?: number | undefined;
    readonly lineage?: string | undefined;
    readonly limit?: number | undefined;
    /** Rewind only: restore the frame's jj operation instead of only its tree. */
    readonly wholeRepo?: boolean | undefined;
    /** Fork only: the step result the child replays in place of the parent's. */
    readonly override?: StepOverride | undefined;
    /**
     * Fork only: the root input the child runs with in place of the parent's.
     * It is planned and approved as a plan of its own, which the child is bound
     * to; every recorded step whose key it leaves unchanged still replays.
     */
    readonly input?: Schema.Json | undefined;
    /** The flow modules a host would load, for planning an edited input; tests supply them. */
    readonly modules?: NativeControl.ModuleRegistration | undefined;
}
/**
 * Resolve local history using the CLI's project and environment rules.
 * @since 1.0.0
 * @category constructors
 */
export { localRoot } from "../Project.ts";
/**
 * Reads the stored prefix without executing effects or startup recovery.
 * @since 1.0.0
 * @category constructors
 */
export declare const read: (root: string, runId: string, options: Options, replay: boolean, signal?: AbortSignal) => Promise<{
    events: readonly Entry[] | undefined;
    entryCount: number;
    eventTypes: Readonly<Record<string, number>>;
    state?: unknown;
    sealed: ReadonlyArray<{
        seq: number;
        result: unknown;
    }>;
    position: {
        runId: string;
        frame: {
            lineageId: string;
            seq: number;
        };
    };
    executionFlow: string | undefined;
    status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
    parentRunId: string | null;
}>;
/**
 * Lists exactly the suffix/effects a rewind would cross; never mutates it.
 * @since 1.0.0
 * @category constructors
 */
export declare const preview: (root: string, runId: string, options: Options, signal?: AbortSignal) => Promise<{
    preview: boolean;
    position: {
        runId: string;
        frame: {
            lineageId: string;
            seq: number;
        };
    };
    status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
    entriesToArchive: number;
    effects: readonly {
        readonly runId: string;
        readonly seq: number;
        readonly kind: string;
        readonly lineageId: string;
        readonly tier: "sealed" | "compensable" | "irreversible";
        readonly id: string;
        readonly status: "succeeded" | "unknown" | "intended";
        readonly durableBoundary: boolean;
        readonly providerStream: boolean;
        readonly attempt?: number;
        readonly input?: unknown;
        readonly nonce?: string;
        readonly idempotencyKey?: string;
        readonly output?: unknown;
        readonly cacheKey?: string;
        readonly changeId?: string;
        readonly compensation?: string;
        readonly residue?: string;
    }[];
    blockedEffects: {
        readonly runId: string;
        readonly seq: number;
        readonly kind: string;
        readonly lineageId: string;
        readonly tier: "sealed" | "compensable" | "irreversible";
        readonly id: string;
        readonly status: "succeeded" | "unknown" | "intended";
        readonly durableBoundary: boolean;
        readonly providerStream: boolean;
        readonly attempt?: number;
        readonly input?: unknown;
        readonly nonce?: string;
        readonly idempotencyKey?: string;
        readonly output?: unknown;
        readonly cacheKey?: string;
        readonly changeId?: string;
        readonly compensation?: string;
        readonly residue?: string;
    }[];
    active: boolean;
    requiresConfirmation: boolean;
}>;
/** Repairs committed engine history and its durable control projection.
 *
 * The stores are scanned read-only first; a writable connection, and the
 * control migrations it runs, are opened only when a gap is pending.
 * @category constructors
 * @since 1.0.0
 */
export declare const reconcile: (root: string) => Promise<void>;
/** Fork or rewind a run and reconcile its durable control identity.
 * @category constructors
 * @since 1.0.0
 */
export declare const mutate: (root: string, runId: string, options: Options, operation: "fork" | "rewind", signal?: AbortSignal) => Promise<{
    workspace: string;
    status: string;
    next: string;
    warnings: ReadonlyArray<string>;
    runId: string;
    edge: {
        readonly parentRunId: string;
        readonly parentSeq: number;
        readonly childRunId: string;
        readonly kind: "child" | "fork" | "continuation";
        readonly attached: boolean;
    };
} | {
    runId: string;
    status: string;
    next: string;
    auditId: string;
    frame: {
        readonly lineageId: string;
        readonly seq: number;
    };
    archive: {
        readonly archived: number;
        readonly orphaned: readonly {
            readonly parentRunId: string;
            readonly parentSeq: number;
            readonly childRunId: string;
            readonly kind: "child" | "fork" | "continuation";
            readonly attached: boolean;
        }[];
    };
    assessments: readonly {
        readonly effect: {
            readonly runId: string;
            readonly seq: number;
            readonly kind: string;
            readonly lineageId: string;
            readonly tier: "sealed" | "compensable" | "irreversible";
            readonly id: string;
            readonly status: "succeeded" | "unknown" | "intended";
            readonly durableBoundary: boolean;
            readonly providerStream: boolean;
            readonly attempt?: number;
            readonly input?: unknown;
            readonly nonce?: string;
            readonly idempotencyKey?: string;
            readonly output?: unknown;
            readonly cacheKey?: string;
            readonly changeId?: string;
            readonly compensation?: string;
            readonly residue?: string;
        };
        readonly classification: "warning" | "revertible" | "blocking";
        readonly reason: string;
        readonly residue: string;
    }[];
    warnings: readonly {
        readonly childRunId: string;
        readonly parentSeq: number;
        readonly reason: string;
    }[];
    cancelledChildren: readonly string[];
}>;
/** Resolves a committed workspace before resuming execution.
 * @category constructors
 * @since 1.0.0
 */
export declare const prepare: (root: string, runId: string) => Promise<{
    readonly executionRoot: string;
}>;
