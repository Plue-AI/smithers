#!/usr/bin/env node
/**
 * Public process entry; bootstrap shared declaration identities before loading commands.
 * @since 1.0.0
 */
export {};
