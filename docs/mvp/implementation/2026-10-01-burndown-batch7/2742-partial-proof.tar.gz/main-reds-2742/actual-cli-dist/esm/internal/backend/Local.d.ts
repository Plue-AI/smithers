/**
 * Local jj operations and landing requests, with backend merge gates intact.
 * @since 0.1.0
 */
import { type Client } from "./Client.ts";
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const lines: (text: string) => Array<string>;
/**
 * @private
 * @since 1.0.0
 */
export declare const revision: (c: Client, rev: string) => Promise<{
    change_id: string;
    commit_id: string | undefined;
    description: string;
}>;
/**
 * @private
 * @since 1.0.0
 */
export declare const stackChanges: (c: Client, target: string) => Promise<{
    change_id: string;
    commit_id: string;
    description: string;
}[]>;
/**
 * @private
 * @since 1.0.0
 */
export declare const local: Record<string, Handler>;
