/**
 * The featured flows a project declares, read from the `flows` rows of its
 * generated `.smithers/factory.json` and folded into the `ls` listing, and
 * the apps its generated `.smithers/home.json` declares (PRODUCT.md D-18: an
 * app is a featured flow with a picture), listed after the flows.
 *
 * The projection is what `//:factoryProjection` writes from the
 * `.smithers/FACTORY.ts` declarations over the discovered flows. `ls` never
 * evaluates `FACTORY.ts`; it reads the file when it is checked in and lists
 * the flows unchanged when it is not. An unreadable or malformed projection
 * is treated as absent here: `doctor` owns diagnostics, and a listing that
 * refused to print because a generated file drifted would hide the flows
 * behind the drift.
 *
 * @since 1.0.0
 */
import type * as FlowCatalog from "@smthrs/targets/FlowCatalog";
/**
 * The catalog a projection carries: its `flows` rows.
 *
 * @category models
 * @since 1.0.0
 */
export interface Catalog {
    readonly flows: ReadonlyArray<FlowCatalog.Row>;
}
/**
 * One app the homepage declares: the flow it opens, its title, its picture.
 *
 * @category models
 * @since 1.0.0
 */
export interface App {
    readonly flow: string;
    readonly title: string;
    readonly picture: string;
}
/**
 * Reads the project's projected homepage apps, or none when the project has
 * no `.smithers/home.json` or it does not parse.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const apps: (projectRoot: string) => ReadonlyArray<App>;
/**
 * One listed flow, with the presentation the catalog declares when it does.
 *
 * `featured` and `summary` are present only when the catalog says so, so a
 * project without a catalog lists exactly what it listed before.
 *
 * @category models
 * @since 1.0.0
 */
export interface Presented {
    readonly flowId: string;
    readonly description: string;
    readonly featured?: true;
    readonly summary?: string;
}
/**
 * Reads the project's projected catalog, or nothing when the project has
 * no `.smithers/factory.json`.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const read: (projectRoot: string) => Catalog | undefined;
/**
 * Folds the catalog's presentation into the listed flows: featured flows
 * first, in catalog order, each carrying `featured` and its summary; then
 * every other flow in listing order, with a summary where the catalog
 * declares one. A catalog row naming no listed flow contributes nothing.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const present: (items: ReadonlyArray<{
    readonly flowId: string;
    readonly description: string;
}>, catalog: Catalog | undefined) => ReadonlyArray<Presented>;
/**
 * Whether a rendered value is a flow page this module can present.
 *
 * @category guards
 * @since 1.0.0
 */
export declare const isFlowPage: (value: unknown) => value is {
    readonly _tag: "flows";
    readonly items: ReadonlyArray<Presented>;
};
/**
 * The apps a rendered listing carries, when it carries any.
 *
 * @category guards
 * @since 1.0.0
 */
export declare const appsOf: (value: unknown) => ReadonlyArray<App>;
/**
 * The human listing: one line per flow, a leading `*` on featured rows, the
 * id, then the declared summary or the flow's own description; then the
 * homepage's apps, one line each, when the project declares any.
 *
 * @category rendering
 * @since 1.0.0
 */
export declare const human: (items: ReadonlyArray<Presented>, apps?: ReadonlyArray<App>) => string;
