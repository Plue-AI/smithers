/**
 * Durable approvals for build targets that declare `approval: "required"`.
 *
 * An approval is an ordinary control-plane plan approval: the reserved
 * `system/target` plan whose input names the target and the revision digest
 * the build planner computed. The build planner asks the project's control
 * database before such a target runs; granting goes through `Control.approve`,
 * so the host's approval authority, principal attribution and idempotency
 * apply unchanged.
 *
 * @since 1.0.0
 */
import type { TargetApprovalRequest, TargetApprovals } from "@smthrs/build-cli/PackageExec";
import { Control, type ControlSchema } from "@smthrs/control";
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
/**
 * The reserved flow a target approval is planned against.
 * @category constants
 * @since 1.0.0
 */
export declare const flowId = "system/target";
/**
 * The plan request that names one target revision. The same request plans the
 * pending approval, grants it and checks it, so all three address one plan.
 * @category constructors
 * @since 1.0.0
 */
export declare const planInput: (request: Pick<TargetApprovalRequest, "label" | "digest">) => Control.PlanInput;
/**
 * Whether the control database under `root` records an approval of exactly
 * this revision. An unapproved revision is left as a pending plan the operator
 * can approve; a store that cannot be read rejects instead of answering.
 * @category constructors
 * @since 1.0.0
 */
export declare const decision: (request: TargetApprovalRequest) => Effect.Effect<"pending" | "approved" | "denied", import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").PersistenceError, never>;
/**
 * The approval store the unified CLI hands the build planner.
 * @category constructors
 * @since 1.0.0
 */
export declare const store: TargetApprovals;
/**
 * Approves one target revision through the control plane.
 * @category constructors
 * @since 1.0.0
 */
export declare const grant: (request: Pick<TargetApprovalRequest, "label" | "digest">) => Effect.Effect<{
    label: string;
    revision: string;
    planId: string;
    receipt: "Accepted" | "AlreadyApplied" | "Parked" | "Conflict" | "Terminal";
}, import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError, Control.Control>;
/**
 * One target revision waiting for an operator: the target's label, the
 * revision digest, and the exact payload `approvals approve` or
 * `approvals deny` takes.
 * @category models
 * @since 1.0.0
 */
export interface PendingTarget {
    readonly target: string;
    readonly revision: string;
    readonly approval: ControlSchema.ApprovalPayload;
}
/**
 * Every target revision the control plane holds pending, oldest first, read
 * through `Control.list` so a local store and a remote control plane answer
 * alike.
 * @category constructors
 * @since 1.0.0
 */
export declare const pending: Effect.Effect<PendingTarget[], CliError.Refused | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, Control.Control>;
/**
 * Approves a pending revision of `target` found through the control plane,
 * without the workspace: how a remote operator grants what a remote build
 * refused. `revision` picks one when several revisions of the target wait.
 * @category constructors
 * @since 1.0.0
 */
export declare const grantPending: (target: string, revision?: string | undefined) => Effect.Effect<{
    label: string;
    revision: string;
    planId: string;
    receipt: "Accepted" | "AlreadyApplied" | "Parked" | "Conflict" | "Terminal";
}, CliError.UsageError | CliError.Refused | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, Control.Control>;
