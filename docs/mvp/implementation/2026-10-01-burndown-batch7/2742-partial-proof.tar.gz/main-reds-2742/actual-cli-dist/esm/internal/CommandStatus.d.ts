/**
 * Per-invocation command status, shared by the CLI and its MCP host.
 *
 * @since 1.0.0
 */
import { Context, Effect } from "effect";
/**
 * Sink for a command's process-style exit status.
 * @category services
 * @since 1.0.0
 */
export declare const CommandStatus: Context.Reference<(code: number) => void>;
/**
 * Records a command status through the current sink.
 * @category constructors
 * @since 1.0.0
 */
export declare const set: (code: number) => Effect.Effect<void>;
