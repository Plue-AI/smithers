/**
 * One run's history and summary, read from the control plane for a verb.
 *
 * @since 1.0.0
 */
import type { Control as ControlService } from "@smthrs/control";
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
/**
 * Every event of one run, oldest first.
 * @category getters
 * @since 1.0.0
 */
export declare const events: (control: ControlService.Service, runId: string) => Effect.Effect<readonly {
    readonly payload: import("effect/Schema").Json;
    readonly kind: string;
    readonly sequence: number;
    readonly occurredAt: number;
    readonly runId?: string | undefined;
    readonly cursor?: {
        readonly sequence: number;
        readonly offset?: number | undefined;
    } | undefined;
}[], CliError.ResourceLimitError | import("@smthrs/control/ControlError").TransportError, never>;
/**
 * One run's summary, or undefined when the control plane has no such run.
 * @category getters
 * @since 1.0.0
 */
export declare const summary: (control: ControlService.Service, runId: string) => Effect.Effect<{
    readonly runId: string;
    readonly status: "failed" | "running" | "completed" | "cancelled" | "accepted" | "parked" | "waiting-approval";
    readonly flowId: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly lineageId?: string | undefined;
    readonly parentRunId?: string | undefined;
    readonly planId?: string | undefined;
    readonly roundOrdinal?: number | undefined;
    readonly origin?: "child" | "fork" | "continuation" | undefined;
    readonly executionDigest?: string | undefined;
    readonly executionObservation?: "missing" | "observed" | undefined;
    readonly executionView?: {
        readonly root: {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        };
        readonly current: {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        };
        readonly humanWaits?: readonly {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        }[] | undefined;
    } | undefined;
    readonly planDigest?: string | undefined;
    readonly engineVersion?: string | undefined;
    readonly codeDrift?: {
        readonly current?: string | undefined;
        readonly recorded?: string | undefined;
        readonly recordedEngine?: string | undefined;
        readonly currentEngine?: string | undefined;
    } | undefined;
    readonly ownerId?: string | undefined;
    readonly launchedBy?: {
        readonly id: string;
        readonly kind: string;
    } | undefined;
    readonly waitingReason?: string | undefined;
    readonly steering?: {
        readonly pending: number;
    } | undefined;
    readonly pendingResume?: number | undefined;
    readonly parkedBy?: string | undefined;
    readonly cancellation?: {
        readonly source: "control" | "engine" | "cascade";
        readonly requestedAt: number;
        readonly reason?: string | undefined;
        readonly principal?: {
            readonly id: string;
            readonly kind: string;
            readonly stampedAt: number;
        } | undefined;
        readonly cascadedFrom?: string | undefined;
    } | undefined;
    readonly pendingWaits?: readonly {
        readonly token: string;
        readonly reason: string;
        readonly runId: string;
        readonly createdAt: number;
        readonly name?: string | undefined;
        readonly attempt?: number | undefined;
        readonly tokenDigest?: string | undefined;
        readonly request?: import("effect/Schema").Json | undefined;
        readonly flowId?: string | undefined;
    }[] | undefined;
    readonly deadlineAt?: number | undefined;
} | undefined, import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, never>;
/**
 * The usage error a verb reports for a run id the control plane does not hold.
 * @category constructors
 * @since 1.0.0
 */
export declare const missing: (runId: string) => CliError.UsageError;
/**
 * One run's summary, failing before a reader projects an empty history.
 * @category getters
 * @since 1.0.0
 */
export declare const existing: (control: ControlService.Service, runId: string) => Effect.Effect<{
    readonly runId: string;
    readonly status: "failed" | "running" | "completed" | "cancelled" | "accepted" | "parked" | "waiting-approval";
    readonly flowId: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly lineageId?: string | undefined;
    readonly parentRunId?: string | undefined;
    readonly planId?: string | undefined;
    readonly roundOrdinal?: number | undefined;
    readonly origin?: "child" | "fork" | "continuation" | undefined;
    readonly executionDigest?: string | undefined;
    readonly executionObservation?: "missing" | "observed" | undefined;
    readonly executionView?: {
        readonly root: {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        };
        readonly current: {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        };
        readonly humanWaits?: readonly {
            readonly lineageId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly parentRunId: (string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">) | null;
            readonly finishedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly startedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly executionId: string & import("effect/Brand").Brand<"@smthrs/journal/JournalEvent/RunId">;
            readonly status: "failed" | "running" | "suspended" | "completed" | "pending" | "cancelled";
            readonly cancelRequestedAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
            readonly waiting: {
                readonly reason: string;
                readonly wakeAtMs: (number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">) | null;
                readonly tokenDigest: string | null;
                readonly point?: string | null | undefined;
                readonly request?: import("effect/Schema").Json | undefined;
            } | null;
            readonly flowName: string;
            readonly createdAtMs: number & import("effect/Brand").Brand<"@smthrs/journal/TimestampMs">;
            readonly roundOrdinal: number;
            readonly treeVersion?: 1 | undefined;
            readonly parentPolicy?: "cancel" | "detach" | undefined;
        }[] | undefined;
    } | undefined;
    readonly planDigest?: string | undefined;
    readonly engineVersion?: string | undefined;
    readonly codeDrift?: {
        readonly current?: string | undefined;
        readonly recorded?: string | undefined;
        readonly recordedEngine?: string | undefined;
        readonly currentEngine?: string | undefined;
    } | undefined;
    readonly ownerId?: string | undefined;
    readonly launchedBy?: {
        readonly id: string;
        readonly kind: string;
    } | undefined;
    readonly waitingReason?: string | undefined;
    readonly steering?: {
        readonly pending: number;
    } | undefined;
    readonly pendingResume?: number | undefined;
    readonly parkedBy?: string | undefined;
    readonly cancellation?: {
        readonly source: "control" | "engine" | "cascade";
        readonly requestedAt: number;
        readonly reason?: string | undefined;
        readonly principal?: {
            readonly id: string;
            readonly kind: string;
            readonly stampedAt: number;
        } | undefined;
        readonly cascadedFrom?: string | undefined;
    } | undefined;
    readonly pendingWaits?: readonly {
        readonly token: string;
        readonly reason: string;
        readonly runId: string;
        readonly createdAt: number;
        readonly name?: string | undefined;
        readonly attempt?: number | undefined;
        readonly tokenDigest?: string | undefined;
        readonly request?: import("effect/Schema").Json | undefined;
        readonly flowId?: string | undefined;
    }[] | undefined;
    readonly deadlineAt?: number | undefined;
}, CliError.UsageError | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, never>;
