/**
 * Time-travel commands mounted on the durable runs namespace.
 * @since 1.0.0
 */
import { type Cli } from "incur";
import * as Bridge from "./ControlBridge.ts";
/**
 * Mount the read and mutation commands on an existing runs group.
 * @since 1.0.0
 * @category constructors
 */
export declare const appendHistoryCommands: (cli: Cli.Cli, runtime?: Bridge.Runtime) => Cli.Cli<{
    inspect: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            limit: number;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            at?: number | undefined;
            lineage?: string | undefined;
        };
    };
} & {
    replay: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            limit: number;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            at?: number | undefined;
            lineage?: string | undefined;
        };
    };
} & {
    verify: {
        args: {
            run?: string | undefined;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            against?: string | undefined;
        };
    };
} & {
    fork: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            limit: number;
            at: number;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            lineage?: string | undefined;
            step?: string | undefined;
            result?: string | undefined;
        };
    };
} & {
    rewind: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            limit: number;
            at: number;
            preview: boolean;
            yes: boolean;
            wholeRepo: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            lineage?: string | undefined;
        };
    };
}, undefined, undefined, undefined, string>;
/**
 * Reconciles local history before a normal runs list/show query.
 * @since 1.0.0
 * @category constructors
 */
export declare const reconcileHistory: (connection: Bridge.ConnectionOptions, runtime?: Bridge.Runtime) => Promise<void>;
/**
 * Resolves the worktree passed through Bridge.Runtime before a local resume.
 * @since 1.0.0
 * @category constructors
 */
export declare const prepareHistoryRun: (runId: string, connection: Bridge.ConnectionOptions, runtime?: Bridge.Runtime) => Promise<{
    executionRoot?: string;
}>;
