/**
 * What the implementing agent is told: the stable teaching every
 * implementation shares, and the brief for one suggestion or one follow-up.
 *
 * The teaching is the authoring model of a Smithers 1.0 project in the
 * fewest words that make a written flow launchable: a `flow.mdx` whose
 * frontmatter declares the seat, the capabilities, and a budget, and whose
 * body is the prompt; and, when the repository already carries `PACKAGE.ts`
 * files, a target in one of them. The agent is told to read what exists
 * before writing, so a repository's own conventions beat the sample here.
 *
 * @since 1.0.0-rc.0
 */
import type * as Checklist from "./Checklist.ts";
/**
 * The stable teaching, placed ahead of every brief.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const system: string;
/**
 * What one brief needs to know about the repository.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Context {
    readonly seat: string;
    readonly facts: Checklist.Evidence;
}
/**
 * The brief for one suggestion.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const suggestion: (context: Context, chosen: Checklist.Suggestion) => string;
/**
 * The brief for one accepted follow-up on a suggestion already implemented.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const followUp: (context: Context, chosen: Checklist.Suggestion, implemented: {
    readonly files: ReadonlyArray<string>;
    readonly command: string;
}, which: Checklist.FollowUp) => string;
