/**
 * Process lifetime, cancellation, and cache-secret isolation for the unified CLI.
 * @since 1.0.0
 */
import type { Host as BuildHost } from "@smthrs/build-cli/Entry";
/**
 * Process hosts keep MCP alive until stdin closes or the operator interrupts.
 * @category models
 * @since 1.0.0
 */
export interface Host extends BuildHost {
    readonly waitForDisconnect?: ((signal: AbortSignal) => Promise<void>) | undefined;
}
/**
 * Runs one invocation; help and validation do not construct a durable runtime.
 * Relative `PATH` entries are fixed to the launch directory first.
 * @category constructors
 * @since 1.0.0
 */
export declare const main: (host: Host) => Promise<void>;
