/**
 * The removed-command contract refusals, as Effect CLI wiring.
 *
 * Every removed verb is a hidden subcommand that exits 1 with its reason, and
 * every removed flag is a hidden flag whose presence is a refusal.
 *
 * @since 1.0.0
 */
import { Effect, Option } from "effect";
import { Command, Flag } from "effect/unstable/cli";
import type * as CliError from "../CliError.ts";
import * as Unsupported from "../Unsupported.ts";
/**
 * One removed verb by name, so a handler cannot cite the wrong entry.
 * @category getters
 * @since 1.0.0
 */
export declare const verb: (name: string) => Unsupported.RemovedVerb;
/**
 * A hidden boolean flag whose presence is a refusal.
 * @category constructors
 * @since 1.0.0
 */
export declare const flag: (_parent: string, name: string) => Flag.Flag<boolean>;
/**
 * A hidden value flag whose presence is a refusal.
 * @category constructors
 * @since 1.0.0
 */
export declare const valueFlag: (name: string) => Flag.Flag<Option.Option<string>>;
/**
 * Fails when a removed flag was passed.
 *
 * Taking the whole flag record and the names to check keeps the refusal in one
 * place: a handler that forgot one would accept a flag the contract removed.
 * @category constructors
 * @since 1.0.0
 */
export declare const refuse: (parent: string, passed: Readonly<Record<string, boolean | Option.Option<string>>>) => Effect.Effect<void, CliError.UnsupportedError>;
/**
 * Every removed verb, as a hidden subcommand that exits 1 with its reason.
 *
 * `workflows` is registered here under its own spelling like the rest. The
 * singular `workflow` is a separate command group, because `workflow list`
 * survives as the `ls` alias, and it refuses on its own with the same reason.
 * @category constructors
 * @since 1.0.0
 */
export declare const commands: Command.Command<string, {
    readonly rest: readonly string[];
}, {}, CliError.UnsupportedError, never>[];
