/**
 * Node WebSocket construction with errors owned through finalization.
 * @since 1.0.0
 */
import type * as Socket from "effect/unstable/socket/Socket";
/**
 * Constructs the transport used by the CLI and its real-socket fault harness.
 * @since 1.0.0
 * @category constructors
 */
export declare const make: (credential?: string) => Socket.WebSocketConstructor["Service"];
