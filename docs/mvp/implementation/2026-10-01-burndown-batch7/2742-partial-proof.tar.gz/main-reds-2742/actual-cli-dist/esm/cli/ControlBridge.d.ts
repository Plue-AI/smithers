/**
 * Adapts the existing Effect command handlers to the unified Incur surface.
 *
 * @since 1.0.0
 */
import type { RuntimeConfig } from "@smthrs/build-cli/Cli";
import { ApprovalAuthority, Control } from "@smthrs/control";
import type * as Evaluator from "@smthrs/model/Evaluator";
import type * as Registry from "@smthrs/registry/Registry";
import { Effect, Layer } from "effect";
import { z } from "incur";
import * as Serve from "../Serve.ts";
import * as Ui from "../Ui.ts";
/**
 * Shared connection options for commands that reach the control plane.
 * @category schemas
 * @since 1.0.0
 */
export declare const connectionOptions: z.ZodObject<{
    root: z.ZodOptional<z.ZodString>;
    remote: z.ZodOptional<z.ZodString>;
    mcpConfig: z.ZodOptional<z.ZodString>;
    quiet: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>;
/**
 * Parsed control-plane connection options.
 * @category models
 * @since 1.0.0
 */
export type ConnectionOptions = z.output<typeof connectionOptions>;
/**
 * Host inputs used while invoking an adapted command.
 * @category models
 * @since 1.0.0
 */
export interface Runtime extends RuntimeConfig {
    /** Explicit judge for an embedded or offline CLI host; otherwise select the gateway. */
    readonly evaluator?: Layer.Layer<Evaluator.Evaluator> | undefined;
    /** Host-owned delegation for local commands and the served gateway, never a request argument. */
    readonly approvalAuthority?: ApprovalAuthority.Service | undefined;
    readonly executionRoot?: string | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly environment?: Readonly<Record<string, string | undefined>> | undefined;
    readonly exit?: ((code: number) => void) | undefined;
}
/**
 * Renders connection options as arguments for the Effect CLI.
 * @category constructors
 * @since 1.0.0
 */
export declare const connectionArguments: (options: ConnectionOptions) => Array<string>;
/**
 * Resolves transport and execution roots for an adapted command.
 * @category constructors
 * @since 1.0.0
 */
export declare const configuration: (options: ConnectionOptions, runtime: Runtime) => {
    executionRoot: string | undefined;
    approvalAuthority: ApprovalAuthority.Service | undefined;
    principal: {
        id: string;
        kind: "agent";
    } | undefined;
    evaluator?: Layer.Layer<Evaluator.Evaluator> | undefined;
    startsRuns?: boolean | undefined;
    plansFlows?: boolean | undefined;
    approvalChannel?: boolean | undefined;
    health?: import("@smthrs/control/Health").HealthConfig | undefined;
    stateRoot?: string | undefined;
    databases?: import("../Application.ts").Databases | undefined;
    replayOnly?: Layer.Layer<import("@smthrs/engine-store/ReplayOnly").ReplayOnly> | undefined;
    remote?: string | undefined;
    credential?: string | undefined;
    login?: (() => Promise<string | undefined>) | undefined;
    rebuildAuthoredFlows?: boolean | undefined;
    mcpServers?: ReadonlyArray<import("@smthrs/mcp/McpClient").ConnectOptions> | undefined;
    sandboxProviders?: import("../Application.ts").SandboxProviders | undefined;
    root?: string | undefined;
    migrationRoot?: string | undefined;
};
/**
 * Whether this invocation targets a remote control plane.
 * @category predicates
 * @since 1.0.0
 */
export declare const isRemote: (options: ConnectionOptions, runtime: Runtime) => boolean;
/**
 * Whether there are durable records to observe: a remote control plane, or a
 * local project whose control store exists. Observing verbs answer empty
 * without opening, and so creating, a local store that does not.
 * @category predicates
 * @since 1.0.0
 */
export declare const hasRecords: (options: ConnectionOptions, runtime: Runtime) => boolean;
/**
 * Reuses the tested flow control handlers without starting a second process.
 * @category constructors
 * @since 1.0.0
 */
export declare const invoke: (args: ReadonlyArray<string>, options: ConnectionOptions, runtime?: Runtime) => Promise<unknown>;
/**
 * Runs a typed verb against the same local or remote host as flow commands.
 *
 * The host layer also carries the project references, so a verb that reads
 * `Project.ProjectRoot` or the 0.x snapshot sees the host's answer.
 *
 * The host observes runs and drives none, so it opens with no gateway key: a
 * flow listing, a run diagnosis, a pending-approval listing and a bulk cancel
 * all work in a project that has never had one. An operation that starts or
 * resumes a run does not belong here and its launch would die on the observing
 * executor; route one through {@link invoke}, whose verb declares the
 * capability.
 * @category constructors
 * @since 1.0.0
 */
export declare const query: <A, E>(operation: Effect.Effect<A, E, Control.Control | Ui.Ui>, options: ConnectionOptions, runtime?: Runtime) => Promise<A>;
/**
 * Runs a read-only verb over the project's existing stores.
 *
 * Nothing is created, migrated, recovered or reaped, and the reads answer
 * while another process holds the writer. Only a verb that changes nothing
 * belongs here; one that cancels, signals or decides goes through
 * {@link query} or {@link invoke}.
 * @category constructors
 * @since 1.0.0
 */
export declare const read: <A, E>(operation: Effect.Effect<A, E, Control.Control | Ui.Ui>, options: ConnectionOptions, runtime?: Runtime) => Promise<A>;
/**
 * Runs a typed verb on the project alone, without opening the control host or
 * building the flow registry. The project references are the host's.
 * @category constructors
 * @since 1.0.0
 */
export declare const project: <A, E>(operation: Effect.Effect<A, E, Ui.Ui>, options: ConnectionOptions, runtime?: Runtime) => Promise<A>;
/**
 * Runs a typed verb on the project alone, without opening the control host:
 * the 0.x migration, garbage collection, and the registry check. The project
 * references and the flow registry are the host's.
 * @category constructors
 * @since 1.0.0
 */
export declare const local: <A, E>(operation: Effect.Effect<A, E, Registry.Registry | Ui.Ui>, options: ConnectionOptions, runtime?: Runtime) => Promise<A>;
/**
 * A scoped stream closes its transports when the consumer stops following.
 *
 * Reading events changes nothing, so it observes the stores as {@link read} does.
 * @category constructors
 * @since 1.0.0
 */
export declare const events: (runId: string, follow: boolean, options: ConnectionOptions, runtime?: Runtime, afterSequence?: number) => AsyncIterable<{
    readonly payload: import("effect/Schema").Json;
    readonly kind: string;
    readonly sequence: number;
    readonly occurredAt: number;
    readonly runId?: string | undefined;
    readonly cursor?: {
        readonly sequence: number;
        readonly offset?: number | undefined;
    } | undefined;
}>;
/**
 * Serves the gateway and durable trigger scheduler on one shared local Control host.
 * @category constructors
 * @since 1.0.0
 */
export declare const host: (bind: Serve.Bind, options: ConnectionOptions, runtime?: Runtime) => Promise<void>;
