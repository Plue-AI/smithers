/**
 * Local, cached documentation lookup for agent ask; no model or second agent loop.
 * @since 0.1.0
 */
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const ask: Handler;
