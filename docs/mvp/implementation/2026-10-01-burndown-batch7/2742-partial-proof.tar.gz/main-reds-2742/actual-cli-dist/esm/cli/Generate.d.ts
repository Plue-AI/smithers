/**
 * Workspace initialization and generators backed by the existing scaffolds.
 * @since 1.0.0
 */
import { type RuntimeConfig } from "@smthrs/build-cli/Cli";
import { Cli } from "incur";
import * as Init from "../Init.ts";
import * as Presentation from "./Presentation.ts";
/**
 * Follow-ups after a workspace or target is scaffolded.
 * @category constants
 * @since 1.0.0
 */
export declare const scaffolded: Presentation.FollowUps;
/**
 * Initialize without replacing an existing workspace, package declaration, or flow.
 * @category constructors
 * @since 1.0.0
 */
export declare const initialize: (root: string, name: string, environment: Readonly<Record<string, string | undefined>>) => Promise<{
    root: string;
    created: string[];
    retained: string[];
    flow: Init.Scaffolded;
    next: string[];
}>;
/**
 * Commands use configured target generators so repository policy remains authoritative.
 * @category constructors
 * @since 1.0.0
 */
export declare const createGenerateCli: (config?: RuntimeConfig) => Cli.Cli<{
    app: {
        args: {
            directory: string;
        };
        options: {
            template: string;
        };
    };
} & {
    flow: {
        args: {
            name: string;
        };
        options: {
            root?: string | undefined;
        };
    };
} & {
    package: {
        args: {
            name: string;
        };
        options: {
            workspace: string;
            plan: boolean;
            target?: string | undefined;
        };
    };
} & {
    ci: {
        args: {};
        options: {
            workspace: string;
            plan: boolean;
            target?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "generate">;
