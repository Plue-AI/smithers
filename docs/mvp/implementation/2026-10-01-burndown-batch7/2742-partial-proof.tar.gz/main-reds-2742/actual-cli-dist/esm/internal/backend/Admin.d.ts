/**
 * Administrator command plumbing; the backend owns authorization and transitions.
 * @since 0.1.0
 */
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const admin: Record<string, Handler>;
