/**
 * The one line an unknown command earns, decided by Jev.
 *
 * A command the parser does not know is a closed question: the answer is one
 * of the commands the canonical Incur tree serves, or none of them. So it is
 * asked as a classifier `choice` over that tree, each option described by the
 * same line `--help` prints, rather than measured by a string distance that
 * knows nothing about what the commands do. The options are read from the
 * tree itself, so a hidden transition alias is never one of them. A removed
 * verb is never asked about: it has its own migration sentence in
 * {@link Unsupported}.
 *
 * There is no fallback. Below {@link floor} the suggestion is withheld, and a
 * transport that cannot answer says so by name, because a guess an operator
 * cannot tell from an answer is worse than no line at all.
 *
 * @since 1.0.0
 */
import type * as Evaluator from "@smthrs/model/Evaluator";
import * as Effect from "effect/Effect";
import { Cli } from "incur";
/**
 * One command the canonical tree serves: its full path and its help line.
 *
 * @category models
 * @since 1.0.0
 */
export interface Command {
    readonly name: string;
    readonly description: string;
}
/**
 * Every command `cli` serves, by the path `--help` prints, aliases excluded.
 *
 * A group is a command only when it has a root handler of its own.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const commands: (cli: Cli.Cli<any, any, any, any>) => ReadonlyArray<Command>;
/**
 * The suggestion line for a typed command, or `undefined` when there is none
 * to give.
 *
 * `candidates` is the tree {@link commands} reads. The line is appended to
 * the refusal the parser already prints; it never changes the exit code and
 * never runs the command it names.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const didYouMean: (typed: string, args: ReadonlyArray<string>, candidates: ReadonlyArray<Command>) => Effect.Effect<string | undefined, never, Evaluator.Evaluator>;
