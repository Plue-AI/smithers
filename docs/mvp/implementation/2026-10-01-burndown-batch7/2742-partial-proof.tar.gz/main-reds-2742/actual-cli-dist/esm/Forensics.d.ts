/**
 * Read-only forensic projections of a run's journal events.
 *
 * The vault's Forensics concept fixes the CLI surface at exactly two
 * projections: `smthrs logs` projects journal queries and `smthrs status`
 * projects the run summary and its gating cause. This module is the rendering
 * half of both: pure functions from the `ControlEvent` deltas that
 * `Control.watch` already serves, to a turn-by-turn transcript, a one-line
 * follow view, and the status card's diagnosis. Nothing here opens a
 * database; the control plane stays the only read path, so `--remote` renders
 * exactly what a local run renders.
 *
 * The need is concrete: the first SWE-bench benchmark of the built-in harness
 * was diagnosed with ad-hoc SQLite scripts because a settled run's journal
 * had no readable projection. Every question those scripts answered, where
 * the turns went, which calls were refused and why, whether an edit was ever
 * attempted, and what the run died of, is computed here from the events alone.
 *
 * @since 0.1.0
 */
import { ControlFacts, ControlSchema } from "@smthrs/control";
import { type RunMemory } from "@smthrs/gateway/RunTrace";
/**
 * One refused flow call, aggregated by its refusal message. Reach for this in
 * diagnosis renderers that need the reason and its frequency together. The
 * digest normalizes malformed source events before constructing this shape, so
 * consumers do not handle a separate parse failure.
 *
 * @category models
 * @since 0.1.0
 */
export interface Refusal {
    readonly message: string;
    readonly count: number;
}
/**
 * Everything the diagnosis computes from one run's events. Reach for this
 * projection when a status card or transcript needs one consistent account of
 * activity, cost, gating, and outcome. Missing or malformed event fields become
 * optional or zero values rather than making construction fail.
 *
 * @category models
 * @since 0.1.0
 */
export interface Digest {
    /**
     * The last status transition seen, or undefined before launch. A
     * `control.run.*` kind that names an operation rather than a status, such as
     * `control.run.lineage`, is not one.
     */
    readonly status: string | undefined;
    /** The journaled failure cause, when the run failed and recorded one. */
    readonly cause: string | undefined;
    readonly seat: string | undefined;
    readonly turns: number;
    readonly calls: number;
    readonly callsFailed: number;
    /** Calls whose flow and input were byte-identical to an earlier call. */
    readonly duplicateCalls: number;
    readonly editsAttempted: number;
    readonly editsSucceeded: number;
    /** Call counts by flow name, descending. */
    readonly flows: ReadonlyArray<readonly [string, number]>;
    /** Refusal messages, descending by count. */
    readonly refusals: ReadonlyArray<Refusal>;
    readonly inputTokens: number;
    readonly outputTokens: number;
    /** USD the run's priced model calls cost; zero when none was priced. */
    readonly costUsd: number;
    /** The final assistant output, when the run resolved. */
    readonly finalOutput: string | undefined;
    /** The pending ask's question, when the run parked for approval. */
    readonly parkedQuestion: string | undefined;
    /** The serialized approval payload that unblocks a parked run. */
    readonly parkedApproval: string | undefined;
    /**
     * The facts a runaway guard parked the run on (`RunawayGuard.incident`),
     * while its request is undecided: approving it is Continue, cancelling the
     * run is Stop.
     */
    readonly parkedIncident?: typeof ControlFacts.GuardIncident.Type | undefined;
    readonly startedAt: number | undefined;
    readonly endedAt: number | undefined;
    /**
     * The memory the run was brought and the memory Jev withheld, by id,
     * absent when Jev never read for the run. The run card folds the same rows.
     */
    readonly memory?: RunMemory | undefined;
}
/**
 * Computes the diagnosis for one run from its ordered events. Reach for this
 * before rendering status or transcript output so both views share the same
 * counts and final state.
 *
 * `@smthrs/gateway` `Diagnosis.digest` is the fold; this adds the three facts
 * a terminal card reports and a served row does not, so `smthrs status` and a
 * client's run card cannot disagree about one run: how many calls repeated an
 * earlier call byte for byte, how many calls each flow took, and the approval
 * payload that unblocks a parked run.
 *
 * Total on purpose: payloads are wire `Json`, so every field read tolerates
 * absence and the digest of a malformed journal is a sparse digest, never a
 * throw.
 *
 * @param events the run's watch stream
 * @param runId the run being digested; a `control.run.*` verdict stamped with
 *   another run's id, such as a child's, sets neither status nor cause.
 *   Omitted, every verdict folds.
 * @category constructors
 * @since 0.1.0
 */
export declare const digest: (events: ReadonlyArray<ControlSchema.ControlEvent>, runId?: string) => Digest;
/**
 * Quotes one argv element as exactly one POSIX shell word. Reach for this for
 * every caller-controlled value in a copy-paste command. It preserves all
 * bytes, including newlines, and performs no semantic validation.
 *
 * A value made only of characters no shell interprets is returned unchanged,
 * so the advertised command reads as the one an operator would have typed.
 * Anything else, including the empty string, is wrapped in single quotes with
 * embedded quotes escaped as `'\''`.
 *
 * @category conversions
 * @since 0.1.0
 */
export declare const shellQuote: (value: string) => string;
/**
 * Renders the status card for one run: verdict, gating cause, activity
 * evidence, and the exact next commands. Reach for this in `smthrs status` or
 * another read-only projection. Missing summaries render as unknown values,
 * and long evidence is clipped instead of throwing.
 *
 * @category rendering
 * @since 0.1.0
 */
export declare const renderDiagnosis: (run: {
    readonly runId?: string;
    readonly flowId?: string;
    readonly codeDrift?: {
        readonly recorded?: string | undefined;
        readonly current?: string | undefined;
        readonly recordedEngine?: string | undefined;
        readonly currentEngine?: string | undefined;
    } | undefined;
} | undefined, d: Digest) => string;
/**
 * Renders one event as a single follow-mode line. Reach for this while polling
 * a live run. Unknown event kinds fall back to their compact payload, and
 * missing fields render as empty or question-mark values rather than failing.
 *
 * @category rendering
 * @since 0.1.0
 */
export declare const eventLine: (event: ControlSchema.ControlEvent) => string;
/**
 * Renders the whole run as a turn-by-turn transcript. Reach for this when the
 * operator needs event order and model-turn boundaries rather than raw JSON.
 *
 * One `=== turn N ===` header per model turn; one line per event under it,
 * offset-stamped from the run's first event. Refusals and errors keep their
 * message; successful payloads are compressed to a line, because the reader
 * scanning for "where did it go wrong" needs the shape of the run, not the
 * bytes of every result.
 *
 * @param events the run's watch stream
 * @param watchedRunId the run being rendered; a child's verdict does not set its status
 * @category rendering
 * @since 0.1.0
 */
export declare const renderTranscript: (events: ReadonlyArray<ControlSchema.ControlEvent>, watchedRunId?: string) => string;
