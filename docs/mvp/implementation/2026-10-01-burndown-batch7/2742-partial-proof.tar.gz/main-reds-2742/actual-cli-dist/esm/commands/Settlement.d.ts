/**
 * How a verb that launched or restarted a run learns what the run then did.
 *
 * A local CLI owns the executor layer. It keeps that scope alive after
 * accepting a run so its driver is not interrupted as soon as the receipt is
 * printed, and it reports the settlement it waited for as the process status.
 *
 * @since 1.0.0
 */
import { type Control as ControlService, ControlError, type ControlSchema } from "@smthrs/control";
import { Effect, Stream } from "effect";
import * as CliError from "../CliError.ts";
/**
 * The event kind that settled a run, and the cause its payload recorded.
 * @category models
 * @since 1.0.0
 */
export interface Settlement {
    readonly kind: string;
    readonly cause?: string;
}
/**
 * Whether an event leaves this process nothing to drive: a park for approval,
 * a `pending` launch the executor declined, or a terminal status.
 * @category predicates
 * @since 1.0.0
 */
export declare const settled: (kind: string) => boolean;
/**
 * The retryable transport failure a failed watch reports, naming the run and
 * the operation it interrupted.
 * @category constructors
 * @since 1.0.0
 */
export declare const watchFailure: (error: unknown, runId: string, operation: string) => ControlError.TransportError;
/**
 * Waits for the run to settle and reports the event kind that settled it, or
 * `undefined` when nothing was waited for. `quiet` suppresses progress.
 * @category constructors
 * @since 1.0.0
 */
export declare const awaitRun: (control: ControlService.Service, runId: string, afterSequence: number | undefined, quiet: boolean) => Effect.Effect<Settlement | undefined, ControlError.TransportError>;
/**
 * Finds the greatest sequence in a stream without retaining its history.
 *
 * Use this for journal cursors whose histories can exceed the JavaScript
 * argument limit. Stream failures are preserved so a caller never substitutes
 * a weaker cursor after a failed read.
 *
 * @category getters
 * @since 1.0.0-rc.0
 */
export declare const latestSequence: <E, R>(events: Stream.Stream<{
    readonly sequence: number;
}, E, R>) => Effect.Effect<number | undefined, E, R>;
/**
 * The sequence of the latest committed `control.run.waiting-approval` event:
 * the park a resume applies to. It keys the resume mutation, so resuming a
 * second park is a fresh mutation instead of a replay of the first resume's
 * recorded receipt, and it scopes the settlement wait.
 * @category getters
 * @since 1.0.0
 */
export declare const latestPark: (control: ControlService.Service, runId: string) => Effect.Effect<number | undefined, ControlError.TransportError, never>;
/**
 * Waits for a run this process's executor owns, or reports the receipt's own
 * terminal status.
 * @category constructors
 * @since 1.0.0
 */
export declare const awaitOwnedRun: (control: ControlService.Service, receipt: ControlSchema.Receipt, afterSequence: number | undefined, quiet: boolean) => Effect.Effect<Settlement | undefined, ControlError.TransportError, never>;
/**
 * The park a decision answers, or nothing for a plan-level decision.
 *
 * `Control.approve` and `Control.deny` restart the run their `ask` parked, in
 * the deciding call. The driver that picks that
 * resume up is this process's own executor, so a command that printed its
 * receipt and returned took the driver down with it and left the run it had
 * just restarted exactly where it stood, still needing `run --resume`, which
 * is the second call the contract says a decision replaces.
 *
 * A plan-level decision has no run yet, and the settlement wait needs one.
 * @category getters
 * @since 1.0.0
 */
export declare const decisionPark: (control: ControlService.Service, target: ControlSchema.ApprovalTarget) => Effect.Effect<number | undefined, ControlError.TransportError, never>;
/**
 * The refusal a declined launch exits with, given what the control plane
 * knows about the run.
 *
 * `control.run.pending` is the executor saying it will not take the run: no
 * seat resolved, a capability was not granted, or the host refused it. The run
 * row is durable and stays at `accepted` with nothing driving it. Printing the
 * launch receipt there said `Accepted` and exited 0, which is the one answer
 * that is wrong in both halves.
 * @category constructors
 * @since 1.0.0
 */
export declare const declined: (runId: string, summary: ControlSchema.RunSummary | undefined) => CliError.UnsupportedError;
/**
 * Whether the settlement this process waited for was the executor declining.
 * @category predicates
 * @since 1.0.0
 */
export declare const wasDeclined: (settlement: Settlement | undefined) => boolean;
/**
 * The process status one settlement reports, or nothing when the settlement
 * says nothing about how the run ended.
 *
 * The `up` command promises that an
 * attached launch exits with the terminal status code. The launch contract
 * paragraph is the vocabulary that code is spelled in: 0 success, 1 error, 2
 * usage, 3 parked, 130 SIGINT, 143 SIGTERM. A cancel reports the interrupt
 * status because a cancel is an interruption: `Control.cancel` settles the run
 * through `ControlRuntime.interrupt`, and reporting it separately keeps a
 * cancelled run distinguishable from a failed one.
 *
 * Until this existed, `runLaunch` failed only on `control.run.pending`, so a
 * `control.run.failed` settlement rendered the launch receipt and exited 0.
 * No caller of `smthrs up` could read a red run from the exit code: the
 * release validation measured `smthrs up ci-fast --json` returning 0 in
 * three seconds while `smthrs ps` reported `failed`.
 * @category getters
 * @since 1.0.0
 */
export declare const status: (settlement: Settlement | undefined) => number | undefined;
/**
 * Reports a settled run's terminal status as this process's exit status.
 *
 * Written after the receipt is rendered, never instead of it: the `--json`
 * contract is that an attached launch prints its receipt, and a caller reads
 * `runId` from that document whatever the run then did. `bin.ts` hands a
 * successful exit whatever `process.exitCode` holds, which is how
 * `smthrs migrate` reports its own status too.
 * @category constructors
 * @since 1.0.0
 */
export declare const report: (settlement: Settlement | undefined) => Effect.Effect<void, never, never>;
/**
 * The receipt document to render. Admission stays identifiable while an
 * attached failure states its verdict.
 * @category getters
 * @since 1.0.0
 */
export declare const receiptDocument: (receipt: ControlSchema.Receipt, settlement: Settlement | undefined) => unknown;
