/**
 * `smthrs doctor`: the report, from either catalog source.
 *
 * @since 1.0.0
 */
import { Control as ControlService } from "@smthrs/control";
import type * as Registry from "@smthrs/registry/Registry";
import { Effect, type Layer } from "effect";
import * as Doctor from "../Doctor.ts";
import * as FlowCatalog from "./FlowCatalog.ts";
import * as Globals from "./Globals.ts";
/**
 * A catalog the registry could not produce, reported as a failed check.
 * @category models
 * @since 1.0.0
 */
export interface DiscoveryFailed {
    readonly failure: string;
}
/**
 * The report for one already-read catalog.
 * @category constructors
 * @since 1.0.0
 */
export declare const report: (catalog: Pick<FlowCatalog.FlowPage, "items" | "warnings"> | DiscoveryFailed, globals: Globals.Options) => Effect.Effect<Doctor.Report>;
/**
 * Local diagnostics use the discovery snapshot without opening execution
 * databases. A registry that discovery cannot build, such as one whose
 * filesystem helper is missing, is a failed `registry` check rather than a
 * crash; any other defect still crashes.
 * @category constructors
 * @since 1.0.0
 */
export declare const fromRegistry: (globals: Globals.Options, registry?: (root: string) => Layer.Layer<Registry.Registry>) => Effect.Effect<Doctor.Report>;
/**
 * Remote diagnostics read the catalog the selected control plane serves.
 * @category constructors
 * @since 1.0.0
 */
export declare const fromControl: (globals: Globals.Options) => Effect.Effect<Doctor.Report, import("../CliError.ts").UnsupportedError | import("../CliError.ts").ResourceLimitError | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, ControlService.Control>;
