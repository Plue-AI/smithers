/**
 * Retained Effect handlers and migration refusals for the unified CLI.
 *
 * Cli.ts owns the public command tree. Its control commands delegate here,
 * and Compatibility.ts retains old spellings with their output contracts.
 * Local init, suggest, memory, MCP registration, and gateway hosting belong
 * exclusively to the Incur tree.
 *
 * @since 1.0.0
 */
import { Control as ControlService, ControlSchema } from "@smthrs/control";
import { Effect, Option, Stream } from "effect";
import { Command } from "effect/unstable/cli";
import * as CliError from "./CliError.ts";
import { Output } from "./Output.ts";
/**
 * Finds the greatest sequence in a stream without retaining its history.
 *
 * Use this for journal cursors whose histories can exceed the JavaScript
 * argument limit. Stream failures are preserved so a caller never substitutes
 * a weaker cursor after a failed read.
 *
 * @category getters
 * @since 1.0.0-rc.0
 */
export declare const latestSequence: <E, R>(events: Stream.Stream<{
    readonly sequence: number;
}, E, R>) => Effect.Effect<number | undefined, E, R>;
/**
 * The idempotency key of one signal delivery.
 *
 * The payload digest is part of the key because two different signals to one
 * run are two mutations. At the import reference the key was `cli:signal:<id>`
 * alone, so the second signal replayed the first one's recorded receipt and
 * was never delivered.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const signalKey: (runId: string, payload: ControlSchema.SignalPayload) => string;
/**
 * The composed root command. Application composition supplies Control and
 * Output layers; this module contains no transport selection.
 *
 * Reach for this value from the executable or parser-level tests. Individual
 * handlers fail with the package's typed CLI errors, while a missing service
 * is left visible as a composition defect rather than hidden by the command
 * tree.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const cli: Command.Command<"smthrs", {
    readonly json: boolean;
    readonly remote: Option.Option<string>;
    readonly quiet: boolean;
    readonly silent: boolean;
    readonly audience: "agent" | "human" | "auto";
    readonly verbose: boolean;
    readonly mcpConfig: Option.Option<string>;
    readonly root: Option.Option<string>;
    readonly backend: Option.Option<string>;
}, {
    readonly json: boolean;
    readonly remote: Option.Option<string>;
    readonly quiet: boolean;
    readonly silent: boolean;
    readonly audience: "agent" | "human" | "auto";
    readonly verbose: boolean;
    readonly mcpConfig: Option.Option<string>;
    readonly root: Option.Option<string>;
    readonly backend: Option.Option<string>;
}, CliError.UsageError | CliError.UnsupportedError | CliError.ResourceLimitError | CliError.RenderingError | CliError.Refused | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, ControlService.Control | Output>;
