/**
 * `smthrs suggest`: read the project, stream the ways Smithers can help, and
 * implement the one the operator picks.
 *
 * The verb is the composition of four modules that already exist and are
 * tested on their own: `Providers` decides which seat this machine can run,
 * `suggest/Checklist` reads the repository and yields one suggestion per
 * match, `suggest/Brief` turns a match into the text the agent is handed, and
 * `suggest/SuggestFlow` runs that text through a kernel-guarded filesystem
 * pinned to the project root. Nothing here reads a file or spends a token
 * itself; this module is the order those four happen in and the shape of what
 * an operator sees.
 *
 * Three renderings, one scan. `--json` writes one document per suggestion as
 * it is found, then the seat and the outcome, and never asks a question.
 * `--list`, and any session whose streams are not terminals, prints the same
 * suggestions as lines and stops there. An interactive session prints them
 * while a spinner says the scan continues, then asks which one to implement,
 * implements it, and offers that suggestion's follow-ups and the large
 * suggestions the checklist held back.
 *
 * Every side effect an operator did not ask for is a side effect they have to
 * undo, so the implementation writes files under the project root and never
 * commits: `SuggestFlow.rules` denies `.git/` and `.flows/` in the grant
 * store, and there is no `proc:spawn` grant at all.
 *
 * @since 1.0.0-rc.0
 */
import { Effect } from "effect";
import * as CliError from "./CliError.ts";
import type * as Environment from "./Environment.ts";
import * as Providers from "./Providers.ts";
import * as Checklist from "./suggest/Checklist.ts";
import * as SuggestFlow from "./suggest/SuggestFlow.ts";
/**
 * What one implementation wrote, and which question it answered.
 *
 * `kind` separates the three briefs the agent can be handed: the suggestion
 * the operator picked, one of that suggestion's follow-ups, and a suggestion
 * the checklist held back as too large to offer first.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Implementation {
    readonly kind: "suggestion" | "follow-up" | "held-back";
    /** The suggestion this implementation belongs to. */
    readonly suggestion: string;
    /** The follow-up id, for `kind: "follow-up"`. */
    readonly followUp?: string | undefined;
    readonly files: ReadonlyArray<string>;
    readonly command: string;
    readonly notes: string;
}
/**
 * What one `smthrs suggest` did.
 *
 * `listed` covers every rendering that only prints: `--json`, `--list`, and a
 * session that cannot ask. `nothing` is a scan that found nothing small
 * enough to offer first, which is not a failure.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Outcome {
    readonly status: "listed" | "implemented" | "cancelled" | "nothing";
    readonly root: string;
    readonly seat: string;
    /** The suggestion ids, in the order the scan streamed them. */
    readonly suggestions: ReadonlyArray<string>;
    readonly implemented: ReadonlyArray<Implementation>;
}
/**
 * The process status one outcome ends on.
 *
 * A cancelled prompt is 130, the status the rest of the CLI already uses for
 * a cancelled thing. Everything else here is 0; a failure never reaches this
 * function, because it left as a typed `CliError`.
 *
 * @category getters
 * @since 1.0.0-rc.0
 */
export declare const exitStatus: (outcome: Outcome) => number;
/**
 * One implementing step: a brief in, the files it wrote out.
 *
 * The seam a test replaces. Everything above it (the seat, the scan, the
 * prompts, the rendering) is the verb; everything below it is one model call
 * inside a sandbox, which `test/suggest/SuggestFlow.scripted.test.ts` proves
 * on its own.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export type Implement = (brief: string) => Effect.Effect<SuggestFlow.Implemented, Error>;
/**
 * What one invocation was told.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Options {
    /** The absolute project root to read. */
    readonly root: string;
    /** The `--seat provider:model` override. */
    readonly seat?: string | undefined;
    readonly list: boolean;
    readonly json: boolean;
    readonly environment: Environment.Source;
    /** Explicit judge for an embedded or offline implementation host. */
    readonly evaluator?: SuggestFlow.NodeConfig["evaluator"];
    readonly homeDirectory?: string | undefined;
    /** How the seat scan reads a credential store. Defaults to the real one. */
    readonly readFile?: ((path: string) => string | undefined) | undefined;
    /** What the checklist reads. Defaults to the Node reader over `root`. */
    readonly repository?: Checklist.Repository | undefined;
    /** How a brief is implemented. Defaults to the bundled flow on this host. */
    readonly implement?: Implement | undefined;
    /** Where a `--json` document is written. Defaults to stdout. */
    readonly emit?: ((line: string) => void) | undefined;
}
/**
 * Whether a path is a directory this verb can read.
 *
 * @category predicates
 * @since 1.0.0-rc.0
 */
export declare const isDirectory: (path: string) => boolean;
/**
 * The `--json` document for one suggestion, in the order it was found.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const suggestionDocument: (suggestion: Checklist.Suggestion, position: number) => {
    document: "suggestion";
    position: number;
    id: string;
    title: string;
    why: string;
    effort: "small" | "medium" | "large";
    followUp: boolean;
    followUps: ("ci" | "incremental")[];
    files: readonly string[];
};
/**
 * The `--json` document for the seat the scan and the implementation run on.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const seatDocument: (chosen: Providers.Chosen) => {
    document: "seat";
    seat: string;
    source: "override" | Providers.Candidate;
    label: string;
};
/**
 * The `--json` document that closes the stream.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const outcomeDocument: (outcome: Outcome) => {
    document: "outcome";
    status: "cancelled" | "listed" | "implemented" | "nothing";
    root: string;
    seat: string;
    suggestions: readonly string[];
    implemented: readonly Implementation[];
};
/**
 * The intro line, which names the seat before anything is read.
 *
 * An operator who is about to spend a subscription or a key has to be told
 * which one, and told it before the scan rather than beside the first
 * question.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const introLine: (chosen: Providers.Chosen) => string;
/**
 * The one line a streamed suggestion prints.
 *
 * Complete on its own: the position, the title, how big the change is,
 * whether it was held back, and the files that triggered it. It is the whole
 * of what `--list` prints, so nothing an operator needs may sit anywhere else.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const streamLabel: (suggestion: Checklist.Suggestion, position: number) => string;
/**
 * The note printed after an implementation: every file, then the command that
 * runs them, then what the agent wanted the reader to know.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const wroteNote: (implemented: SuggestFlow.Implemented) => string;
/**
 * Runs one `smthrs suggest`.
 *
 * The seat is decided before anything is read, so a machine with no seat is
 * told so before a scan it cannot act on. A malformed `--seat` is a usage
 * error (2); no seat at all, a failed scan, and a failed implementation are
 * failures (1); a cancelled prompt is reported in the outcome and becomes 130
 * through {@link exitStatus}.
 *
 * @category execution
 * @since 1.0.0-rc.0
 */
export declare const run: (options: Options) => Effect.Effect<Outcome, CliError.CliError>;
