/**
 * `smthrs runs verify`: what a resume under the current code would replay and
 * what it would execute again.
 *
 * A step is recorded under a key the engine derives at dispatch from the
 * flow's own declaration, ordinal and scope, so only the engine can say
 * whether current code still derives a recorded key. The verifier copies the
 * project's stores, resumes the run on the copy under a replay-only engine
 * (`@smthrs/engine-store/ReplayOnly`) and reads back what each dispatch did:
 * a recorded step served from its record replays, and the first step no record
 * serves stops the run before its body. The original stores are only read.
 *
 * `--against <engine.db>` verifies every run stored in that engine store (with
 * the `control.db` beside it) under the project's current flows. A SQLite store
 * is copied with `VACUUM INTO`; a PostgreSQL one schema by schema
 * (`StoreCopy`).
 *
 * @since 1.0.0
 */
import { type Duration, Effect } from "effect";
import * as CliError from "../CliError.ts";
import type * as NativeControl from "../internal/NativeControl.ts";
/**
 * One step of the run, by the key its attempts are recorded under.
 *
 * `action` is the declared action name and `node` the graph node that drove
 * the dispatch, each when the record names it.
 *
 * @since 1.0.0
 * @category models
 */
export interface Step {
    readonly stepKeyDigest: string;
    readonly action?: string | undefined;
    readonly node?: string | undefined;
}
/**
 * What a resume under the current code would do.
 *
 * `replayed` are dispatches served from a durable record. `resumes` is a
 * recorded step that never finished, which the resume would re-enter.
 * `executes` is the first dispatch no record serves, where the resume would
 * run code again.
 * `notReplayed` are recorded successful steps the resume never asked for:
 * dropped or re-keyed by the current code. A run is `divergent` when a
 * recorded step goes unreplayed while the resume executes; one that replays
 * everything it recorded before executing new work is `consistent`.
 *
 * @since 1.0.0
 * @category models
 */
export interface Report {
    readonly runId: string;
    readonly verdict: "consistent" | "divergent";
    readonly replayed: ReadonlyArray<Step>;
    readonly resumes?: Step | undefined;
    readonly executes?: Step | undefined;
    readonly notReplayed: ReadonlyArray<Step>;
}
/**
 * A run the store holds that no resume can take: it already settled.
 *
 * @since 1.0.0
 * @category models
 */
export interface Settled {
    readonly runId: string;
    readonly status: "completed" | "failed" | "cancelled";
}
/**
 * What resuming every run a store holds would do: one {@link Report} per run a
 * resume can take, the settled runs it cannot, and the runs whose resume was
 * refused ({@link Unverified}). The store is `divergent` when any report is.
 *
 * @since 1.0.0
 * @category models
 */
export interface Summary {
    readonly verdict: "consistent" | "divergent";
    readonly reports: ReadonlyArray<Report>;
    readonly settled: ReadonlyArray<Settled>;
    readonly unverified: ReadonlyArray<Unverified>;
}
/**
 * The seams a verification runs over; tests supply the flow modules a host
 * would load.
 *
 * @since 1.0.0
 * @category models
 */
export interface Options {
    readonly modules?: NativeControl.ModuleRegistration | undefined;
    /** How long each resumed copy may take to stop; defaults to ten minutes. */
    readonly settleWithin?: Duration.Input | undefined;
    /**
     * The engine store to verify, with the `control.db` beside it; the
     * project's own `.flows/engine.db` by default. The flows are always the
     * project's.
     */
    readonly against?: string | undefined;
}
/**
 * The successful steps `runId` and the runs it spawned recorded in the store at
 * `filename`, which is only read.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const recordedSteps: (filename: string, runId: string) => Effect.Effect<ReadonlyArray<Step>, unknown>;
/**
 * A run the store holds that verification could not resume, with the refusal's
 * own code: a run another host still owns, or a copy that did not stop in time.
 *
 * @since 1.0.0
 * @category models
 */
export interface Unverified {
    readonly runId: string;
    readonly code: string;
    readonly message: string;
}
/**
 * Resumes a copy of `runId` replay-only under the flows on disk and reports
 * which recorded steps replay and which step would execute.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const verify: (root: string, runId: string, options?: Options, signal?: AbortSignal) => Promise<Report>;
/**
 * Resumes a fresh copy of every run the store holds replay-only under the
 * flows on disk, one after another, and reports each. Settled runs are listed
 * apart, and a run whose resume was refused (another host still owns it, or
 * its copy did not stop in time) is listed with the refusal instead of ending
 * the whole verification.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const verifyAll: (root: string, options?: Options, signal?: AbortSignal) => Promise<Summary>;
/**
 * The refusal a divergent report exits with: the step that would run again
 * and the recorded steps that would not replay.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const divergence: (report: Report) => CliError.Refused;
/**
 * The refusal a divergent store exits with: every divergent run's sentence.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const storeDivergence: (summary: Summary) => CliError.Refused;
