/**
 * What a run is doing, folded from the events `runs show` already reads: the
 * executions its flow spawned, the actions each one is running, and when the
 * run last made progress.
 *
 * The engine starts every planned run as an `agent/run` execution, which runs
 * the approved plan through a `registry/entry/<digest>/<flow>` execution. Both
 * are wrappers around the operator's flow, so this view names the run by its
 * flow and folds the wrappers' work into that one row.
 *
 * @since 1.0.0
 */
import type { ControlSchema } from "@smthrs/control";
import * as Forensics from "../Forensics.ts";
/**
 * Rows `runs show` prints before it reports the rest as omitted.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maximumExecutions = 20;
/**
 * One execution in a run's tree, as `runs show` prints it.
 *
 * @category models
 * @since 1.0.0
 */
export interface Execution {
    readonly executionId: string;
    readonly flowName: string;
    readonly status: string;
    /** The execution that spawned this one; the run's id for the run's own row. */
    readonly parent: string | null;
    readonly round: number;
    readonly startedAtMs: number | null;
    readonly finishedAtMs: number | null;
    /** Actions scheduled and not yet settled, newest last; null when none is. */
    readonly running: string | null;
}
/**
 * The activity `runs show` adds to a run.
 *
 * @category models
 * @since 1.0.0
 */
export interface Activity {
    /** When the run last recorded progress; monitor checks do not count. */
    readonly lastProgressAt: number | undefined;
    /** The run's own row first, then live executions, then the latest settled ones. */
    readonly executions: ReadonlyArray<Execution>;
    /** Executions beyond {@link maximumExecutions}, all of them settled. */
    readonly omitted: number;
}
/**
 * The name an operator gave the flow an engine execution runs.
 *
 * @param flowName the execution's engine flow name
 * @param runFlow the flow the run was started from
 * @category rendering
 * @since 1.0.0
 */
export declare const flowNameOf: (flowName: string, runFlow: string) => string;
/**
 * A run's execution view with the plan wrapper named by the run's flow.
 *
 * @category rendering
 * @since 1.0.0
 */
export declare const presentView: <View extends {
    readonly root: {
        readonly flowName: string;
    };
    readonly current: {
        readonly flowName: string;
    };
}>(view: View | undefined, runFlow: string) => View | undefined;
/**
 * Folds a run's events into its execution tree and latest progress.
 *
 * @param events the run's journal, in order
 * @param run the run's id and the flow it was started from
 * @category constructors
 * @since 1.0.0
 */
export declare const fold: (events: ReadonlyArray<ControlSchema.ControlEvent>, run: {
    readonly runId: string;
    readonly flowId: string;
}) => Activity;
/**
 * What a recorded code drift means for resuming the run.
 *
 * @category rendering
 * @since 1.0.0
 */
export declare const driftVerdict: (drift: NonNullable<ControlSchema.RunSummary["codeDrift"]>) => string;
/**
 * A run as `runs show` prints it.
 *
 * @category models
 * @since 1.0.0
 */
export type Shown = Omit<ControlSchema.RunSummary, "codeDrift"> & {
    readonly codeDrift?: NonNullable<ControlSchema.RunSummary["codeDrift"]> & {
        readonly verdict: string;
    };
    readonly executions: ReadonlyArray<Execution>;
    readonly executionsOmitted?: number;
    readonly diagnosis: Forensics.Digest;
};
/**
 * The run `runs show` prints: its flow named in place of the engine wrapper,
 * its last progress as `updatedAt`, its executions, its drift verdict, and a
 * diagnosis whose `endedAt` is absent until the run settles.
 *
 * @param run the observed run
 * @param events the run's journal, in order
 * @category rendering
 * @since 1.0.0
 */
export declare const show: (run: ControlSchema.RunSummary, events: ReadonlyArray<ControlSchema.ControlEvent>) => Shown;
