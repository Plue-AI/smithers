/**
 * Local operator commands for durable step-result heads. The recorded replay
 * ledger is never mutated here.
 * @since 1.0.0
 */
import { Cli } from "incur";
/**
 * Construct the local step-cache operator command tree.
 * @category constructors
 * @since 1.0.0
 */
export declare const createStepCacheCli: () => Cli.Cli<{
    ls: {
        args: {};
        options: {
            root?: string | undefined;
        };
    };
} & {
    show: {
        args: {
            key: string;
        };
        options: {
            root?: string | undefined;
        };
    };
} & {
    evict: {
        args: {
            key: string;
        };
        options: {
            ifRecordedBy: string;
            root?: string | undefined;
        };
    };
} & {
    sweep: {
        args: {};
        options: {
            olderThan: string;
            root?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "steps">;
