/**
 * Configured provider diagnostics.
 * @since 1.0.0
 */
import { Cli, z } from "incur";
declare const entry: z.ZodObject<{
    id: z.ZodString;
    provider: z.ZodEnum<{
        linear: "linear";
        github: "github";
        telegram: "telegram";
    }>;
    tokenEnv: z.ZodOptional<z.ZodString>;
    credentialId: z.ZodOptional<z.ZodString>;
    apiBaseUrl: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
/** One integration's public configuration, containing references rather than tokens.
 * @category models
 * @since 1.0.0
 */
export type Integration = z.infer<typeof entry>;
/** Reads versioned provider configuration, or discovers explicitly configured environment adapters.
 *
 * Every entry is authorized against the host environment, so configuration
 * committed to a repository can only select credentials and provider origins
 * the host itself configured.
 *
 * @category configuration
 * @since 1.0.0
 */
export declare const readIntegrations: (root: string, file?: string, env?: Readonly<Record<string, string | undefined>>) => ReadonlyArray<Integration>;
/** Probes a provider through its real client, returning no credential or provider response body.
 *
 * Re-checks host authorization at the point the credential leaves the process,
 * so a caller holding a hand-built entry cannot reach an unauthorized origin.
 *
 * @category diagnostics
 * @since 1.0.0
 */
export declare const probe: (entry: Integration, token: string, timeoutMs?: number) => Promise<{
    id: string;
    provider: "linear" | "github" | "telegram";
    healthy: boolean;
}>;
/** Builds provider discovery and diagnostics.
 * @category constructors
 * @since 1.0.0
 */
export declare const createIntegrationsCli: () => Cli.Cli<{
    list: {
        args: {};
        options: {
            config: string;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    doctor: {
        args: {
            id?: string | undefined;
        };
        options: {
            config: string;
            offline: boolean;
            timeoutMs: number;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "integrations">;
export {};
