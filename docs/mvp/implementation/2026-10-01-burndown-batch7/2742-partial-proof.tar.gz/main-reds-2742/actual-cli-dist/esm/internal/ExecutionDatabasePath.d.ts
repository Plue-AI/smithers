/**
 * Pure database location shared with the public NodeControl projection.
 * @since 1.0.0
 */
/**
 * Resolves the project's engine.db without opening it.
 * @category constructors
 * @since 1.0.0
 */
export declare const executionDatabasePath: (root: string) => string;
