/**
 * The repository history from the terminal: the coding factory's stack as the
 * app's History card reads it (`GET …/mythical`, D-20), its writes, a TODO
 * filed for the factory, and a watch that follows one issue through the
 * lanes. The watch reads the one item (`GET …/mythical/items/{id|issue}`,
 * which finds it however many items the snapshot's bound leaves out) on
 * every hint from `…/mythical/events`, or on a poll without one. Writes are
 * acknowledged at once; the stack does the work.
 *
 * The words and groups mirror `@smthrs/rpc/StackView` and
 * `@smthrs/rpc/StackIssues`, which this published package cannot depend on;
 * `test/BackendHistory.test.ts` keeps them equal.
 * @since 1.0.0
 */
import { type Values } from "./Client.ts";
import type { Handler } from "./Resources.ts";
/**
 * How long a watch waits for a hint before it reads the snapshot anyway.
 * @private
 * @since 1.0.0
 */
export declare const POLL_MS = 10000;
/**
 * The owner's word for where an item is (`itemStateLabel`).
 * @private
 * @since 1.0.0
 */
export declare const stateLabel: (item: Values) => string;
/**
 * The group an item is listed under (`issueGroupOf`).
 * @private
 * @since 1.0.0
 */
export declare const groupOf: (item: Values) => "needs-you" | "working" | "done";
/**
 * Whether the item is out of the lanes: settled, or its pull request is open (`settled`).
 * @private
 * @since 1.0.0
 */
export declare const outOfLanes: (item: Values) => boolean;
/**
 * One item: `#12 Title · PR open · checks failed: ci · reason · pull request`.
 * @private
 * @since 1.0.0
 */
export declare const itemLine: (item: Values, changes?: ReadonlyArray<unknown>) => string;
/**
 * How long a check ran, as `mythicalReceiptDuration` shows it: `42s`, `1m 04s`, `2h 05m`.
 * @private
 * @since 1.0.0
 */
export declare const checkDuration: (ms: number) => string;
/**
 * Each check receipt on the item's candidate and how long it ran, then the
 * run that recorded them, as the TUI shows them:
 * `✓ affected-lint 1a2b3c4 42s · ✗ affected-test 1a2b3c4 1m 04s · run run-1`.
 * @private
 * @since 1.0.0
 */
export declare const receiptLine: (item: Values) => string;
/**
 * The machine the item's lane runs on, as every surface shows it
 * (`mythicalMachine`): `vm · registry/env:…`, or `container`; "" when its
 * placement was refused or it was never placed.
 * @private
 * @since 1.0.0
 */
export declare const machineLine: (item: Values) => string;
/**
 * The account a lane's latest model call used, and how many more served it
 * (`accountLabel`): `work@example.com +1`, else the provider's name.
 * @private
 * @since 1.0.0
 */
export declare const accountLabel: (account: Values) => string;
/**
 * Model spend in dollars from USD nanos, as the History card shows it: `$0.42`.
 * @private
 * @since 1.0.0
 */
export declare const spendLabel: (nanos: number) => string;
/**
 * How long a lane has worked its item, as the History card's lane row shows
 * it: `4:05`, `1:02:05`; "" for an unreadable stamp.
 * @private
 * @since 1.0.0
 */
export declare const elapsedLabel: (startedAt: string, now: number) => string;
/**
 * Who works the item, as the History card's lane row shows it, then its
 * model spend: `lane 2 · 4:05 · work@example.com +1 · luna · ws1a2b3c · $0.42`.
 * The lane's running time, account, seat and box come from the snapshot's
 * `lanes`; without them (or `now`) the line has the lane and spend alone. An
 * item out of the lanes shows only its spend.
 * @private
 * @since 1.0.0
 */
export declare const workerLine: (item: Values, lanes?: ReadonlyArray<unknown>, now?: number) => string;
/**
 * The History as lines: the stack's state and lanes, then Needs you, Working
 * and Done (the last 24 hours), ordered as the app lists them. Under each
 * item: its check receipts, who works it and its spend, and its machine.
 * @private
 * @since 1.0.0
 */
export declare const render: (value: unknown, now?: number) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const history: Record<string, Handler>;
/**
 * Each history command's human body.
 * @private
 * @since 1.0.0
 */
export declare const humans: Record<string, (value: unknown) => string>;
