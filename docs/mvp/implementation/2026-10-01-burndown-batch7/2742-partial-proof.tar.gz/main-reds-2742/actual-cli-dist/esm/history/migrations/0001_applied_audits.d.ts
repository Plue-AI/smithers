/**
 * The control-side record of which completed time-travel audits have parked
 * their control run.
 * @since 1.0.0
 */
import * as Effect from "effect/Effect";
import * as SqlClient from "effect/unstable/sql/SqlClient";
/**
 * Idempotent: CLIs before this rung created the same table on demand.
 * @category migrations
 * @since 1.0.0
 */
export declare const appliedAudits: Effect.Effect<void, import("effect/unstable/sql/SqlError").SqlError, SqlClient.SqlClient>;
