/**
 * One origin-bound Smithers login, shared by backend and control-plane clients.
 * @since 0.1.0
 */
import { Refused } from "../../CliError.ts";
type RecordValue = Record<string, unknown>;
/**
 * @private
 * @since 1.0.0
 */
export declare const normalizeOrigin: (raw: string) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const observeOrigin: (raw: string) => string;
/**
 * A login token that is empty or holds characters no token has.
 * @private
 * @since 1.0.0-rc.1
 */
export declare const invalidToken: () => Refused;
/**
 * @private
 * @since 1.0.0
 */
export declare class Session {
    readonly home: string;
    readonly configPath: string;
    readonly authPath: string;
    readonly env: Readonly<Record<string, string | undefined>>;
    constructor(env: Readonly<Record<string, string | undefined>>);
    config(effective?: boolean): RecordValue;
    saveConfig(update: RecordValue): void;
    write(path: string, data: string, mode?: number): void;
    target(hostname?: string): {
        api_url: string;
        host: string;
    };
    record(origin: string): RecordValue | undefined;
    keyring(action: "get" | "set" | "delete", host: string, token?: string): Promise<string | undefined>;
    resolve(origin?: string): Promise<{
        token: string;
        source: string;
        api_url: string;
        host: string;
    } | undefined>;
    require(origin?: string): Promise<{
        token: string;
        source: string;
        api_url: string;
        host: string;
    }>;
    save(origin: string, token: string, metadata?: RecordValue): Promise<{
        source: string;
        api_url: string;
        host: string;
    }>;
    clear(origin?: string): Promise<{
        status: string;
        host: string;
        cleared: boolean;
        env_active: boolean;
    }>;
}
export {};
