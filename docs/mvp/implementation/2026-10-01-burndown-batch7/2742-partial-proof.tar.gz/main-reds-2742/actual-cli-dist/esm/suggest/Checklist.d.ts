/**
 * The ordered checklist `smthrs suggest` runs against a repository, and the
 * suggestions it streams.
 *
 * Every check is a small, specific read of the repository: which package
 * manager and scripts it declares, which test runner and lint configuration
 * it carries, whether it has CI files, flows, a `PACKAGE.ts`, a GitHub
 * remote, a monorepo layout, an `AGENTS.md`, a changelog. The checks are
 * deterministic and cost no model call, which is what lets a suggestion be
 * printed the moment its check matches, while the scan continues. The model
 * is spent on the implementation, not on the reading.
 *
 * The order is low-hanging fruit first, then the heavier suggestions. A heavy
 * one is still streamed (a `--json` consumer sees the whole list) but is
 * marked `followUp`, so the interactive pick offers it only after a smaller
 * suggestion has landed.
 *
 * Pure over an injected {@link Repository}, so the whole table is a unit
 * test over an in-memory tree; {@link repository} is the Node reader.
 *
 * @since 1.0.0-rc.0
 */
/**
 * What the checks read.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Repository {
    readonly root: string;
    /** Whether a project-relative path exists. */
    readonly exists: (path: string) => boolean;
    /** The text of a project-relative file, or `undefined` when it cannot be read. */
    readonly read: (path: string) => string | undefined;
    /** The entry names of a project-relative directory; empty when it is not one. */
    readonly list: (path: string) => ReadonlyArray<string>;
}
/**
 * A question offered after a suggestion lands.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface FollowUp {
    readonly id: "ci" | "incremental";
    readonly question: string;
}
/**
 * One way Smithers can help this repository.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Suggestion {
    readonly id: string;
    readonly title: string;
    /** One line, citing the files that triggered it. */
    readonly why: string;
    readonly effort: "small" | "medium" | "large";
    /** Held back from the first pick; offered after a smaller one has landed. */
    readonly followUp: boolean;
    readonly followUps: ReadonlyArray<FollowUp>;
    /** The project-relative files the check read. */
    readonly files: ReadonlyArray<string>;
}
/**
 * The follow-up every implementable suggestion offers.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const followUps: Readonly<Record<FollowUp["id"], FollowUp>>;
/**
 * What the reads found, in the shape the implementation prompt cites.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Evidence {
    readonly packageManager: string | undefined;
    readonly scripts: Readonly<Record<string, string>>;
    readonly testRunner: string | undefined;
    readonly lint: ReadonlyArray<string>;
    readonly ci: ReadonlyArray<string>;
    readonly flows: ReadonlyArray<string>;
    readonly packageFile: boolean;
    readonly github: boolean;
    readonly git: boolean;
    readonly monorepo: ReadonlyArray<string>;
    readonly agentsFile: string | undefined;
    readonly changelog: string | undefined;
    readonly language: ReadonlyArray<string>;
}
/**
 * Reads the facts every check consults, once.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const evidence: (repository: Repository) => Evidence;
/**
 * One entry of the checklist: a check over the evidence that either matches,
 * with the suggestion it makes, or does not.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Rule {
    readonly id: string;
    readonly match: (facts: Evidence, repository: Repository) => Suggestion | undefined;
}
/**
 * The checklist, in the order the scan runs it.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const checks: ReadonlyArray<Rule>;
/**
 * Runs the checklist, yielding each suggestion the moment its check matches.
 *
 * An async generator rather than an array, so a renderer can print the first
 * suggestion before the last check has run and a `--json` consumer reads one
 * document per match as it happens.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare function scan(repository: Repository): AsyncGenerator<Suggestion, void, undefined>;
/**
 * The Node reader over one project root.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const repository: (root: string) => Repository;
/**
 * An in-memory reader, for tests and for the `--json` fixtures.
 *
 * `files` maps project-relative paths to their text; a directory exists when
 * a file lives under it.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const memoryRepository: (root: string, files: Readonly<Record<string, string>>) => Repository;
