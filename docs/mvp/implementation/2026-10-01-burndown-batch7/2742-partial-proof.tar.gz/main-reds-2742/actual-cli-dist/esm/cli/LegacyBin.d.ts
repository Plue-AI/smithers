#!/usr/bin/env node
/**
 * The `smthrs` executable. It builds the CLI application, runs it on the Node
 * runtime, and maps a failed exit to a process exit code.
 *
 * @since 0.1.0
 */
export {};
