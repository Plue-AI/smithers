/** Private control persistence over the selected native SQL adapter.
 * @since 1.0.0
 */
import * as DurableWriter from "@smthrs/database/DurableWriter";
import { FileSystem, Layer, Path } from "effect";
import type { SqlClient } from "effect/unstable/sql/SqlClient";
/** Uses injected filesystem and path services, and opens only the supplied SQL adapter.
 * @since 1.0.0
 * @private
 */
export declare const make: (database: (filename: string) => Layer.Layer<SqlClient>) => (file: string) => Layer.Layer<SqlClient | DurableWriter.DurableWriter, import("effect/PlatformError").PlatformError | import("effect/unstable/sql/SqlError").SqlError | import("effect/unstable/sql/Migrator").MigrationError, Path.Path | FileSystem.FileSystem>;
/** Opens an existing store with the supplied read-only SQL adapter: no directory,
 * migration or permission change.
 * @since 1.0.0
 * @private
 */
export declare const observe: (database: (filename: string) => Layer.Layer<SqlClient>) => (file: string) => Layer.Layer<SqlClient | DurableWriter.DurableWriter, never, never>;
