/**
 * `smthrs gc`: the retention pass over this project's databases, then the
 * artifact pass over its objects directory.
 *
 * `@smthrs/engine-store`'s `Retention` and `ArtifactGc` own what a pass
 * deletes; this module owns which files they run against and how an operator
 * spells the threshold. A project has two databases — the control plane's and
 * the engine's — and a sweep of one without the other leaves half of a
 * deleted run behind. Retention deletes the attempt and cache rows that were
 * the only roots of a spilled output, and nothing else deletes a published
 * blob, so the artifact pass runs in the same verb.
 *
 * @since 1.0.0
 */
import * as ArtifactGc from "@smthrs/engine-store/ArtifactGc";
import * as Retention from "@smthrs/engine-store/Retention";
import { Effect } from "effect";
import * as CliError from "./CliError.ts";
/**
 * How long history is kept when `--older-than` is omitted.
 *
 * Thirty days, because the question a retained run answers is "what did the
 * agent do to this repository", and that question is asked in the weeks after
 * a change lands, not the hours.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const defaultRetention = "30d";
/**
 * Parses a duration such as `30d`, `12h`, or `90m` into milliseconds.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const duration: (value: string) => number | undefined;
/**
 * The databases a sweep runs against, in the order it runs them.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const databases: (root: string) => ReadonlyArray<string>;
/**
 * The content-addressed objects directory the engine spills large outputs
 * into, beside its database.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const objectsDirectory: (root: string) => string;
/**
 * One store the sweep could not collect from, and why: a database it could
 * not open, or an objects directory whose artifact pass failed.
 *
 * @category models
 * @since 1.0.0
 */
export interface Failure {
    readonly database: string;
    readonly reason: string;
}
/**
 * What one sweep did, and what it could not do.
 *
 * @category models
 * @since 1.0.0
 */
export interface Sweep {
    readonly olderThan: string;
    readonly dryRun: boolean;
    readonly reports: ReadonlyArray<Retention.Report>;
    /**
     * The artifact pass over {@link objectsDirectory}. Absent when the project
     * has no objects directory or no engine database, or when the pass failed.
     */
    readonly artifacts?: ArtifactGc.GcReport | undefined;
    /** Stores the sweep could not collect from. Empty on a clean sweep. */
    readonly failures: ReadonlyArray<Failure>;
}
/**
 * Runs the retention pass over every database this project has, then the
 * artifact pass over the engine's objects directory.
 *
 * A project with no `.flows/` reports an empty sweep rather than failing: `gc`
 * on a project that has never run anything is a no-op, not an error. That is
 * the only empty sweep this function reports. A database it could not open is
 * a {@link Failure}, never a report of zero runs: `gc --dry-run` is trusted to
 * name exactly what a real pass would delete, and a locked or corrupt file
 * rendered as `{ runs: [] }` reads as "there is nothing to collect".
 *
 * Every database is PROBED before any of them is written to, and a probe that
 * fails abandons the whole pass. A run owns rows in both files, so sweeping
 * them independently and continuing past a failure could delete a run's
 * control rows and leave its engine rows behind, which no verb afterwards
 * converges. Refusing to start costs the operator a retry; a half-swept run
 * costs them the run. The caller decides the exit status from `failures`.
 *
 * The artifact pass runs last, over the engine database's roots, and only
 * when both the engine database and its objects directory exist. Under
 * `dryRun` it marks from rows retention has not deleted yet, so it can name
 * fewer blobs than the real pass then collects.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const sweep: (root: string, options: {
    readonly olderThan: string;
    readonly dryRun: boolean;
    readonly now?: number | undefined;
}) => Effect.Effect<Sweep, CliError.UsageError>;
/**
 * The stderr paragraph a sweep with failures owes its operator.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const failureMessage: (failures: ReadonlyArray<Failure>) => string;
