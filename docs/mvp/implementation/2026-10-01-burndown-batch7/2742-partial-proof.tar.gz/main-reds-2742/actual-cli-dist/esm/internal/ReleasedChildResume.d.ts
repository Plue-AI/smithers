/**
 * Durable permission for one explicit retry of released native children.
 * @since 1.0.0
 */
import type * as DurableEngineState from "@smthrs/engine-store/DurableEngineState";
import * as Journal from "@smthrs/journal/Journal";
import { Ownership } from "@smthrs/run-store";
import type * as RunStore from "@smthrs/run-store/RunStore";
import { Effect, Schema } from "effect";
/**
 * Existing native and control durability used to bind retries.
 * @since 1.0.0
 * @private
 */
export interface Options {
    readonly engineJournal: Journal.Service;
    readonly controlJournal: Journal.Service;
    readonly engineRuns: RunStore.Service;
    readonly claimant?: Ownership.OwnerId | undefined;
    readonly isAlive?: Ownership.LivenessCheck | undefined;
    readonly engineState: Pick<DurableEngineState.Service, "runChildren">;
}
/**
 * Authorizes the release snapshot once per explicit resume and checks its identity.
 * @since 1.0.0
 * @private
 */
export declare const make: (options: Options) => {
    authorize: (root: string, resumeSequence: number) => Effect.Effect<undefined, Schema.SchemaError | Journal.JournalError | RunStore.RunStoreError, never>;
    canRetryReleased: (executionId: string, root: string) => Effect.Effect<boolean, Schema.SchemaError | Journal.JournalError, never>;
};
