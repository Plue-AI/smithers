/**
 * Durable trigger administration and a Control-backed scheduler host.
 * @since 1.0.0
 */
import * as Scheduler from "@smthrs/triggers/Scheduler";
import * as TriggerStore from "@smthrs/triggers/TriggerStore";
import { Effect, Layer } from "effect";
import { Cli } from "incur";
import { type LocalOptions } from "./Store.ts";
/** Executes one operation against the shared durable trigger store.
 * @category execution
 * @since 1.0.0
 */
export declare const withTriggers: <A, E>(options: LocalOptions, effect: Effect.Effect<A, E, TriggerStore.TriggerStore>) => Promise<A>;
/** Hosts durable polling using the caller's Control service; it never approves a plan.
 * @category layers
 * @since 1.0.0
 */
export declare const layerTriggerScheduler: (root: string, pollIntervalMs?: number) => Layer.Layer<Scheduler.Scheduler, import("effect/PlatformError").PlatformError | import("effect/unstable/sql/SqlError").SqlError | import("effect/unstable/sql/Migrator").MigrationError | import("@smthrs/triggers/TriggerError").TriggerError, import("@smthrs/control/Control").Control>;
/** Builds commands for registration, inspection and durable manual scheduling.
 * @category constructors
 * @since 1.0.0
 */
export declare const createTriggersCli: (runtime?: {
    readonly signal?: AbortSignal | undefined;
}) => Cli.Cli<{
    list: {
        args: {};
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    show: {
        args: {
            id: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    register: {
        args: {
            id?: string | undefined;
        };
        options: {
            input: string;
            overlap: "skip" | "buffer-one" | "supersede";
            catchUp: "all" | "none" | "one";
            maxCatchUp: number;
            enabled: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            file?: string | undefined;
            flow?: string | undefined;
            cron?: string | undefined;
            timezone?: string | undefined;
        };
    };
} & {
    fire: {
        args: {
            id: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
            occurrence?: number | undefined;
        };
    };
} & {
    serve: {
        args: {};
        options: {
            pollIntervalMs: number;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "triggers">;
