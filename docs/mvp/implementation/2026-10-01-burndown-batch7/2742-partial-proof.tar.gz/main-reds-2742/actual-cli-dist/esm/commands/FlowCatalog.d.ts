/**
 * The complete flow catalog, read the same way by `ls`, `flow list`, and
 * `doctor`: from a control plane's pages, or from the local discovery snapshot.
 *
 * @since 1.0.0
 */
import { ControlSchema } from "@smthrs/control";
import type { Service as ControlServiceShape } from "@smthrs/control/Control";
import * as Registry from "@smthrs/registry/Registry";
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
import * as FeaturedFlows from "../internal/FeaturedFlows.ts";
/**
 * One page of the flow listing.
 * @category models
 * @since 1.0.0
 */
export type FlowPage = Extract<ControlSchema.ListResponse, {
    readonly _tag: "flows";
}>;
/**
 * Every page, bounded by the history limits so a runaway registry cannot
 * exhaust the process.
 * @category constructors
 * @since 1.0.0
 */
export declare const read: (control: ControlServiceShape) => Effect.Effect<{
    items: {
        readonly description: string;
        readonly flowId: string;
        readonly inputSchema?: import("effect/Schema").Json | undefined;
    }[];
    warnings: import("@smthrs/registry/Descriptor").DiscoveryWarning[];
}, CliError.UnsupportedError | CliError.ResourceLimitError | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, never>;
/**
 * The project's discovered flows, read from the discovery snapshot without
 * opening the control or execution databases. Reserved `system/*` flows belong
 * to the control plane, which lists them only for an empty registry; every
 * listing hides them and `plan` and `up` refuse them.
 * @category constructors
 * @since 1.0.0
 */
export declare const discovered: Effect.Effect<Pick<FlowPage, "items" | "warnings">, never, Registry.Registry>;
/**
 * The listing document: reserved system flows removed, featured rows applied
 * from the project's generated factory projection when one is checked in,
 * and the homepage's apps when the project declares any.
 * @category constructors
 * @since 1.0.0
 */
export declare const listing: (items: FlowPage["items"], projectRoot: string) => {
    apps?: readonly FeaturedFlows.App[];
    _tag: "flows";
    items: readonly FeaturedFlows.Presented[];
};
