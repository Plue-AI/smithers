/**
 * `smthrs update`: is the installed CLI the current one?
 *
 * The check is a plain registry read of `@smthrs/cli`'s dist-tags and nothing
 * else. rc.0 never installs anything on the operator's behalf: 0.x's
 * self-upgrade path had to know about npm, pnpm, bun, and global versus local
 * installs, and got it wrong often enough that the honest answer is to print
 * the command for the package manager the operator actually uses.
 *
 * A release candidate publishes under the `next` tag, so the comparison is
 * against `next` first and `latest` second: an rc.0 install told about a 0.35
 * `latest` would be told to downgrade.
 *
 * @since 1.0.0
 */
/**
 * The package this CLI ships as.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const packageName = "@smthrs/cli";
/**
 * The registry endpoint the check reads.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const registryUrl = "https://registry.npmjs.org/-/package/@smthrs/cli/dist-tags";
/**
 * What the check found.
 *
 * @category models
 * @since 1.0.0
 */
export interface Status {
    readonly current: string;
    readonly available: string | undefined;
    readonly tag: "next" | "latest" | undefined;
    readonly upToDate: boolean;
    readonly install: string | undefined;
}
/**
 * Whether `candidate` is a later version than `current`, by SemVer 2.0.0
 * precedence.
 *
 * The core compares first. On an equal core a release outranks its own
 * prereleases, so `1.0.0` beats `1.0.0-rc.0`, and two prereleases compare
 * identifier by identifier, so `1.0.0-rc.10` beats `1.0.0-rc.9` and
 * `1.0.0-rc.1.1` beats `1.0.0-rc.1`. Build metadata is ignored.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const isNewer: (candidate: string, current: string) => boolean;
/**
 * Turns a dist-tag document into a status.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const compare: (current: string, tags: Readonly<Record<string, string>>) => Status;
/**
 * The human rendering of a status.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const render: (status: Status) => string;
