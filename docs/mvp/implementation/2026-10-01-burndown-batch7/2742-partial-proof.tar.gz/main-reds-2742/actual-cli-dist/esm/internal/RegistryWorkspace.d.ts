/** Retained workspace bytes keep the project's approved locator identity.
 * @since 1.0.0
 */
import { Registry } from "@smthrs/registry";
import { Layer } from "effect";
/** Private composition: relocation changes loading, never executable identity.
 * @since 1.0.0
 * @private
 */
export declare const layer: (registry: Layer.Layer<Registry.Registry>, identityRoot: string, workspaceRoot: string) => Layer.Layer<Registry.Registry>;
