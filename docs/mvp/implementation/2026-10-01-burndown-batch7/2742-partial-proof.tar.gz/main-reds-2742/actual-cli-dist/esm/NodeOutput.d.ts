/**
 * The node-output projection `smthrs output` and the MCP `get_node_detail`
 * tool both read.
 *
 * A run's journal records every flow call an agent made and how it settled.
 * What an operator asks for afterwards is narrower: "what did that one step
 * produce?" This module is that question, computed from the `ControlEvent`
 * deltas `Control.watch` already serves, so the answer is identical for a
 * local run and a `--remote` one and no command reaches past the control
 * plane into a store.
 *
 * A node's identity is `<flowName>#<ordinal>`, the ordinal counting that
 * flow's distinct calls within the run from 1. Durable `callId` joins starts
 * and settlements; legacy name/FIFO matching applies only to idless starts.
 * Repeated identified lifecycle events do not renumber later nodes.
 * The public node identity is stable for a settled
 * run — the journal is append-only and the ordinal is its order — which is
 * what a reference in a report or a follow-up command needs. The reserved id
 * `result` names the run's final assistant output.
 *
 * @since 1.0.0
 */
import type { ControlSchema } from "@smthrs/control";
/**
 * The reserved node id for the run's final output.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const resultNodeId = "result";
/**
 * One node's recorded output.
 *
 * @category models
 * @since 1.0.0
 */
export interface Node {
    readonly nodeId: string;
    readonly flowName: string;
    /** Durable dispatch identity; absent on legacy journal records. */
    readonly callId?: string | undefined;
    readonly outcome: "success" | "failure" | "pending";
    readonly input?: unknown;
    readonly value?: unknown;
    readonly message?: string | undefined;
    readonly startedAt?: number | undefined;
    readonly settledAt?: number | undefined;
    /**
     * The sequence of the event that started this call, and of the one that
     * settled it.
     *
     * Ordinals are assigned within one projection, so they only mean the same
     * thing across two projections of the same events. A delta reader that
     * projected a filtered slice to find what changed renumbered the second
     * `bash` call as `bash#1` and then read the first call's output. Carrying
     * the sequences lets a caller ask what moved after a cursor from the ONE
     * run-wide projection instead.
     */
    readonly startedSequence?: number | undefined;
    readonly settledSequence?: number | undefined;
}
/**
 * Projects a run's events into its node outputs, in the order they started.
 *
 * A call that started and never settled is reported `pending` rather than
 * dropped: a run that died mid-call is exactly when an operator asks what the
 * last step was doing.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const project: (events: ReadonlyArray<ControlSchema.ControlEvent>) => ReadonlyArray<Node>;
/**
 * Finds one node by id.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const find: (events: ReadonlyArray<ControlSchema.ControlEvent>, nodeId: string) => Node | undefined;
/**
 * The message printed when a node id names nothing, listing what the run has.
 *
 * An operator who guessed a node id needs the real ones, and a run with no
 * recorded calls at all is a different problem than a mistyped id.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const notFound: (runId: string, nodeId: string, nodes: ReadonlyArray<Node>) => string;
/**
 * The human rendering of one node: its outcome line, then its value.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const render: (node: Node) => string;
