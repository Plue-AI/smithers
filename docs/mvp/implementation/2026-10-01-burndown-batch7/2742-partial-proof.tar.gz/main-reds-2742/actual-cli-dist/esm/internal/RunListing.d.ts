/**
 * The one run-listing request `ps`, `runs list`, and `runs count` build from
 * their filter flags, so a count always matches the listing it describes.
 *
 * @since 1.0.0
 */
import { Control as ControlService, ControlSchema } from "@smthrs/control";
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
/**
 * The listing's filter flags as a command receives them.
 *
 * @category models
 * @since 1.0.0
 */
export interface Filters {
    readonly flow?: string | undefined;
    readonly status?: ControlSchema.RunStatus | undefined;
    readonly since?: string | undefined;
    readonly until?: string | undefined;
    readonly sort?: "newest" | "oldest" | undefined;
    readonly parent?: string | undefined;
    readonly trigger?: string | undefined;
}
/**
 * A `runs` listing request.
 *
 * @category models
 * @since 1.0.0
 */
export type Request = Extract<ControlSchema.ListRequest, {
    readonly _tag: "runs";
}>;
/**
 * The creation-time sort orders a listing accepts.
 *
 * @category models
 * @since 1.0.0
 */
export declare const sorts: readonly ["newest", "oldest"];
/**
 * Reads an epoch millisecond or an ISO 8601 date/time.
 *
 * @category parsing
 * @since 1.0.0
 */
export declare const instant: (flag: string, value: string) => Effect.Effect<number, CliError.UsageError>;
/**
 * Builds the listing request for `filters`, plus the page to read.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const request: (filters: Filters, page?: {
    readonly limit?: number | undefined;
    readonly cursor?: string | undefined;
}) => Effect.Effect<Request, CliError.UsageError>;
/**
 * Counts every run `listing` selects by walking its pages at the largest size.
 *
 * @category combinators
 * @since 1.0.0
 */
export declare const count: (listing: Request) => Effect.Effect<number, import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, ControlService.Control>;
/**
 * Names what an unclaimed run waits for, in the field that already carries it.
 *
 * `RunSummary.waitingReason` is "what a parked run is holding on". This one
 * holds on an executor, and before the label a listing showed it as an
 * ordinary `accepted` run, indistinguishable from one a live peer owns.
 *
 * @category combinators
 * @since 1.0.0
 */
export declare const label: (listed: ControlSchema.ListResponse, now: number) => Effect.Effect<ControlSchema.ListResponse>;
