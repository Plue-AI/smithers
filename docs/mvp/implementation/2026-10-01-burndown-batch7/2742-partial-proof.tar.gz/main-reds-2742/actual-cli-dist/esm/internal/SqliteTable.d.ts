/**
 * Table presence probe for databases this package reads but does not own.
 * @since 1.0.0
 */
import type { DatabaseSync } from "node:sqlite";
/**
 * Whether `db` holds a table named `name`.
 * @category predicates
 * @since 1.0.0
 */
export declare const hasTable: (db: DatabaseSync, name: string) => boolean;
