/**
 * Persistent memory administration over the same store used by agent runs.
 *
 * @since 1.0.0
 */
import * as MemoryStore from "@smthrs/memory/MemoryStore";
import { Effect } from "effect";
import { Cli } from "incur";
import { type LocalOptions } from "./Store.ts";
/**
 * Runs an operation against the authoritative local memory store.
 * @category constructors
 * @since 1.0.0
 */
export declare const withMemory: <A, E>(options: LocalOptions & {
    readonly namespace?: string | undefined;
    readonly id?: string | undefined;
}, effect: Effect.Effect<A, E, MemoryStore.MemoryStore>) => Promise<A>;
/**
 * Builds the fact, note, thread, message, and recall commands.
 * @category constructors
 * @since 1.0.0
 */
export declare const createMemoryCli: () => Cli.Cli<{
    list: {
        args: {};
        options: {
            namespace: string;
            limit: number;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
            prefix?: string | undefined;
        };
    };
} & {
    get: {
        args: {
            key: string;
        };
        options: {
            namespace: string;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    set: {
        args: {
            key: string;
            value: string;
        };
        options: {
            namespace: string;
            valueJson: boolean;
            tag: string[];
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
            ttlMs?: number | undefined;
        };
    };
} & {
    rm: {
        args: {
            key: string;
        };
        options: {
            namespace: string;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    recall: {
        args: {
            query: string;
        };
        options: {
            namespace: string;
            method: "keyword" | "fts";
            bank: string[];
            maxTokens: number;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    compact: {
        args: {
            thread: string;
        };
        options: {
            summary: string;
            before: number;
            keep: number;
            dryRun: boolean;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    "notes add": {
        args: {
            text: string;
        };
        options: {
            namespace: string;
            status: "pending" | "accepted" | "rejected";
            tag: string[];
            supersedes: string[];
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
            noteId?: string | undefined;
        };
    };
    "notes list": {
        args: {};
        options: {
            namespace: string;
            limit: number;
            status: "pending" | "accepted" | "any" | "rejected";
            includeSuperseded: boolean;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "notes status": {
        args: {
            note: string;
            status: "pending" | "accepted" | "rejected";
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "notes supersede": {
        args: {
            note: string;
            replacement: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "notes get": {
        args: {
            note: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    "threads list": {
        args: {};
        options: {
            namespace: string;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "threads create": {
        args: {};
        options: {
            namespace: string;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
            title?: string | undefined;
            threadId?: string | undefined;
        };
    };
    "threads rm": {
        args: {
            thread: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "threads show": {
        args: {
            thread: string;
        };
        options: {
            namespace: string;
            limit: number;
            id?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    "messages add": {
        args: {
            thread: string;
            text: string;
        };
        options: {
            role: "user" | "system" | "assistant" | "tool";
            messageId?: string | undefined;
            at?: number | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
    "messages list": {
        args: {
            thread: string;
        };
        options: {
            limit: number;
            afterId?: string | undefined;
            afterAt?: number | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "memory">;
