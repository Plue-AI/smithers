/**
 * Deterministic rendering for the CLI projection.
 *
 * @since 0.1.0
 */
import { Context, Effect, Layer } from "effect";
import * as CliError from "./CliError.ts";
/**
 * The two stable renderings exposed by CLI handlers.
 *
 * Choose `human` for readable indentation and `json` for compact machine
 * output. Rendering refuses executable or unbounded values before writing.
 *
 * @category models
 * @since 0.1.0
 */
export type Format = "human" | "json";
/**
 * Text ready for stdout together with the status the process should publish.
 *
 * Handlers consume this result instead of inferring status from serialized
 * text. `text` is always a string, including for top-level `undefined`.
 *
 * @category models
 * @since 0.1.0
 */
export interface Rendered {
    readonly text: string;
    readonly exitCode: number;
}
/**
 * The rendering service consumed by command handlers.
 *
 * Reach for this service at the presentation boundary. It snapshots inert
 * data, normalizes explicitly supported scalar values, and refuses executable
 * or unbounded structures with a path-specific error.
 *
 * @category services
 * @since 0.1.0
 */
export interface Service {
    readonly render: (value: unknown, format: Format) => Effect.Effect<Rendered, CliError.RenderingError>;
}
declare const Output_base: Context.ServiceClass<Output, "/cli/Output", Service>;
/**
 * Context key for the CLI rendering service.
 *
 * Platform compositions provide it once for every handler. A missing service
 * is a composition defect surfaced by Effect before output is written.
 *
 * @category services
 * @since 0.1.0
 */
export declare class Output extends Output_base {
}
declare const RenderValueTypeId: unique symbol;
interface RenderValue {
    readonly [RenderValueTypeId]: true;
    readonly value: unknown;
}
/**
 * Marks caller-controlled data as output, never as a control receipt.
 *
 * Use this around values read from memory or projected from a run. It keeps
 * receipt-shaped user data from changing the process status.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const renderValue: (value: unknown) => RenderValue;
/**
 * Maximum object/array nesting accepted by one render.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const maximumDepth = 128;
/**
 * Maximum enumerable data members accepted by one render.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const maximumMembers = 10000;
/**
 * Maximum UTF-8 bytes written by one rendered document.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const maximumOutputBytes: number;
/**
 * Renders a decoded value in a deterministic human or machine form.
 *
 * Construct this service for platform layers and focused tests. Only inert
 * plain data crosses the boundary; executable and oversized inputs fail with
 * a stable code and path before any output is written.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const make: () => Service;
/**
 * Default deterministic output layer.
 *
 * Use it when no platform-specific exit-code transfer is needed. Construction
 * is infallible; a missing layer is reported as an Effect service requirement.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layer: Layer.Layer<Output, never, never>;
/**
 * Maps validated control receipts to process status codes.
 *
 * Call this only at the output boundary. Non-receipts, including objects with
 * receipt-like field names, return zero; malformed values never throw.
 *
 * @category getters
 * @since 0.1.0
 */
export declare const exitCode: (value: unknown) => number;
export {};
