/**
 * `smthrs egress`: a repository's egress allowlist (#2653). Its owner lists
 * the hosts the repository's sandboxes may reach besides the deployment's own
 * list, allows one more or denies one again; every running sandbox of the
 * repository reloads the new list. Each write names only its own host, so two
 * owners writing at once never undo each other (#3263).
 * @since 1.0.0
 */
import type { Handler } from "./Resources.ts";
/** @private
 * @since 1.0.0
 */
export declare const egress: Record<string, Handler>;
