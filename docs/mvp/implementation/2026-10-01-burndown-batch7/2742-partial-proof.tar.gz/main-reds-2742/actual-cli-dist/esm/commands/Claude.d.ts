/**
 * `smthrs claude`: the Claude Code mirror's tick, node-wait, monitor, and
 * subscription verbs, as an Effect CLI command group.
 *
 * @since 1.0.0
 */
import { Control as ControlService } from "@smthrs/control";
import { Effect } from "effect";
import { type Argument, Command } from "effect/unstable/cli";
import * as CliError from "../CliError.ts";
import { Output } from "../Output.ts";
/**
 * What the command group borrows from the root tree it is composed into.
 * @category models
 * @since 1.0.0
 */
export interface Options<E, R> {
    /** The shared pre-handler every verb runs first. */
    readonly guard: Effect.Effect<void, E, R>;
    /** A required positional argument, with the tree's fallback prompt. */
    readonly required: (name: string) => Argument.Argument<string>;
}
/**
 * The `claude` command group.
 * @category constructors
 * @since 1.0.0
 */
export declare const make: <E, R>({ guard, required }: Options<E, R>) => Command.Command<"claude", {}, {}, CliError.UsageError | CliError.ResourceLimitError | CliError.RenderingError | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict | E, ControlService.Control | Output | Exclude<Exclude<R, "effect/unstable/cli/GlobalFlag/log-level">, Command.CommandContext<"claude">>>;
