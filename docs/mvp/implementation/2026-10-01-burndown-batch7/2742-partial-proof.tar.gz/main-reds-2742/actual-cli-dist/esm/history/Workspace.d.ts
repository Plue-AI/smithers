/** Durable workspace routing shared by the CLI and every engine host.
 * @since 1.0.0
 */
/** Undefined means a fork has not finished linking its retained workspace.
 * @category getters
 * @since 1.0.0
 */
export declare const workspaceFor: (root: string, runId: string) => Promise<string | undefined>;
/** Only the host bound to a committed workspace identity may execute its run.
 * @category guards
 * @since 1.0.0
 */
export declare const canExecute: (root: string, workspace: string, runId: string) => Promise<boolean>;
