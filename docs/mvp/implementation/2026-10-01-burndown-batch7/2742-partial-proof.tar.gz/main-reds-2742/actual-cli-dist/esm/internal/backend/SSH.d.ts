/**
 * Validated SSH transport.
 * @since 0.1.0
 */
import type { Readable } from "node:stream";
import type { Client } from "./Client.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const quote: (text: string) => string;
/**
 * A workspace SSH endpoint as the authenticated API answers it: the command and
 * the gateway host keys (`algorithm base64`) it advertises.
 *
 * @private
 * @since 1.0.0
 */
export interface Endpoint {
    readonly command: string;
    readonly hostKeys: ReadonlyArray<string>;
}
/**
 * The advertised host keys of an API `/ssh` response, validated as
 * `algorithm base64` pairs.
 *
 * @private
 * @since 1.0.0
 */
export declare const hostKeys: (value: unknown) => Array<string>;
/**
 * @private
 * @since 1.0.0
 */
export declare const sshArgs: (c: Client, endpoint: Endpoint, tty?: boolean) => Promise<Array<string>>;
/**
 * @private
 * @since 1.0.0
 */
export declare const remote: (c: Client, endpoint: Endpoint, script: string | undefined, timeout?: number, input?: Readable, interactive?: boolean, stream?: boolean) => Promise<{
    code: number;
    stdout: Buffer;
    stderr: Buffer;
}>;
