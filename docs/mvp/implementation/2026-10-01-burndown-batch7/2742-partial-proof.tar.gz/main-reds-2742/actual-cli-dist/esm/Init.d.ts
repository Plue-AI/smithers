/**
 * `smthrs init`: the smallest project a flow can be run from.
 *
 * rc.0 scaffolds one thing, a markdown flow at `flows/<name>/flow.mdx`, and
 * makes one edit, adding `.flows/` to the repository's ignore file. The 0.x
 * ceremony, interactive agent selection, a workflow pack, a global
 * `~/.smithers` install, and skill installation as a side effect, is gone: seats
 * resolve from environment keys, and every side effect a command performs
 * without being asked is a side effect an operator has to undo.
 *
 * The one thing the scaffold reads from the host is its seat. `smthrs up`
 * cannot run a prompt flow that declares none, so a scaffold without a
 * `model:` line is a scaffold that is not launchable, which is what rc.0 first
 * shipped (release rehearsal). {@link defaultSeat} chooses it from
 * the same environment keys `smthrs doctor` reports.
 *
 * The ignore edit is idempotent and repository-scoped, carried over from the
 * 0.x `ensureRootGitignore` requirement: append once, never inside a
 * non-repository directory, and never a second time when a rule already
 * covers the path.
 *
 * @since 1.0.0
 */
import * as Environment from "./Environment.ts";
/**
 * The ignore rule rc.0 state needs.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const ignoreRule = ".flows/";
/**
 * What one ignore-file edit did.
 *
 * @category models
 * @since 1.0.0
 */
export type IgnoreStatus = "created" | "updated" | "unchanged" | "skipped";
/**
 * Explains why a proposed flow name cannot be used by `init`.
 *
 * Reach for this before presenting a usage error. It accepts one portable path
 * segment from the documented character set and otherwise returns a sentence
 * safe to show to the operator without creating any project state.
 *
 * @category validation
 * @since 1.0.0-rc.0
 */
export declare const nameProblem: (name: string) => string | undefined;
/**
 * Whether a scaffold name passes {@link nameProblem}.
 *
 * Use this predicate when only a boolean is needed. Invalid input returns
 * `false`; callers that need the refusal sentence should use `nameProblem`.
 *
 * @category predicates
 * @since 1.0.0-rc.0
 */
export declare const isValidName: (name: string) => boolean;
/**
 * Whether a directory is the root of a repository whose ignore file is worth
 * editing.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const isRepository: (root: string, exists?: (path: string) => boolean) => boolean;
/**
 * Adds `.flows/` to the repository ignore file, once.
 *
 * Outside a git or jj repository this reports `skipped` and writes nothing: a
 * `.gitignore` in a directory that is not a repository is litter.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const ensureIgnored: (root: string) => IgnoreStatus;
/**
 * The seat a scaffold declares, and the credential that chose it.
 *
 * @category models
 * @since 1.0.0
 */
export interface Seat {
    /** The `model:` line's value. */
    readonly seat: string;
    /** The environment variable that resolves it. */
    readonly variable: string;
    /** Whether that variable is set in the environment `init` read. */
    readonly resolved: boolean;
}
/**
 * The seat `smthrs init` writes into the scaffold.
 *
 * rc.0 resolves seats from environment keys, so the scaffold's seat is chosen
 * from the same keys `smthrs doctor` reports, in doctor's order. An `openai`
 * seat is credentialed by `OPENAI_API_KEY` or by the ChatGPT session
 * `SMITHERS_OPENAI_AUTH=chatgpt` selects, exactly as `NodeControl.seatResolver`
 * reads them.
 *
 * A directory with no provider key still gets a `model:` line. A scaffold
 * without one is not launchable at all: `smthrs up` on it answered `Run
 * run-1 was accepted but the executor did not take it` and left a run nothing
 * would ever drive (release rehearsal). With the line, the same
 * launch refuses by naming the key to set.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const defaultSeat: (environment: Environment.Source) => Seat;
/**
 * The scaffolded flow body.
 *
 * Markdown, not TypeScript: `flow.mdx` needs no build step, no import
 * resolution, and no dependency on the package layout of the project it lands
 * in, so `smthrs flow start <name>` works in the directory `init` just created.
 *
 * The seat is a frontmatter comment rather than prose, because every line of
 * the markdown body below the frontmatter is an instruction the agent is
 * handed.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const template: (name: string, seat: Seat) => string;
/**
 * What `smthrs init` created.
 *
 * @category models
 * @since 1.0.0
 */
export interface Scaffolded {
    readonly name: string;
    readonly flowFile: string;
    readonly created: boolean;
    readonly gitignore: IgnoreStatus;
    /** The state directory this project's runs will use. */
    readonly stateDirectory: string;
    /** The model seat the scaffolded flow declares. */
    readonly seat: string;
}
/**
 * Scaffolds `flows/<name>/flow.mdx` and ignores `.flows/`.
 *
 * An existing flow file is left exactly as it is: `init` is a starting point,
 * not an overwrite, and a second `init` in a project that already has flows
 * must not destroy one.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const scaffold: (root: string, name: string, environment: Environment.Source) => Scaffolded;
/**
 * The default flow name, taken from the project directory.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const defaultName: (root: string) => string;
