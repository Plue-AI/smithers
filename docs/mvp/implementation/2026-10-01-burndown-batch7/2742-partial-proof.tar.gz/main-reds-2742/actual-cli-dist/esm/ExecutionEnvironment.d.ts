/**
 * Persistent execution locations shared by command consumers, including the TUI.
 * Profiles contain locations, never tool credentials. Tools keep their own login
 * and sessions in the selected machine's home.
 * @since 1.0.0
 */
/**
 * The caller's process configuration.
 *
 * @category models
 * @since 1.0.0
 */
export type Source = Readonly<Record<string, string | undefined>>;
/**
 * An existing execution location; contains no tool credentials.
 *
 * @category models
 * @since 1.0.0
 */
export interface Profile {
    readonly name: string;
    readonly transport: "local" | "ssh" | "workspace";
    readonly destination?: string | undefined;
    readonly directory: string;
    readonly home?: string | undefined;
}
/**
 * Terminal, cancellation, and forwarding controls for one invocation.
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    readonly terminal?: boolean | undefined;
    readonly signal?: AbortSignal | undefined;
    readonly forward?: {
        readonly localPort: number;
        readonly remotePort: number;
    } | undefined;
}
/**
 * The process and isolated transport environment to execute.
 *
 * @category models
 * @since 1.0.0
 */
export interface Plan {
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly cwd?: string | undefined;
    readonly environment: Source;
}
/**
 * The location registry for this caller.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const registryPath: (source: Source) => string;
/**
 * Read validated execution locations without creating a registry.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const list: (source: Source) => Promise<ReadonlyArray<Profile>>;
/**
 * Resolve a saved execution location by name.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const get: (name: string, source: Source) => Promise<Profile>;
/**
 * Save a new location without replacing an existing name.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const add: (profile: Profile, source: Source) => Promise<Profile>;
/**
 * Forget a location without deleting its files or compute.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const remove: (name: string, source: Source) => Promise<void>;
/**
 * Assemble a command without opening a shell on the caller's machine. SSH uses
 * the caller's known_hosts, or the Cloud API's authenticated advertised keys.
 * @category constructors
 * @since 1.0.0
 */
export declare const plan: (profile: Profile, argv: ReadonlyArray<string>, source: Source, options?: Options) => Promise<Plan>;
/**
 * Execute with inherited terminal I/O. Cancellation stops the local process
 * group; a remote command has SSH's connection lifecycle, not a durable receipt.
 * @category constructors
 * @since 1.0.0
 */
export declare const run: (profile: Profile, argv: ReadonlyArray<string>, source: Source, options?: Options) => Promise<number>;
