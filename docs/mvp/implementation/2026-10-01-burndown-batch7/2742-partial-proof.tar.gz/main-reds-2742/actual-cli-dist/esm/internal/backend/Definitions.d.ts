/** Backend command schemas, owned by the npm CLI.
 * @since 0.1.0
 */
import { z } from "incur";
/** @private
 * @since 0.1.0
 */
export declare const definitions: {
    readonly "admin alerts channels add": {
        readonly description: "Add an alert channel";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            type: z.ZodEnum<{
                email: "email";
                sms: "sms";
                pagerduty: "pagerduty";
                webhook: "webhook";
            }>;
            "display-name": z.ZodString;
            target: z.ZodString;
            route: z.ZodEnum<{
                all: "all";
                critical: "critical";
            }>;
        }, z.core.$strip>;
    };
    readonly "admin alerts channels list": {
        readonly description: "List alert channels";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin alerts channels remove": {
        readonly description: "Remove an alert channel";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin alerts channels send-code": {
        readonly description: "Send a verification code to an alert channel";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin alerts channels set-route": {
        readonly description: "Choose which alerts a channel receives";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            route: z.ZodEnum<{
                all: "all";
                critical: "critical";
            }>;
        }, z.core.$strip>;
    };
    readonly "admin alerts channels verify": {
        readonly description: "Verify an alert channel with its code";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            code: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "admin alerts policies disable": {
        readonly description: "Turn off an alert policy";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin alerts policies enable": {
        readonly description: "Turn on an alert policy";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin alerts policies list": {
        readonly description: "List alert policies";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin analytics summary": {
        readonly description: "Summarize product usage over a time range";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            "include-synthetic": z.ZodDefault<z.ZodBoolean>;
            range: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "admin audit list": {
        readonly description: "List audit log entries";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            since: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "admin deploys observe list": {
        readonly description: "List Observe deployments";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin deploys observe redeploy": {
        readonly description: "Redeploy an Observe deployment";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin deploys observe restart": {
        readonly description: "Restart an Observe deployment";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin deploys observe rollback": {
        readonly description: "Roll back an Observe deployment";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin deploys platform list": {
        readonly description: "List platform components";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin deploys platform rollback": {
        readonly description: "Roll a platform component back to a revision";
        readonly args: z.ZodObject<{
            component: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            revision: z.ZodString;
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin deploys platform status": {
        readonly description: "Show a platform component's deployment status";
        readonly args: z.ZodObject<{
            component: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin health": {
        readonly description: "System health status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin runs list": {
        readonly description: "List workflow runs in a repository";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodString;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "admin sessions cancel": {
        readonly description: "Cancel an agent session";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            reason: z.ZodOptional<z.ZodString>;
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin sessions list": {
        readonly description: "List agent sessions";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            "include-synthetic": z.ZodDefault<z.ZodBoolean>;
            limit: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            status: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "admin status": {
        readonly description: "Show system status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin tokens list": {
        readonly description: "List access tokens";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            "expiring-days": z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            limit: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            scope: z.ZodOptional<z.ZodString>;
            "unused-days": z.ZodOptional<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "admin user create": {
        readonly description: "Create a user";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            username: z.ZodString;
            email: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "admin user delete": {
        readonly description: "Suspend a user and mark it deleted; keeps its data";
        readonly args: z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin user erase": {
        readonly description: "Erase a user's data; keeps billing records";
        readonly args: z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            "request-date": z.ZodString;
            "user-id": z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin user export": {
        readonly description: "Download a user's data as a tar.gz archive";
        readonly args: z.ZodObject<{
            username: z.ZodString;
            out: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin user disable": {
        readonly description: "Suspend a user";
        readonly args: z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin user enable": {
        readonly description: "Lift a user's suspension";
        readonly args: z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "admin user list": {
        readonly description: "List all users";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "admin users set-synthetic": {
        readonly description: "Mark a user as synthetic or not";
        readonly args: z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            value: z.ZodEnum<{
                true: "true";
                false: "false";
            }>;
        }, z.core.$strip>;
    };
    readonly "admin workspaces list": {
        readonly description: "List workspaces";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            "include-synthetic": z.ZodDefault<z.ZodBoolean>;
            kind: z.ZodOptional<z.ZodString>;
            limit: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            owner: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "admin workspaces stop": {
        readonly description: "Stop a workspace";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "admin workspaces suspend": {
        readonly description: "Suspend a workspace";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "agent ask": {
        readonly description: "Talk to the local Smithers usage helper";
        readonly args: z.ZodObject<{
            prompt: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "agent chat": {
        readonly description: "Send a message to an existing remote conversation";
        readonly args: z.ZodObject<{
            id: z.ZodString;
            message: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            provider: z.ZodDefault<z.ZodEnum<{
                smithers: "smithers";
                codex: "codex";
            }>>;
            repo: z.ZodOptional<z.ZodString>;
            transport: z.ZodDefault<z.ZodEnum<{
                http: "http";
                workflow: "workflow";
            }>>;
        }, z.core.$strip>;
    };
    readonly "agent list": {
        readonly description: "List remote conversations";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            "per-page": z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "agent run": {
        readonly description: "Start a remote conversation and run a prompt";
        readonly args: z.ZodObject<{
            prompt: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            provider: z.ZodDefault<z.ZodEnum<{
                smithers: "smithers";
                codex: "codex";
            }>>;
            repo: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            transport: z.ZodDefault<z.ZodEnum<{
                http: "http";
                workflow: "workflow";
            }>>;
        }, z.core.$strip>;
    };
    readonly "agent session chat": {
        readonly description: "Send a message to an existing remote conversation";
        readonly args: z.ZodObject<{
            id: z.ZodString;
            message: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            provider: z.ZodDefault<z.ZodEnum<{
                smithers: "smithers";
                codex: "codex";
            }>>;
            repo: z.ZodOptional<z.ZodString>;
            transport: z.ZodDefault<z.ZodEnum<{
                http: "http";
                workflow: "workflow";
            }>>;
        }, z.core.$strip>;
    };
    readonly "agent session list": {
        readonly description: "List remote conversations";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            "per-page": z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "agent session run": {
        readonly description: "Start a remote conversation and run a prompt";
        readonly args: z.ZodObject<{
            prompt: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            provider: z.ZodDefault<z.ZodEnum<{
                smithers: "smithers";
                codex: "codex";
            }>>;
            repo: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            transport: z.ZodDefault<z.ZodEnum<{
                http: "http";
                workflow: "workflow";
            }>>;
        }, z.core.$strip>;
    };
    readonly "agent session view": {
        readonly description: "View a remote conversation";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "agent view": {
        readonly description: "View a remote conversation";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly api: {
        readonly description: "Make raw API calls to the Smithers server";
        readonly args: z.ZodObject<{
            endpoint: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            method: z.ZodDefault<z.ZodString>;
            field: z.ZodOptional<z.ZodArray<z.ZodString>>;
            header: z.ZodOptional<z.ZodArray<z.ZodString>>;
            input: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "artifact download": {
        readonly description: "Download an artifact from a workflow run";
        readonly args: z.ZodObject<{
            runId: z.ZodCoercedNumber<unknown>;
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            output: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "artifact list": {
        readonly description: "List artifacts for a workflow run";
        readonly args: z.ZodObject<{
            runId: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth connect": {
        readonly description: "Connect an Anthropic API key (--api-key) for your own agent runs on a self-hosted server. Vendor subscriptions stay with their own CLIs; sign into Codex on the workspace with codex login --device-auth";
        readonly args: z.ZodObject<{
            provider: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            label: z.ZodOptional<z.ZodString>;
            "api-key": z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "auth connections": {
        readonly description: "List connected subscriptions";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            org: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth local bootstrap": {
        readonly description: "Create and log in as the installation owner";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            hostname: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth local login": {
        readonly description: "Log in to an owner backend";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            hostname: z.ZodOptional<z.ZodString>;
            username: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth local status": {
        readonly description: "Show owner setup status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            hostname: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth login": {
        readonly description: "Log in to Smithers";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            admin: z.ZodDefault<z.ZodBoolean>;
            host: z.ZodOptional<z.ZodString>;
            hostname: z.ZodOptional<z.ZodString>;
            observe: z.ZodDefault<z.ZodBoolean>;
            ttl: z.ZodOptional<z.ZodString>;
            "with-token": z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "auth logout": {
        readonly description: "Log out of Smithers";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            hostname: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth revoke": {
        readonly description: "Revoke a connected subscription";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "auth status": {
        readonly description: "Show authentication status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            hostname: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "auth token": {
        readonly description: "Show token status without displaying the credential";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            hostname: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "bookmark create": {
        readonly description: "Create a bookmark";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            change: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "bookmark delete": {
        readonly description: "Delete a bookmark";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "bookmark list": {
        readonly description: "List local bookmarks";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "cache clear": {
        readonly description: "Clear workflow caches for a repository";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            bookmark: z.ZodOptional<z.ZodString>;
            key: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "cache connect": {
        readonly description: "Connect this workspace to the Smithers Cloud build cache: mint a public read token and declare it in the root PACKAGE.ts";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            workspace: z.ZodDefault<z.ZodString>;
            write: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "cache list": {
        readonly description: "List workflow caches for a repository";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            bookmark: z.ZodOptional<z.ZodString>;
            key: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "cache stats": {
        readonly description: "Show workflow cache statistics for a repository";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "cache token create": {
        readonly description: "Mint a public read token: it can only read this repository's build cache and is safe to commit";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            name: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "cache token list": {
        readonly description: "List the repository's active public read tokens";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "cache token revoke": {
        readonly description: "Revoke a public read token by id";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            id: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "change conflicts": {
        readonly description: "List conflicts in a change";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "change diff": {
        readonly description: "Show diff for a change";
        readonly args: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "change files": {
        readonly description: "List files in a change";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "change list": {
        readonly description: "List changes";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "change show": {
        readonly description: "Show a specific change";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "changeset create": {
        readonly description: "Create a changeset that pins one change per member repository";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            org: z.ZodString;
            member: z.ZodDefault<z.ZodArray<z.ZodString>>;
            description: z.ZodDefault<z.ZodString>;
            parent: z.ZodDefault<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "changeset get": {
        readonly description: "Show a changeset";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            org: z.ZodString;
            id: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "changeset land": {
        readonly description: "Land a changeset: every member change, then the superproject commit, as one transaction";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            org: z.ZodString;
            id: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "changeset list": {
        readonly description: "List an organization's changesets";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            org: z.ZodString;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly completion: {
        readonly description: "Generate shell completions";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "config get": {
        readonly description: "Get a config value by key";
        readonly args: z.ZodObject<{
            key: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "config list": {
        readonly description: "List all config values";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "config set": {
        readonly description: "Set a config value by key";
        readonly args: z.ZodObject<{
            key: z.ZodString;
            value: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "config show": {
        readonly description: "Show effective configuration with env var overrides and source information";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "egress allow": {
        readonly description: "Let the repository's sandboxes reach a host";
        readonly args: z.ZodObject<{
            host: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "egress deny": {
        readonly description: "Take a host off the repository's egress allowlist";
        readonly args: z.ZodObject<{
            host: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "egress list": {
        readonly description: "List the hosts the repository's sandboxes may reach";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history backfill": {
        readonly description: "Admit every open issue to the history now";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history bootstrap": {
        readonly description: "Create the history from main's commits";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history parallel": {
        readonly description: "Set how many lanes work at once";
        readonly args: z.ZodObject<{
            lanes: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history land": {
        readonly description: "Land a proposed TODO's pull request once its review approves and CI is green";
        readonly args: z.ZodObject<{
            issue: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history retry": {
        readonly description: "Give a blocked, rejected or declined issue a fresh set of attempts";
        readonly args: z.ZodObject<{
            issue: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history show": {
        readonly description: "Show the history: each issue's lane, checks and pull request";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history todo": {
        readonly description: "File a TODO for the factory";
        readonly args: z.ZodObject<{
            title: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodDefault<z.ZodString>;
            request: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "history watch": {
        readonly description: "Follow one issue until its pull request is open or it stops";
        readonly args: z.ZodObject<{
            issue: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue close": {
        readonly description: "Close an issue";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            comment: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue comment": {
        readonly description: "Add a comment to an issue";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodString;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue create": {
        readonly description: "Create an issue";
        readonly args: z.ZodObject<{
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            assignee: z.ZodOptional<z.ZodString>;
            body: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue edit": {
        readonly description: "Edit an issue";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            assignee: z.ZodOptional<z.ZodString>;
            body: z.ZodOptional<z.ZodString>;
            label: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue list": {
        readonly description: "List issues";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            all: z.ZodDefault<z.ZodBoolean>;
            cursor: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            state: z.ZodDefault<z.ZodEnum<{
                fixed: "fixed";
                all: "all";
                open: "open";
                closed: "closed";
                verified: "verified";
            }>>;
            view: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue reopen": {
        readonly description: "Reopen an issue";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue view": {
        readonly description: "View an issue";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "issue views": {
        readonly description: "List the repository's saved issue views";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "label create": {
        readonly description: "Create a label";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            color: z.ZodDefault<z.ZodString>;
            description: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "label delete": {
        readonly description: "Delete a label";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "label list": {
        readonly description: "List labels";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land checks": {
        readonly description: "View landing request checks";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land comment": {
        readonly description: "Add a comment to a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodString;
            commit: z.ZodString;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land conflicts": {
        readonly description: "View landing request conflicts";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land create": {
        readonly description: "Create a landing request";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            title: z.ZodString;
            body: z.ZodDefault<z.ZodString>;
            change: z.ZodOptional<z.ZodString>;
            "change-id": z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            stack: z.ZodDefault<z.ZodBoolean>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land edit": {
        readonly description: "Edit a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land land": {
        readonly description: "Land (merge) a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            commit: z.ZodString;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land list": {
        readonly description: "List landing requests";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            all: z.ZodDefault<z.ZodBoolean>;
            cursor: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            state: z.ZodDefault<z.ZodEnum<{
                all: "all";
                open: "open";
                closed: "closed";
                merged: "merged";
                landed: "landed";
            }>>;
        }, z.core.$strip>;
    };
    readonly "land review": {
        readonly description: "Submit a review on a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            commit: z.ZodString;
            approve: z.ZodDefault<z.ZodBoolean>;
            body: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "land view": {
        readonly description: "View a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "notification list": {
        readonly description: "List notifications";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            all: z.ZodDefault<z.ZodBoolean>;
            cursor: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            unread: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "notification read": {
        readonly description: "Mark a notification as read";
        readonly args: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            all: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "org create": {
        readonly description: "Create an organization";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodDefault<z.ZodString>;
            visibility: z.ZodDefault<z.ZodEnum<{
                private: "private";
                public: "public";
                limited: "limited";
            }>>;
        }, z.core.$strip>;
    };
    readonly "org edit": {
        readonly description: "Update organization settings";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            visibility: z.ZodDefault<z.ZodEnum<{
                "": "";
                private: "private";
                public: "public";
                limited: "limited";
            }>>;
        }, z.core.$strip>;
    };
    readonly "org list": {
        readonly description: "List organizations for the authenticated user";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org member add": {
        readonly description: "Add a member to an organization";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org member list": {
        readonly description: "List members in an organization";
        readonly args: z.ZodObject<{
            org: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org member remove": {
        readonly description: "Remove a member from an organization";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team create": {
        readonly description: "Create a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodDefault<z.ZodString>;
            permission: z.ZodDefault<z.ZodEnum<{
                read: "read";
                write: "write";
                admin: "admin";
            }>>;
        }, z.core.$strip>;
    };
    readonly "org team delete": {
        readonly description: "Delete a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team edit": {
        readonly description: "Update a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            permission: z.ZodDefault<z.ZodEnum<{
                "": "";
                read: "read";
                write: "write";
                admin: "admin";
            }>>;
        }, z.core.$strip>;
    };
    readonly "org team list": {
        readonly description: "List teams in an organization";
        readonly args: z.ZodObject<{
            org: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team member add": {
        readonly description: "Add a user to a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team member list": {
        readonly description: "List members in a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team member remove": {
        readonly description: "Remove a user from a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
            username: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team repo add": {
        readonly description: "Grant a team access to a repository";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team repo list": {
        readonly description: "List repositories assigned to a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team repo remove": {
        readonly description: "Remove a repository from a team";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org team view": {
        readonly description: "View team details";
        readonly args: z.ZodObject<{
            org: z.ZodString;
            team: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "org view": {
        readonly description: "View organization details";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo archive": {
        readonly description: "Archive a repository";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo clone": {
        readonly description: "Clone a repository";
        readonly args: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            rest: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            "clone-arg": z.ZodDefault<z.ZodArray<z.ZodString>>;
            directory: z.ZodOptional<z.ZodString>;
            protocol: z.ZodDefault<z.ZodEnum<{
                "": "";
                https: "https";
                ssh: "ssh";
            }>>;
        }, z.core.$strip>;
    };
    readonly "repo connect": {
        readonly description: "Connect this jj repository to a public GitHub repository";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo create": {
        readonly description: "Create a new repository";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodDefault<z.ZodString>;
            private: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "repo delete": {
        readonly description: "Delete a repository";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "repo disconnect": {
        readonly description: "Disconnect this repository from Smithers";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo edit": {
        readonly description: "Edit repository settings";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            description: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            private: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "repo fork": {
        readonly description: "Fork a repository";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            organization: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "repo home": {
        readonly description: "List remote homepage blocks in server order using the saved login; local smthrs flow list reads checkout flows";
        readonly args: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "repo list": {
        readonly description: "List your repositories";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "repo mirror-sync": {
        readonly description: "Start a GitHub mirror sync run";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "repo push": {
        readonly description: "Push this checkout to your own ref on Smithers Cloud for a workspace to fetch";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            delete: z.ZodDefault<z.ZodBoolean>;
            list: z.ZodDefault<z.ZodBoolean>;
            name: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            "working-copy": z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "repo status": {
        readonly description: "Show local repository connection status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo report": {
        readonly description: "Read the registration report another account recorded for a public repository at its current commit, without analysing it again; prints cached: false when there is none";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            workspace: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "repo transfer": {
        readonly description: "Transfer repository ownership";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            to: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "repo unarchive": {
        readonly description: "Unarchive a repository";
        readonly args: z.ZodObject<{
            repo: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "repo view": {
        readonly description: "View repository details";
        readonly args: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run cancel": {
        readonly description: "Cancel a workflow run";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run list": {
        readonly description: "List workflow runs";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run logs": {
        readonly description: "Stream logs for a workflow run";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run rerun": {
        readonly description: "Rerun a workflow";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run view": {
        readonly description: "View a workflow run";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "run watch": {
        readonly description: "Watch a workflow run in real-time (streams logs, status changes, and completion)";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "search code": {
        readonly description: "Search code";
        readonly args: z.ZodObject<{
            query: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "search issues": {
        readonly description: "Search issues";
        readonly args: z.ZodObject<{
            query: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "search repos": {
        readonly description: "Search repositories";
        readonly args: z.ZodObject<{
            query: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "search users": {
        readonly description: "Search users";
        readonly args: z.ZodObject<{
            query: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "secret bind": {
        readonly description: "Set the hosts and headers a secret may be sent to; none unbinds it";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            header: z.ZodDefault<z.ZodArray<z.ZodString>>;
            host: z.ZodDefault<z.ZodArray<z.ZodString>>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "secret delete": {
        readonly description: "Delete a secret";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "secret list": {
        readonly description: "List secrets";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "secret set": {
        readonly description: "Set a secret";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            "body-stdin": z.ZodDefault<z.ZodBoolean>;
            header: z.ZodDefault<z.ZodArray<z.ZodString>>;
            host: z.ZodDefault<z.ZodArray<z.ZodString>>;
            "main-only": z.ZodDefault<z.ZodBoolean>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "secret scope": {
        readonly description: "Limit a secret to trusted runs on the default bookmark, or give it to every run";
        readonly args: z.ZodObject<{
            name: z.ZodString;
            scope: z.ZodEnum<{
                all: "all";
                "main-only": "main-only";
            }>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "ssh-key add": {
        readonly description: "Add an SSH key";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            title: z.ZodString;
            key: z.ZodString;
        }, z.core.$strip>;
    };
    readonly "ssh-key delete": {
        readonly description: "Delete an SSH key";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "ssh-key list": {
        readonly description: "List SSH keys";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "stack land": {
        readonly description: "Land approved stack PRs from the bottom and re-stack remaining changes";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            all: z.ZodDefault<z.ZodBoolean>;
            change: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "stack status": {
        readonly description: "Show stack status with PR, review, and CI state";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "stack submit": {
        readonly description: "Create or update linked GitHub pull requests from the local jj stack";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            draft: z.ZodDefault<z.ZodBoolean>;
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "stack sync": {
        readonly description: "Sync stack with merged PRs, rebase remaining changes, and refresh PR tables";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "stack unsubmit": {
        readonly description: "Close stacked PRs, delete smithers remote branches, and remove stack mapping";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly status: {
        readonly description: "Show working copy status";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{}, z.core.$strip>;
    };
    readonly "variable delete": {
        readonly description: "Delete a variable";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "variable get": {
        readonly description: "Get a variable value";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "variable list": {
        readonly description: "List variables";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "variable set": {
        readonly description: "Set a variable";
        readonly args: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodString;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "webhook create": {
        readonly description: "Create a webhook";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            url: z.ZodString;
            active: z.ZodDefault<z.ZodBoolean>;
            events: z.ZodDefault<z.ZodArray<z.ZodString>>;
            repo: z.ZodOptional<z.ZodString>;
            "secret-stdin": z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "webhook delete": {
        readonly description: "Delete a webhook";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "webhook deliveries": {
        readonly description: "View delivery history for a webhook";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            replay: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "webhook list": {
        readonly description: "List webhooks";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "webhook update": {
        readonly description: "Update a webhook";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            active: z.ZodOptional<z.ZodBoolean>;
            events: z.ZodDefault<z.ZodArray<z.ZodString>>;
            repo: z.ZodOptional<z.ZodString>;
            "secret-stdin": z.ZodDefault<z.ZodBoolean>;
            url: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "webhook view": {
        readonly description: "View webhook details and recent deliveries";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "wiki create": {
        readonly description: "Create a wiki page";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            title: z.ZodString;
            body: z.ZodDefault<z.ZodString>;
            path: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            slug: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki delete": {
        readonly description: "Delete a wiki page";
        readonly args: z.ZodObject<{
            slug: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki edit": {
        readonly description: "Edit a wiki page";
        readonly args: z.ZodObject<{
            slug: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            body: z.ZodOptional<z.ZodString>;
            "expected-revision": z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            path: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            slug: z.ZodOptional<z.ZodString>;
            title: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki history": {
        readonly description: "List a wiki page's history by page id, renames and the deletion included";
        readonly args: z.ZodObject<{
            "page-id": z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki index": {
        readonly description: "Show a space's navigation index: pages with tags and backlinks, folders, tags";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki list": {
        readonly description: "List wiki pages";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            query: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki revisions": {
        readonly description: "List revisions for a wiki page";
        readonly args: z.ZodObject<{
            slug: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki search": {
        readonly description: "Search wiki pages by title, slug, and body content";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            query: z.ZodString;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "wiki view": {
        readonly description: "View a wiki page";
        readonly args: z.ZodObject<{
            slug: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            visibility: z.ZodOptional<z.ZodEnum<{
                private: "private";
                public: "public";
            }>>;
        }, z.core.$strip>;
    };
    readonly "workflow dispatch": {
        readonly description: "Trigger a workflow";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            input: z.ZodDefault<z.ZodArray<z.ZodString>>;
            ref: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workflow list": {
        readonly description: "List workflows";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workflow run": {
        readonly description: "Run a workflow by name";
        readonly args: z.ZodObject<{
            workflow: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            input: z.ZodDefault<z.ZodArray<z.ZodString>>;
            ref: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workflow watch": {
        readonly description: "Watch a workflow run in real-time";
        readonly args: z.ZodObject<{
            id: z.ZodCoercedNumber<unknown>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace children list": {
        readonly description: "List a workspace's children";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            workspace: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace children spawn": {
        readonly description: "Spawn children of a running workspace";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            count: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            profile: z.ZodOptional<z.ZodEnum<{
                small: "small";
                build: "build";
            }>>;
            repo: z.ZodOptional<z.ZodString>;
            ttl: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            workspace: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace children stop": {
        readonly description: "Stop a workspace's child";
        readonly args: z.ZodObject<{
            child: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            workspace: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace cp": {
        readonly description: "Copy files or directories between the local machine and a workspace";
        readonly args: z.ZodObject<{
            src: z.ZodString;
            dst: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            timeout: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            user: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace create": {
        readonly description: "Create a workspace";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            allow: z.ZodDefault<z.ZodArray<z.ZodString>>;
            cpus: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            disk: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            idleTimeout: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            image: z.ZodOptional<z.ZodString>;
            kind: z.ZodOptional<z.ZodEnum<{
                container: "container";
                vm: "vm";
                desktop: "desktop";
            }>>;
            memory: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
            name: z.ZodDefault<z.ZodString>;
            network: z.ZodOptional<z.ZodString>;
            ref: z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            service: z.ZodDefault<z.ZodArray<z.ZodString>>;
            snapshot: z.ZodOptional<z.ZodString>;
            wait: z.ZodDefault<z.ZodBoolean>;
            waitTimeout: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "workspace delete": {
        readonly description: "Delete a workspace";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            yes: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>;
    };
    readonly "workspace exec": {
        readonly description: "Run a workspace command with a durable receipt and bounded output";
        readonly args: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            command: z.ZodString;
            cwd: z.ZodOptional<z.ZodString>;
            detach: z.ZodDefault<z.ZodBoolean>;
            env: z.ZodDefault<z.ZodArray<z.ZodString>>;
            "exec-id": z.ZodOptional<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
            seedAgentAuth: z.ZodOptional<z.ZodString>;
            timeout: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "workspace fork": {
        readonly description: "Fork a workspace";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            name: z.ZodDefault<z.ZodString>;
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace issue": {
        readonly description: "Spin up a workspace for an issue, run Claude Code, then create a landing request";
        readonly args: z.ZodObject<{
            number: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
            target: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace list": {
        readonly description: "List workspaces";
        readonly args: z.ZodObject<{}, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace shell": {
        readonly description: "Open an interactive terminal in a workspace via the WebSocket terminal endpoint";
        readonly args: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            cols: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
            repo: z.ZodOptional<z.ZodString>;
            rows: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strip>;
    };
    readonly "workspace snapshots": {
        readonly description: "List workspace snapshots";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace ssh": {
        readonly description: "SSH into a workspace (creates one if none exists for the repo)";
        readonly args: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace view": {
        readonly description: "View workspace details (status, SSH info, persistence)";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
    readonly "workspace watch": {
        readonly description: "Watch a workspace for real-time status updates";
        readonly args: z.ZodObject<{
            id: z.ZodString;
        }, z.core.$strip>;
        readonly options: z.ZodObject<{
            repo: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
    };
};
