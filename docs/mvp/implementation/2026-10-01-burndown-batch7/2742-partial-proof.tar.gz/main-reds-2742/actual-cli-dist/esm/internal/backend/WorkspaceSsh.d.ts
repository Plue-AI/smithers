/**
 * The canonical workspace SSH transport, shared by CLI control and Cloud sandboxes.
 * @since 1.0.0
 */
/**
 * Resolves a fresh SSH grant with advertised host keys pinned. The optional
 * signal cancels the public API read and SSH-readiness polling.
 * @private
 * @since 1.0.0
 */
export declare const workspaceSshPrefix: (environment: Readonly<Record<string, string | undefined>>, reference: string, signal?: AbortSignal) => Promise<Array<string>>;
