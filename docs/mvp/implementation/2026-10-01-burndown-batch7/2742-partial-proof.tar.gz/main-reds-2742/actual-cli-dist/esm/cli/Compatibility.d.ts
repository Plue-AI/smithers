/**
 * Hidden transition aliases; canonical commands are the only advertised surface.
 * @since 1.0.0
 */
import * as Argv from "./Argv.ts";
/**
 * Route only unambiguous old spellings, retaining their existing output contracts.
 * @category constructors
 * @since 1.0.0
 */
export declare const legacyArguments: (input: ReadonlyArray<string> | Argv.Globals) => Array<string> | undefined;
/**
 * Modern log formatting and pagination use the canonical streaming command.
 * @category parsing
 * @since 1.0.0
 */
export declare const formattedLogArguments: (input: ReadonlyArray<string> | Argv.Globals) => Array<string> | undefined;
/**
 * Bots using familiar flat spellings get canonical Incur results and next actions.
 * Explicit legacy JSON/quiet/backend contracts and internal protocols stay intact.
 * @category parsing
 * @since 1.0.0
 */
export declare const agentArguments: (input: ReadonlyArray<string> | Argv.Globals) => Array<string> | undefined;
