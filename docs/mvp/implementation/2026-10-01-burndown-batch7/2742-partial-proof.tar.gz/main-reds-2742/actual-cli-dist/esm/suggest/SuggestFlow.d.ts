/**
 * The bundled flow `smthrs suggest` runs to implement one suggestion, and the
 * Node composition it runs under.
 *
 * One model-backed step: the brief in, an {@link Implemented} out. The agent
 * writes through the standard filesystem flows over a kernel-guarded
 * filesystem pinned to the project root, with no shell, so the promise the
 * verb makes ("writes files and never commits") is enforced by the grant
 * store rather than asserted by a prompt sentence: `.git/` and `.flows/` are
 * denied, every other path under the root is allowed, and nothing else
 * exists.
 *
 * The composition mirrors `@smthrs/migrate`'s `Layers`: the deterministic
 * half (the scan) never enters here, the credentialed half runs through the
 * CLI's own seat resolver so the seat this verb chose is exactly a seat
 * `smthrs up` can run, and a scripted composition replaces only the model.
 *
 * @since 1.0.0-rc.0
 */
import * as NodeServices from "../../vendor/node/NodeServices.js";
import * as Agent from "@smthrs/agent/Agent";
import * as AgentAction from "@smthrs/agent/AgentAction";
import * as Budget from "@smthrs/agent/Budget";
import * as QuotaPolicy from "@smthrs/agent/QuotaPolicy";
import * as Seat from "@smthrs/agent/Seat";
import * as SeatResolver from "@smthrs/agent/SeatResolver";
import * as SeatRouter from "@smthrs/agent/SeatRouter";
import { FlowEngine } from "@smthrs/engine";
import { Action, Flow } from "@smthrs/flow";
import type * as Sandbox from "@smthrs/harness/Sandbox";
import { Permission } from "@smthrs/kernel";
import type * as Evaluator from "@smthrs/model/Evaluator";
import type * as Model from "@smthrs/model/Model";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
/**
 * What the agent hands back: the files it wrote, the command that runs them,
 * and what a reader should know first.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export declare const Implemented: Schema.Struct<{
    readonly files: Schema.$Array<Schema.String>;
    readonly command: Schema.String;
    readonly notes: Schema.String;
}>;
/**
 * The decoded answer of one implementation.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export type Implemented = typeof Implemented.Type;
/**
 * The seat role the action declares. The composition maps it onto the seat
 * the verb chose; no model id appears in this module.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const seat = "suggest";
/**
 * How many cell frames one implementation gets before the step fails.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const maxFrames = 40;
/**
 * The sandbox budget every cell runs under.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const limits: Sandbox.Limits;
/**
 * The implementing step: one brief in, one {@link Implemented} out.
 *
 * @category actions
 * @since 1.0.0-rc.0
 */
export declare const implement: AgentAction.AgentAction<"smthrs/suggest-v1/Implement", Schema.Struct<{
    brief: Schema.String;
}>, Schema.Struct<{
    readonly files: Schema.$Array<Schema.String>;
    readonly command: Schema.String;
    readonly notes: Schema.String;
}>>;
/**
 * The flow id, as the journal records it.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const tag = "smthrs/suggest-v1";
/**
 * The bundled flow: exactly the implementing step.
 *
 * @category flows
 * @since 1.0.0-rc.0
 */
export declare const flow: Flow.Flow<"smthrs/suggest-v1", Schema.Struct<{
    brief: Schema.String;
}>, Schema.Struct<{
    readonly files: Schema.$Array<Schema.String>;
    readonly command: Schema.String;
    readonly notes: Schema.String;
}>, Schema.Union<readonly [typeof import("@smthrs/harness/StructuredOutput").StructuredOutputFailure, typeof Seat.SeatUnresolved, typeof Seat.SeatUnrouted, typeof Budget.BudgetExceeded, typeof Budget.Skipped, typeof import("@smthrs/harness/HarnessError").HarnessError, typeof import("@smthrs/plugin").PluginError]>, Action.Requirement<"smthrs/suggest-v1/Implement">>;
/**
 * The action implementation and the flow registration.
 *
 * @category layers
 * @since 1.0.0-rc.0
 */
export declare const layer: Layer.Layer<Action.Implementations | Action.Requirement<"smthrs/suggest-v1/Implement">, never, import("effect/Crypto").Crypto | import("@smthrs/flow/FlowRuntime").FlowRuntime | Evaluator.Evaluator | Sandbox.Sandbox | import("@smthrs/harness/Steering").Source | Budget.Budget | QuotaPolicy.QuotaClassifier | Agent.Agent | SeatResolver.SeatResolver | AgentAction.Host>;
/**
 * The capability envelope the step runs under. Wider than the confinement,
 * for the reason `@smthrs/migrate`'s `Transform.envelope` gives: the envelope
 * has to subsume what the standard filesystem flows declare, and the grant
 * rules below are what actually bound the writes.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const envelope: ReadonlyArray<string>;
/**
 * The permission rules one implementation runs under: the project tree, the
 * model calls, and a denial of every filesystem action under `.git/` and
 * `.flows/`. No `proc:spawn` at all: the step writes files and runs nothing.
 *
 * @category combinators
 * @since 1.0.0-rc.0
 */
export declare const rules: (root: string) => ReadonlyArray<Permission.Rule>;
declare const RelativeRoot_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "/suggest/RelativeRoot";
} & Readonly<A>;
/**
 * A root that is not absolute builds grant patterns that match nothing, so it
 * is refused before any layer is built.
 *
 * @category errors
 * @since 1.0.0-rc.0
 */
export declare class RelativeRoot extends RelativeRoot_base<{
    readonly root: string;
    readonly message: string;
}> {
    constructor(root: string);
}
/**
 * The spend ceiling one implementation runs under.
 *
 * Not unbounded, and not an approved plan envelope either: this verb is run
 * by hand and there is no control-plane card to read a budget off, so the
 * ceiling is declared here. It is what one suggestion is worth on someone
 * else's subscription, and the latency ceiling is the same wall clock
 * {@link limits} gives the sandbox, so neither half of the step can outlive
 * the other.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const budget: Budget.Policy;
/**
 * What a Node host needs told.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface NodeConfig {
    /** Explicit offline judge; otherwise select the gateway before acquiring resources. */
    readonly evaluator?: Layer.Layer<Evaluator.Evaluator> | undefined;
    readonly root: string;
    /** The `provider:model` seat the role resolves to. */
    readonly seat: string;
    readonly environment: Readonly<Record<string, string | undefined>>;
}
/**
 * Everything an implementation needs on Node, including the credentialed
 * half: the CLI's own seat resolver, so the seat the verb chose is exactly
 * what `smthrs up` would run.
 *
 * @category layers
 * @since 1.0.0-rc.0
 */
export declare const layerNode: (config: NodeConfig) => Layer.Layer<import("@smthrs/flow/FlowRuntime").FlowRuntime | Action.Implementations | Evaluator.Evaluator | FlowEngine.SnapshotBoundary | Sandbox.Sandbox | import("@smthrs/harness/Steering").Source | Budget.Budget | QuotaPolicy.QuotaClassifier | Agent.Agent | SeatRouter.Catalog | SeatResolver.SeatResolver | AgentAction.Host | NodeServices.NodeServices | Action.Requirement<"smthrs/suggest-v1/Implement">, Sandbox.SandboxError | Budget.ConfigurationError | RelativeRoot, never>;
/**
 * The cell a scripted model answers one frame with.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export type Script = (asked: string) => string;
/**
 * Ends a scripted cell with the value the declared output schema expects.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const done: (output: Implemented) => string;
/**
 * A model that answers every frame with one scripted cell.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const scriptedModel: (script: Script) => Model.Model;
/**
 * The production composition with the model scripted: the guarded
 * filesystem, the grant store, the envelope, and the sandbox are real.
 *
 * @category layers
 * @since 1.0.0-rc.0
 */
export declare const layerScripted: (config: {
    readonly root: string;
    readonly script: Script;
    readonly environment?: Readonly<Record<string, string | undefined>>;
}) => Layer.Layer<import("@smthrs/flow/FlowRuntime").FlowRuntime | Action.Implementations | Evaluator.Evaluator | FlowEngine.SnapshotBoundary | Sandbox.Sandbox | import("@smthrs/harness/Steering").Source | Budget.Budget | QuotaPolicy.QuotaClassifier | Agent.Agent | SeatRouter.Catalog | SeatResolver.SeatResolver | AgentAction.Host | NodeServices.NodeServices | Action.Requirement<"smthrs/suggest-v1/Implement">, Sandbox.SandboxError | Budget.ConfigurationError | RelativeRoot, never>;
/**
 * Runs the flow over one brief.
 *
 * The execution id is unique per start: the composition uses an in-memory
 * engine, and one implementation is one run.
 *
 * @category execution
 * @since 1.0.0-rc.0
 */
export declare const run: (brief: string) => Effect.Effect<{
    readonly files: readonly string[];
    readonly command: string;
    readonly notes: string;
}, Schema.SchemaError | import("@smthrs/flow/FlowRuntime").FlowCycleDetected | import("@smthrs/harness/HarnessError").HarnessError | import("@smthrs/plugin").PluginError | Budget.BudgetExceeded | Budget.Skipped | Seat.SeatUnresolved | Seat.SeatUnrouted | import("@smthrs/harness/StructuredOutput").StructuredOutputFailure, import("effect/Crypto").Crypto | import("@smthrs/flow/FlowRuntime").FlowRuntime | Action.Requirement<"smthrs/suggest-v1/Implement">>;
/**
 * One sentence for a failed implementation.
 *
 * A tagged failure reads as its class and its own sentence. Anything nobody
 * designed a sentence for (a runtime bug, a Node system error, a thrown
 * string) reads as the generic sentence; its raw text is detail, not a
 * sentence.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const failureMessage: (error: unknown) => string;
type Complete<L> = [L] extends [Layer.Layer<infer _A, infer _E, infer R>] ? [R] extends [never] ? true : false : false;
type Expect<T extends true> = T;
/**
 * Each composition root above owes nothing at the layer level.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export type CompositionRootsAreComplete = [
    Expect<Complete<ReturnType<typeof layerNode>>>,
    Expect<Complete<ReturnType<typeof layerScripted>>>
];
export {};
