/**
 * The pre-handler every canonical verb owes, whichever entry it arrives through.
 *
 * `Command.ts` reads these values from the Effect CLI's shared flags and the
 * Incur tree reads them from its typed connection options. Both call here, so
 * a notice or refusal cannot depend on which parser a verb was typed into.
 *
 * @since 1.0.0
 */
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
import * as Environment from "../Environment.ts";
/**
 * The shared values a verb is checked against.
 * @category models
 * @since 1.0.0
 */
export interface Options {
    /** The hidden `--backend` flag; the Incur tree never declares it. */
    readonly backend?: string | undefined;
    readonly environment?: Environment.Source | undefined;
}
/**
 * The notices alone, for `doctor`, which reports an unsupported backend as a
 * check instead of refusing before the report exists.
 * @category constructors
 * @since 1.0.0
 */
export declare const notices: (options: Options) => Effect.Effect<void>;
/**
 * The notices and the unsupported-backend refusal every other verb applies
 * before it opens durable services.
 * @category constructors
 * @since 1.0.0
 */
export declare const guard: (options: Options) => Effect.Effect<void, CliError.UnsupportedError>;
