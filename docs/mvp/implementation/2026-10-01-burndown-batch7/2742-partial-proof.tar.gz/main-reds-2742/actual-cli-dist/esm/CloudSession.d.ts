/**
 * The signed-in Smithers Cloud session, for hosts other than the CLI: the
 * terminal UI reads the factory's issue list with it. The token comes from
 * where `smthrs auth login` put it (`SMITHERS_TOKEN`, then the keyring, the
 * auth file, the config), and the origin from `SMITHERS_API_ORIGIN` or the
 * configured `api_origin`. Nothing here stores or prints a token.
 *
 * @since 1.0.0
 */
/**
 * An authenticated Cloud origin.
 *
 * @category models
 * @since 1.0.0
 */
export interface Cloud {
    readonly origin: string;
    /** GETs `path` (starting `/api/`) as the signed-in person; resolves the parsed JSON body. */
    readonly get: (path: string, signal?: AbortSignal) => Promise<unknown>;
    /** POSTs the JSON `body` to `path` (starting `/api/`) as the signed-in person; resolves the parsed JSON body. */
    readonly post: (path: string, body: unknown, signal?: AbortSignal) => Promise<unknown>;
}
/**
 * The signed-in session, or undefined when there is no origin or no login.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const signedIn: (env: Readonly<Record<string, string | undefined>>) => Promise<Cloud | undefined>;
/**
 * The Cloud repository a checkout names, `owner/name`, from its git or jj
 * remote the way `smthrs open` reads it; undefined when no remote names one.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const repository: (directory: string, env: Readonly<Record<string, string | undefined>>) => string | undefined;
