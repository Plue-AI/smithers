/**
 * Repository operations and scoped checkout transfer through the backend API.
 * @since 0.1.0
 */
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const gitAuth: (origin: string, token: string) => NodeJS.ProcessEnv;
/**
 * @private
 * @since 1.0.0
 */
export declare const repositories: Record<string, Handler>;
