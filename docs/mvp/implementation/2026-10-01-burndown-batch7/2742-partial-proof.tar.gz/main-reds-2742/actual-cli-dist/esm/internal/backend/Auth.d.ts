/**
 * Browser consent, owner login and subscription connections for the npm CLI.
 * @since 0.1.0
 */
import { type Client, type Values } from "./Client.ts";
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const browserLogin: (c: Client, origin: string, admin: boolean, ttl: string, launch?: (url: string) => void, timeout?: number) => Promise<Values>;
/**
 * @private
 * @since 1.0.0
 */
export declare const auth: Record<string, Handler>;
