/**
 * Public fixed-suite evaluation commands.
 *
 * @since 1.0.0
 */
import type { RuntimeConfig } from "@smthrs/build-cli/Cli";
import { Cli } from "incur";
/**
 * Builds the fixed-suite evaluation command group.
 * @category constructors
 * @since 1.0.0
 */
export declare const createEvalCli: (runtime?: RuntimeConfig) => Cli.Cli<{
    list: {
        args: {};
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    run: {
        args: {
            suite: string;
        };
        options: {
            runId?: string | undefined;
            at?: string | undefined;
            trials?: number | undefined;
            k?: number | undefined;
            output?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    baseline: {
        args: {
            run: string;
        };
        options: {
            force: boolean;
            output?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    compare: {
        args: {
            run: string;
        };
        options: {
            baseline?: string | undefined;
            mean?: number | undefined;
            min?: number | undefined;
            output?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "eval">;
