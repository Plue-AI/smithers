/**
 * File-backed evaluation commands over the public fixed-suite APIs.
 *
 * @since 1.0.0
 */
import type { RuntimeConfig } from "@smthrs/build-cli/Cli";
import { CaseExecutor, Gate, Regression, Runner, Suite } from "@smthrs/evals";
import type { ScorerError } from "@smthrs/scorers/ScorerError";
import { Effect, Layer } from "effect";
import { z } from "incur";
import type * as Environment from "../Environment.ts";
/**
 * Executable suite modules export this value as default, or export its two fields.
 * @category models
 * @since 1.0.0
 */
export interface EvaluationModule {
    readonly suite: Suite.Suite | Promise<Suite.Suite> | Effect.Effect<Suite.Suite, unknown>;
    readonly executor: CaseExecutor.Service;
}
/**
 * Project selection accepted by local evaluation operations.
 * @category models
 * @since 1.0.0
 */
export interface Options {
    readonly root?: string | undefined;
    readonly remote?: string | undefined;
}
/**
 * Resolves the local project root and refuses remote execution.
 * @category constructors
 * @since 1.0.0
 */
export declare const localRoot: (options: Options, environment?: Environment.Source) => string;
/**
 * Discovery does not import modules or run any suite/executor code.
 * @category constructors
 * @since 1.0.0
 */
export declare const list: (root: string) => Promise<{
    name: string;
    file: string;
}[]>;
/**
 * Loads and validates one discovered evaluation module.
 * @category constructors
 * @since 1.0.0
 */
export declare const load: (root: string, selector: string, runtime?: RuntimeConfig) => Promise<{
    readonly file: string;
    readonly suite: Suite.Suite;
    readonly executor: CaseExecutor.Service;
}>;
/**
 * Artifacts intentionally exclude executable flow/scorer objects.
 * @category schemas
 * @since 1.0.0
 */
export declare const RunArtifact: z.ZodObject<{
    version: z.ZodLiteral<1>;
    runId: z.ZodString;
    suite: z.ZodString;
    cases: z.ZodArray<z.ZodObject<{
        case: z.ZodString;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strip>>;
        observations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"score">;
            score: z.ZodNumber;
            case: z.ZodString;
            scorer: z.ZodString;
            scorerName: z.ZodOptional<z.ZodString>;
            stepKey: z.ZodString;
            at: z.ZodString;
            reason: z.ZodOptional<z.ZodString>;
            meta: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"inconclusive">;
            reason: z.ZodString;
            case: z.ZodString;
            scorer: z.ZodString;
            scorerName: z.ZodOptional<z.ZodString>;
            stepKey: z.ZodString;
            at: z.ZodString;
            meta: z.ZodOptional<z.ZodUnknown>;
        }, z.core.$strip>], "kind">>;
        trials: z.ZodOptional<z.ZodObject<{
            n: z.ZodNumber;
            passes: z.ZodNumber;
            rate: z.ZodNumber;
            passAt1: z.ZodNumber;
            passAtK: z.ZodNumber;
            passHatK: z.ZodNumber;
            stderr: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    observations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"score">;
        score: z.ZodNumber;
        case: z.ZodString;
        scorer: z.ZodString;
        scorerName: z.ZodOptional<z.ZodString>;
        stepKey: z.ZodString;
        at: z.ZodString;
        reason: z.ZodOptional<z.ZodString>;
        meta: z.ZodOptional<z.ZodUnknown>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"inconclusive">;
        reason: z.ZodString;
        case: z.ZodString;
        scorer: z.ZodString;
        scorerName: z.ZodOptional<z.ZodString>;
        stepKey: z.ZodString;
        at: z.ZodString;
        meta: z.ZodOptional<z.ZodUnknown>;
    }, z.core.$strip>], "kind">>;
    trials: z.ZodOptional<z.ZodObject<{
        cases: z.ZodNumber;
        passAt1: z.ZodNumber;
        passAtK: z.ZodNumber;
        passHatK: z.ZodNumber;
        allPass: z.ZodNumber;
        perCase: z.ZodRecord<z.ZodString, z.ZodObject<{
            n: z.ZodNumber;
            passes: z.ZodNumber;
            rate: z.ZodNumber;
            passAt1: z.ZodNumber;
            passAtK: z.ZodNumber;
            passHatK: z.ZodNumber;
            stderr: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    k: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/**
 * JSON-safe result of an evaluation run.
 * @category models
 * @since 1.0.0
 */
export type RunArtifact = z.infer<typeof RunArtifact>;
/**
 * Removes executable values from a runner result for persistence.
 * @category constructors
 * @since 1.0.0
 */
export declare const artifactOf: (run: Runner.RunResult) => RunArtifact;
/**
 * Rehydrates a persisted artifact for baseline and regression APIs.
 * @category constructors
 * @since 1.0.0
 */
export declare const runOf: (artifact: RunArtifact) => Runner.RunResult;
/**
 * A caller-supplied identity cannot escape the artifact directory.
 * @category constructors
 * @since 1.0.0
 */
export declare const runPath: (root: string, runId: string) => string;
/**
 * Writes a JSON artifact atomically and refuses replacement by default.
 * @category constructors
 * @since 1.0.0
 */
export declare const writeJson: (file: string, source: string, overwrite?: boolean, signal?: AbortSignal) => Promise<void>;
/**
 * The scorer runner a project's evaluations use.
 *
 * With an engine store, observations are recorded through the store-backed
 * scorer runner into that database, after applying the score-store
 * migrations, so later runs and gates can read them back. Without one, scoring
 * stays in process and nothing is recorded.
 * @category layers
 * @since 1.0.0
 */
export declare const scoring: (root: string) => Layer.Layer<Runner.Runner, ScorerError>;
/**
 * Executes a suite and returns its persistable artifact.
 *
 * `options.root` selects the project whose {@link scoring} the run uses;
 * without it the run scores in process.
 * @category constructors
 * @since 1.0.0
 */
export declare const execute: (suite: Suite.Suite, executor: CaseExecutor.Service, options: {
    readonly runId: string;
    readonly at: string;
    readonly trials?: number;
    readonly k?: number;
    readonly root?: string;
}, runtime?: RuntimeConfig) => Promise<RunArtifact>;
/**
 * Reads a saved run by identity or path.
 * @category constructors
 * @since 1.0.0
 */
export declare const readRun: (root: string, selector: string) => Promise<RunArtifact>;
/**
 * Reads a committed baseline file.
 * @category constructors
 * @since 1.0.0
 */
export declare const readBaseline: (file: string) => Promise<string>;
/**
 * Returns the committed baseline path for a suite.
 * @category constructors
 * @since 1.0.0
 */
export declare const defaultBaselinePath: (root: string, suite: string) => string;
/**
 * Serializes a complete run as a baseline.
 * @category constructors
 * @since 1.0.0
 */
export declare const baseline: (run: RunArtifact) => Promise<string>;
/**
 * Compares a run with a baseline and returns its CI verdict.
 * @category constructors
 * @since 1.0.0
 */
export declare const compare: (run: RunArtifact, source: string, options?: Gate.Options) => Promise<{
    exitCode: 0 | 1 | 5;
    summary: string;
    report: Regression.Report;
    verdict: import("@smthrs/scorers/ScoreGate").Verdict;
}>;
