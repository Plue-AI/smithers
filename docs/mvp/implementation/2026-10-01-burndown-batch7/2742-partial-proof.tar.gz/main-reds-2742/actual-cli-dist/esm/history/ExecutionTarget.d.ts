/**
 * File-free extraction of unambiguous execution targets from transition aliases.
 * @since 1.0.0
 */
import * as Argv from "../cli/Argv.ts";
/**
 * Called only after the real parser selects a handler; never resolves files
 * or guesses a target from an unknown flag's value.
 * @since 1.0.0
 * @category getters
 */
export declare const executionRunId: (args: ReadonlyArray<string> | Argv.Globals) => string | undefined;
