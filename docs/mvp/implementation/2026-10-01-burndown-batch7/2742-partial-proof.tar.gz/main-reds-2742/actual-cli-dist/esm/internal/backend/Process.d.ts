/**
 * Backend command processes, started through the contained host spawner.
 *
 * `ProcessReaper.layerSpawner` gives each child a supervisor that owns its
 * process group, so a cancelled or timed-out `ssh`, `jj`, `git` or keyring
 * helper takes its descendants with it. The ledger is in memory: these
 * commands live and die with one CLI invocation.
 * @since 1.0.0
 */
import { PassThrough } from "node:stream";
type Environment = Readonly<Record<string, string | undefined>>;
declare const NotFound_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "/backend/NotFound";
} & Readonly<A>;
/**
 * A spawn the operating system refused because the program does not exist.
 * @private
 * @since 1.0.0
 */
export declare class NotFound extends NotFound_base<{
    readonly command: string;
    readonly message: string;
}> {
    constructor(command: string);
}
/**
 * @private
 * @since 1.0.0
 */
export interface Result {
    readonly code: number;
    readonly stdout: string;
    readonly stderr: string;
}
/**
 * Runs one command to completion and buffers its output.
 *
 * Rejects with {@link NotFound} when the program is missing, and with a
 * `Refused` on timeout, cancellation, output past `maxBytes`, or any other
 * spawn failure. The child's environment is exactly `env`.
 * @private
 * @since 1.0.0
 */
export declare const run: (command: string, args: ReadonlyArray<string>, options: {
    readonly env: Environment;
    readonly input?: string | undefined;
    readonly timeoutMs: number;
    readonly maxBytes?: number | undefined;
    readonly signal?: AbortSignal | undefined;
}) => Promise<Result>;
/**
 * A running command with Node streams, for callers that stream archives or
 * relay output as it arrives.
 * @private
 * @since 1.0.0
 */
export interface Child {
    /** Absent when stdio is inherited. Ending it closes the child's stdin. */
    readonly stdin: PassThrough | undefined;
    readonly stdout: PassThrough | undefined;
    readonly stderr: PassThrough | undefined;
    /** The exit code; rejects when the spawn fails or {@link kill} stopped it. */
    readonly exited: Promise<number>;
    /** Stops the child and its process group. Safe to call after exit. */
    readonly kill: () => void;
}
/**
 * Starts a command whose streams the caller drives.
 * @private
 * @since 1.0.0
 */
export declare const spawn: (command: string, args: ReadonlyArray<string>, options: {
    readonly env: Environment;
    readonly stdio: "pipe" | "inherit";
    readonly signal?: AbortSignal | undefined;
}) => Child;
export {};
