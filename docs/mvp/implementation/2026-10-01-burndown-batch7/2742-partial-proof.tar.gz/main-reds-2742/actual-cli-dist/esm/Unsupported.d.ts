/**
 * The removal surface for 0.x commands and flags.
 *
 * A verb that 0.x had and rc.0 does not must fail with a sentence that names
 * the replacement, not with a usage error. `effect/unstable/cli` answers an
 * unknown subcommand with exit 2 and a "did you mean" list, which tells an
 * operator nothing about why `smthrs rewind` stopped existing. So every
 * removed verb is registered as a hidden subcommand whose only behaviour is
 * to fail with {@link message}, and every removed flag is declared hidden on
 * the command that used to carry it.
 *
 * The tables below are the contract. `test/Verb.test.ts` pins the verb set and
 * `test/Bin.test.ts` pins the flags, so a verb cannot quietly reappear and a
 * flag cannot quietly become a usage error again.
 *
 * @since 1.0.0
 */
import * as Argv from "./cli/Argv.ts";
import * as CliError from "./CliError.ts";
/**
 * The documentation base every removal message points at.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const migrationUrl = "https://smithers.sh/migration/1.0";
/**
 * One removed verb: its name, the anchor its message links to, and why it is
 * gone.
 *
 * `anchor` differs from `name` only for a sub-verb group, where the whole
 * group is documented under its parent (`worktrees list` links to
 * `#worktrees`).
 *
 * @category models
 * @since 1.0.0
 */
export interface RemovedVerb {
    readonly name: string;
    readonly group: string;
    readonly reason: string;
    readonly subcommands?: ReadonlyArray<string> | undefined;
}
/**
 * Every verb removed in 1.0.0-rc.0.
 *
 * Only names the CLI no longer answers belong here. A 0.x spelling the
 * canonical tree reissued with a new meaning is not a removal: `smthrs graph`,
 * `eval`, `review`, `test`, `runs`, and `show` all run today, so saying they
 * were removed would make every consumer of this table maintain the same
 * exclusion list by hand. `test/Verb.test.ts` pins the two sets apart.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const removedVerbs: ReadonlyArray<RemovedVerb>;
/**
 * One removed flag, declared hidden on the command that used to carry it.
 *
 * @category models
 * @since 1.0.0
 */
export interface RemovedFlag {
    /** The rc.0 command the flag is declared on; `""` names the shared globals. */
    readonly parent: string;
    readonly flag: string;
    readonly reason: string;
    readonly anchor: string;
}
/**
 * Every flag removed in 1.0.0-rc.0.
 *
 * `--backend` is the one entry that is not a plain refusal: `--backend sqlite`
 * names the supported backend and is accepted as a no-op, and only another
 * value fails. {@link Environment.unsupportedBackend} owns that distinction.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const removedFlags: ReadonlyArray<RemovedFlag>;
/**
 * The removal sentence for one verb.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const message: (verb: string, reason: string, anchor?: string) => string;
/**
 * The removal sentence for one flag.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const flagMessage: (removedFlag: RemovedFlag) => string;
/**
 * The failure a removed verb raises: exit 1, never a usage error.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const verbError: (verb: RemovedVerb, subcommand?: string | undefined) => CliError.UnsupportedError;
/**
 * The refusal an argument vector earns before anything boots, or `undefined`.
 *
 * A removed verb is a sentence, not work. Answering it from the command tree
 * meant answering it from inside `NodeControl.layer`, so the process created
 * `<cwd>/.flows/` and opened `engine.db` and `control.db` before it printed:
 * an operator who typed a 0.x verb got a project state directory as the side
 * effect of being told the verb is gone, and the eight-at-a-time spawns in
 * `scripts/docs-removals.test.mjs` contended on those two SQLite files.
 *
 * The scan is deliberately narrow, the way `cli/LegacyBin.ts` reads `--help` and
 * `--version`: it fires only for `smthrs <verb> [<positional>...]`, and any
 * flag anywhere in the vector sends the invocation down the ordinary path,
 * except the removed initializer with known root and presentation options.
 * A flag can take a value, a value can be spelled like a verb, and the
 * registered hidden commands in `Command.ts` are still the authority for every
 * shape this one declines to read. Missing a refusal here costs the old
 * startup; misreading one would print the wrong sentence.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const refusal: (input: ReadonlyArray<string> | Argv.Globals) => CliError.UnsupportedError | undefined;
/**
 * Whether a flow id belongs to the control plane's reserved catalog.
 *
 * `@smthrs/control`'s `SystemFlows.catalog` reserves one `system/*` id per
 * command-line verb so a projection has a flow row to hang off. rc.0 ships a
 * body for none of them.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const isReservedFlow: (flowId: string) => boolean;
/**
 * The failure naming a reserved flow raises.
 *
 * A bodiless flow plans and launches perfectly well: the run row is durable,
 * the receipt says `Accepted`, and then nothing ever happens, because there is
 * no graph to execute. That partial appearance
 * forbids, so the verbs that take a flow id refuse the reserved ones outright.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const reservedFlowError: (verb: string, flowId: string) => CliError.UnsupportedError;
/**
 * The failure a removed flag raises: exit 1, never a usage error.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const flagError: (removedFlag: RemovedFlag) => CliError.UnsupportedError;
/**
 * Looks up one removed flag by the command it is declared on and its name.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const findFlag: (parent: string, flag: string) => RemovedFlag;
