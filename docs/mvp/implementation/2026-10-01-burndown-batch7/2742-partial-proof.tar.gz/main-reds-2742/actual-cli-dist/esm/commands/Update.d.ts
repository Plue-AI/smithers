/**
 * `smthrs update`: the registry check, after the shared guard.
 *
 * @since 1.0.0
 */
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
import * as Update from "../Update.ts";
import * as Globals from "./Globals.ts";
/**
 * Compares the installed version with the registry's dist-tags.
 * @category constructors
 * @since 1.0.0
 */
export declare const check: (globals: Globals.Options) => Effect.Effect<Update.Status, CliError.UnsupportedError | CliError.Refused>;
