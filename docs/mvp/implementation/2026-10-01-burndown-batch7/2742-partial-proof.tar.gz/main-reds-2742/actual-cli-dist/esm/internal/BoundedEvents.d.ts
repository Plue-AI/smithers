/**
 * Bounded collection of durable control-event histories.
 *
 * @since 1.0.0-rc.0
 * @private
 */
import { Effect, Stream } from "effect";
import * as CliError from "../CliError.ts";
/**
 * Largest event count retained by one CLI history projection.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const maximumEvents = 50000;
/**
 * Largest encoded history retained by one CLI projection.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const maximumBytes: number;
/**
 * Largest encoded individual event admitted to a CLI projection.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const maximumEventBytes: number;
/**
 * Resource limits for one history projection.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export interface Limits {
    readonly maxEvents: number;
    readonly maxBytes: number;
    readonly maxEventBytes: number;
}
/**
 * Stable attribution for one bounded history read.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export interface Context {
    readonly operation: string;
    readonly subject: string;
}
/**
 * Mutable accumulator owned by one projection.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export interface HistoryBuffer<A> {
    readonly values: Array<A>;
    events: number;
    bytes: number;
}
/**
 * Default CLI history limits.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const defaultLimits: Limits;
/**
 * Starts an empty bounded accumulator.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const empty: <A>() => HistoryBuffer<A>;
/**
 * Encoded bytes charged for one NDJSON-style event.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const encodedBytes: (value: unknown) => number;
/**
 * Folds a stream into an existing budget, failing on the first excess item.
 *
 * Reusing the buffer makes polling incremental: both its cursor payload and
 * its resource accounting advance without rereading or recounting history.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const collectInto: <A, E, R>(stream: Stream.Stream<A, E, R>, buffer: HistoryBuffer<A>, context: Context, limits?: Limits) => Effect.Effect<HistoryBuffer<A>, E | CliError.ResourceLimitError, R>;
/**
 * Collects a stream under a fresh finite event and byte budget.
 *
 * @since 1.0.0-rc.0
 * @private
 */
export declare const collect: <A, E, R>(stream: Stream.Stream<A, E, R>, context: Context, limits?: Limits) => Effect.Effect<ReadonlyArray<A>, E | CliError.ResourceLimitError, R>;
