/**
 * `smthrs doctor`: the one command that answers "why did that not work?"
 * without running anything.
 *
 * Every check here is a thing an operator has been surprised by: a flow
 * directory that discovers nothing, a database that is not where they thought,
 * a Node build below the durable engine's floor, `jj` missing from a `PATH`
 * that has it interactively, a provider key that is exported but empty, and
 * Smithers 0.x state beside a project that has already moved on.
 *
 * The report is data, not text. `--json` prints it verbatim, the human
 * rendering is one line per check, and nothing about a check's outcome is
 * decided by the renderer.
 *
 * @since 1.0.0
 */
import * as Environment from "./Environment.ts";
import * as Ui from "./Ui.ts";
/**
 * The outcome of one check.
 *
 * `warn` is a fact the operator should know and that stops nothing; `fail` is
 * a fact that will stop the next command they run.
 *
 * @category models
 * @since 1.0.0
 */
export type Level = "ok" | "warn" | "fail";
/**
 * One line of the report.
 *
 * @category models
 * @since 1.0.0
 */
export type Check = Ui.Check;
/**
 * The whole report.
 *
 * @category models
 * @since 1.0.0
 */
export interface Report {
    readonly root: string;
    readonly checks: ReadonlyArray<Check>;
}
/**
 * The minimum Node the durable engine runs on (the release policy).
 *
 * @category constants
 * @since 1.0.0
 */
export declare const minimumNode = "26.4.0";
/**
 * Node versions supported by the CLI and its runtime dependencies.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const supportedNodeRange = ">=26.4.0";
/**
 * Whether a Node version is supported and satisfies an optional higher floor.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const satisfiesNode: (version: string, minimum?: string) => boolean;
interface DiscoveredFlow {
    readonly flowId: string;
    readonly description: string;
}
interface DiscoveryWarning {
    readonly code: string;
    readonly path: string;
    readonly message: string;
    readonly name?: string | undefined;
}
/**
 * Arguments accepted by {@link inspect}. Every host fact is a parameter so the
 * report is deterministic in a test.
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    readonly root: string;
    /**
     * The descriptors returned by the same control listing as `smthrs ls`.
     * When present, including as an empty list, this authoritative discovery
     * result replaces the filesystem fallback.
     */
    readonly discoveredFlows?: ReadonlyArray<DiscoveredFlow> | undefined;
    /** Why discovery produced no registry; replaces every other registry fact. */
    readonly discoveryFailure?: string | undefined;
    /** Diagnostics returned by the same registry snapshot as discoveredFlows. */
    readonly discoveryWarnings?: ReadonlyArray<DiscoveryWarning> | undefined;
    readonly environment?: Environment.Source | undefined;
    readonly nodeVersion?: string | undefined;
    readonly jj?: {
        readonly path: string;
        readonly executable: boolean;
        readonly hint?: string | undefined;
    } | undefined;
    readonly cwd?: string | undefined;
    /**
     * The 0.x state found when the invocation started. The caller samples it,
     * because by the time a command runs its own control database has created
     * `<root>/.flows` and `Project.legacyState` would report nothing.
     */
    readonly legacyPaths?: ReadonlyArray<string> | undefined;
}
/**
 * Runs every check and returns the report.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const inspect: (options: Options) => Report;
/**
 * The human rendering: one line per check.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const render: (report: Report) => string;
/**
 * Whether the report contains a failing check, which decides the exit status.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const failed: (report: Report) => boolean;
export {};
