/**
 * Public spelling aliases shared by target and durable command invocations.
 * @since 1.0.0
 */
/**
 * Accept --root for target commands while preserving the published --workspace schema.
 * Durable commands keep --root unchanged, and arguments after -- are never rewritten.
 * @category parsing
 * @since 1.0.0
 */
export declare const normalizeArguments: (args: ReadonlyArray<string>) => Array<string>;
