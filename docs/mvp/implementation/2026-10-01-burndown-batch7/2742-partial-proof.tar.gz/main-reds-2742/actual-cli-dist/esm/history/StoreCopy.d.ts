/**
 * A consistent copy of one local store, for work that must not touch the
 * original: `smthrs runs verify` resumes a run on a copy.
 *
 * A SQLite store is copied with `VACUUM INTO`, inside one read transaction. A
 * PostgreSQL store is a schema, copied into the schema the copy's filename
 * selects, which the copy creates and so must not exist: its trigger
 * functions, tables with their defaults, identities and checks, rows,
 * identity positions, then keys, indexes and triggers under their own names,
 * all in one transaction that holds the source schema's writer lock, so the
 * copy is one moment of the source and a failed copy leaves no schema. A copy
 * that would still reach into the source (a sequence or function it does not
 * own, a function pinned to another search path or naming the source) is
 * refused and rolled back.
 *
 * @since 1.0.0
 */
import { Effect } from "effect";
/**
 * Where the store at `filename` lives on PostgreSQL, or `undefined` for SQLite.
 *
 * @since 1.0.0
 * @category getters
 */
export declare const postgres: (filename: string) => {
    readonly url: string;
    readonly schema: string;
} | undefined;
/**
 * Copies the store at `from` to `to`, on the backend `from` is on. `to` must be
 * a filename the same backend places apart from `from`: a new SQLite file, or
 * a filename whose PostgreSQL schema does not exist yet.
 *
 * @since 1.0.0
 * @category constructors
 */
export declare const copy: (from: string, to: string) => Effect.Effect<void, unknown>;
/**
 * Removes a copy {@link copy} made: a PostgreSQL copy's schema. Call it only
 * for a copy that succeeded, which is the only kind whose schema this caller
 * created. A SQLite copy is a file its caller deletes with the directory it
 * made for it.
 *
 * @since 1.0.0
 * @category destructors
 */
export declare const discard: (to: string) => Effect.Effect<void, unknown>;
