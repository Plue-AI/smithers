/**
 * Backend flow/run handlers used by the canonical flow and runs groups.
 * @since 0.1.0
 */
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const runs: Record<string, Handler>;
