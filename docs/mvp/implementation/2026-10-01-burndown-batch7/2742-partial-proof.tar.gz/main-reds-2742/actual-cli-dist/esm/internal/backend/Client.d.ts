/**
 * The CLI's authenticated backend transport and shared command inputs.
 * @since 0.1.0
 */
import type { Runtime } from "../../cli/ControlBridge.ts";
import { Refused } from "../../CliError.ts";
import { Session } from "./Session.ts";
/**
 * @private
 * @since 1.0.0
 */
export type Values = Record<string, unknown>;
/**
 * @private
 * @since 1.0.0
 */
export declare const object: (value: unknown) => Values;
/**
 * @private
 * @since 1.0.0
 */
export declare const list: (value: unknown) => Array<unknown>;
/**
 * @private
 * @since 1.0.0
 */
export declare const str: (value: unknown) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const esc: (value: unknown) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const query: (values: Values) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const pick: (values: Values, keys: Array<string>) => Values;
/**
 * @private
 * @since 1.0.0
 */
export declare const positive: (value: unknown, label?: string) => number;
/**
 * Reads cursor metadata without trusting a backend-provided destination.
 * @private
 * @since 1.0.0
 */
export declare const paginationCursor: (headers: Headers, current: URL) => string;
declare const APIError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "/backend/APIError";
} & Readonly<A>;
/**
 * @private
 * @since 1.0.0
 */
export declare class APIError extends APIError_base<{
    readonly status: number;
    readonly detail: Values;
    readonly message: string;
}> {
    constructor(status: number, detail: Values, method: string, path: string, headers: Headers);
}
/**
 * Attaches the inner failure as `cause`, where only `--verbose` prints it.
 * @private
 * @since 1.0.0-rc.1
 */
export declare const withCause: <E extends Error>(error: E, cause: unknown) => E;
/**
 * The refusal an operator reads for one backend HTTP failure: the fault and
 * code its status names, and the backend's own sentence, redacted and made
 * inert for a terminal. The method, path, and request id stay on the
 * `APIError`, which rides along as `cause`.
 * @private
 * @since 1.0.0-rc.1
 */
export declare const refusalOf: (error: APIError, redact?: (value: unknown) => unknown) => Refused;
/**
 * @private
 * @since 1.0.0
 */
export declare class Client {
    readonly env: Readonly<Record<string, string | undefined>>;
    readonly session: Session;
    readonly runtime: Runtime;
    readonly live: boolean;
    private readonly secrets;
    private readonly outputPartial;
    private readonly outputDecoders;
    private readonly outputRules;
    private readonly outputRedactors;
    constructor(runtime?: Runtime, live?: boolean);
    get home(): string;
    protect(value: string): void;
    redact(value: unknown): unknown;
    write(text: string): void;
    output(out: Buffer, err: Buffer): void;
    private outputChunk;
    flushOutput(): void;
    /**
     * What a failed command reports: a backend HTTP failure as the `Refused`
     * its status names, any other designed failure with its tag and its
     * sentence redacted of this session's secrets, and anything else as it
     * came, so the reporter prints the generic sentence.
     */
    failure(error: unknown): unknown;
    exec(command: string, args: Array<string>, extra?: NodeJS.ProcessEnv, input?: string): Promise<string>;
    /**
     * The repository from `value`, else the checkout's remote on this backend,
     * else — with `fallback` — the repository its origin names on those hosts.
     */
    repo(value?: unknown, fallback?: ReadonlySet<string>): string;
    repoPath(value?: unknown): string;
    confirm(yes: unknown, description: string): Promise<void>;
    stdin(label: string, allowEmpty?: boolean): Promise<string>;
    response(method: string, path: string, body?: unknown, options?: {
        origin?: string;
        anonymous?: boolean;
        token?: string;
        headers?: Record<string, string>;
        stream?: boolean;
        signal?: AbortSignal;
    }): Promise<Response>;
    text(response: Response, maximum?: number): Promise<string>;
    request(method: string, path: string, body?: unknown, options?: Parameters<Client["response"]>[3]): Promise<unknown>;
    pages(path: (cursor: string) => string, cursor?: string, all?: boolean, key?: string): Promise<unknown>;
    events(path: string, stop?: string, terminalStatuses?: Array<string>, defaultType?: string): Promise<Array<unknown>>;
}
/** @private
 * @since 1.0.0
 */
export declare function chunksOf(body: ReadableStream<Uint8Array>): AsyncGenerator<Uint8Array<ArrayBufferLike>, void, unknown>;
export {};
