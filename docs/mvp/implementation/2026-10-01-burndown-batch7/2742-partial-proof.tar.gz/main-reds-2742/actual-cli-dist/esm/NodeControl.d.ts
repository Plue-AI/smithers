/**
 * Node transport composition for the Control service.
 *
 * @since 0.1.0
 */
import { NodeServices } from "../vendor/platform-node.js";
import { Control, ControlRpcs, type ControlRuntime } from "@smthrs/control";
import type * as Journal from "@smthrs/journal/Journal";
import * as MemoryStore from "@smthrs/memory/MemoryStore";
import type { NotificationQueue } from "@smthrs/notifications";
import type * as Registry from "@smthrs/registry/Registry";
import { Effect, Layer } from "effect";
import type { ListenOptions } from "node:net";
import * as Application from "./Application.ts";
import * as Argv from "./cli/Argv.ts";
import * as CliError from "./CliError.ts";
import * as Environment_ from "./Environment.ts";
import { native } from "./internal/NodeControlHost.ts";
import type { EngineDurable, ModuleRegistration } from "./internal/NativeControl.ts";
import * as Output from "./Output.ts";
import * as Serve from "./Serve.ts";
/**
 * The environment subset consulted while resolving Node application
 * configuration.
 *
 * Names are read through `Environment.read`. Pass a captured source to
 * configuration helpers so tests and alternate hosts do not read ambient
 * process state; invalid values fail through the helper that consumes them.
 *
 * @category models
 * @since 0.1.0
 */
export type Environment = Environment_.Source;
/**
 * Node HTTP listen options accepted by the control server.
 *
 * Use these at a Node bind boundary. A non-loopback host without the required
 * opt-in is rejected synchronously before the server layer is built.
 *
 * @category models
 * @since 0.1.0
 */
export type ServerOptions = ListenOptions & {
    readonly disablePreemptiveShutdown?: boolean | undefined;
    /** Explicit opt-in corresponding to the host CLI's `--listen` flag. */
    readonly listen?: boolean | undefined;
};
/**
 * Resolves application configuration from command arguments with an
 * environment fallback.
 *
 * Use this before constructing any durable layer. Invalid `--remote` and
 * `--mcp-config` values raise `CliError.UsageError`, naming the offending flag
 * before a transport or database can surface a lower-level exception.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeConfig: (args: ReadonlyArray<string> | Argv.Globals, environment: Environment, cwd: string) => Application.Config;
/**
 * Resolves process configuration using an existing argument parse.
 *
 * The executable reaches for this effect before parsing the command tree. It
 * preserves configuration usage errors so the top-level reporter exits with
 * status 2 and never leaks a host exception.
 *
 * @category configuration
 * @since 0.1.0
 */
export declare const configFromArguments: (args: ReadonlyArray<string> | Argv.Globals) => Effect.Effect<Application.Config, CliError.UsageError>;
/**
 * Resolves configuration for the current process.
 * @category configuration
 * @since 0.1.0
 */
export declare const config: Effect.Effect<Application.Config, CliError.UsageError>;
export type { EngineDurable, ModuleRegistration } from "./internal/NativeControl.ts";
export { accountPoolDefaultModel, checkpointStore, layerSeatCatalog, layerSeatEvaluator, layerSeatResolver, seatCandidates, seatResolver, testFlows, testRunner } from "./internal/NativeEquipment.ts";
export { environmentDispatcher, layerEgressHttpClient, layerRebuildableRequestExecutor, rebuildableTransport } from "./internal/NodeControlHost.ts";
/**
 * The static stance a judged run on this host is taught:
 * `SMITHERS_SUPERVISOR_STANCE`, `careful` when unset. Any other value throws
 * a `UsageError` naming the variable, so a host refuses to start on it.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const supervisorStance: (environment: Environment_.Source) => "careful" | "paranoid";
/**
 * The `ssh` argv prefix that reaches a Smithers Cloud workspace through the
 * public `GET /api/repos/{owner}/{repo}/workspaces/{id}/ssh` endpoint, with the
 * advertised host keys pinned. `reference` is `OWNER/REPO/WORKSPACE_ID`; the
 * API URL and token come from `environment` and the CLI's configuration. The
 * embedded grant expires, so ask again for a later command. Pass `signal` to
 * cancel SSH-readiness polling when the acquiring operation ends.
 *
 * @category constructors
 * @since 1.0.0
 */
export { workspaceSshPrefix } from "./internal/backend/WorkspaceSsh.ts";
/**
 * The flow sources a local CLI discovers: the project `flows/` directory, whose
 * per-directory layout is the convention in
 * `docs/specs/Specs/Flow Directory.md`.
 *
 * Use this when building a project registry. It is pure and cannot fail; the
 * discovery layer reports unreadable or malformed sources later.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const projectSources: (root: string) => ReadonlyArray<import("@smthrs/registry/Descriptor").Source>;
/**
 * The raw host platform: Node's own services plus the descriptor-relative,
 * no-follow filesystem the kernel needs underneath it. `NodeServices` alone is
 * not enough: the kernel's guarded `FileSystem` refuses every operation unless
 * the host provides descriptor-relative, no-follow access, which is what
 * `AtomicFileSystem` adds on Node.
 *
 * This is the *unguarded* half of the composition. It is what
 * {@link layerGuardedPlatform} is built on, and it is what host equipment that
 * carries its own confinement argument runs on, today only the workspace
 * observer, whose module documents why (`@smthrs/agent/WorkspaceObservation`).
 * Agent-reachable equipment never gets this layer: a flow, a tool, or anything
 * a model can steer takes {@link layerGuardedPlatform} so the kernel decides
 * what it may touch.
 *
 * One `const`, not a function, so every consumer in one composition shares a
 * single memoized build. Host acquisition failures remain startup failures in
 * the layers that consume it.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerHostPlatform: Layer.Layer<NodeServices.NodeServices, never, never>;
/**
 * The local CLI's real permission store.
 *
 * Its configured rule preserves the operator-owned CLI's allow policy, while
 * the real store still enforces the fiber's capability ceiling. This is
 * intentionally distinct from `GrantStore.layerNoop`, which skips both policy
 * evaluation and ceiling enforcement and is suitable only as an explicit test
 * input.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layerGrantStore: (root: string) => Layer.Layer<import("@smthrs/kernel/GrantStore").GrantStore>;
/**
 * The kernel-guarded platform over one workspace root: every filesystem
 * operation resolved, authorized, re-resolved, and executed relative to a
 * pinned root descriptor.
 *
 * `grants` is the store the kernel asks before it authorizes an operation, and
 * it is a parameter rather than a constant so that one composition cannot end
 * up asking two different stores. The default is the local CLI's real store;
 * a hosted composition may supply a stricter `GrantStore`, and must supply the same one it gives
 * `KernelChildProcessSpawner`: a filesystem pinned to the allow-all store
 * beside a shell pinned to a real one is a fail-open the types would not catch.
 *
 * The confinement the kernel still enforces here is structural: canonical
 * resolution, the hard-link refusal, and descriptor-relative execution from a
 * pinned root. That is what costs: on Node one authorized operation is one
 * helper process, so a caller that performs one operation per file in a
 * checkout pays for the whole checkout. That is a cost to spend on
 * agent-reachable equipment and to refuse for a whole-tree walk; see
 * {@link layerHostPlatform}.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerGuardedPlatform: (root: string, grants?: Layer.Layer<import("@smthrs/kernel/GrantStore").GrantStore>) => Layer.Layer<NodeServices.NodeServices, never, never>;
/**
 * Provides the workspace observer the run's mutation accounting is measured
 * with: one pruned walk of the workspace root, taken at both ends of every
 * frame.
 *
 * On {@link layerHostPlatform}, deliberately, and never on
 * {@link layerGuardedPlatform}. The observer is host equipment: the root is
 * this composition's, not a model's. It carries its own confinement
 * argument: it stats, it never opens, it follows no symlink, and every path it
 * builds is an entry name under the root. `@smthrs/agent/WorkspaceObservation`
 * states that argument in full. Guarding it decides nothing and costs one
 * helper process per file: SWE-bench wave 6 spent 912 s of a 1,200 s budget on
 * django's opening walk and never reached the agent's first tool call.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerObserver: (root: string, options?: import("@smthrs/agent/WorkspaceObservation").Options) => Layer.Layer<import("@smthrs/agent/WorkspaceObservation").Observer>;
/**
 * Provides the Node-backed flow registry the local CLI discovers flows with.
 *
 * `Registry.layerNoop()` was the previous local composition, so the CLI found
 * no flows at all. Discovery runs under an allow-all grant store because the
 * local CLI is the operator's own process; a hosted composition supplies a real
 * `GrantStore`. A source root that does not exist scans empty, so this is not a
 * startup failure. An unreadable one is, and dies rather than silently
 * discovering nothing.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerRegistry: (root: string) => Layer.Layer<Registry.Registry>;
/**
 * Where a local CLI keeps its control-plane database.
 *
 * Use this instead of assembling `.flows` paths at call sites. It is a pure
 * path projection and cannot fail; opening the returned file can.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const databasePath: (root: string) => string;
/**
 * Where the durable flow engine keeps executions, attempts, cache entries,
 * and wake state. The control plane has a separate connection and schema in
 * {@link databasePath}; keeping the files separate makes each composition's
 * migration ownership explicit.
 * This is a pure path projection; engine startup reports creation or migration
 * failures when it opens the file.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const executionDatabasePath: (root: string) => string;
/**
 * Provides the durable local engine: `SqlControlRuntime` and the production
 * SQL journal, both over one SQLite file under the project root.
 *
 * The previous local composition was `ControlRuntime.layerMemory()` over
 * `TestJournal`, an in-memory database, so no plan, approval, run, or journal
 * entry survived the process. Sharing one connection between the runtime and
 * the journal is deliberate: the fenced run transitions and the events that
 * describe them then commit against the same database.
 *
 * With a `registry`, the runtime knows every discovered flow as well as the
 * reserved system catalog, so `smthrs plan <flow>` plans a project flow
 * instead of failing `FlowNotFound`.
 *
 * Reach for this value at a Node composition root and reuse it. Database open,
 * migration, and journal startup failures are promoted to defects because no
 * local command can proceed honestly without the store.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const engineDurable: (root: string, registry?: Layer.Layer<Registry.Registry> | undefined, authority?: Pick<Application.Config, "approvalAuthority" | "principal" | "credential" | "stateRoot" | "databases">) => EngineDurable;
/**
 * Builds the executor over one captured control-store graph. Materializing
 * before native registration prevents the shared RunStore layer from being
 * memoized against the other database in an embedding composition.
 * @category layers
 * @since 1.0.0
 */
export declare const layerExecutor: (registry: Layer.Layer<Registry.Registry>, engine: EngineDurable, root: string, options: import("./internal/NativeControl.ts").ExecutorOptions) => ReturnType<(registry: Layer.Layer<Registry.Registry>, engine: EngineDurable, root: string, options: import("./internal/NativeControl.ts").ExecutorOptions, evaluator: Layer.Layer<import("@smthrs/model/Evaluator").Evaluator>) => Layer.Layer<import("@smthrs/control/ControlExecutor").ControlExecutor, never, ControlRuntime.ControlRuntime | Journal.Journal | NotificationQueue.NotificationQueue | Registry.Registry>>;
/**
 * Provides the application-selected Control service over Node transports.
 *
 * Use the optional registry and engine when embedding the CLI in an existing
 * composition. A local engine is materialized once before its runtime,
 * journal, executor, and memory consumers are assembled; startup failures die
 * with the layer. A remote configuration opens no local database and reports
 * transport failures through the control client.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerControl: (applicationConfig: Application.Config, suppliedRegistry?: Layer.Layer<Registry.Registry> | undefined, suppliedEngine?: EngineDurable | undefined, modules?: ModuleRegistration) => Layer.Layer<Control.Control, never, never>;
/**
 * Provides a Control service that observes runs and changes nothing.
 *
 * A local project's existing stores open read-only: no file, migration,
 * schema object, sweeper, recovery or reaper, and every read is a snapshot a
 * peer holding the writer does not block. A remote configuration reads the
 * control plane it names, which owns its own stores.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layerObserve: (applicationConfig: Application.Config) => Layer.Layer<Control.Control>;
/**
 * Provides deterministic rendering and transfers rendered statuses to the
 * Node process exit code.
 *
 * Reach for this layer only at the Node executable boundary. Rendering admits
 * only bounded inert data, and only validated control receipts can set a
 * nonzero process status; a missing service is a composition defect.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerOutput: Layer.Layer<Output.Output, never, never>;
/**
 * Provides the complete Node command-handler environment.
 *
 * This is the production layer for `smthrs`. Local composition acquires one
 * durable engine and shares it across control, execution, memory, and serving;
 * open or migration failures terminate startup. Remote composition builds the
 * RPC client without opening a local control database.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layer: (applicationConfig: Application.Config, modules?: ModuleRegistration) => Layer.Layer<Control.Control | MemoryStore.MemoryStore | NodeServices.NodeServices | Serve.GatewayHost | Output.Output, never, never>;
/** Refuses a composition root that still owes a service. */
type Complete<L> = [L] extends [Layer.Layer<infer _A, infer _E, infer R>] ? [R] extends [never] ? true : false : false;
/** Refuses a composition root whose allowed requirement channel is not exact. */
type RequirementsAre<L, Expected> = [L] extends [Layer.Layer<infer _A, infer _E, infer R>] ? [R] extends [Expected] ? [Expected] extends [R] ? true : false : false : false;
/** Fails to compile unless its argument is `true`. */
type Expect<T extends true> = T;
/**
 * Pins the executor and both complete control-plane compositions.
 *
 * The executor is installed beneath `Application.layer`, so its control
 * runtime, journal, notification queue, and registry are deliberate inputs.
 * `layerControl` supplies them, and the final command-handler root owes
 * nothing.
 *
 * @category models
 * @since 1.0.0
 */
export type CompositionRootsAreComplete = [
    Expect<RequirementsAre<ReturnType<typeof layerExecutor>, ControlRuntime.ControlRuntime | Journal.Journal | NotificationQueue.NotificationQueue | Registry.Registry>>,
    Expect<Complete<ReturnType<typeof layerControl>>>,
    Expect<Complete<ReturnType<typeof layer>>>
];
/**
 * Provides the memory store a `--remote` invocation gets: none, said out loud.
 *
 * The control plane owns memory. Building the local store here would open (and
 * create) a `.flows/control.db` beside the operator's shell and write facts the
 * server never reads, which is worse than a refusal because it looks like it
 * worked.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layerMemoryRemote: Layer.Layer<MemoryStore.MemoryStore>;
/**
 * Provides the durable memory store the `memory` verbs read and write, over
 * the control database.
 *
 * A remote composition has no local database, so the store is the unavailable
 * one there: `smthrs --remote ... memory set` must say the control plane
 * owns memory rather than write a fact into a file the server never reads.
 * Local open and migration failures are startup defects, consistent with the
 * control runtime using the same store.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layerMemory: (root: string, engine?: EngineDurable) => Layer.Layer<MemoryStore.MemoryStore, never, never>;
/**
 * Hosts the abstract Control HTTP/WebSocket router on a scoped Node HTTP
 * server. The returned layer retains the concrete HttpServer service so
 * callers can inspect an ephemeral address.
 *
 * Use this with an explicit authentication layer. Non-loopback hosts without
 * `listen: true` are rejected synchronously, and socket failures remain in the
 * returned server layer.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerServer: (auth: Layer.Layer<ControlRpcs.ControlAuth>, options?: ServerOptions) => Layer.Layer<import("effect/unstable/rpc/RpcServer").Protocol | import("effect/unstable/http/HttpServer").HttpServer | NodeServices.NodeServices | import("effect/unstable/http/HttpPlatform").HttpPlatform | import("effect/unstable/http/Etag").Generator, import("effect/unstable/http/HttpServerError").ServeError, Control.Control>;
/**
 * Hosts the whole workspace gateway: the control plane, the served
 * projections, the journal read path, and the health probe, on one socket.
 *
 * `@smthrs/gateway` owns the assembly (`GatewayServer.layer`) and its Node
 * host (`NodeGateway.layer`); this function supplies the four services those
 * mounts read through that only a project on disk can provide. `Control` stays
 * a requirement, so the verb hosts the same control plane its own commands
 * talk to rather than opening a second one.
 *
 * The sync read path receives the already-open journal when this is composed
 * by {@link layer}. Standalone callers may omit it and let one durable engine
 * provide the journal. A second `ControlLive` is never constructed.
 *
 * `RunCatalog` and `WorkspaceShare` are the no-op implementations: a local
 * gateway shares nothing and publishes no catalog, and the relay
 * implementations belong to a host that has an account to publish under.
 *
 * @category layers
 * @since 1.0.0
 */
export declare const layerGateway: typeof native.layerGateway;
/**
 * Hosts Control using the alpha's single shared bearer token.
 *
 * Use this at an authenticated bind boundary. It inherits {@link layerServer}
 * failures, including the refusal of a non-loopback host without `listen`.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerServerBearerAuth: (auth: ControlRpcs.BearerAuthOptions, options?: ServerOptions) => Layer.Layer<import("effect/unstable/rpc/RpcServer").Protocol | import("effect/unstable/http/HttpServer").HttpServer | NodeServices.NodeServices | import("effect/unstable/http/HttpPlatform").HttpPlatform | import("effect/unstable/http/Etag").Generator, import("effect/unstable/http/HttpServerError").ServeError, Control.Control>;
/**
 * Hosts Control with permissive authentication for trusted local and test use.
 * Production hosts must call `layerServer` with an explicit authentication
 * layer.
 *
 * Any non-loopback host is rejected synchronously, even when `listen` is true;
 * loopback socket failures remain in the returned server layer.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerServerNoopAuth: (options?: ServerOptions) => Layer.Layer<import("effect/unstable/rpc/RpcServer").Protocol | import("effect/unstable/http/HttpServer").HttpServer | NodeServices.NodeServices | import("effect/unstable/http/HttpPlatform").HttpPlatform | import("effect/unstable/http/Etag").Generator, import("effect/unstable/http/HttpServerError").ServeError, Control.Control>;
