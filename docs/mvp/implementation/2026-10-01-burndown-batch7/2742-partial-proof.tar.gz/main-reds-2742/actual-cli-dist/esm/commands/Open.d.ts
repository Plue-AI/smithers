/**
 * `smthrs open [dir]` and `smthrs .`: open a checkout's repository in the
 * Smithers app (#1964).
 *
 * The checkout's git remote names `owner/repo` (origin first; a jj checkout
 * without a git directory answers `jj git remote list`). The repository page
 * `/<owner>/<repo>` is that repository's workspace chat, whose first message
 * is the repository homepage. The first match wins:
 *
 * 1. macOS with Smithers.app installed: `smithers://open/<owner>/<repo>`
 *    (apps/app/src/bun/DeepLink.ts) through LaunchServices.
 * 2. The smithers checkout itself (its remote is smithersai/smithers on
 *    github.com or smithers.sh and it carries apps/app): the dev build,
 *    `pnpm --dir apps/app dev`, handed the same link as `SMITHERS_OPEN_URL`,
 *    with the terminal inherited. The remote check, host included, keeps
 *    `smthrs .` in any other checkout, such as a clone of
 *    `https://evil.example/smithersai/smithers`, from running that checkout's
 *    package scripts.
 * 3. Otherwise the web page, `https://smithers.sh/<owner>/<repo>`, printed.
 *
 * @since 1.0.0
 */
/**
 * The Smithers Cloud web origin.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const webOrigin = "https://smithers.sh";
/**
 * The repository whose checkout runs the app's dev build.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const smithersRepo = "smithersai/smithers";
/**
 * The hosts whose smithersai/smithers remote runs the dev build.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const smithersHosts: ReadonlySet<string>;
/**
 * The `owner/repo` a git remote URL names, or null. Accepts scp-like
 * (`git@host:owner/repo.git`), `ssh://`, `git://` and `http(s)://` spellings
 * with exactly two path segments; the host is not interpreted, since
 * a GitHub remote and its Smithers Cloud mirror share the name.
 *
 * @category parsing
 * @since 1.0.0
 */
export declare const repoFromRemote: (remote: string, allowedHosts?: ReadonlySet<string>) => string | null;
/**
 * The deep link the installed app answers for a repository.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const deepLink: (repo: string) => string;
/**
 * The repository's page on smithers.sh.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const webUrl: (repo: string) => string;
/**
 * What `open` did.
 *
 * @category models
 * @since 1.0.0
 */
export interface Opened {
    readonly repo: string;
    readonly opened: "app" | "dev" | "web";
    readonly url: string;
}
/**
 * The host doors `open` uses, injectable so tests never launch anything.
 *
 * @category models
 * @since 1.0.0
 */
export interface Host {
    readonly platform: NodeJS.Platform;
    readonly home: string;
    readonly exists: (path: string) => boolean;
    /** Runs a command to completion and answers its stdout, or null when it failed. */
    readonly read: (command: string, args: ReadonlyArray<string>, cwd: string) => string | null;
    /** Runs a command with the terminal inherited and answers its exit status. */
    readonly launch: (command: string, args: ReadonlyArray<string>, options: {
        readonly cwd: string;
        readonly env?: Readonly<Record<string, string>>;
    }) => Promise<number>;
}
/**
 * The process host.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const processHost: (environment: Readonly<Record<string, string | undefined>>) => Host;
/**
 * The repository a checkout's remote names. With `allowedHosts`, only remotes
 * on those hosts count, origin first; `remoteName` further limits them to one
 * remote.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const resolveRepo: (host: Host, directory: string, allowedHosts?: ReadonlySet<string>, remoteName?: string) => string;
/**
 * Opens the checkout's repository in the app, the dev build, or prints the web page.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const open: (host: Host, directory: string | undefined) => Promise<Opened>;
