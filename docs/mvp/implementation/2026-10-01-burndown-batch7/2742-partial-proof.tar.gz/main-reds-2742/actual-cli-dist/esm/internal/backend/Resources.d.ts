/**
 * Backend issue, wiki, organization and repository resource commands.
 * @since 0.1.0
 */
import { type Client, type Values } from "./Client.ts";
/**
 * @private
 * @since 1.0.0
 */
export type Handler = (client: Client, args: Values, options: Values) => Promise<unknown>;
/**
 * @private
 * @since 1.0.0
 */
export declare const resources: Record<string, Handler>;
