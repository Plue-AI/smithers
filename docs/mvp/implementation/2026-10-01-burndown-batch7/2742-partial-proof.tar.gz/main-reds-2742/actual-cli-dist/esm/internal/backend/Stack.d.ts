/**
 * Stacked GitHub requests backed by the existing stack API.
 * @since 1.0.0
 */
import type { Handler } from "./Resources.ts";
/** @private
 * @since 1.0.0
 */
export declare const stacks: Record<string, Handler>;
