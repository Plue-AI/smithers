/**
 * Invocation-scoped presentation: handlers return data, this adapter owns UX.
 * Async-local context keeps concurrent MCP requests from sharing UI state.
 * @since 1.0.0
 */
import * as Audience from "@smthrs/build-cli/Audience";
import type { RuntimeConfig } from "@smthrs/build-cli/Cli";
import { Writable } from "node:stream";
interface Session {
    readonly transport: "mcp" | "cli";
    readonly policy: Audience.Policy;
    readonly command: string;
    readonly stdout: Writable;
    readonly stderr: Writable;
}
/**
 * Presentation inputs supplied by Incur without exposing its implementation internals.
 * @category models
 * @since 1.0.0
 */
export interface Context {
    readonly command?: string | undefined;
    readonly agent?: boolean | undefined;
    readonly formatExplicit?: boolean | undefined;
    readonly request?: unknown;
    readonly globals?: {
        readonly audience?: Audience.Mode;
        readonly silent?: boolean;
    } | undefined;
    readonly args?: Readonly<Record<string, unknown>> | undefined;
    readonly options?: Readonly<Record<string, unknown>> | undefined;
    readonly ok?: ((data: unknown, meta?: {
        cta?: {
            commands: Array<{
                command: string;
                description: string;
            }>;
        };
    }) => never) | undefined;
}
/**
 * Resolve once per invocation. No streams or environment values are mutated.
 * @category selection
 * @since 1.0.0
 */
export declare const policy: (context: Context, runtime?: RuntimeConfig) => Audience.Policy;
/**
 * Keep one command's rendering preferences out of every handler's business logic.
 * @category constructors
 * @since 1.0.0
 */
export declare const scope: (context: Context, runtime: RuntimeConfig, next: () => Promise<void>) => Promise<void>;
/**
 * Current invocation, absent for direct library calls.
 * @category getters
 * @since 1.0.0
 */
export declare const current: () => Session | undefined;
/**
 * One follow-up command, written without the `smthrs` prefix. The connection
 * options of the invocation are appended when it is shown.
 * @category models
 * @since 1.0.0
 */
export interface Next {
    readonly command: string;
    readonly description: string;
}
/**
 * The follow-ups a command declares: a fixed list, or one derived from its
 * result and arguments.
 * @category models
 * @since 1.0.0
 */
export type FollowUps = ReadonlyArray<Next> | ((data: Readonly<Record<string, unknown>>, args: Readonly<Record<string, unknown>>) => ReadonlyArray<Next>);
/**
 * Quote one argument for a copyable follow-up command.
 * @category formatting
 * @since 1.0.0
 */
export declare const quote: (value: string) => string;
/**
 * Follow-ups for a result that names a durable run, falling back to
 * `otherwise` when it names none. Every command gets `runs()` unless it
 * declares its own `next`.
 * @category constructors
 * @since 1.0.0
 */
export declare const runs: (options?: {
    readonly show?: boolean;
    readonly otherwise?: ReadonlyArray<Next>;
}) => FollowUps;
/**
 * Resolve declared follow-ups against one result: at most three, each with
 * the invocation's root and credential-free remote. Never echo credentials or
 * approval payloads.
 * @category constructors
 * @since 1.0.0
 */
export declare const nextActions: (value: unknown, context?: Context, next?: FollowUps) => Array<Next>;
/**
 * Sanitizes and bounds one terminal field. A run of control characters is one
 * space, including a BEL after an SGR sequence, regardless of Node version.
 * @category formatting
 * @since 1.0.0
 */
export declare const clean: (value: unknown) => string;
/**
 * How a handler wants its result shown to a person. Agents and explicit
 * formats never see it: the returned document stays the contract.
 * @category models
 * @since 1.0.0
 */
export interface Rendering {
    /**
     * A body already written for a person, printed in place of the generic
     * key/value summary. The command title and the Next actions still frame it.
     */
    readonly human?: string | undefined;
    /** The command's follow-ups; results naming a run default to `runs()`. */
    readonly next?: FollowUps | undefined;
}
/**
 * Preserve data for agents; render a bounded Clack result for humans.
 * Explicit JSON/format always keeps the original machine-readable document.
 * @category formatting
 * @since 1.0.0
 */
export declare const finish: <A>(context: Context, value: A, rendering?: Rendering) => A;
/**
 * The Incur failure channel a guarded command reports through.
 * @category models
 * @since 1.0.0
 */
export interface Failing extends Context {
    readonly error: (error: {
        code: string;
        message: string;
        exitCode?: number;
    }) => never;
}
/**
 * How a guarded command names its failures.
 * @category models
 * @since 1.0.0
 */
export interface Refusal {
    /** Stable code for failures without a database code; defaults to the error tag, then `command_failed`. */
    readonly code?: string | undefined;
    /** Exit status for failures other than a UsageError, which always exits 2. */
    readonly exitCode?: number | undefined;
}
/**
 * Report one failure through Incur: a stable code, a redacted sentence, and
 * exit 2 for a UsageError.
 * @category constructors
 * @since 1.0.0
 */
export declare const fail: (context: Failing, cause: unknown, refusal?: Refusal) => never;
/**
 * The one Incur error boundary: run the handler, finish its result with the
 * declared follow-ups, and report any failure through `fail`.
 * @category constructors
 * @since 1.0.0
 */
export declare const guard: <A>(context: Failing, body: () => Promise<A>, options?: Refusal & {
    readonly next?: FollowUps | undefined;
    readonly render?: ((value: A) => Rendering) | undefined;
}) => Promise<A>;
export {};
