/**
 * `smthrs bug`: preview, consent, and the post, behind both parsers.
 *
 * @since 1.0.0
 */
import { Control as ControlService, ControlError } from "@smthrs/control";
import { Effect } from "effect";
import * as Bug from "../Bug.ts";
import * as CliError from "../CliError.ts";
import * as Globals from "./Globals.ts";
/**
 * The typed options both parsers produce.
 * @category models
 * @since 1.0.0
 */
export interface Options {
    /** The summary words, joined; an empty summary is a usage error. */
    readonly summary: string;
    readonly runId?: string | undefined;
    readonly yes: boolean;
    readonly dryRun: boolean;
    /**
     * Receives the endpoint and the already-redacted consent document before
     * any confirmation, so the operator can inspect everything a subsequent
     * POST will send. Each entry routes it to its own stderr, even under quiet.
     */
    readonly preview: (line: string) => Effect.Effect<void>;
}
/**
 * The document the verb renders.
 * @category models
 * @since 1.0.0
 */
export type Outcome = {
    readonly reported: false;
    readonly endpoint: string;
    readonly payload: Bug.Report;
} | {
    readonly reported: true;
    readonly endpoint: string;
};
/**
 * Builds the redacted report, previews it, asks, and posts.
 * @category constructors
 * @since 1.0.0
 */
export declare const submit: (options: Options, globals: Globals.Options) => Effect.Effect<Outcome, CliError.UsageError | CliError.UnsupportedError | CliError.Refused | CliError.ResourceLimitError | ControlError.ControlError, ControlService.Control>;
