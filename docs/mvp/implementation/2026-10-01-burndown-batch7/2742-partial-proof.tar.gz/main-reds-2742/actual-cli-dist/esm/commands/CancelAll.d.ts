/**
 * Shared cancellation operation for the legacy and unified command surfaces.
 *
 * @since 1.0.0
 */
import { Control } from "@smthrs/control";
import { Effect } from "effect";
import * as CliError from "../CliError.ts";
/**
 * The refusal for a run listing that answered some other kind of page: the
 * control plane broke its own contract, so the operator is told it is not
 * their fault.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const unexpectedRunList: () => CliError.Refused;
/**
 * Collects every page before cancelling, keeping one Control service for the
 * whole operation and preserving the single-run cancellation keys and receipts.
 * @category constructors
 * @since 1.0.0
 */
export declare const cancelAll: () => Effect.Effect<{
    cancelled: {
        runId: string;
        receipt: {
            readonly _tag: "Accepted";
            readonly receiptId: string;
            readonly runId?: string | undefined;
        } | {
            readonly _tag: "AlreadyApplied";
            readonly receiptId: string;
            readonly runId?: string | undefined;
        } | {
            readonly _tag: "Parked";
            readonly receiptId: string;
            readonly planId: string;
            readonly status: "waiting-approval";
        } | {
            readonly _tag: "Conflict";
            readonly message: string;
        } | {
            readonly _tag: "Terminal";
            readonly runId: string;
            readonly status: "failed" | "running" | "completed" | "cancelled" | "accepted" | "parked" | "waiting-approval";
        };
    }[];
}, CliError.Refused | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, Control.Control>;
