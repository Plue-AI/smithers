/**
 * The `smthrs claude ...` protocol the Claude Code plugin's `/workflows`
 * mirror consumes.
 *
 * The plugin does not read a database and does not know the control plane. It
 * runs one of these commands and relays the JSON, so this module is the whole
 * contract between them. {@link contract} is the wire-format major version the
 * plugin pins; bump it only when a response shape changes incompatibly.
 *
 * Two 0.x fields are gone in contract 2. `humanRequests` had no rc.0
 * counterpart — there is no question or answer RPC, and an approval parks the
 * run instead (the release policy) — and `continuedAs` described the
 * `continued` terminal status, which rc.0 does not have: a handoff round
 * settles `completed` with a lineage id (the release policy).
 *
 * Subscriptions exist because the mirror follows the runs *this* Claude
 * session started, not every run in the project. The registry never throws: a
 * missing or corrupt file degrades to no subscriptions, and writes are
 * temp-plus-rename with last-write-wins, because the next tick re-asserts a
 * lost upsert.
 *
 * @since 1.0.0
 */
import type { ControlSchema } from "@smthrs/control";
/**
 * The wire-format major version the plugin pins.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const contract = 2;
/**
 * How long a subscription stays live without being re-asserted.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const subscriptionTtlMs: number;
/**
 * Where the per-project subscription registry lives.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const subscriptionsPath: (root: string) => string;
/**
 * One session's interest in one run.
 *
 * @category models
 * @since 1.0.0
 */
export interface Subscription {
    readonly runId: string;
    readonly sessionId: string;
    readonly updatedAtMs: number;
}
/**
 * Reads the live subscriptions, dropping expired and malformed entries.
 *
 * @category getters
 * @since 1.0.0
 */
export declare const readSubscriptions: (root: string, now?: number) => ReadonlyArray<Subscription>;
/**
 * Records this session's interest in a run. Following a run *is* subscribing,
 * so every tick re-asserts.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const subscribe: (root: string, runId: string, sessionId: string, now?: number) => ReadonlyArray<Subscription>;
/**
 * Drops this session's interest in a run.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const unsubscribe: (root: string, runId: string, sessionId: string, now?: number) => ReadonlyArray<Subscription>;
/**
 * One node as the mirror renders it.
 *
 * @category models
 * @since 1.0.0
 */
export interface MirrorNode {
    readonly nodeId: string;
    readonly label: string;
    readonly phase: string;
    readonly kind: string;
    readonly state: "pending" | "running" | "finished" | "failed";
}
/**
 * One complete mirror frame.
 *
 * @category models
 * @since 1.0.0
 */
export interface Frame {
    readonly contract: number;
    readonly runId: string;
    readonly status: ControlSchema.RunStatus | "unknown";
    readonly seq: number;
    readonly phases: ReadonlyArray<{
        readonly title: string;
    }>;
    readonly nodes: ReadonlyArray<MirrorNode>;
    readonly changed: ReadonlyArray<string>;
    readonly outputs: Readonly<Record<string, string>>;
    readonly approvals: ReadonlyArray<{
        readonly question: string | undefined;
        readonly approval: string | undefined;
    }>;
    readonly timedOut: boolean;
}
/**
 * How much of one node's output a frame carries.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const defaultMaxOutputChars = 2000;
/**
 * Computes one mirror frame from a run's summary and events.
 *
 * `changed` is the set of nodes whose state moved after `afterSeq`, which is
 * what lets a blocking tick wake on real progress instead of on every model
 * token.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const frame: (runId: string, run: ControlSchema.RunSummary | undefined, events: ReadonlyArray<ControlSchema.ControlEvent>, options?: {
    readonly afterSeq?: number | undefined;
    readonly maxOutputChars?: number | undefined;
    readonly parked?: {
        readonly question: string | undefined;
        readonly approval: string | undefined;
    } | undefined;
    readonly timedOut?: boolean | undefined;
}) => Frame;
/**
 * rc.0 run statuses that mean the run is over. `continued` is not one of them:
 * it does not exist in rc.0.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const terminalStatuses: ReadonlyArray<string>;
/**
 * Whether a frame's run has settled, which is what stops a blocking tick.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const isTerminal: (status: string) => boolean;
/**
 * One line of the monitor's NDJSON stream.
 *
 * @category models
 * @since 1.0.0
 */
export interface Transition {
    readonly runId: string;
    readonly at: number;
    readonly kind: string;
    readonly status?: string | undefined;
    readonly nodeId?: string | undefined;
}
/**
 * The events the monitor reports, which is deliberately far short of every
 * event: a mirror that printed one line per model token would be unreadable
 * and would wake the plugin continuously.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const notableKinds: ReadonlySet<string>;
/**
 * Projects one event into a monitor line, or `undefined` when it is not
 * notable.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const transition: (event: ControlSchema.ControlEvent) => Transition | undefined;
