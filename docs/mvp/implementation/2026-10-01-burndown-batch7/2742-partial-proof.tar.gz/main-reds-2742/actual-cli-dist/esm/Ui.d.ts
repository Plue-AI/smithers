/**
 * The interactive rendering layer for human output.
 *
 * `Output` renders documents: the one value a verb produces, as JSON or as
 * indented text. This module renders the other half of a terminal session,
 * the part that is not a document: the brand line that opens a command, log
 * lines that arrive while work continues, a spinner that says a scan is still
 * running, the list of suggestions that scan streams out, and the questions a
 * verb asks before a follow-up. It wraps `@clack/prompts` and owns the one
 * decision clack leaves to its caller: whether the session is interactive at
 * all.
 *
 * Every method has two renderings. Interactive human sessions use clack's
 * guide bars, symbols, colour, animated spinners, and modal prompts. Harness,
 * CI, pipe, and dumb-terminal detection comes from the shared Audience policy;
 * non-interactive prompts resolve without asking. Document encoding is a
 * separate choice: humans can request JSON and still receive progress on
 * stderr. Nothing here decides process status; that stays with `Output.exitCode`.
 *
 * @since 1.0.0-rc.0
 */
import { Context, Effect, Layer, Option } from "effect";
import type { Readable, Writable } from "node:stream";
import type * as Environment from "./Environment.ts";
/**
 * The line `intro` prints when a verb gives it no title.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const brand: string;
/**
 * One line of a checklist: `smthrs doctor`'s checks, or any report that is
 * a list of named facts at three levels.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Check {
    readonly name: string;
    readonly level: "ok" | "warn" | "fail";
    readonly detail: string;
}
/**
 * A running indicator. `start` is not an Effect because a spinner is
 * imperative by nature: it is started before work, updated during it, and
 * settled once, and the Effect boundary sits around that whole span.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Spinner {
    readonly start: (message: string) => void;
    readonly message: (message: string) => void;
    readonly stop: (message?: string) => void;
    readonly cancel: (message?: string) => void;
    readonly error: (message?: string) => void;
}
/**
 * How a streamed list is labelled and settled.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface StreamOptions<A> {
    /** The one line printed for an item, given its 1-based position. */
    readonly label: (item: A, position: number) => string;
    /** The spinner text while the scan continues. Defaults to `Scanning`. */
    readonly scanning?: string | undefined;
    /** The line printed when the scan settles. Defaults to `<n> suggestions`. */
    readonly settled?: ((count: number) => string) | undefined;
    /** Aborting stops the scan early and settles with the items received so far. */
    readonly signal?: AbortSignal | undefined;
}
/**
 * How long an aborted scan waits for its source's `return()` before settling.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const cleanupTimeoutMillis = 2000;
/**
 * What a streamed scan produced.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Streamed<A> {
    readonly items: ReadonlyArray<A>;
    /** Whether `signal` aborted the scan before the source ended. */
    readonly stopped: boolean;
}
/**
 * How a pick is presented.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface PickOptions<A> {
    readonly message: string;
    readonly label: (item: A, position: number) => string;
    readonly hint?: ((item: A) => string | undefined) | undefined;
}
/**
 * How a confirmation is presented, and what it answers when nobody can be
 * asked.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface ConfirmOptions {
    readonly message: string;
    /** The option the cursor starts on. Defaults to `true`. */
    readonly initialValue?: boolean | undefined;
    /**
     * The answer in a non-interactive session. Required, because the safe
     * answer differs per question and a default here would decide it silently.
     */
    readonly nonInteractive: boolean;
}
/**
 * The rendering service.
 *
 * @category services
 * @since 1.0.0-rc.0
 */
export interface Service {
    readonly interactive: boolean;
    /** A required text value; cancellation or a non-interactive session returns None. */
    readonly text: (message: string) => Effect.Effect<Option.Option<string>>;
    readonly intro: (title?: string) => Effect.Effect<void>;
    readonly outro: (message: string) => Effect.Effect<void>;
    readonly note: (message: string, title?: string) => Effect.Effect<void>;
    readonly info: (message: string) => Effect.Effect<void>;
    readonly success: (message: string) => Effect.Effect<void>;
    readonly step: (message: string) => Effect.Effect<void>;
    readonly warn: (message: string) => Effect.Effect<void>;
    readonly error: (message: string) => Effect.Effect<void>;
    /** A titled list of checks; non-interactive output matches `Doctor.render`. */
    readonly checklist: (title: string, checks: ReadonlyArray<Check>) => Effect.Effect<void>;
    readonly spinner: () => Spinner;
    /**
     * Prints each item as it arrives while a spinner says the scan continues,
     * and returns everything received once the source settles or `signal`
     * aborts. A source that throws settles the spinner as an error and fails
     * with the thrown value.
     */
    readonly streamSuggestions: <A>(items: AsyncIterable<A>, options: StreamOptions<A>) => Effect.Effect<Streamed<A>, Error>;
    /**
     * A `select` over items already received. `None` when the list is empty,
     * when the operator cancels, or in a non-interactive session, where the
     * candidates are printed as numbered lines instead.
     */
    readonly pickSuggestion: <A>(items: ReadonlyArray<A>, options: PickOptions<A>) => Effect.Effect<Option.Option<A>>;
    /** A yes/no question. A cancelled prompt answers `false`. */
    readonly confirm: (options: ConfirmOptions) => Effect.Effect<boolean>;
}
declare const Ui_base: Context.ServiceClass<Ui, "/cli/Ui", Service>;
/**
 * Context key for the rendering service.
 *
 * @category services
 * @since 1.0.0-rc.0
 */
export declare class Ui extends Ui_base {
}
/**
 * The streams and the interactivity decision one service is built on.
 *
 * @category models
 * @since 1.0.0-rc.0
 */
export interface Options {
    readonly output: Writable;
    readonly input?: Readable | undefined;
    readonly interactive: boolean;
}
interface Terminal {
    readonly isTTY?: boolean | undefined;
}
/**
 * Whether a human session can animate and ask. Harness detection and explicit
 * audience overrides use the same policy as target and durable-run progress.
 *
 * @category predicates
 * @since 1.0.0-rc.0
 */
export declare const isInteractive: (output: Terminal, input: Terminal, environment: Environment.Source) => boolean;
/**
 * The fixed-width word a checklist line leads with.
 * @category formatting
 * @since 1.0.0
 */
export declare const levelWord: (level: Check["level"]) => string;
/**
 * Builds a service on explicit streams.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const make: (options: Options) => Service;
/**
 * Renders a checklist to a string, for handlers that print through `Output`
 * and `Console` rather than writing to a stream themselves.
 *
 * The non-interactive text is what `Doctor.render` returns; the
 * interactive text carries clack's symbols and, when the real stdout has
 * colour, its escape sequences.
 *
 * @category conversions
 * @since 1.0.0-rc.0
 */
export declare const renderChecklist: (title: string, checks: ReadonlyArray<Check>, options: {
    readonly interactive: boolean;
    readonly columns?: number | undefined;
}) => string;
/**
 * The service on the process's own streams.
 *
 * @category layers
 * @since 1.0.0-rc.0
 */
export declare const layer: (environment: Environment.Source) => Layer.Layer<Ui>;
/**
 * The service in scope, or one built on the process's streams when no layer
 * provided it. Handlers read this so a test can inject a fake terminal
 * without every test composition having to.
 *
 * @category accessors
 * @since 1.0.0-rc.0
 */
export declare const current: Effect.Effect<Service>;
/**
 * Required-input prompts use stderr so piping a document leaves stdin usable.
 *
 * @category accessors
 * @since 1.0.0-rc.0
 */
export declare const prompting: Effect.Effect<Service>;
export {};
