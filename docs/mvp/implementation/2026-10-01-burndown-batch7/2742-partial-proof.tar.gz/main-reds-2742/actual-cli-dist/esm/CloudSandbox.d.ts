/**
 * Scoped Smithers Cloud workspaces for any sandbox-backed flow.
 *
 * @since 1.0.0
 */
import { type Sandbox } from "@smthrs/sandbox";
import { Duration } from "effect";
import type { ChildProcessSpawner } from "effect/unstable/process/ChildProcessSpawner";
/**
 * Workspace control transport. Supply a fake for deterministic lifecycle tests;
 * ordinary hosts use the CLI's authenticated API client and pinned SSH prefix.
 * Implementations must honor the supplied abort signal, including time bounds.
 *
 * @category models
 * @since 1.0.0
 */
export interface WorkspaceApi {
    request(method: "POST" | "GET" | "DELETE", path: string, body: unknown, signal: AbortSignal): Promise<unknown>;
    sshPrefix(reference: string, signal: AbortSignal): Promise<ReadonlyArray<string>>;
}
/**
 * The ordinary workspace transport: the CLI's authenticated control client and
 * pinned SSH prefix, resolved from `environment`.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const workspaceApi: (environment: Readonly<Record<string, string | undefined>>) => WorkspaceApi;
/**
 * One repository and machine shape, shared by independently named sessions.
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    /** Local host spawner, used to run the SSH client. */
    readonly spawner: ChildProcessSpawner["Service"];
    /** Cloud repository, OWNER/REPO. */
    readonly repository: string;
    /** The CLI's origin and login settings; defaults to process.env. */
    readonly environment?: Readonly<Record<string, string | undefined>> | undefined;
    /** Repository bookmark to check out; defaults to the repository default. */
    readonly sourceBookmark?: string | undefined;
    /** Absolute guest checkout path; defaults to /home/developer/workspace. */
    readonly workdir?: string | undefined;
    /** Prefix for the SHA-256 session name; defaults to smthrs-. */
    readonly namePrefix?: string | undefined;
    /** Provisioning status cadence; defaults to 3 seconds. */
    readonly pollInterval?: Duration.Input | undefined;
    /** Maximum wait for running; defaults to 10 minutes. */
    readonly readyTimeout?: Duration.Input | undefined;
    /** Optional workspace transport for alternate hosts and lifecycle tests. */
    readonly api?: WorkspaceApi | undefined;
}
/**
 * Creates or resumes a Cloud workspace by its stable session name, waits until
 * running, and projects CommandSandbox over freshly acquired SSH grants.
 * Closing the acquiring scope deletes the workspace, including when readiness
 * or SSH setup fails or the caller is interrupted. Concurrent holders must use
 * distinct session keys; reusing a key is an exclusive resume claim.
 *
 * Credentials are resolved locally by the existing CLI transport, never placed
 * in workspace creation metadata or provider failures. Agent credentials are
 * supplied separately by the caller to each command.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const make: (options: Options) => Sandbox.Provider;
