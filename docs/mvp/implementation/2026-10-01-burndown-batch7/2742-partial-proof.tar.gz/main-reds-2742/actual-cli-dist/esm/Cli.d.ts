/**
 * Unified Incur CLI; Effect remains the durable execution and service runtime.
 * Command handlers acquire services only after parsing, keeping help/schema inert.
 * @since 1.0.0
 */
import { makeCli as makeBuildCli } from "@smthrs/build-cli/Cli";
import * as Bridge from "./cli/ControlBridge.ts";
/**
 * Construct the public command tree without opening stores or evaluating declarations.
 * @category constructors
 * @since 1.0.0
 */
export declare const makeCli: (config?: Bridge.Runtime) => ReturnType<typeof makeBuildCli>;
