/**
 * Shared pre-parser globals. The declaration coverage test pins this table to
 * Command's root flags and ControlBridge's connection options.
 * @since 1.0.0
 */
/**
 * The shared flags with their values, and every word they did not claim.
 *
 * @category models
 * @since 1.0.0
 */
export interface Globals {
    readonly argv: ReadonlyArray<string>;
    /** Original positions of the words retained in rest. */
    readonly restIndices: ReadonlyArray<number>;
    /** Other options, kept in rest but with their values treated as opaque. */
    readonly options: ReadonlyMap<string, string | boolean>;
    readonly root: string | undefined;
    readonly remote: string | undefined;
    readonly mcpConfig: string | undefined;
    readonly backend: string | undefined;
    readonly audience: string | undefined;
    readonly format: string | undefined;
    readonly json: boolean;
    readonly quiet: boolean;
    readonly silent: boolean;
    readonly verbose: boolean;
    /**
     * Argv with every recognized global removed, in order. A global with a
     * malformed value (`--json=maybe`, a trailing `--root` with nothing after
     * it) stays here, so a reader that must not guess sees it. `--` and every
     * word after it are kept verbatim.
     */
    readonly rest: ReadonlyArray<string>;
    /** The index in argv of the first word the globals did not claim; `argv.length` when they claimed all of it. */
    readonly first: number;
}
/** Parser output adds transport metadata without narrowing the existing Globals input contract. */
interface ParsedGlobals extends Globals {
    /** Equivalent options with opaque values protected from Incur built-in extraction. */
    readonly incurArgv: ReadonlyArray<string>;
    /** Actual stdio transport selection, excluding opaque option values and literal tails. */
    readonly mcp: boolean;
}
/**
 * Parses the shared globals out of raw argv.
 *
 * Valued globals retain the configuration reader's inline `=value` or next
 * word semantics; the command parser owns syntax validation. A switch takes an
 * inline boolean literal, a following boolean literal, or nothing, and
 * `--no-<switch>` clears it. The first occurrence of a flag wins, as
 * `NodeControl.makeConfig` always promised.
 *
 * @category parsing
 * @since 1.0.0
 */
export declare const parse: (args: ReadonlyArray<string> | Globals, cli?: object) => ParsedGlobals;
/**
 * The words one command line offers a verb lookup, in order.
 *
 * `rest` still holds every option the globals did not claim, so a reader that
 * wants the verb has to step over them. A valued option this pre-parser
 * recognizes takes its value with it; an unknown one is a switch, because
 * guessing an arity would swallow the verb standing behind it. Everything
 * after `--` is an argument, never a verb.
 *
 * @category parsing
 * @since 1.0.0
 */
export declare const words: (args: ReadonlyArray<string> | Globals) => ReadonlyArray<string>;
export {};
