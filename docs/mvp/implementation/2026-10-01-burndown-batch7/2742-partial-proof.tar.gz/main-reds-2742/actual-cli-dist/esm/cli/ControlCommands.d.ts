/**
 * Durable flow, run, and approval commands for the unified CLI.
 * @since 1.0.0
 */
import { Control, type ControlSchema } from "@smthrs/control";
import { Effect, Schema } from "effect";
import { Cli } from "incur";
import * as CliError from "../CliError.ts";
import { cancelAll } from "../commands/CancelAll.ts";
import * as Bridge from "./ControlBridge.ts";
export { cancelAll };
/**
 * The flow catalog and explicit plan/start lifecycle.
 * @category constructors
 * @since 1.0.0
 */
export declare const createFlowCli: (runtime?: Bridge.Runtime) => Cli.Cli<{
    list: {
        args: {};
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    show: {
        args: {
            flow: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    plan: {
        args: {
            flow: string;
            input: string[];
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            data?: string | undefined;
        };
    };
} & {
    start: {
        args: {
            flow: string;
        };
        options: {
            quiet: boolean;
            detached: boolean;
            wait: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            data?: string | undefined;
            budgetTokens?: number | undefined;
            budgetMs?: number | undefined;
            budgetUsd?: number | undefined;
            onExceeded?: "warn" | "fail" | "park" | "skip-remaining" | undefined;
            deadline?: string | undefined;
        };
    };
} & {
    execute: {
        args: {
            approval: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "flow">;
/**
 * Canonical commands for existing durable run records.
 * @category constructors
 * @since 1.0.0
 */
export declare const createRunsCli: (runtime?: Bridge.Runtime) => Cli.Cli<{
    wait: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            timeout?: number | undefined;
        };
    };
} & {
    list: {
        args: {};
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            flow?: string | undefined;
            status?: "failed" | "running" | "completed" | "cancelled" | "accepted" | "parked" | "waiting-approval" | undefined;
            since?: string | undefined;
            until?: string | undefined;
            sort?: "newest" | "oldest" | undefined;
            parent?: string | undefined;
            trigger?: string | undefined;
            limit?: number | undefined;
            cursor?: string | undefined;
        };
    };
} & {
    count: {
        args: {};
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            flow?: string | undefined;
            status?: "failed" | "running" | "completed" | "cancelled" | "accepted" | "parked" | "waiting-approval" | undefined;
            since?: string | undefined;
            until?: string | undefined;
            sort?: "newest" | "oldest" | undefined;
            parent?: string | undefined;
            trigger?: string | undefined;
        };
    };
} & {
    show: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    devtools: {
        args: {
            run: string;
            node?: string | undefined;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            frames?: number | undefined;
        };
    };
} & {
    logs: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            follow: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            after?: number | undefined;
            limit?: number | undefined;
        };
    };
} & {
    output: {
        args: {
            run: string;
            node?: string | undefined;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    cancel: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    "cancel-all": {
        args: {};
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    resume: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            allowCodeDrift: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    continue: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    stop: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    signal: {
        args: {
            run: string;
            payload: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    steer: {
        args: {
            run: string;
        };
        options: {
            quiet: boolean;
            message: string;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "runs">;
/**
 * The latest request a budget or time guard parked the run on, decided or not.
 *
 * A run that parks again after a Continue holds a newer request, so the
 * latest is the one an operator answers. The request's `incident` carries the
 * facts the guard froze when it tripped.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const guardIncident: (runId: string) => Effect.Effect<{
    incident: {
        readonly message: string;
        readonly source: "tokens" | "cell" | "usd" | "tool-call" | "latency" | "model-call";
        readonly classification: "Runaway" | "Stuck";
        readonly subject?: string | undefined;
        readonly next?: number | undefined;
        readonly max?: number | undefined;
        readonly used?: number | undefined;
        readonly reserved?: number | undefined;
        readonly allowance?: number | undefined;
    };
    runId: string;
    waitRunId?: string | undefined;
    questionProvenance?: "events" | "legacy-observation" | "unverified-observation" | undefined;
    requestId: string;
    title: string;
    request: ControlSchema.ControlEvent["payload"];
    payload: ControlSchema.ApprovalPayload;
    requestedAt: number;
    status: "pending" | "approved" | "denied";
} | undefined, CliError.ResourceLimitError | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, Control.Control>;
/**
 * Pending in-run approvals, including pages beyond the first.
 *
 * A run whose whole TREE is waiting on a person is one of these: the control
 * plane rolls a nested `HumanTask` park up to `waiting-approval`, so the
 * filter finds the root, and `waits` names the open questions beneath it.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const pendingApprovals: (runId?: string) => Effect.Effect<{
    waits?: {
        request?: Schema.Json;
        attempt?: number;
        name?: string;
        flowId?: string;
        runId: string;
    }[];
    incident?: {
        readonly message: string;
        readonly source: "tokens" | "cell" | "usd" | "tool-call" | "latency" | "model-call";
        readonly classification: "Runaway" | "Stuck";
        readonly subject?: string | undefined;
        readonly next?: number | undefined;
        readonly max?: number | undefined;
        readonly used?: number | undefined;
        readonly reserved?: number | undefined;
        readonly allowance?: number | undefined;
    };
    runId: string;
    flowId: string;
    question: string | undefined;
    approval: string | undefined;
}[], CliError.ResourceLimitError | CliError.Refused | import("@smthrs/notifications/NotificationQueue").NotificationError | import("@smthrs/control/ControlError").RunNotFound | import("@smthrs/control/ControlError").PlanNotFound | import("@smthrs/control/ControlError").PlanDenied | import("@smthrs/control/ControlError").FlowNotFound | import("@smthrs/control/ControlError").PlanDigestMismatch | import("@smthrs/control/ControlError").EnvelopeMismatch | import("@smthrs/control/ControlError").ClaimLost | import("@smthrs/control/ControlError").CodeDrift | import("@smthrs/control/ControlError").AlreadyResolved | import("@smthrs/control/ControlError").InvalidInput | import("@smthrs/control/ControlError").Unauthorized | import("@smthrs/control/ControlError").Unavailable | import("@smthrs/control/ControlError").TransportError | import("@smthrs/control/ControlError").PersistenceError | import("@smthrs/control/ControlError").LaunchFailed | import("@smthrs/control/ControlError").NoMatchingWait | import("@smthrs/control/ControlError").CredentialConflict, Control.Control>;
/**
 * Pending decisions and approval payload submission.
 * @category constructors
 * @since 1.0.0
 */
export declare const createApprovalsCli: (runtime?: Bridge.Runtime) => Cli.Cli<{
    list: {
        args: {};
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
            run?: string | undefined;
            targets?: boolean | undefined;
        };
    };
} & {
    approve: {
        args: {
            approval: string;
        };
        options: {
            quiet: boolean;
            scope: "run" | "once" | "remembered";
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    deny: {
        args: {
            approval: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            mcpConfig?: string | undefined;
        };
    };
} & {
    grant: {
        args: {
            target: string;
        };
        options: {
            quiet: boolean;
            root?: string | undefined;
            remote?: string | undefined;
            input?: string[] | undefined;
            revision?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "approvals">;
