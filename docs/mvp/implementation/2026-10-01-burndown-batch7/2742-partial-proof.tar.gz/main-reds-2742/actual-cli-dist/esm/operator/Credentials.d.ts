/**
 * Encrypted local credentials; command output contains references only.
 *
 * @since 1.0.0
 */
import * as Credential from "@smthrs/control/Credential";
import { Effect, Redacted } from "effect";
import { Cli } from "incur";
import { type LocalOptions } from "./Store.ts";
/**
 * Selects exactly one source for a credential secret.
 * @category models
 * @since 1.0.0
 */
export interface SecretOptions {
    readonly secretEnv?: string | undefined;
    readonly secretFile?: string | undefined;
}
/**
 * Reads a credential without exposing it through command output.
 * @category constructors
 * @since 1.0.0
 */
export declare const readSecret: (options: SecretOptions, root: string) => Redacted.Redacted<string>;
/**
 * Runs an operation against the authoritative encrypted credential store.
 * @category constructors
 * @since 1.0.0
 */
export declare const withCredentials: <A, E>(options: LocalOptions, operation: (service: Credential.Credential) => Effect.Effect<A, E>, needsKey?: boolean) => Promise<A>;
/**
 * Builds the local credential administration command group.
 * @category constructors
 * @since 1.0.0
 */
export declare const createCredentialsCli: () => Cli.Cli<{
    list: {
        args: {};
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    add: {
        args: {
            id: string;
        };
        options: {
            name: string;
            secretEnv?: string | undefined;
            secretFile?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    rotate: {
        args: {
            id: string;
        };
        options: {
            secretEnv?: string | undefined;
            secretFile?: string | undefined;
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
} & {
    revoke: {
        args: {
            id: string;
        };
        options: {
            root?: string | undefined;
            remote?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "credentials">;
