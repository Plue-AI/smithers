/**
 * Shared local persistence for operator commands.
 *
 * @since 1.0.0
 */
import { Layer } from "effect";
import { z } from "incur";
import type * as Environment from "../Environment.ts";
/**
 * Connection fields shared by local operator commands.
 * @category schemas
 * @since 1.0.0
 */
export declare const localFields: {
    root: z.ZodOptional<z.ZodString>;
    remote: z.ZodOptional<z.ZodString>;
};
/**
 * Parsed project selection for local operator commands.
 * @category models
 * @since 1.0.0
 */
export interface LocalOptions {
    readonly root?: string | undefined;
    readonly remote?: string | undefined;
}
/**
 * Resolves the project root and refuses remote operator access.
 * @category constructors
 * @since 1.0.0
 */
export declare const localRoot: (options: LocalOptions, environment?: Environment.Source) => string;
/**
 * Shares the authoritative control database and its migration ledger.
 * @category layers
 * @since 1.0.0
 */
export declare const databaseLayer: (root: string) => Layer.Layer<import("effect/Crypto").Crypto | import("effect/unstable/sql/SqlClient").SqlClient | import("@smthrs/database/DurableWriter").DurableWriter, import("effect/PlatformError").PlatformError | import("effect/unstable/sql/SqlError").SqlError | import("effect/unstable/sql/Migrator").MigrationError, never>;
