/**
 * Generic persistent execution environments.
 * @since 1.0.0
 */
import { Cli } from "incur";
import type { Runtime } from "./ControlBridge.ts";
/**
 * Create the location management and command execution projection.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const createEnvironmentCli: (runtime: Runtime) => Cli.Cli<{
    add: {
        args: {
            name: string;
        };
        options: {
            local: boolean;
            directory: string;
            ssh?: string | undefined;
            workspace?: string | undefined;
            home?: string | undefined;
        };
    };
} & {
    list: {
        args: {};
        options: {};
    };
} & {
    view: {
        args: {
            name: string;
        };
        options: {};
    };
} & {
    remove: {
        args: {
            name: string;
        };
        options: {};
    };
} & {
    exec: {
        args: {
            name: string;
        };
        options: {
            arg: string[];
            terminal: boolean;
        };
    };
} & {
    shell: {
        args: {
            name: string;
        };
        options: {};
    };
} & {
    forward: {
        args: {
            name: string;
        };
        options: {
            localPort: number;
            remotePort: number;
        };
    };
}, undefined, undefined, undefined, "environment">;
