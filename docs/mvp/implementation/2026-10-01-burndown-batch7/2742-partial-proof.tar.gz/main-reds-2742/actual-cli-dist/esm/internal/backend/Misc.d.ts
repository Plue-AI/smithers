/**
 * Raw API, configuration and remote agent conversation commands.
 * @since 0.1.0
 */
import type { Handler } from "./Resources.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const misc: Record<string, Handler>;
