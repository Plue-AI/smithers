/**
 * Workspace API operations, terminal sessions and durable remote execution.
 * @since 0.1.0
 */
import { type Client, type Values } from "./Client.ts";
import type { Handler } from "./Resources.ts";
import { type Endpoint } from "./SSH.ts";
/**
 * @private
 * @since 1.0.0
 */
export declare const resolveID: (c: Client, a: Values, o: Values) => Promise<string>;
/**
 * @private
 * @since 1.0.0
 */
export declare const workspaceBody: (o: Values) => Values;
/**
 * @private
 * @since 1.0.0
 */
export declare const workspaces: Record<string, Handler>;
/**
 * Run Claude as the box's developer, including images whose SSH user is root.
 * @private
 * @since 1.0.0
 */
export declare const claudeScript: (prompt: string) => string;
/**
 * @private
 * @since 1.0.0
 */
export declare const workspaceSSH: (c: Client, id: string, options: Values) => Promise<Endpoint>;
