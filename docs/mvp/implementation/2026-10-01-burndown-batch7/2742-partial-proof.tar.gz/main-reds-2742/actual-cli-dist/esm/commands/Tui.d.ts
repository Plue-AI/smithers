/**
 * `smthrs tui`: hands the terminal to the Smithers TUI.
 *
 * The TUI renders with `@opentui/core`, whose native library loads through
 * Bun's FFI or through Node's `node:ffi`, which needs Node >= 26.4 started
 * with `--experimental-ffi`. This CLI cannot enable FFI in its own running
 * process, so it always starts the TUI as a child with the terminal inherited
 * and exits with the child's status. The first match wins:
 *
 * 1. `SMITHERS_TUI_BIN`: that executable.
 * 2. An installation's compiled binary, `@smthrs/tui-<os>-<arch>[-baseline][-musl]`
 *    (an optional dependency built by `scripts/build-tui-binaries.mjs`), so
 *    `npx smthrs tui` needs neither Bun nor a particular Node.
 * 3. Bun, when `SMITHERS_BUN` names it or this CLI already runs on Bun.
 * 4. This Node, when it is >= 26.4, with `--experimental-ffi`.
 * 5. Otherwise an `UnsupportedError` naming Node >= 26.4 and Bun.
 *
 * The entry Bun or Node runs is the bundle `scripts/build-tui.mjs` writes to
 * `dist/tui/main.js`. A source checkout skips the compiled binaries, which
 * would be stale; there Bun runs `apps/tui/src/main.tsx` directly, and Node
 * runs the bundle after rebuilding it (esbuild takes well under a second and
 * rewrites only changed files), because the workspace's TypeScript sources do
 * not run on plain Node.
 *
 * @since 1.0.0
 */
import * as CliError from "../CliError.ts";
/**
 * The TUI's own flags, forwarded unchanged.
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    /** Execute the app where this environment keeps its agents and sessions. */
    readonly environment?: string | undefined;
    readonly directory?: string | undefined;
    readonly model?: string | undefined;
    readonly continue?: boolean | undefined;
    readonly resume?: boolean | undefined;
    readonly print?: string | undefined;
    readonly approve?: "all" | "ask" | "deny" | undefined;
    /** Validated by the TUI. */
    readonly budgetTokens?: string | undefined;
}
/**
 * The argument vector `apps/tui/src/main.tsx` parses.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const argv: (options: Options) => Array<string>;
/**
 * What the launch decision reads from the machine, so tests can fake it.
 *
 * @category models
 * @since 1.0.0
 */
export interface Host {
    readonly platform: string;
    readonly arch: string;
    readonly execPath: string;
    readonly versions: {
        readonly node: string;
        readonly bun?: string | undefined;
    };
    readonly exists: (path: string) => boolean;
    /** The directory of a package as `packageRoot`'s package resolves it, or `undefined`. */
    readonly packageDirectory: (name: string, packageRoot: URL) => string | undefined;
    readonly musl: () => boolean;
    readonly avx2: () => boolean;
}
/**
 * The process this CLI runs in. Package lookups resolve from `@smthrs/cli`,
 * which is meant to declare the platform packages as optional dependencies.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const host: Host;
/**
 * The compiled TUI packages that can run here, best first: the exact build,
 * then the other libc or CPU-baseline builds this machine can still run.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const binaryPackages: (machine: Host) => Array<string>;
/**
 * Whether `packageRoot` is `packages/smithers` inside a Smithers checkout.
 *
 * @category predicates
 * @since 1.0.0
 */
export declare const checkout: (packageRoot: URL, machine?: Host) => boolean;
/**
 * The TUI entry Bun (`bun: true`) or Node runs for the package rooted at
 * `packageRoot`: the checkout source for Bun inside the workspace, else the
 * bundle.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const entry: (packageRoot: URL, bun: boolean, machine?: Host) => string;
/**
 * A process to start: the executable and its arguments before the TUI's own.
 *
 * @category models
 * @since 1.0.0
 */
export interface Launch {
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    /** The runtime the choice fell to, for messages and tests. */
    readonly runtime: "binary" | "bun" | "node";
}
/**
 * The process that runs the TUI here, or an `UnsupportedError` when nothing
 * can. It does not build or check the Bun/Node entry; `run` does.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const launch: (environment: Record<string, string | undefined>, packageRoot: URL, machine?: Host) => Launch | CliError.UnsupportedError;
/**
 * Runs the TUI to completion and resolves with its exit status.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const run: (options: Options, environment: Record<string, string | undefined>, packageRoot?: URL, machine?: Host, signal?: AbortSignal) => Promise<number>;
