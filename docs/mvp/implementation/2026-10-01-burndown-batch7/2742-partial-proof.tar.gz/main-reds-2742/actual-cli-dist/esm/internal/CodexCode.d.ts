/**
 * A Codex subscription seat. Only the vendor binary holds and refreshes its login.
 * @since 1.0.0
 */
import type * as FlowEngineLike from "@smthrs/agent/FlowEngineLike";
import * as Model from "@smthrs/model/Model";
import type { ModelEvent } from "@smthrs/model/ModelEvent";
import * as ModelRequest from "@smthrs/model/ModelRequest";
/**
 * @private
 * @since 1.0.0
 */
export interface Options {
    readonly model: string;
    readonly executable: string;
    readonly environment: Readonly<Record<string, string | undefined>>;
    readonly cwd?: string | undefined;
    readonly timeoutMs?: number | undefined;
    readonly maxBytes?: number | undefined;
    /**
     * Whether the vendor loads the Smithers MCP server, the seat's only tools.
     * Defaults to true; false makes a tool-free seat for untrusted input, such
     * as a security review of source.
     */
    readonly mcp?: boolean | undefined;
}
/**
 * A subscription cannot be silently replaced by an ambient API key or token.
 * @private
 * @since 1.0.0
 */
export declare const environment: (source: Readonly<Record<string, string | undefined>>) => NodeJS.ProcessEnv;
/**
 * Fresh invocations carry the complete history; no hidden vendor history affects replay.
 * @private
 * @since 1.0.0
 */
export declare const command: (options: Options, request: ModelRequest.ModelRequest) => ReadonlyArray<string>;
/**
 * Validate the JSONL receipt before publishing any answer as completed.
 * @private
 * @since 1.0.0
 */
export declare const parse: (stdout: string) => ReadonlyArray<ModelEvent>;
/**
 * @private
 * @since 1.0.0
 */
export declare const make: (options: Options) => Model.Model;
/**
 * @private
 * @since 1.0.0
 */
export declare const route: (model: string) => FlowEngineLike.RouteResolver;
