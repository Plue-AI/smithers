/**
 * Backend commands mounted into the single npm CLI command tree.
 * @since 1.0.0
 */
import { Cli } from "incur";
import type { Runtime } from "../../cli/ControlBridge.ts";
import { type Handler } from "./Resources.ts";
/** @private
 * @since 1.0.0
 */
export declare const handlers: Record<string, Handler>;
/** @private
 * Help summaries for the command groups the backend commands create.
 * @since 1.0.0
 */
export declare const groups: Record<string, string>;
/** @private
 * @since 1.0.0
 */
export declare const commandPath: (name: string) => string;
/** @private
 * @since 1.0.0
 */
export declare const mount: (cli: Cli.Cli<any, any, any, any>, runtime: Runtime) => void;
