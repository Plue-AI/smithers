/**
 * Streaming workspace copies with archive containment at the local boundary.
 * @since 1.0.0
 */
import type { Stats } from "node:fs";
import * as tar from "tar";
import type { Handler } from "./Resources.ts";
/** @private
 * @since 1.0.0
 */
export declare const copyEndpoint: (raw: string) => {
    remote: boolean;
    id: string;
    path: string;
};
/** @private
 * @since 1.0.0
 */
export declare const copyScript: (upload: boolean, path: string, name: string, contents: boolean) => string;
/** @private
 * @since 1.0.0
 */
export declare const archiveFilter: (root: string) => (path: string, entry: tar.ReadEntry | Stats) => boolean;
/** @private
 * @since 1.0.0
 */
export declare const copy: Handler;
