/**
 * `smthrs token mint`: a scoped, expiring gateway token signed under
 * `SMITHERS_TOKEN`.
 *
 * The gateway verifies the token with the same credential it serves under
 * (`@smthrs/control` `ScopedToken`), so minting needs no running gateway and
 * stores nothing. The verb runs on the host that holds the credential; it is
 * never offered over MCP, where a connected client could otherwise turn the
 * host's credential into tokens of its own.
 *
 * @since 1.0.0
 */
import * as ScopedToken from "@smthrs/control/ScopedToken";
import { Effect } from "effect";
import { Cli } from "incur";
import type * as Bridge from "../cli/ControlBridge.ts";
import * as CliError from "../CliError.ts";
/**
 * What `token mint` reports: the token, when it stops working, and the exact
 * grant it carries.
 *
 * @category models
 * @since 1.0.0
 */
export interface MintedToken {
    readonly token: string;
    readonly expiresAt: string;
    readonly scopes: ReadonlyArray<ScopedToken.Scope>;
    readonly procedures: ReadonlyArray<string>;
    readonly runId?: string | undefined;
    readonly flowId?: string | undefined;
}
/**
 * Mints one token from the environment's `SMITHERS_TOKEN`.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const mint: (options: {
    readonly scope: ReadonlyArray<ScopedToken.Scope>;
    readonly ttl: string;
    readonly run?: string | undefined;
    readonly flow?: string | undefined;
}, environment: Record<string, string | undefined>) => Effect.Effect<MintedToken, CliError.UsageError>;
/**
 * Builds the `token` command group.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const createTokenCli: (config?: Bridge.Runtime) => Cli.Cli<{
    mint: {
        args: {};
        options: {
            scope: ("read:runs" | "write:runs" | "approve:runs")[];
            ttl: string;
            run?: string | undefined;
            flow?: string | undefined;
        };
    };
}, undefined, undefined, undefined, "token">;
