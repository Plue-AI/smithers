/** Sends one product API request. The CLI's backend `Client` is one; so is anything with these two methods. */
export interface Transport {
    /** Sends a JSON request and resolves to the parsed JSON response, or null when it has no body. */
    request(method: string, path: string, body?: unknown): Promise<unknown>;
    /** Sends a request and resolves to the raw response, for streams and files. */
    response(method: string, path: string, body?: unknown): Promise<Response>;
}
export type AppBootstrap = { apiVersion: 1; authFlow: "credentials" | "none" | "redirect"; buildSha: string; capabilities: Array<"agent" | "billing.balance" | "billing.checkout" | "billing.overview" | "billing.plans" | "billing.portal" | "cloud" | "cloud.terminal" | "github" | "identity" | "model.turn" | "recommend">; host: "cloud"; sandbox: null | { mode: "enforced" | "trusted-only"; platform: string; }; version: string; };
export type RepositoryTransferRequest = { created_at: string; expires_at: string; id: number; recipient_id: number; repository_id: number; resolved_at?: null | string; sender_id: number; source_name: string; source_org_id?: null | number; source_owner: string; source_user_id?: null | number; status: "accepted" | "cancelled" | "declined" | "expired" | "pending"; };
/** Repository response using its current owner. pending_transfer is present while a user transfer awaits acceptance. */
export type RepositoryTransferResponse = { clone_url?: string; full_name?: string; owner?: string; pending_transfer?: RepositoryTransferRequest; };
export type BillingPlan = { checkout_available: boolean; display_name: string; interval: "annual" | "monthly"; key: "free" | "max" | "pro"; limits: { agent_runs: number; ci_minutes: number; concurrent_sandboxes: number; hours_per_day: number; idle_timeout_secs: number; private_repos: number; seats: number; storage_bytes: number; }; price_cents: number; };
export type BillingPlansResponse = { current_plan_key: string; plans: Array<BillingPlan>; };
export type SandboxEntitlement = { child_max_ttl_secs?: number; concurrent_children?: number; concurrent_in_use: number; concurrent_sandboxes: number; day_resets_at: string; hours_per_day: number; idle_timeout_secs: number; plan_key: string; seconds_used_today: number; };
/** Endpoint-specific JSON response. */
export type AnyJSON = unknown;
/** Where a comment was written. Comments created from a synced Slack or Telegram message carry that provider; every other comment was written in the app. */
export type IssueCommentOrigin = "app" | "slack" | "telegram";
export type IssueComment = { [key: string]: unknown; body: string; commenter: string; created_at: string; id: number; idempotency_key?: string; issue_id: number; origin: IssueCommentOrigin; persona?: Record<string, unknown>; type: string; updated_at: string; user_id: number; };
/** The issue's newest comment. */
export type IssueLastComment = { commenter: string; created_at: string; excerpt: string; origin: IssueCommentOrigin; persona?: Record<string, unknown>; };
export type Issue = { [key: string]: unknown; author: Record<string, unknown>; body: string; comment_count: number; created_at: string; id: number; idempotency_key?: string; kind: string; last_comment: IssueLastComment | null; number: number; state: string; title: string; updated_at: string; visibility: string; };
export type GitMirrorSyncRunStatus = { behind_refs: number; failed_refs: number; finished_at: null | string; refs: Array<Record<string, unknown>>; started_at: null | string; state: "failed" | "queued" | "running" | "succeeded"; };
export type SyncRunAccepted = { run_id: number; };
export type ChangeFinding = { analyzer: string; anchor_hash?: string; commit_id: string; created_at: string; feedback?: "fixed" | "not_useful" | "useful"; id: number; line: number; path: string; seq: number; severity: string; side: "both" | "left" | "right"; source: "analyzer" | "reviewer"; state: "current" | "moved" | "stale"; suggestion?: string; text: string; };
export type ChangeAnalyzerRun = { failure_reason?: string; finished_at: null | string; name: string; paused_by?: string; paused_reason?: string; seq: number; started_at: null | string; state: "done" | "failed" | "paused" | "queued" | "running"; };
export type ChangeFindingsResponse = { analyzers: Array<ChangeAnalyzerRun>; change_id: string; current_seq: number; findings: Array<ChangeFinding>; };
export type ResolveChangeConflictRequest = { path: string; };
export type ResolveChangeConflictResponse = { agent_session_id: string; };
export type SandboxEgressAuditEntries = Array<SandboxEgressAuditEntry>;
export type SandboxEgressAuditEntry = { allowed: boolean; host: string; method: string; occurred_at: string; path: string; status: number; swapped_secret_names: Array<string>; };
export type MultiWorkflowRunsResponse = { [key: string]: unknown; workflow_runs: Array<MultiWorkflowRun>; };
export type MultiWorkflowRun = { [key: string]: unknown; check_run_id?: null | number; check_run_url?: null | string; completed_at?: null | string; created_at: string; id: number; repository_id: number; started_at?: null | string; status: string; trigger_commit_sha: string; trigger_event: string; trigger_ref: string; updated_at: string; workflow_definition_id: number; };
export type MultiWorkflowStepsResponse = { [key: string]: unknown; steps: Array<MultiWorkflowStep>; };
export type MultiWorkflowStep = { [key: string]: unknown; completed_at?: null | string; created_at: string; id: number; name: string; position: number; started_at?: null | string; status: string; updated_at: string; workflow_run_id: number; };
export type IssueStateFact = { entity_key: string; entity_type: "issue" | "issue_assignee" | "issue_label"; id: string; issue_id: number; operation: "baseline" | "created" | "deleted" | "updated"; post_image?: IssueAssigneeStateRow | IssueLabelStateRow | IssueStateRow; recorded_at: string; schema_version: 1; sequence: number; stream_id: string; };
export type IssueStateRow = { author_id: number; body: string; closed_at: null | string; comment_count: number; created_at: string; fixed_at: null | string; fixed_by_agent_session_id: null | string; fixed_by_id: null | number; id: number; milestone_id: null | number; number: number; repository_id: number; state: "closed" | "fixed" | "open" | "verified"; title: string; updated_at: string; verified_at: null | string; verified_by_agent_session_id: null | string; verified_by_id: null | number; };
export type IssueLabelStateRow = { created_at: string; issue_id: number; label_id: number; };
export type IssueAssigneeStateRow = { created_at: string; id: number; issue_id: number; user_id: null | number; };
export type IssueStateFactPage = { coverage: { kind: "from_creation" | "legacy_snapshot"; started_at?: string; }; cursor: number; events: Array<IssueStateFact>; has_more: boolean; head: number; schema_version: 1; stream_id: string; };
export type NotificationFact = { id: string; notification?: NotificationPostImage; notification_id: number; recorded_at: string; schema_version: 1; sequence: number; stream_id: string; type: "notification.baseline" | "notification.created" | "notification.deleted" | "notification.read" | "notification.unread" | "notification.updated"; };
export type NotificationPostImage = { body: string; created_at: string; id: number; read_at: null | string; source_id: null | number; source_type: string; status: "pinned" | "read" | "unread"; subject: string; updated_at: string; };
export type NotificationFactPage = { coverage: { kind: "from_creation" | "legacy_snapshot"; started_at?: string; }; cursor: number; events: Array<NotificationFact>; has_more: boolean; head: number; schema_version: 1; stream_id: string; visibility_filtered: boolean; };
export type MultiNotificationListResponse = Array<MultiNotification>;
export type MultiNotification = { [key: string]: unknown; body?: string; created_at?: string; id: number; last_read_at?: null | string; read_at?: null | string; reason?: string; repository?: { [key: string]: unknown; full_name?: string; }; source_id?: unknown; source_type?: string; status?: string; subject: MultiNotificationSubject | string; unread?: boolean; updated_at?: string; };
export type MultiNotificationSubject = { [key: string]: unknown; title: string; type?: string; url?: string; };
export type MultiGitHubImportJob = { [key: string]: unknown; counts: { issues: MultiGitHubImportCount; objects: MultiGitHubImportCount; refs: MultiGitHubImportCount; }; created_at: string; error?: string; importJobId: string; repoName: string; repoOwner: string; repository?: { name: string; owner: string; }; stage: string; status: "cloning" | "failed" | "ready"; target_bookmark: string; updated_at: string; workspace?: unknown; workspace_id?: string; };
export type MultiGitHubImportCount = { done: number; total: number; };
export type MultiSSETicketResponse = { [key: string]: unknown; ticket: string; };
export type MultiBillingOverview = { [key: string]: unknown; account?: MultiBillingAccount | null; billing_interval: string; entitlements?: Array<MultiBillingEntitlement>; owner_id?: number; owner_name: string; owner_type: string; plan_key: string; sandbox?: SandboxEntitlement; stripe_configured: boolean; subscription?: MultiBillingSubscription | null; usage: Array<MultiBillingUsage>; usage_period_end?: string; usage_period_start?: string; };
export type MultiBillingAccount = { [key: string]: unknown; created_at?: string; stripe_customer_email?: string; stripe_customer_id?: string; stripe_customer_name?: string; updated_at?: string; };
export type MultiBillingSubscription = { [key: string]: unknown; billing_interval: string; cancel_at_period_end: boolean; canceled_at?: string; current_period_end?: string; current_period_start?: string; plan_key: string; quantity: number; status: string; stripe_price_id?: string; stripe_subscription_id?: string; trial_end?: string; };
export type MultiBillingEntitlement = { [key: string]: unknown; active: boolean; feature_key: string; last_synced_at: string; };
export type MultiBillingUsage = { [key: string]: unknown; consumed_quantity: number; included_quantity: number; metric_key: string; overage_quantity: number; };
export type MultiBillingSessionResult = { [key: string]: unknown; url: string; };
export type ErrorDetail = { code: string; field?: string; message?: string; resource?: string; };
export type Error = { [key: string]: unknown; code?: string; errors?: Array<ErrorDetail>; fault?: string; limit_kind?: "agent_runs" | "concurrent_sandboxes" | "organizations" | "repositories" | "sandbox_hours_per_day"; message: string; plan_key?: string; request_id?: string; retryable?: boolean; upgrade_plan_key?: string; };
export type SSHKey = { created_at: string; fingerprint: string; id: number; key_type: string; name: string; };
export type AdminCreditGrantRequest = { amountUsd: number; login: string; operationKey: string; };
export type AdminCreditGrantReceipt = { amountUsd: number; duplicate: boolean; grantId: string; granted: true; login: string; operationKey: string; };
export type PostApiAdminGrantBody = AdminCreditGrantRequest;
export type PostApiAdminGrantResponse = AdminCreditGrantReceipt;
export interface PostApiAdminGrantInput {
    readonly body: PostApiAdminGrantBody;
}
/** POST /api/admin/grant: Grant credit to a user */
export declare const postApiAdminGrant: (transport: Transport, input: PostApiAdminGrantInput) => Promise<PostApiAdminGrantResponse>;
export interface DeleteApiAdminUsersUsernameInput {
    readonly path: { readonly username: string; };
}
/** DELETE /api/admin/users/{username} */
export declare const deleteApiAdminUsersUsername: (transport: Transport, input: DeleteApiAdminUsersUsernameInput) => Promise<void>;
export type PatchApiAdminUsersUsernameResponse = AnyJSON;
export interface PatchApiAdminUsersUsernameInput {
    readonly path: { readonly username: string; };
}
/** PATCH /api/admin/users/{username} */
export declare const patchApiAdminUsersUsername: (transport: Transport, input: PatchApiAdminUsersUsernameInput) => Promise<PatchApiAdminUsersUsernameResponse>;
export interface DeleteApiAdminUsersUsernameTokensTokenIdInput {
    readonly path: { readonly token_id: string; readonly username: string; };
}
/** DELETE /api/admin/users/{username}/tokens/{token_id} */
export declare const deleteApiAdminUsersUsernameTokensTokenId: (transport: Transport, input: DeleteApiAdminUsersUsernameTokensTokenIdInput) => Promise<void>;
export type GetApiAdminAgentSessionsResponse = AnyJSON;
/** GET /api/admin/agent-sessions */
export declare const getApiAdminAgentSessions: (transport: Transport) => Promise<GetApiAdminAgentSessionsResponse>;
export type GetApiAdminAnalyticsSummaryResponse = AnyJSON;
/** GET /api/admin/analytics/summary */
export declare const getApiAdminAnalyticsSummary: (transport: Transport) => Promise<GetApiAdminAnalyticsSummaryResponse>;
/** GET /api/admin/audit-logs */
export declare const getApiAdminAuditLogs: (transport: Transport) => Promise<Response>;
export type GetApiAdminOrgsResponse = AnyJSON;
/** GET /api/admin/orgs */
export declare const getApiAdminOrgs: (transport: Transport) => Promise<GetApiAdminOrgsResponse>;
export type GetApiAdminReposResponse = AnyJSON;
/** GET /api/admin/repos */
export declare const getApiAdminRepos: (transport: Transport) => Promise<GetApiAdminReposResponse>;
export type GetApiAdminSandboxEnvironmentImagesResponse = AnyJSON;
/** GET /api/admin/sandbox/environment-images */
export declare const getApiAdminSandboxEnvironmentImages: (transport: Transport) => Promise<GetApiAdminSandboxEnvironmentImagesResponse>;
export type PostApiAdminSandboxEnvironmentImagesResponse = AnyJSON;
/** POST /api/admin/sandbox/environment-images */
export declare const postApiAdminSandboxEnvironmentImages: (transport: Transport) => Promise<PostApiAdminSandboxEnvironmentImagesResponse>;
export type GetApiAdminSystemHealthResponse = AnyJSON;
/** GET /api/admin/system/health */
export declare const getApiAdminSystemHealth: (transport: Transport) => Promise<GetApiAdminSystemHealthResponse>;
export type GetApiAdminSystemStatusResponse = AnyJSON;
/** GET /api/admin/system/status */
export declare const getApiAdminSystemStatus: (transport: Transport) => Promise<GetApiAdminSystemStatusResponse>;
export type GetApiAdminTokensResponse = AnyJSON;
/** GET /api/admin/tokens */
export declare const getApiAdminTokens: (transport: Transport) => Promise<GetApiAdminTokensResponse>;
export type GetApiAdminUsersResponse = AnyJSON;
/** GET /api/admin/users */
export declare const getApiAdminUsers: (transport: Transport) => Promise<GetApiAdminUsersResponse>;
export type PostApiAdminUsersResponse = AnyJSON;
/** POST /api/admin/users */
export declare const postApiAdminUsers: (transport: Transport) => Promise<PostApiAdminUsersResponse>;
export type GetApiAdminWorkspacesResponse = AnyJSON;
/** GET /api/admin/workspaces */
export declare const getApiAdminWorkspaces: (transport: Transport) => Promise<GetApiAdminWorkspacesResponse>;
export type PostApiAdminUsersUsernameEraseBody = { request_date: string; user_id?: number; };
export type PostApiAdminUsersUsernameEraseResponse = { already_erased?: boolean; repositories?: number; rows_changed?: number; tombstone?: string; user_id?: number; workspaces?: number; };
export interface PostApiAdminUsersUsernameEraseInput {
    readonly path: { readonly username: string; };
    readonly body: PostApiAdminUsersUsernameEraseBody;
}
/** POST /api/admin/users/{username}/erase */
export declare const postApiAdminUsersUsernameErase: (transport: Transport, input: PostApiAdminUsersUsernameEraseInput) => Promise<PostApiAdminUsersUsernameEraseResponse>;
export interface PostApiAdminUsersUsernameExportInput {
    readonly path: { readonly username: string; };
}
/** POST /api/admin/users/{username}/export */
export declare const postApiAdminUsersUsernameExport: (transport: Transport, input: PostApiAdminUsersUsernameExportInput) => Promise<Response>;
export type PatchApiAdminUsersUsernameAdminResponse = AnyJSON;
export interface PatchApiAdminUsersUsernameAdminInput {
    readonly path: { readonly username: string; };
}
/** PATCH /api/admin/users/{username}/admin */
export declare const patchApiAdminUsersUsernameAdmin: (transport: Transport, input: PatchApiAdminUsersUsernameAdminInput) => Promise<PatchApiAdminUsersUsernameAdminResponse>;
export type PostApiAdminAgentSessionsIdCancelResponse = AnyJSON;
export interface PostApiAdminAgentSessionsIdCancelInput {
    readonly path: { readonly id: string; };
}
/** POST /api/admin/agent-sessions/{id}/cancel */
export declare const postApiAdminAgentSessionsIdCancel: (transport: Transport, input: PostApiAdminAgentSessionsIdCancelInput) => Promise<PostApiAdminAgentSessionsIdCancelResponse>;
export type PostApiAdminGithubAppReconcileResponse = AnyJSON;
/** POST /api/admin/github-app/reconcile */
export declare const postApiAdminGithubAppReconcile: (transport: Transport) => Promise<PostApiAdminGithubAppReconcileResponse>;
export type PostApiAdminUsersUsernameTokensResponse = AnyJSON;
export interface PostApiAdminUsersUsernameTokensInput {
    readonly path: { readonly username: string; };
}
/** POST /api/admin/users/{username}/tokens */
export declare const postApiAdminUsersUsernameTokens: (transport: Transport, input: PostApiAdminUsersUsernameTokensInput) => Promise<PostApiAdminUsersUsernameTokensResponse>;
export type PostApiAdminWorkspacesIdStopResponse = AnyJSON;
export interface PostApiAdminWorkspacesIdStopInput {
    readonly path: { readonly id: string; };
}
/** POST /api/admin/workspaces/{id}/stop */
export declare const postApiAdminWorkspacesIdStop: (transport: Transport, input: PostApiAdminWorkspacesIdStopInput) => Promise<PostApiAdminWorkspacesIdStopResponse>;
export type PostApiAdminWorkspacesIdSuspendResponse = AnyJSON;
export interface PostApiAdminWorkspacesIdSuspendInput {
    readonly path: { readonly id: string; };
}
/** POST /api/admin/workspaces/{id}/suspend */
export declare const postApiAdminWorkspacesIdSuspend: (transport: Transport, input: PostApiAdminWorkspacesIdSuspendInput) => Promise<PostApiAdminWorkspacesIdSuspendResponse>;
export type PostApiAgentTurnBody = AnyJSON;
export type PostApiAgentTurnResponse = AnyJSON;
export interface PostApiAgentTurnInput {
    readonly body: PostApiAgentTurnBody;
}
/** POST /api/agent/turn */
export declare const postApiAgentTurn: (transport: Transport, input: PostApiAgentTurnInput) => Promise<PostApiAgentTurnResponse>;
export type PostApiAgentTurnCancelBody = AnyJSON;
export type PostApiAgentTurnCancelResponse = AnyJSON;
export interface PostApiAgentTurnCancelInput {
    readonly body?: PostApiAgentTurnCancelBody;
}
/** POST /api/agent/turn/cancel */
export declare const postApiAgentTurnCancel: (transport: Transport, input?: PostApiAgentTurnCancelInput) => Promise<PostApiAgentTurnCancelResponse>;
export type PostApiAgentTurnEraseBody = AnyJSON;
export type PostApiAgentTurnEraseResponse = AnyJSON;
export interface PostApiAgentTurnEraseInput {
    readonly body?: PostApiAgentTurnEraseBody;
}
/** POST /api/agent/turn/erase */
export declare const postApiAgentTurnErase: (transport: Transport, input?: PostApiAgentTurnEraseInput) => Promise<PostApiAgentTurnEraseResponse>;
export type PostApiAgentTurnReplayBody = AnyJSON;
export type PostApiAgentTurnReplayResponse = AnyJSON;
export interface PostApiAgentTurnReplayInput {
    readonly body?: PostApiAgentTurnReplayBody;
}
/** POST /api/agent/turn/replay */
export declare const postApiAgentTurnReplay: (transport: Transport, input?: PostApiAgentTurnReplayInput) => Promise<PostApiAgentTurnReplayResponse>;
export type PostApiAgentTurnRetireBody = AnyJSON;
export type PostApiAgentTurnRetireResponse = AnyJSON;
export interface PostApiAgentTurnRetireInput {
    readonly body?: PostApiAgentTurnRetireBody;
}
/** POST /api/agent/turn/retire */
export declare const postApiAgentTurnRetire: (transport: Transport, input?: PostApiAgentTurnRetireInput) => Promise<PostApiAgentTurnRetireResponse>;
export type DeleteApiAppTimelinesIdMembersUserDResponse = AnyJSON;
export interface DeleteApiAppTimelinesIdMembersUserDInput {
    readonly path: { readonly id: string; readonly userId: string; };
}
/** DELETE /api/app-timelines/{id}/members/{userId} */
export declare const deleteApiAppTimelinesIdMembersUserD: (transport: Transport, input: DeleteApiAppTimelinesIdMembersUserDInput) => Promise<DeleteApiAppTimelinesIdMembersUserDResponse>;
export type GetApiAppTimelinesIdResponse = AnyJSON;
export interface GetApiAppTimelinesIdInput {
    readonly path: { readonly id: string; };
}
/** GET /api/app-timelines/{id} */
export declare const getApiAppTimelinesId: (transport: Transport, input: GetApiAppTimelinesIdInput) => Promise<GetApiAppTimelinesIdResponse>;
export type GetApiAppTimelinesIdMembersResponse = AnyJSON;
export interface GetApiAppTimelinesIdMembersInput {
    readonly path: { readonly id: string; };
}
/** GET /api/app-timelines/{id}/members */
export declare const getApiAppTimelinesIdMembers: (transport: Transport, input: GetApiAppTimelinesIdMembersInput) => Promise<GetApiAppTimelinesIdMembersResponse>;
export type PostApiAppTimelinesIdMembersBody = AnyJSON;
export type PostApiAppTimelinesIdMembersResponse = AnyJSON;
export interface PostApiAppTimelinesIdMembersInput {
    readonly path: { readonly id: string; };
    readonly body?: PostApiAppTimelinesIdMembersBody;
}
/** POST /api/app-timelines/{id}/members */
export declare const postApiAppTimelinesIdMembers: (transport: Transport, input: PostApiAppTimelinesIdMembersInput) => Promise<PostApiAppTimelinesIdMembersResponse>;
export type PostApiAppTimelinesBody = AnyJSON;
export type PostApiAppTimelinesResponse = AnyJSON;
export interface PostApiAppTimelinesInput {
    readonly body?: PostApiAppTimelinesBody;
}
/** POST /api/app-timelines */
export declare const postApiAppTimelines: (transport: Transport, input?: PostApiAppTimelinesInput) => Promise<PostApiAppTimelinesResponse>;
export type PostApiAppTimelinesIdEventsBody = AnyJSON;
export type PostApiAppTimelinesIdEventsResponse = AnyJSON;
export interface PostApiAppTimelinesIdEventsInput {
    readonly path: { readonly id: string; };
    readonly body?: PostApiAppTimelinesIdEventsBody;
}
/** POST /api/app-timelines/{id}/events */
export declare const postApiAppTimelinesIdEvents: (transport: Transport, input: PostApiAppTimelinesIdEventsInput) => Promise<PostApiAppTimelinesIdEventsResponse>;
export type PutApiAppTimelinesIdSnapshotsBody = AnyJSON;
export type PutApiAppTimelinesIdSnapshotsResponse = AnyJSON;
export interface PutApiAppTimelinesIdSnapshotsInput {
    readonly path: { readonly id: string; };
    readonly body?: PutApiAppTimelinesIdSnapshotsBody;
}
/** PUT /api/app-timelines/{id}/snapshots */
export declare const putApiAppTimelinesIdSnapshots: (transport: Transport, input: PutApiAppTimelinesIdSnapshotsInput) => Promise<PutApiAppTimelinesIdSnapshotsResponse>;
export type PutApiAppTimelinesIdStateBody = AnyJSON;
export type PutApiAppTimelinesIdStateResponse = AnyJSON;
export interface PutApiAppTimelinesIdStateInput {
    readonly path: { readonly id: string; };
    readonly body?: PutApiAppTimelinesIdStateBody;
}
/** PUT /api/app-timelines/{id}/state */
export declare const putApiAppTimelinesIdState: (transport: Transport, input: PutApiAppTimelinesIdStateInput) => Promise<PutApiAppTimelinesIdStateResponse>;
export type GetApiAuthAuth0AuthorizeResponse = AnyJSON;
/** GET /api/auth/auth0/authorize */
export declare const getApiAuthAuth0Authorize: (transport: Transport) => Promise<GetApiAuthAuth0AuthorizeResponse>;
export type GetApiAuthAuth0CallbackResponse = AnyJSON;
/** GET /api/auth/auth0/callback */
export declare const getApiAuthAuth0Callback: (transport: Transport) => Promise<GetApiAuthAuth0CallbackResponse>;
export type GetApiAuthGithubResponse = AnyJSON;
/** GET /api/auth/github */
export declare const getApiAuthGithub: (transport: Transport) => Promise<GetApiAuthGithubResponse>;
export type GetApiAuthGithubCallbackResponse = AnyJSON;
/** GET /api/auth/github/callback */
export declare const getApiAuthGithubCallback: (transport: Transport) => Promise<GetApiAuthGithubCallbackResponse>;
export interface GetApiAuthGithubCliInput {
    readonly query: { readonly admin?: "1"; readonly callback_port: number; readonly callback_state?: string; readonly scopes?: string; readonly ttl?: string; };
}
/** GET /api/auth/github/cli */
export declare const getApiAuthGithubCli: (transport: Transport, input: GetApiAuthGithubCliInput) => Promise<void>;
/** GET /api/auth/github/cli/consent: Deny pending administrator CLI login */
export declare const getApiAuthGithubCliConsent: (transport: Transport) => Promise<Response>;
export type GetApiAuthKeyNonceResponse = AnyJSON;
/** GET /api/auth/key/nonce */
export declare const getApiAuthKeyNonce: (transport: Transport) => Promise<GetApiAuthKeyNonceResponse>;
export type PostApiAuthGithubTokenExchangeResponse = AnyJSON;
/** POST /api/auth/github/token-exchange */
export declare const postApiAuthGithubTokenExchange: (transport: Transport) => Promise<PostApiAuthGithubTokenExchangeResponse>;
export type PostApiAuthKeyTokenResponse = AnyJSON;
/** POST /api/auth/key/token */
export declare const postApiAuthKeyToken: (transport: Transport) => Promise<PostApiAuthKeyTokenResponse>;
export type PostApiAuthKeyVerifyResponse = AnyJSON;
/** POST /api/auth/key/verify */
export declare const postApiAuthKeyVerify: (transport: Transport) => Promise<PostApiAuthKeyVerifyResponse>;
export type PostApiAuthLogoutResponse = AnyJSON;
/** POST /api/auth/logout */
export declare const postApiAuthLogout: (transport: Transport) => Promise<PostApiAuthLogoutResponse>;
export type PostApiAuthSseTicketResponse = MultiSSETicketResponse;
/** POST /api/auth/sse-ticket */
export declare const postApiAuthSseTicket: (transport: Transport) => Promise<PostApiAuthSseTicketResponse>;
export type GetApiAuthLocalStatusResponse = AnyJSON;
/** GET /api/auth/local/status */
export declare const getApiAuthLocalStatus: (transport: Transport) => Promise<GetApiAuthLocalStatusResponse>;
export type PostApiAuthLocalBootstrapBody = AnyJSON;
export type PostApiAuthLocalBootstrapResponse = AnyJSON;
export interface PostApiAuthLocalBootstrapInput {
    readonly body?: PostApiAuthLocalBootstrapBody;
}
/** POST /api/auth/local/bootstrap */
export declare const postApiAuthLocalBootstrap: (transport: Transport, input?: PostApiAuthLocalBootstrapInput) => Promise<PostApiAuthLocalBootstrapResponse>;
export type PostApiAuthLocalLoginBody = AnyJSON;
export type PostApiAuthLocalLoginResponse = AnyJSON;
export interface PostApiAuthLocalLoginInput {
    readonly body?: PostApiAuthLocalLoginBody;
}
/** POST /api/auth/local/login */
export declare const postApiAuthLocalLogin: (transport: Transport, input?: PostApiAuthLocalLoginInput) => Promise<PostApiAuthLocalLoginResponse>;
export type PostApiAuthLocalPasswordBody = AnyJSON;
export type PostApiAuthLocalPasswordResponse = AnyJSON;
export interface PostApiAuthLocalPasswordInput {
    readonly body?: PostApiAuthLocalPasswordBody;
}
/** POST /api/auth/local/password */
export declare const postApiAuthLocalPassword: (transport: Transport, input?: PostApiAuthLocalPasswordInput) => Promise<PostApiAuthLocalPasswordResponse>;
export type PostApiAuthLocalTokenBody = AnyJSON;
export type PostApiAuthLocalTokenResponse = AnyJSON;
export interface PostApiAuthLocalTokenInput {
    readonly body?: PostApiAuthLocalTokenBody;
}
/** POST /api/auth/local/token */
export declare const postApiAuthLocalToken: (transport: Transport, input?: PostApiAuthLocalTokenInput) => Promise<PostApiAuthLocalTokenResponse>;
export type GetApiBillingResponse = MultiBillingOverview;
/** GET /api/billing */
export declare const getApiBilling: (transport: Transport) => Promise<GetApiBillingResponse>;
export type GetApiBillingPlansResponse = BillingPlansResponse;
/** GET /api/billing/plans */
export declare const getApiBillingPlans: (transport: Transport) => Promise<GetApiBillingPlansResponse>;
export type PostApiBillingCheckoutBody = { interval: "annual" | "monthly"; plan: "max" | "personal" | "pro"; };
export type PostApiBillingCheckoutResponse = MultiBillingSessionResult;
export interface PostApiBillingCheckoutInput {
    readonly body: PostApiBillingCheckoutBody;
}
/** POST /api/billing/checkout */
export declare const postApiBillingCheckout: (transport: Transport, input: PostApiBillingCheckoutInput) => Promise<PostApiBillingCheckoutResponse>;
export type PostApiBillingPortalResponse = MultiBillingSessionResult;
/** POST /api/billing/portal */
export declare const postApiBillingPortal: (transport: Transport) => Promise<PostApiBillingPortalResponse>;
export type PostApiBillingRefreshResponse = MultiBillingOverview;
/** POST /api/billing/refresh */
export declare const postApiBillingRefresh: (transport: Transport) => Promise<PostApiBillingRefreshResponse>;
export type PostApiBillingWebhookResponse = AnyJSON;
/** POST /api/billing/webhook */
export declare const postApiBillingWebhook: (transport: Transport) => Promise<PostApiBillingWebhookResponse>;
export type GetApiBillingBalanceResponse = AnyJSON;
/** GET /api/billing/balance */
export declare const getApiBillingBalance: (transport: Transport) => Promise<GetApiBillingBalanceResponse>;
export type GetApiBootstrapResponse = AppBootstrap;
/** GET /api/bootstrap: Read the instance bootstrap document */
export declare const getApiBootstrap: (transport: Transport) => Promise<GetApiBootstrapResponse>;
/** HEAD /api/bootstrap: Probe the instance bootstrap document */
export declare const headApiBootstrap: (transport: Transport) => Promise<void>;
export type GetApiBuildCacheHealthzResponse = AnyJSON;
/** GET /api/build-cache/healthz */
export declare const getApiBuildCacheHealthz: (transport: Transport) => Promise<GetApiBuildCacheHealthzResponse>;
/** HEAD /api/build-cache/healthz */
export declare const headApiBuildCacheHealthz: (transport: Transport) => Promise<void>;
export type GetApiFeatureFlagsResponse = AnyJSON;
/** GET /api/feature-flags */
export declare const getApiFeatureFlags: (transport: Transport) => Promise<GetApiFeatureFlagsResponse>;
export type PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestBody = AnyJSON;
export type PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestResponse = AnyJSON;
export interface PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestInput {
    readonly path: { readonly hostID: string; readonly requestID: string; };
    readonly body?: PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestBody;
}
/** PUT /api/gateways/{hostID}/repository-jobs/ci/check-receipts/{requestID} */
export declare const putApiGatewaysHostRepositoryJobsCiCheckReceiptsRequest: (transport: Transport, input: PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestInput) => Promise<PutApiGatewaysHostRepositoryJobsCiCheckReceiptsRequestResponse>;
export type PutApiGatewaysHostRepositoryJobsJobBody = AnyJSON;
export type PutApiGatewaysHostRepositoryJobsJobResponse = AnyJSON;
export interface PutApiGatewaysHostRepositoryJobsJobInput {
    readonly path: { readonly hostID: string; readonly job: string; };
    readonly body?: PutApiGatewaysHostRepositoryJobsJobBody;
}
/** PUT /api/gateways/{hostID}/repository-jobs/{job} */
export declare const putApiGatewaysHostRepositoryJobsJob: (transport: Transport, input: PutApiGatewaysHostRepositoryJobsJobInput) => Promise<PutApiGatewaysHostRepositoryJobsJobResponse>;
export type PutApiGatewaysHostRepositoryJobsJobCommentsStepBody = AnyJSON;
export type PutApiGatewaysHostRepositoryJobsJobCommentsStepResponse = AnyJSON;
export interface PutApiGatewaysHostRepositoryJobsJobCommentsStepInput {
    readonly path: { readonly hostID: string; readonly job: string; readonly step: string; };
    readonly body?: PutApiGatewaysHostRepositoryJobsJobCommentsStepBody;
}
/** PUT /api/gateways/{hostID}/repository-jobs/{job}/comments/{step} */
export declare const putApiGatewaysHostRepositoryJobsJobCommentsStep: (transport: Transport, input: PutApiGatewaysHostRepositoryJobsJobCommentsStepInput) => Promise<PutApiGatewaysHostRepositoryJobsJobCommentsStepResponse>;
export type PutApiGatewaysHostRepositoryJobsJobManualRequestBody = AnyJSON;
export type PutApiGatewaysHostRepositoryJobsJobManualRequestResponse = AnyJSON;
export interface PutApiGatewaysHostRepositoryJobsJobManualRequestInput {
    readonly path: { readonly hostID: string; readonly job: string; readonly requestID: string; };
    readonly body?: PutApiGatewaysHostRepositoryJobsJobManualRequestBody;
}
/** PUT /api/gateways/{hostID}/repository-jobs/{job}/manual/{requestID} */
export declare const putApiGatewaysHostRepositoryJobsJobManualRequest: (transport: Transport, input: PutApiGatewaysHostRepositoryJobsJobManualRequestInput) => Promise<PutApiGatewaysHostRepositoryJobsJobManualRequestResponse>;
export type PutApiGatewaysHostRepositoryJobsJobTrialsRequestBody = AnyJSON;
export type PutApiGatewaysHostRepositoryJobsJobTrialsRequestResponse = AnyJSON;
export interface PutApiGatewaysHostRepositoryJobsJobTrialsRequestInput {
    readonly path: { readonly hostID: string; readonly job: string; readonly requestID: string; };
    readonly body?: PutApiGatewaysHostRepositoryJobsJobTrialsRequestBody;
}
/** PUT /api/gateways/{hostID}/repository-jobs/{job}/trials/{requestID} */
export declare const putApiGatewaysHostRepositoryJobsJobTrialsRequest: (transport: Transport, input: PutApiGatewaysHostRepositoryJobsJobTrialsRequestInput) => Promise<PutApiGatewaysHostRepositoryJobsJobTrialsRequestResponse>;
export type GetApiGithubImportIdResponse = MultiGitHubImportJob;
export interface GetApiGithubImportIdInput {
    readonly path: { readonly id: string; };
}
/** GET /api/github/import/{id} */
export declare const getApiGithubImportId: (transport: Transport, input: GetApiGithubImportIdInput) => Promise<GetApiGithubImportIdResponse>;
export type GetApiGithubSyncedReposResponse = AnyJSON;
/** GET /api/github/synced-repos */
export declare const getApiGithubSyncedRepos: (transport: Transport) => Promise<GetApiGithubSyncedReposResponse>;
export type PostApiGithubImportResponse = MultiGitHubImportJob;
/** POST /api/github/import */
export declare const postApiGithubImport: (transport: Transport) => Promise<PostApiGithubImportResponse>;
export type PostApiGithubImportIdRetryResponse = MultiGitHubImportJob;
export interface PostApiGithubImportIdRetryInput {
    readonly path: { readonly id: string; };
}
/** POST /api/github/import/{id}/retry */
export declare const postApiGithubImportIdRetry: (transport: Transport, input: PostApiGithubImportIdRetryInput) => Promise<PostApiGithubImportIdRetryResponse>;
export type PostApiGithubSyncedReposOwnerRepoMirrorStatusResponse = AnyJSON;
export interface PostApiGithubSyncedReposOwnerRepoMirrorStatusInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/github/synced-repos/{owner}/{repo}/mirror-status */
export declare const postApiGithubSyncedReposOwnerRepoMirrorStatus: (transport: Transport, input: PostApiGithubSyncedReposOwnerRepoMirrorStatusInput) => Promise<PostApiGithubSyncedReposOwnerRepoMirrorStatusResponse>;
export type GetApiStatusResponse = { checked_at: string; components: { canary: { detail: string; status: "error" | "ok" | "unknown"; }; }; status: "degraded" | "ok"; };
/** GET /api/status: Read public canary status */
export declare const getApiStatus: (transport: Transport) => Promise<GetApiStatusResponse>;
export type GetApiHealthResponse = AnyJSON;
/** GET /api/health */
export declare const getApiHealth: (transport: Transport) => Promise<GetApiHealthResponse>;
export type PostWebhooksGithubResponse = AnyJSON;
/** POST /webhooks/github */
export declare const postWebhooksGithub: (transport: Transport) => Promise<PostWebhooksGithubResponse>;
export type GetApiIntegrationsMcpResponse = AnyJSON;
/** GET /api/integrations/mcp */
export declare const getApiIntegrationsMcp: (transport: Transport) => Promise<GetApiIntegrationsMcpResponse>;
export type GetApiIntegrationsSkillsResponse = AnyJSON;
/** GET /api/integrations/skills */
export declare const getApiIntegrationsSkills: (transport: Transport) => Promise<GetApiIntegrationsSkillsResponse>;
export type GetApiReposOwnerRepoIssueViewsResponse = Array<{ id: string; labels?: Array<string>; state?: "all" | "closed" | "fixed" | "open" | "verified"; title: string; }>;
export interface GetApiReposOwnerRepoIssueViewsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issue-views */
export declare const getApiReposOwnerRepoIssueViews: (transport: Transport, input: GetApiReposOwnerRepoIssueViewsInput) => Promise<GetApiReposOwnerRepoIssueViewsResponse>;
export type GetApiMetaFailureCodesResponse = AnyJSON;
/** GET /api/meta/failure-codes */
export declare const getApiMetaFailureCodes: (transport: Transport) => Promise<GetApiMetaFailureCodesResponse>;
export type GetApiModelCatalogResponse = AnyJSON;
/** GET /api/model/catalog */
export declare const getApiModelCatalog: (transport: Transport) => Promise<GetApiModelCatalogResponse>;
export type GetApiModelCredentialReceiptResponse = AnyJSON;
/** GET /api/model/credential/receipt */
export declare const getApiModelCredentialReceipt: (transport: Transport) => Promise<GetApiModelCredentialReceiptResponse>;
export type GetApiModelDefaultResponse = AnyJSON;
/** GET /api/model/default */
export declare const getApiModelDefault: (transport: Transport) => Promise<GetApiModelDefaultResponse>;
export type PutApiModelDefaultBody = AnyJSON;
export type PutApiModelDefaultResponse = AnyJSON;
export interface PutApiModelDefaultInput {
    readonly body?: PutApiModelDefaultBody;
}
/** PUT /api/model/default */
export declare const putApiModelDefault: (transport: Transport, input?: PutApiModelDefaultInput) => Promise<PutApiModelDefaultResponse>;
export type PostApiModelAnthropicPathBody = AnyJSON;
export type PostApiModelAnthropicPathResponse = AnyJSON;
export interface PostApiModelAnthropicPathInput {
    readonly path: { readonly path: string; };
    readonly body?: PostApiModelAnthropicPathBody;
}
/** POST /api/model/anthropic/{path} */
export declare const postApiModelAnthropicPath: (transport: Transport, input: PostApiModelAnthropicPathInput) => Promise<PostApiModelAnthropicPathResponse>;
export type PostApiModelCerebrasPathBody = AnyJSON;
export type PostApiModelCerebrasPathResponse = AnyJSON;
export interface PostApiModelCerebrasPathInput {
    readonly path: { readonly path: string; };
    readonly body?: PostApiModelCerebrasPathBody;
}
/** POST /api/model/cerebras/{path} */
export declare const postApiModelCerebrasPath: (transport: Transport, input: PostApiModelCerebrasPathInput) => Promise<PostApiModelCerebrasPathResponse>;
export type PostApiModelCredentialBody = AnyJSON;
export type PostApiModelCredentialResponse = AnyJSON;
export interface PostApiModelCredentialInput {
    readonly body?: PostApiModelCredentialBody;
}
/** POST /api/model/credential */
export declare const postApiModelCredential: (transport: Transport, input?: PostApiModelCredentialInput) => Promise<PostApiModelCredentialResponse>;
export type PostApiModelOpenaiPathBody = AnyJSON;
export type PostApiModelOpenaiPathResponse = AnyJSON;
export interface PostApiModelOpenaiPathInput {
    readonly path: { readonly path: string; };
    readonly body?: PostApiModelOpenaiPathBody;
}
/** POST /api/model/openai/{path} */
export declare const postApiModelOpenaiPath: (transport: Transport, input: PostApiModelOpenaiPathInput) => Promise<PostApiModelOpenaiPathResponse>;
export type PostApiModelOpenrouterPathBody = AnyJSON;
export type PostApiModelOpenrouterPathResponse = AnyJSON;
export interface PostApiModelOpenrouterPathInput {
    readonly path: { readonly path: string; };
    readonly body?: PostApiModelOpenrouterPathBody;
}
/** POST /api/model/openrouter/{path} */
export declare const postApiModelOpenrouterPath: (transport: Transport, input: PostApiModelOpenrouterPathInput) => Promise<PostApiModelOpenrouterPathResponse>;
export type PostApiModelStreamBody = AnyJSON;
export type PostApiModelStreamResponse = AnyJSON;
export interface PostApiModelStreamInput {
    readonly body?: PostApiModelStreamBody;
}
/** POST /api/model/stream */
export declare const postApiModelStream: (transport: Transport, input?: PostApiModelStreamInput) => Promise<PostApiModelStreamResponse>;
export type PostApiModelTestBody = AnyJSON;
export type PostApiModelTestResponse = AnyJSON;
export interface PostApiModelTestInput {
    readonly body?: PostApiModelTestBody;
}
/** POST /api/model/test */
export declare const postApiModelTest: (transport: Transport, input?: PostApiModelTestInput) => Promise<PostApiModelTestResponse>;
export type PostApiModelVercelPathBody = AnyJSON;
export type PostApiModelVercelPathResponse = AnyJSON;
export interface PostApiModelVercelPathInput {
    readonly path: { readonly path: string; };
    readonly body?: PostApiModelVercelPathBody;
}
/** POST /api/model/vercel/{path} */
export declare const postApiModelVercelPath: (transport: Transport, input: PostApiModelVercelPathInput) => Promise<PostApiModelVercelPathResponse>;
export type GetApiNotificationsResponse = AnyJSON;
/** GET /api/notifications */
export declare const getApiNotifications: (transport: Transport) => Promise<GetApiNotificationsResponse>;
export type GetApiNotificationsEventsResponse = NotificationFactPage;
export interface GetApiNotificationsEventsInput {
    readonly query?: { readonly after?: number; readonly limit?: number; };
}
/** GET /api/notifications/events */
export declare const getApiNotificationsEvents: (transport: Transport, input?: GetApiNotificationsEventsInput) => Promise<GetApiNotificationsEventsResponse>;
export interface GetApiNotificationsEventsStreamInput {
    readonly query?: { readonly after?: number; };
}
/** GET /api/notifications/events/stream */
export declare const getApiNotificationsEventsStream: (transport: Transport, input?: GetApiNotificationsEventsStreamInput) => Promise<Response>;
export type GetApiNotificationsListResponse = MultiNotificationListResponse;
/** GET /api/notifications/list */
export declare const getApiNotificationsList: (transport: Transport) => Promise<GetApiNotificationsListResponse>;
export type GetApiNotificationsPreferencesResponse = AnyJSON;
/** GET /api/notifications/preferences */
export declare const getApiNotificationsPreferences: (transport: Transport) => Promise<GetApiNotificationsPreferencesResponse>;
export type PutApiNotificationsPreferencesResponse = AnyJSON;
/** PUT /api/notifications/preferences */
export declare const putApiNotificationsPreferences: (transport: Transport) => Promise<PutApiNotificationsPreferencesResponse>;
export type PatchApiNotificationsIdResponse = AnyJSON;
export interface PatchApiNotificationsIdInput {
    readonly path: { readonly id: string; };
}
/** PATCH /api/notifications/{id} */
export declare const patchApiNotificationsId: (transport: Transport, input: PatchApiNotificationsIdInput) => Promise<PatchApiNotificationsIdResponse>;
/** PUT /api/notifications/mark-read */
export declare const putApiNotificationsMarkRead: (transport: Transport) => Promise<void>;
export type GetApiOauth2ApplicationsIdResponse = AnyJSON;
export interface GetApiOauth2ApplicationsIdInput {
    readonly path: { readonly id: string; };
}
/** GET /api/oauth2/applications/{id} */
export declare const getApiOauth2ApplicationsId: (transport: Transport, input: GetApiOauth2ApplicationsIdInput) => Promise<GetApiOauth2ApplicationsIdResponse>;
export interface DeleteApiOauth2ApplicationsIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/oauth2/applications/{id} */
export declare const deleteApiOauth2ApplicationsId: (transport: Transport, input: DeleteApiOauth2ApplicationsIdInput) => Promise<void>;
export type GetApiOauth2ApplicationsResponse = AnyJSON;
/** GET /api/oauth2/applications */
export declare const getApiOauth2Applications: (transport: Transport) => Promise<GetApiOauth2ApplicationsResponse>;
export type PostApiOauth2ApplicationsResponse = AnyJSON;
/** POST /api/oauth2/applications */
export declare const postApiOauth2Applications: (transport: Transport) => Promise<PostApiOauth2ApplicationsResponse>;
export type GetApiOauth2AuthorizeResponse = AnyJSON;
/** GET /api/oauth2/authorize */
export declare const getApiOauth2Authorize: (transport: Transport) => Promise<GetApiOauth2AuthorizeResponse>;
export type PostApiOauth2AuthorizeResponse = AnyJSON;
/** POST /api/oauth2/authorize */
export declare const postApiOauth2Authorize: (transport: Transport) => Promise<PostApiOauth2AuthorizeResponse>;
export type PostApiOauth2RevokeResponse = AnyJSON;
/** POST /api/oauth2/revoke */
export declare const postApiOauth2Revoke: (transport: Transport) => Promise<PostApiOauth2RevokeResponse>;
export type PostApiOauth2RevokeAllResponse = AnyJSON;
/** POST /api/oauth2/revoke-all */
export declare const postApiOauth2RevokeAll: (transport: Transport) => Promise<PostApiOauth2RevokeAllResponse>;
export type PostApiOauth2TokenResponse = AnyJSON;
/** POST /api/oauth2/token */
export declare const postApiOauth2Token: (transport: Transport) => Promise<PostApiOauth2TokenResponse>;
export interface DeleteApiOrgsOrgMembersUsernameInput {
    readonly path: { readonly org: string; readonly username: string; };
}
/** DELETE /api/orgs/{org}/members/{username} */
export declare const deleteApiOrgsOrgMembersUsername: (transport: Transport, input: DeleteApiOrgsOrgMembersUsernameInput) => Promise<void>;
export interface DeleteApiOrgsOrgSecretsNameInput {
    readonly path: { readonly name: string; readonly org: string; };
}
/** DELETE /api/orgs/{org}/secrets/{name} */
export declare const deleteApiOrgsOrgSecretsName: (transport: Transport, input: DeleteApiOrgsOrgSecretsNameInput) => Promise<void>;
export type GetApiOrgsOrgTeamsTeamResponse = AnyJSON;
export interface GetApiOrgsOrgTeamsTeamInput {
    readonly path: { readonly org: string; readonly team: string; };
}
/** GET /api/orgs/{org}/teams/{team} */
export declare const getApiOrgsOrgTeamsTeam: (transport: Transport, input: GetApiOrgsOrgTeamsTeamInput) => Promise<GetApiOrgsOrgTeamsTeamResponse>;
export interface DeleteApiOrgsOrgTeamsTeamInput {
    readonly path: { readonly org: string; readonly team: string; };
}
/** DELETE /api/orgs/{org}/teams/{team} */
export declare const deleteApiOrgsOrgTeamsTeam: (transport: Transport, input: DeleteApiOrgsOrgTeamsTeamInput) => Promise<void>;
export type PatchApiOrgsOrgTeamsTeamResponse = AnyJSON;
export interface PatchApiOrgsOrgTeamsTeamInput {
    readonly path: { readonly org: string; readonly team: string; };
}
/** PATCH /api/orgs/{org}/teams/{team} */
export declare const patchApiOrgsOrgTeamsTeam: (transport: Transport, input: PatchApiOrgsOrgTeamsTeamInput) => Promise<PatchApiOrgsOrgTeamsTeamResponse>;
export type PutApiOrgsOrgTeamsTeamMembersUsernameResponse = AnyJSON;
export interface PutApiOrgsOrgTeamsTeamMembersUsernameInput {
    readonly path: { readonly org: string; readonly team: string; readonly username: string; };
}
/** PUT /api/orgs/{org}/teams/{team}/members/{username} */
export declare const putApiOrgsOrgTeamsTeamMembersUsername: (transport: Transport, input: PutApiOrgsOrgTeamsTeamMembersUsernameInput) => Promise<PutApiOrgsOrgTeamsTeamMembersUsernameResponse>;
export interface DeleteApiOrgsOrgTeamsTeamMembersUsernameInput {
    readonly path: { readonly org: string; readonly team: string; readonly username: string; };
}
/** DELETE /api/orgs/{org}/teams/{team}/members/{username} */
export declare const deleteApiOrgsOrgTeamsTeamMembersUsername: (transport: Transport, input: DeleteApiOrgsOrgTeamsTeamMembersUsernameInput) => Promise<void>;
export type PutApiOrgsOrgTeamsTeamReposOwnerRepoResponse = AnyJSON;
export interface PutApiOrgsOrgTeamsTeamReposOwnerRepoInput {
    readonly path: { readonly org: string; readonly owner: string; readonly repo: string; readonly team: string; };
}
/** PUT /api/orgs/{org}/teams/{team}/repos/{owner}/{repo} */
export declare const putApiOrgsOrgTeamsTeamReposOwnerRepo: (transport: Transport, input: PutApiOrgsOrgTeamsTeamReposOwnerRepoInput) => Promise<PutApiOrgsOrgTeamsTeamReposOwnerRepoResponse>;
export interface DeleteApiOrgsOrgTeamsTeamReposOwnerRepoInput {
    readonly path: { readonly org: string; readonly owner: string; readonly repo: string; readonly team: string; };
}
/** DELETE /api/orgs/{org}/teams/{team}/repos/{owner}/{repo} */
export declare const deleteApiOrgsOrgTeamsTeamReposOwnerRepo: (transport: Transport, input: DeleteApiOrgsOrgTeamsTeamReposOwnerRepoInput) => Promise<void>;
export interface DeleteApiOrgsOrgVariablesNameInput {
    readonly path: { readonly name: string; readonly org: string; };
}
/** DELETE /api/orgs/{org}/variables/{name} */
export declare const deleteApiOrgsOrgVariablesName: (transport: Transport, input: DeleteApiOrgsOrgVariablesNameInput) => Promise<void>;
export type GetApiOrgsOrgResponse = AnyJSON;
export interface GetApiOrgsOrgInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org} */
export declare const getApiOrgsOrg: (transport: Transport, input: GetApiOrgsOrgInput) => Promise<GetApiOrgsOrgResponse>;
export type PatchApiOrgsOrgResponse = AnyJSON;
export interface PatchApiOrgsOrgInput {
    readonly path: { readonly org: string; };
}
/** PATCH /api/orgs/{org} */
export declare const patchApiOrgsOrg: (transport: Transport, input: PatchApiOrgsOrgInput) => Promise<PatchApiOrgsOrgResponse>;
export type GetApiOrgsOrgBillingResponse = AnyJSON;
export interface GetApiOrgsOrgBillingInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/billing */
export declare const getApiOrgsOrgBilling: (transport: Transport, input: GetApiOrgsOrgBillingInput) => Promise<GetApiOrgsOrgBillingResponse>;
export type GetApiOrgsOrgChangesetsResponse = AnyJSON;
export interface GetApiOrgsOrgChangesetsInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/changesets */
export declare const getApiOrgsOrgChangesets: (transport: Transport, input: GetApiOrgsOrgChangesetsInput) => Promise<GetApiOrgsOrgChangesetsResponse>;
export type PostApiOrgsOrgChangesetsResponse = AnyJSON;
export interface PostApiOrgsOrgChangesetsInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/changesets */
export declare const postApiOrgsOrgChangesets: (transport: Transport, input: PostApiOrgsOrgChangesetsInput) => Promise<PostApiOrgsOrgChangesetsResponse>;
export type GetApiOrgsOrgChangesetsIdResponse = AnyJSON;
export interface GetApiOrgsOrgChangesetsIdInput {
    readonly path: { readonly id: string; readonly org: string; };
}
/** GET /api/orgs/{org}/changesets/{id} */
export declare const getApiOrgsOrgChangesetsId: (transport: Transport, input: GetApiOrgsOrgChangesetsIdInput) => Promise<GetApiOrgsOrgChangesetsIdResponse>;
export type GetApiOrgsOrgMembersResponse = AnyJSON;
export interface GetApiOrgsOrgMembersInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/members */
export declare const getApiOrgsOrgMembers: (transport: Transport, input: GetApiOrgsOrgMembersInput) => Promise<GetApiOrgsOrgMembersResponse>;
export type PostApiOrgsOrgMembersResponse = AnyJSON;
export interface PostApiOrgsOrgMembersInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/members */
export declare const postApiOrgsOrgMembers: (transport: Transport, input: PostApiOrgsOrgMembersInput) => Promise<PostApiOrgsOrgMembersResponse>;
export type GetApiOrgsOrgProviderConnectionsResponse = AnyJSON;
export interface GetApiOrgsOrgProviderConnectionsInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/provider-connections */
export declare const getApiOrgsOrgProviderConnections: (transport: Transport, input: GetApiOrgsOrgProviderConnectionsInput) => Promise<GetApiOrgsOrgProviderConnectionsResponse>;
export type PostApiOrgsOrgProviderConnectionsResponse = AnyJSON;
export interface PostApiOrgsOrgProviderConnectionsInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/provider-connections */
export declare const postApiOrgsOrgProviderConnections: (transport: Transport, input: PostApiOrgsOrgProviderConnectionsInput) => Promise<PostApiOrgsOrgProviderConnectionsResponse>;
export type GetApiOrgsOrgReposResponse = AnyJSON;
export interface GetApiOrgsOrgReposInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/repos */
export declare const getApiOrgsOrgRepos: (transport: Transport, input: GetApiOrgsOrgReposInput) => Promise<GetApiOrgsOrgReposResponse>;
export type PostApiOrgsOrgReposResponse = AnyJSON;
export interface PostApiOrgsOrgReposInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/repos */
export declare const postApiOrgsOrgRepos: (transport: Transport, input: PostApiOrgsOrgReposInput) => Promise<PostApiOrgsOrgReposResponse>;
export type GetApiOrgsOrgSecretsResponse = AnyJSON;
export interface GetApiOrgsOrgSecretsInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/secrets */
export declare const getApiOrgsOrgSecrets: (transport: Transport, input: GetApiOrgsOrgSecretsInput) => Promise<GetApiOrgsOrgSecretsResponse>;
export type PostApiOrgsOrgSecretsResponse = AnyJSON;
export interface PostApiOrgsOrgSecretsInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/secrets */
export declare const postApiOrgsOrgSecrets: (transport: Transport, input: PostApiOrgsOrgSecretsInput) => Promise<PostApiOrgsOrgSecretsResponse>;
export type GetApiOrgsOrgTeamsResponse = AnyJSON;
export interface GetApiOrgsOrgTeamsInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/teams */
export declare const getApiOrgsOrgTeams: (transport: Transport, input: GetApiOrgsOrgTeamsInput) => Promise<GetApiOrgsOrgTeamsResponse>;
export type PostApiOrgsOrgTeamsResponse = AnyJSON;
export interface PostApiOrgsOrgTeamsInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/teams */
export declare const postApiOrgsOrgTeams: (transport: Transport, input: PostApiOrgsOrgTeamsInput) => Promise<PostApiOrgsOrgTeamsResponse>;
export type GetApiOrgsOrgTeamsTeamMembersResponse = AnyJSON;
export interface GetApiOrgsOrgTeamsTeamMembersInput {
    readonly path: { readonly org: string; readonly team: string; };
}
/** GET /api/orgs/{org}/teams/{team}/members */
export declare const getApiOrgsOrgTeamsTeamMembers: (transport: Transport, input: GetApiOrgsOrgTeamsTeamMembersInput) => Promise<GetApiOrgsOrgTeamsTeamMembersResponse>;
export type GetApiOrgsOrgTeamsTeamReposResponse = AnyJSON;
export interface GetApiOrgsOrgTeamsTeamReposInput {
    readonly path: { readonly org: string; readonly team: string; };
}
/** GET /api/orgs/{org}/teams/{team}/repos */
export declare const getApiOrgsOrgTeamsTeamRepos: (transport: Transport, input: GetApiOrgsOrgTeamsTeamReposInput) => Promise<GetApiOrgsOrgTeamsTeamReposResponse>;
export type GetApiOrgsOrgVariablesResponse = AnyJSON;
export interface GetApiOrgsOrgVariablesInput {
    readonly path: { readonly org: string; };
}
/** GET /api/orgs/{org}/variables */
export declare const getApiOrgsOrgVariables: (transport: Transport, input: GetApiOrgsOrgVariablesInput) => Promise<GetApiOrgsOrgVariablesResponse>;
export type PostApiOrgsOrgVariablesResponse = AnyJSON;
export interface PostApiOrgsOrgVariablesInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/variables */
export declare const postApiOrgsOrgVariables: (transport: Transport, input: PostApiOrgsOrgVariablesInput) => Promise<PostApiOrgsOrgVariablesResponse>;
export type PostApiOrgsResponse = AnyJSON;
/** POST /api/orgs */
export declare const postApiOrgs: (transport: Transport) => Promise<PostApiOrgsResponse>;
export type PostApiOrgsOrgBillingCheckoutResponse = AnyJSON;
export interface PostApiOrgsOrgBillingCheckoutInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/billing/checkout */
export declare const postApiOrgsOrgBillingCheckout: (transport: Transport, input: PostApiOrgsOrgBillingCheckoutInput) => Promise<PostApiOrgsOrgBillingCheckoutResponse>;
export type PostApiOrgsOrgBillingPortalResponse = AnyJSON;
export interface PostApiOrgsOrgBillingPortalInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/billing/portal */
export declare const postApiOrgsOrgBillingPortal: (transport: Transport, input: PostApiOrgsOrgBillingPortalInput) => Promise<PostApiOrgsOrgBillingPortalResponse>;
export type PostApiOrgsOrgBillingRefreshResponse = AnyJSON;
export interface PostApiOrgsOrgBillingRefreshInput {
    readonly path: { readonly org: string; };
}
/** POST /api/orgs/{org}/billing/refresh */
export declare const postApiOrgsOrgBillingRefresh: (transport: Transport, input: PostApiOrgsOrgBillingRefreshInput) => Promise<PostApiOrgsOrgBillingRefreshResponse>;
export type PostApiOrgsOrgChangesetsIdLandResponse = AnyJSON;
export interface PostApiOrgsOrgChangesetsIdLandInput {
    readonly path: { readonly id: string; readonly org: string; };
}
/** POST /api/orgs/{org}/changesets/{id}/land */
export declare const postApiOrgsOrgChangesetsIdLand: (transport: Transport, input: PostApiOrgsOrgChangesetsIdLandInput) => Promise<PostApiOrgsOrgChangesetsIdLandResponse>;
export type GetApiPairSessionsIdInvitesResponse = AnyJSON;
export interface GetApiPairSessionsIdInvitesInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id}/invites */
export declare const getApiPairSessionsIdInvites: (transport: Transport, input: GetApiPairSessionsIdInvitesInput) => Promise<GetApiPairSessionsIdInvitesResponse>;
export type PostApiPairSessionsIdInvitesResponse = AnyJSON;
export interface PostApiPairSessionsIdInvitesInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/invites */
export declare const postApiPairSessionsIdInvites: (transport: Transport, input: PostApiPairSessionsIdInvitesInput) => Promise<PostApiPairSessionsIdInvitesResponse>;
export interface DeleteApiPairSessionsIdInvitesInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/pair-sessions/{id}/invites */
export declare const deleteApiPairSessionsIdInvites: (transport: Transport, input: DeleteApiPairSessionsIdInvitesInput) => Promise<void>;
export interface DeleteApiPairSessionsIdLinksLinkidInput {
    readonly path: { readonly id: string; readonly linkId: string; };
}
/** DELETE /api/pair-sessions/{id}/links/{linkId} */
export declare const deleteApiPairSessionsIdLinksLinkid: (transport: Transport, input: DeleteApiPairSessionsIdLinksLinkidInput) => Promise<void>;
export interface DeleteApiPairSessionsIdMembersUseridInput {
    readonly path: { readonly id: string; readonly userId: string; };
}
/** DELETE /api/pair-sessions/{id}/members/{userId} */
export declare const deleteApiPairSessionsIdMembersUserid: (transport: Transport, input: DeleteApiPairSessionsIdMembersUseridInput) => Promise<void>;
export type PatchApiPairSessionsIdMembersUseridResponse = AnyJSON;
export interface PatchApiPairSessionsIdMembersUseridInput {
    readonly path: { readonly id: string; readonly userId: string; };
}
/** PATCH /api/pair-sessions/{id}/members/{userId} */
export declare const patchApiPairSessionsIdMembersUserid: (transport: Transport, input: PatchApiPairSessionsIdMembersUseridInput) => Promise<PatchApiPairSessionsIdMembersUseridResponse>;
export type GetApiPairSessionsResponse = AnyJSON;
/** GET /api/pair-sessions */
export declare const getApiPairSessions: (transport: Transport) => Promise<GetApiPairSessionsResponse>;
export type PostApiPairSessionsResponse = AnyJSON;
/** POST /api/pair-sessions */
export declare const postApiPairSessions: (transport: Transport) => Promise<PostApiPairSessionsResponse>;
export type GetApiPairSessionsIdResponse = AnyJSON;
export interface GetApiPairSessionsIdInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id} */
export declare const getApiPairSessionsId: (transport: Transport, input: GetApiPairSessionsIdInput) => Promise<GetApiPairSessionsIdResponse>;
export type GetApiPairSessionsIdDraftResponse = AnyJSON;
export interface GetApiPairSessionsIdDraftInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id}/draft */
export declare const getApiPairSessionsIdDraft: (transport: Transport, input: GetApiPairSessionsIdDraftInput) => Promise<GetApiPairSessionsIdDraftResponse>;
export type PutApiPairSessionsIdDraftResponse = AnyJSON;
export interface PutApiPairSessionsIdDraftInput {
    readonly path: { readonly id: string; };
}
/** PUT /api/pair-sessions/{id}/draft */
export declare const putApiPairSessionsIdDraft: (transport: Transport, input: PutApiPairSessionsIdDraftInput) => Promise<PutApiPairSessionsIdDraftResponse>;
export type GetApiPairSessionsIdLinksResponse = AnyJSON;
export interface GetApiPairSessionsIdLinksInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id}/links */
export declare const getApiPairSessionsIdLinks: (transport: Transport, input: GetApiPairSessionsIdLinksInput) => Promise<GetApiPairSessionsIdLinksResponse>;
export type PostApiPairSessionsIdLinksResponse = AnyJSON;
export interface PostApiPairSessionsIdLinksInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/links */
export declare const postApiPairSessionsIdLinks: (transport: Transport, input: PostApiPairSessionsIdLinksInput) => Promise<PostApiPairSessionsIdLinksResponse>;
export type GetApiPairSessionsIdMembersResponse = AnyJSON;
export interface GetApiPairSessionsIdMembersInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id}/members */
export declare const getApiPairSessionsIdMembers: (transport: Transport, input: GetApiPairSessionsIdMembersInput) => Promise<GetApiPairSessionsIdMembersResponse>;
export type GetApiPairSessionsIdQueueResponse = AnyJSON;
export interface GetApiPairSessionsIdQueueInput {
    readonly path: { readonly id: string; };
}
/** GET /api/pair-sessions/{id}/queue */
export declare const getApiPairSessionsIdQueue: (transport: Transport, input: GetApiPairSessionsIdQueueInput) => Promise<GetApiPairSessionsIdQueueResponse>;
export type PostApiPairSessionsIdQueueResponse = AnyJSON;
export interface PostApiPairSessionsIdQueueInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/queue */
export declare const postApiPairSessionsIdQueue: (transport: Transport, input: PostApiPairSessionsIdQueueInput) => Promise<PostApiPairSessionsIdQueueResponse>;
export type GetApiPairSessionsByLinkSlugResponse = AnyJSON;
export interface GetApiPairSessionsByLinkSlugInput {
    readonly path: { readonly slug: string; };
}
/** GET /api/pair-sessions/by-link/{slug} */
export declare const getApiPairSessionsByLinkSlug: (transport: Transport, input: GetApiPairSessionsByLinkSlugInput) => Promise<GetApiPairSessionsByLinkSlugResponse>;
export type PatchApiPairSessionsIdAccessResponse = AnyJSON;
export interface PatchApiPairSessionsIdAccessInput {
    readonly path: { readonly id: string; };
}
/** PATCH /api/pair-sessions/{id}/access */
export declare const patchApiPairSessionsIdAccess: (transport: Transport, input: PatchApiPairSessionsIdAccessInput) => Promise<PatchApiPairSessionsIdAccessResponse>;
export type PostApiPairSessionsIdDraftSubmitResponse = AnyJSON;
export interface PostApiPairSessionsIdDraftSubmitInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/draft/submit */
export declare const postApiPairSessionsIdDraftSubmit: (transport: Transport, input: PostApiPairSessionsIdDraftSubmitInput) => Promise<PostApiPairSessionsIdDraftSubmitResponse>;
export type PostApiPairSessionsIdEndResponse = AnyJSON;
export interface PostApiPairSessionsIdEndInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/end */
export declare const postApiPairSessionsIdEnd: (transport: Transport, input: PostApiPairSessionsIdEndInput) => Promise<PostApiPairSessionsIdEndResponse>;
export type PostApiPairSessionsIdJoinResponse = AnyJSON;
export interface PostApiPairSessionsIdJoinInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/join */
export declare const postApiPairSessionsIdJoin: (transport: Transport, input: PostApiPairSessionsIdJoinInput) => Promise<PostApiPairSessionsIdJoinResponse>;
export type PostApiPairSessionsIdPresenceResponse = AnyJSON;
export interface PostApiPairSessionsIdPresenceInput {
    readonly path: { readonly id: string; };
}
/** POST /api/pair-sessions/{id}/presence */
export declare const postApiPairSessionsIdPresence: (transport: Transport, input: PostApiPairSessionsIdPresenceInput) => Promise<PostApiPairSessionsIdPresenceResponse>;
export type PostApiPairSessionsIdQueuePromptidCancelResponse = AnyJSON;
export interface PostApiPairSessionsIdQueuePromptidCancelInput {
    readonly path: { readonly id: string; readonly promptId: string; };
}
/** POST /api/pair-sessions/{id}/queue/{promptId}/cancel */
export declare const postApiPairSessionsIdQueuePromptidCancel: (transport: Transport, input: PostApiPairSessionsIdQueuePromptidCancelInput) => Promise<PostApiPairSessionsIdQueuePromptidCancelResponse>;
export type PostApiPairSessionsIdQueuePromptidClaimResponse = AnyJSON;
export interface PostApiPairSessionsIdQueuePromptidClaimInput {
    readonly path: { readonly id: string; readonly promptId: string; };
}
/** POST /api/pair-sessions/{id}/queue/{promptId}/claim */
export declare const postApiPairSessionsIdQueuePromptidClaim: (transport: Transport, input: PostApiPairSessionsIdQueuePromptidClaimInput) => Promise<PostApiPairSessionsIdQueuePromptidClaimResponse>;
export type PostApiPairSessionsIdQueuePromptidFinishResponse = AnyJSON;
export interface PostApiPairSessionsIdQueuePromptidFinishInput {
    readonly path: { readonly id: string; readonly promptId: string; };
}
/** POST /api/pair-sessions/{id}/queue/{promptId}/finish */
export declare const postApiPairSessionsIdQueuePromptidFinish: (transport: Transport, input: PostApiPairSessionsIdQueuePromptidFinishInput) => Promise<PostApiPairSessionsIdQueuePromptidFinishResponse>;
export type PostApiPairSessionsIdQueuePromptidRenewResponse = AnyJSON;
export interface PostApiPairSessionsIdQueuePromptidRenewInput {
    readonly path: { readonly id: string; readonly promptId: string; };
}
/** POST /api/pair-sessions/{id}/queue/{promptId}/renew */
export declare const postApiPairSessionsIdQueuePromptidRenew: (transport: Transport, input: PostApiPairSessionsIdQueuePromptidRenewInput) => Promise<PostApiPairSessionsIdQueuePromptidRenewResponse>;
export type PostApiPairSessionsIdQueuePromptidStartResponse = AnyJSON;
export interface PostApiPairSessionsIdQueuePromptidStartInput {
    readonly path: { readonly id: string; readonly promptId: string; };
}
/** POST /api/pair-sessions/{id}/queue/{promptId}/start */
export declare const postApiPairSessionsIdQueuePromptidStart: (transport: Transport, input: PostApiPairSessionsIdQueuePromptidStartInput) => Promise<PostApiPairSessionsIdQueuePromptidStartResponse>;
export type PostApiPairSessionsByLinkSlugJoinResponse = AnyJSON;
export interface PostApiPairSessionsByLinkSlugJoinInput {
    readonly path: { readonly slug: string; };
}
/** POST /api/pair-sessions/by-link/{slug}/join */
export declare const postApiPairSessionsByLinkSlugJoin: (transport: Transport, input: PostApiPairSessionsByLinkSlugJoinInput) => Promise<PostApiPairSessionsByLinkSlugJoinResponse>;
export type GetApiPublicReposResponse = AnyJSON;
/** GET /api/public/repos */
export declare const getApiPublicRepos: (transport: Transport) => Promise<GetApiPublicReposResponse>;
export type PostApiRecommendBody = AnyJSON;
export type PostApiRecommendResponse = AnyJSON;
export interface PostApiRecommendInput {
    readonly body?: PostApiRecommendBody;
}
/** POST /api/recommend */
export declare const postApiRecommend: (transport: Transport, input?: PostApiRecommendInput) => Promise<PostApiRecommendResponse>;
export type PostApiRecommendOutcomeBody = AnyJSON;
export type PostApiRecommendOutcomeResponse = AnyJSON;
export interface PostApiRecommendOutcomeInput {
    readonly body?: PostApiRecommendOutcomeBody;
}
/** POST /api/recommend/outcome */
export declare const postApiRecommendOutcome: (transport: Transport, input?: PostApiRecommendOutcomeInput) => Promise<PostApiRecommendOutcomeResponse>;
export type GetApiReposOwnerRepoChangesCountResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesCountInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly query: { readonly rev: string; readonly since: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/count */
export declare const getApiReposOwnerRepoChangesCount: (transport: Transport, input: GetApiReposOwnerRepoChangesCountInput) => Promise<GetApiReposOwnerRepoChangesCountResponse>;
export type GetApiReposOwnerRepoResponse = AnyJSON;
export interface GetApiReposOwnerRepoInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo} */
export declare const getApiReposOwnerRepo: (transport: Transport, input: GetApiReposOwnerRepoInput) => Promise<GetApiReposOwnerRepoResponse>;
export interface DeleteApiReposOwnerRepoInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo} */
export declare const deleteApiReposOwnerRepo: (transport: Transport, input: DeleteApiReposOwnerRepoInput) => Promise<void>;
export type PatchApiReposOwnerRepoResponse = AnyJSON;
export interface PatchApiReposOwnerRepoInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo} */
export declare const patchApiReposOwnerRepo: (transport: Transport, input: PatchApiReposOwnerRepoInput) => Promise<PatchApiReposOwnerRepoResponse>;
export interface DeleteApiReposOwnerRepoActionsRunsIdArtifactsNameInput {
    readonly path: { readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/actions/runs/{id}/artifacts/{name} */
export declare const deleteApiReposOwnerRepoActionsRunsIdArtifactsName: (transport: Transport, input: DeleteApiReposOwnerRepoActionsRunsIdArtifactsNameInput) => Promise<void>;
export type PutApiReposOwnerRepoAgentEnvironmentSecretsNameResponse = AnyJSON;
export interface PutApiReposOwnerRepoAgentEnvironmentSecretsNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/agent-environment/secrets/{name} */
export declare const putApiReposOwnerRepoAgentEnvironmentSecretsName: (transport: Transport, input: PutApiReposOwnerRepoAgentEnvironmentSecretsNameInput) => Promise<PutApiReposOwnerRepoAgentEnvironmentSecretsNameResponse>;
export interface DeleteApiReposOwnerRepoAgentEnvironmentSecretsNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/agent-environment/secrets/{name} */
export declare const deleteApiReposOwnerRepoAgentEnvironmentSecretsName: (transport: Transport, input: DeleteApiReposOwnerRepoAgentEnvironmentSecretsNameInput) => Promise<void>;
export type GetApiReposOwnerRepoAgentSessionsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoAgentSessionsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/agent/sessions/{id} */
export declare const getApiReposOwnerRepoAgentSessionsId: (transport: Transport, input: GetApiReposOwnerRepoAgentSessionsIdInput) => Promise<GetApiReposOwnerRepoAgentSessionsIdResponse>;
export interface DeleteApiReposOwnerRepoAgentSessionsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/agent/sessions/{id} */
export declare const deleteApiReposOwnerRepoAgentSessionsId: (transport: Transport, input: DeleteApiReposOwnerRepoAgentSessionsIdInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoBookmarksNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/bookmarks/{name} */
export declare const deleteApiReposOwnerRepoBookmarksName: (transport: Transport, input: DeleteApiReposOwnerRepoBookmarksNameInput) => Promise<void>;
export type GetApiReposOwnerRepoBuildCacheAcKeydigestResponse = AnyJSON;
export interface GetApiReposOwnerRepoBuildCacheAcKeydigestInput {
    readonly path: { readonly keyDigest: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/build-cache/ac/{keyDigest} */
export declare const getApiReposOwnerRepoBuildCacheAcKeydigest: (transport: Transport, input: GetApiReposOwnerRepoBuildCacheAcKeydigestInput) => Promise<GetApiReposOwnerRepoBuildCacheAcKeydigestResponse>;
export type PutApiReposOwnerRepoBuildCacheAcKeydigestResponse = AnyJSON;
export interface PutApiReposOwnerRepoBuildCacheAcKeydigestInput {
    readonly path: { readonly keyDigest: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/build-cache/ac/{keyDigest} */
export declare const putApiReposOwnerRepoBuildCacheAcKeydigest: (transport: Transport, input: PutApiReposOwnerRepoBuildCacheAcKeydigestInput) => Promise<PutApiReposOwnerRepoBuildCacheAcKeydigestResponse>;
export interface DeleteApiReposOwnerRepoBuildCacheAcKeydigestInput {
    readonly path: { readonly keyDigest: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/build-cache/ac/{keyDigest} */
export declare const deleteApiReposOwnerRepoBuildCacheAcKeydigest: (transport: Transport, input: DeleteApiReposOwnerRepoBuildCacheAcKeydigestInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoBuildCacheTokensIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/build-cache/tokens/{id} */
export declare const deleteApiReposOwnerRepoBuildCacheTokensId: (transport: Transport, input: DeleteApiReposOwnerRepoBuildCacheTokensIdInput) => Promise<void>;
export type GetApiReposOwnerRepoCachesResponse = AnyJSON;
export interface GetApiReposOwnerRepoCachesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/caches */
export declare const getApiReposOwnerRepoCaches: (transport: Transport, input: GetApiReposOwnerRepoCachesInput) => Promise<GetApiReposOwnerRepoCachesResponse>;
export interface DeleteApiReposOwnerRepoCachesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/caches */
export declare const deleteApiReposOwnerRepoCaches: (transport: Transport, input: DeleteApiReposOwnerRepoCachesInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoEnvironmentImagesIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/environment-images/{id} */
export declare const deleteApiReposOwnerRepoEnvironmentImagesId: (transport: Transport, input: DeleteApiReposOwnerRepoEnvironmentImagesIdInput) => Promise<void>;
export type GetApiReposOwnerRepoHooksIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoHooksIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/hooks/{id} */
export declare const getApiReposOwnerRepoHooksId: (transport: Transport, input: GetApiReposOwnerRepoHooksIdInput) => Promise<GetApiReposOwnerRepoHooksIdResponse>;
export interface DeleteApiReposOwnerRepoHooksIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/hooks/{id} */
export declare const deleteApiReposOwnerRepoHooksId: (transport: Transport, input: DeleteApiReposOwnerRepoHooksIdInput) => Promise<void>;
export type PatchApiReposOwnerRepoHooksIdResponse = AnyJSON;
export interface PatchApiReposOwnerRepoHooksIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/hooks/{id} */
export declare const patchApiReposOwnerRepoHooksId: (transport: Transport, input: PatchApiReposOwnerRepoHooksIdInput) => Promise<PatchApiReposOwnerRepoHooksIdResponse>;
export interface DeleteApiReposOwnerRepoIssuesNumberLabelsNameInput {
    readonly path: { readonly name: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/issues/{number}/labels/{name} */
export declare const deleteApiReposOwnerRepoIssuesNumberLabelsName: (transport: Transport, input: DeleteApiReposOwnerRepoIssuesNumberLabelsNameInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoIssuesCommentsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/issues/comments/{id} */
export declare const deleteApiReposOwnerRepoIssuesCommentsId: (transport: Transport, input: DeleteApiReposOwnerRepoIssuesCommentsIdInput) => Promise<void>;
export type PatchApiReposOwnerRepoIssuesCommentsIdResponse = IssueComment;
export interface PatchApiReposOwnerRepoIssuesCommentsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/issues/comments/{id} */
export declare const patchApiReposOwnerRepoIssuesCommentsId: (transport: Transport, input: PatchApiReposOwnerRepoIssuesCommentsIdInput) => Promise<PatchApiReposOwnerRepoIssuesCommentsIdResponse>;
export interface DeleteApiReposOwnerRepoKeysIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/keys/{id} */
export declare const deleteApiReposOwnerRepoKeysId: (transport: Transport, input: DeleteApiReposOwnerRepoKeysIdInput) => Promise<void>;
export type GetApiReposOwnerRepoLabelsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoLabelsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/labels/{id} */
export declare const getApiReposOwnerRepoLabelsId: (transport: Transport, input: GetApiReposOwnerRepoLabelsIdInput) => Promise<GetApiReposOwnerRepoLabelsIdResponse>;
export interface DeleteApiReposOwnerRepoLabelsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/labels/{id} */
export declare const deleteApiReposOwnerRepoLabelsId: (transport: Transport, input: DeleteApiReposOwnerRepoLabelsIdInput) => Promise<void>;
export type PatchApiReposOwnerRepoLabelsIdResponse = AnyJSON;
export interface PatchApiReposOwnerRepoLabelsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/labels/{id} */
export declare const patchApiReposOwnerRepoLabelsId: (transport: Transport, input: PatchApiReposOwnerRepoLabelsIdInput) => Promise<PatchApiReposOwnerRepoLabelsIdResponse>;
export type PostApiReposOwnerRepoLandingsNumberAutoLandBody = { enabled: true; };
export type PostApiReposOwnerRepoLandingsNumberAutoLandResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberAutoLandInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoLandingsNumberAutoLandBody;
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/auto-land */
export declare const postApiReposOwnerRepoLandingsNumberAutoLand: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberAutoLandInput) => Promise<PostApiReposOwnerRepoLandingsNumberAutoLandResponse>;
export interface DeleteApiReposOwnerRepoLandingsNumberAutoLandInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/landings/{number}/auto-land */
export declare const deleteApiReposOwnerRepoLandingsNumberAutoLand: (transport: Transport, input: DeleteApiReposOwnerRepoLandingsNumberAutoLandInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoLandingsNumberReviewRequestsIdInput {
    readonly path: { readonly id: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/landings/{number}/review-requests/{id} */
export declare const deleteApiReposOwnerRepoLandingsNumberReviewRequestsId: (transport: Transport, input: DeleteApiReposOwnerRepoLandingsNumberReviewRequestsIdInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoLfsObjectsOidInput {
    readonly path: { readonly oid: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/lfs/objects/{oid} */
export declare const deleteApiReposOwnerRepoLfsObjectsOid: (transport: Transport, input: DeleteApiReposOwnerRepoLfsObjectsOidInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoProtectedBookmarksPatternInput {
    readonly path: { readonly owner: string; readonly pattern: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/protected-bookmarks/{pattern} */
export declare const deleteApiReposOwnerRepoProtectedBookmarksPattern: (transport: Transport, input: DeleteApiReposOwnerRepoProtectedBookmarksPatternInput) => Promise<void>;
export interface DeleteApiReposOwnerRepoSecretsNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/secrets/{name} */
export declare const deleteApiReposOwnerRepoSecretsName: (transport: Transport, input: DeleteApiReposOwnerRepoSecretsNameInput) => Promise<void>;
export type PatchApiReposOwnerRepoSecretsNameResponse = AnyJSON;
export interface PatchApiReposOwnerRepoSecretsNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/secrets/{name} */
export declare const patchApiReposOwnerRepoSecretsName: (transport: Transport, input: PatchApiReposOwnerRepoSecretsNameInput) => Promise<PatchApiReposOwnerRepoSecretsNameResponse>;
export type GetApiReposOwnerRepoStacksActiveResponse = AnyJSON;
export interface GetApiReposOwnerRepoStacksActiveInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/stacks/active */
export declare const getApiReposOwnerRepoStacksActive: (transport: Transport, input: GetApiReposOwnerRepoStacksActiveInput) => Promise<GetApiReposOwnerRepoStacksActiveResponse>;
export type PostApiReposOwnerRepoStacksActiveResponse = AnyJSON;
export interface PostApiReposOwnerRepoStacksActiveInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/stacks/active */
export declare const postApiReposOwnerRepoStacksActive: (transport: Transport, input: PostApiReposOwnerRepoStacksActiveInput) => Promise<PostApiReposOwnerRepoStacksActiveResponse>;
export interface DeleteApiReposOwnerRepoStacksActiveInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/stacks/active */
export declare const deleteApiReposOwnerRepoStacksActive: (transport: Transport, input: DeleteApiReposOwnerRepoStacksActiveInput) => Promise<void>;
export type GetApiReposOwnerRepoVariablesNameResponse = AnyJSON;
export interface GetApiReposOwnerRepoVariablesNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/variables/{name} */
export declare const getApiReposOwnerRepoVariablesName: (transport: Transport, input: GetApiReposOwnerRepoVariablesNameInput) => Promise<GetApiReposOwnerRepoVariablesNameResponse>;
export interface DeleteApiReposOwnerRepoVariablesNameInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/variables/{name} */
export declare const deleteApiReposOwnerRepoVariablesName: (transport: Transport, input: DeleteApiReposOwnerRepoVariablesNameInput) => Promise<void>;
export type GetApiReposOwnerRepoWikiSlugResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiSlugInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/{slug} */
export declare const getApiReposOwnerRepoWikiSlug: (transport: Transport, input: GetApiReposOwnerRepoWikiSlugInput) => Promise<GetApiReposOwnerRepoWikiSlugResponse>;
export interface DeleteApiReposOwnerRepoWikiSlugInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** DELETE /api/repos/{owner}/{repo}/wiki/{slug} */
export declare const deleteApiReposOwnerRepoWikiSlug: (transport: Transport, input: DeleteApiReposOwnerRepoWikiSlugInput) => Promise<void>;
export type PatchApiReposOwnerRepoWikiSlugResponse = AnyJSON;
export interface PatchApiReposOwnerRepoWikiSlugInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** PATCH /api/repos/{owner}/{repo}/wiki/{slug} */
export declare const patchApiReposOwnerRepoWikiSlug: (transport: Transport, input: PatchApiReposOwnerRepoWikiSlugInput) => Promise<PatchApiReposOwnerRepoWikiSlugResponse>;
export type GetApiReposOwnerRepoWorkflowRunsIdArtifactsNameResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowRunsIdArtifactsNameInput {
    readonly path: { readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflow/runs/{id}/artifacts/{name} */
export declare const getApiReposOwnerRepoWorkflowRunsIdArtifactsName: (transport: Transport, input: GetApiReposOwnerRepoWorkflowRunsIdArtifactsNameInput) => Promise<GetApiReposOwnerRepoWorkflowRunsIdArtifactsNameResponse>;
export interface DeleteApiReposOwnerRepoWorkflowRunsIdArtifactsNameInput {
    readonly path: { readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/workflow/runs/{id}/artifacts/{name} */
export declare const deleteApiReposOwnerRepoWorkflowRunsIdArtifactsName: (transport: Transport, input: DeleteApiReposOwnerRepoWorkflowRunsIdArtifactsNameInput) => Promise<void>;
export type GetApiReposOwnerRepoWorkspaceSnapshotsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSnapshotsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace-snapshots/{id} */
export declare const getApiReposOwnerRepoWorkspaceSnapshotsId: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSnapshotsIdInput) => Promise<GetApiReposOwnerRepoWorkspaceSnapshotsIdResponse>;
export interface DeleteApiReposOwnerRepoWorkspaceSnapshotsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/workspace-snapshots/{id} */
export declare const deleteApiReposOwnerRepoWorkspaceSnapshotsId: (transport: Transport, input: DeleteApiReposOwnerRepoWorkspaceSnapshotsIdInput) => Promise<void>;
export type GetApiReposOwnerRepoWorkspacesIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id} */
export declare const getApiReposOwnerRepoWorkspacesId: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdInput) => Promise<GetApiReposOwnerRepoWorkspacesIdResponse>;
export interface DeleteApiReposOwnerRepoWorkspacesIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** DELETE /api/repos/{owner}/{repo}/workspaces/{id} */
export declare const deleteApiReposOwnerRepoWorkspacesId: (transport: Transport, input: DeleteApiReposOwnerRepoWorkspacesIdInput) => Promise<void>;
export type GetApiReposOwnerRepoActionsRunsResponse = MultiWorkflowRunsResponse;
export interface GetApiReposOwnerRepoActionsRunsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/actions/runs */
export declare const getApiReposOwnerRepoActionsRuns: (transport: Transport, input: GetApiReposOwnerRepoActionsRunsInput) => Promise<GetApiReposOwnerRepoActionsRunsResponse>;
export type GetApiReposOwnerRepoActionsRunsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoActionsRunsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/actions/runs/{id} */
export declare const getApiReposOwnerRepoActionsRunsId: (transport: Transport, input: GetApiReposOwnerRepoActionsRunsIdInput) => Promise<GetApiReposOwnerRepoActionsRunsIdResponse>;
export type GetApiReposOwnerRepoActionsRunsIdArtifactsResponse = AnyJSON;
export interface GetApiReposOwnerRepoActionsRunsIdArtifactsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/actions/runs/{id}/artifacts */
export declare const getApiReposOwnerRepoActionsRunsIdArtifacts: (transport: Transport, input: GetApiReposOwnerRepoActionsRunsIdArtifactsInput) => Promise<GetApiReposOwnerRepoActionsRunsIdArtifactsResponse>;
export type GetApiReposOwnerRepoActionsRunsIdArtifactsNameDownloadResponse = AnyJSON;
export interface GetApiReposOwnerRepoActionsRunsIdArtifactsNameDownloadInput {
    readonly path: { readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/actions/runs/{id}/artifacts/{name}/download */
export declare const getApiReposOwnerRepoActionsRunsIdArtifactsNameDownload: (transport: Transport, input: GetApiReposOwnerRepoActionsRunsIdArtifactsNameDownloadInput) => Promise<GetApiReposOwnerRepoActionsRunsIdArtifactsNameDownloadResponse>;
export type GetApiReposOwnerRepoActionsRunsIdStepsResponse = AnyJSON;
export interface GetApiReposOwnerRepoActionsRunsIdStepsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/actions/runs/{id}/steps */
export declare const getApiReposOwnerRepoActionsRunsIdSteps: (transport: Transport, input: GetApiReposOwnerRepoActionsRunsIdStepsInput) => Promise<GetApiReposOwnerRepoActionsRunsIdStepsResponse>;
export type GetApiReposOwnerRepoAgentEnvironmentResponse = AnyJSON;
export interface GetApiReposOwnerRepoAgentEnvironmentInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/agent-environment */
export declare const getApiReposOwnerRepoAgentEnvironment: (transport: Transport, input: GetApiReposOwnerRepoAgentEnvironmentInput) => Promise<GetApiReposOwnerRepoAgentEnvironmentResponse>;
export type PutApiReposOwnerRepoAgentEnvironmentResponse = AnyJSON;
export interface PutApiReposOwnerRepoAgentEnvironmentInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/agent-environment */
export declare const putApiReposOwnerRepoAgentEnvironment: (transport: Transport, input: PutApiReposOwnerRepoAgentEnvironmentInput) => Promise<PutApiReposOwnerRepoAgentEnvironmentResponse>;
export type GetApiReposOwnerRepoAgentSessionsIdEgressResponse = SandboxEgressAuditEntries;
export interface GetApiReposOwnerRepoAgentSessionsIdEgressInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly query?: { readonly cursor?: string; readonly limit?: number; };
}
/** GET /api/repos/{owner}/{repo}/agent-sessions/{id}/egress */
export declare const getApiReposOwnerRepoAgentSessionsIdEgress: (transport: Transport, input: GetApiReposOwnerRepoAgentSessionsIdEgressInput) => Promise<GetApiReposOwnerRepoAgentSessionsIdEgressResponse>;
export type GetApiReposOwnerRepoAgentSessionsResponse = AnyJSON;
export interface GetApiReposOwnerRepoAgentSessionsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/agent/sessions */
export declare const getApiReposOwnerRepoAgentSessions: (transport: Transport, input: GetApiReposOwnerRepoAgentSessionsInput) => Promise<GetApiReposOwnerRepoAgentSessionsResponse>;
export type PostApiReposOwnerRepoAgentSessionsResponse = AnyJSON;
export interface PostApiReposOwnerRepoAgentSessionsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/agent/sessions */
export declare const postApiReposOwnerRepoAgentSessions: (transport: Transport, input: PostApiReposOwnerRepoAgentSessionsInput) => Promise<PostApiReposOwnerRepoAgentSessionsResponse>;
export type GetApiReposOwnerRepoAgentSessionsIdMessagesResponse = AnyJSON;
export interface GetApiReposOwnerRepoAgentSessionsIdMessagesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/agent/sessions/{id}/messages */
export declare const getApiReposOwnerRepoAgentSessionsIdMessages: (transport: Transport, input: GetApiReposOwnerRepoAgentSessionsIdMessagesInput) => Promise<GetApiReposOwnerRepoAgentSessionsIdMessagesResponse>;
export type PostApiReposOwnerRepoAgentSessionsIdMessagesResponse = AnyJSON;
export interface PostApiReposOwnerRepoAgentSessionsIdMessagesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/agent/sessions/{id}/messages */
export declare const postApiReposOwnerRepoAgentSessionsIdMessages: (transport: Transport, input: PostApiReposOwnerRepoAgentSessionsIdMessagesInput) => Promise<PostApiReposOwnerRepoAgentSessionsIdMessagesResponse>;
export interface GetApiReposOwnerRepoAgentSessionsIdStreamInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/agent/sessions/{id}/stream */
export declare const getApiReposOwnerRepoAgentSessionsIdStream: (transport: Transport, input: GetApiReposOwnerRepoAgentSessionsIdStreamInput) => Promise<Response>;
export type GetApiReposOwnerRepoApprovalsResponse = AnyJSON;
export interface GetApiReposOwnerRepoApprovalsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/approvals */
export declare const getApiReposOwnerRepoApprovals: (transport: Transport, input: GetApiReposOwnerRepoApprovalsInput) => Promise<GetApiReposOwnerRepoApprovalsResponse>;
export type GetApiReposOwnerRepoApprovalsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoApprovalsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/approvals/{id} */
export declare const getApiReposOwnerRepoApprovalsId: (transport: Transport, input: GetApiReposOwnerRepoApprovalsIdInput) => Promise<GetApiReposOwnerRepoApprovalsIdResponse>;
export type GetApiReposOwnerRepoBookmarksResponse = AnyJSON;
export interface GetApiReposOwnerRepoBookmarksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/bookmarks */
export declare const getApiReposOwnerRepoBookmarks: (transport: Transport, input: GetApiReposOwnerRepoBookmarksInput) => Promise<GetApiReposOwnerRepoBookmarksResponse>;
export type PostApiReposOwnerRepoBookmarksResponse = AnyJSON;
export interface PostApiReposOwnerRepoBookmarksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/bookmarks */
export declare const postApiReposOwnerRepoBookmarks: (transport: Transport, input: PostApiReposOwnerRepoBookmarksInput) => Promise<PostApiReposOwnerRepoBookmarksResponse>;
export type GetApiReposOwnerRepoBranchLocksJoinRequestsResponse = AnyJSON;
export interface GetApiReposOwnerRepoBranchLocksJoinRequestsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/branch-locks/join-requests */
export declare const getApiReposOwnerRepoBranchLocksJoinRequests: (transport: Transport, input: GetApiReposOwnerRepoBranchLocksJoinRequestsInput) => Promise<GetApiReposOwnerRepoBranchLocksJoinRequestsResponse>;
export type PostApiReposOwnerRepoBranchLocksJoinRequestsResponse = AnyJSON;
export interface PostApiReposOwnerRepoBranchLocksJoinRequestsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/branch-locks/join-requests */
export declare const postApiReposOwnerRepoBranchLocksJoinRequests: (transport: Transport, input: PostApiReposOwnerRepoBranchLocksJoinRequestsInput) => Promise<PostApiReposOwnerRepoBranchLocksJoinRequestsResponse>;
export type GetApiReposOwnerRepoBuildCacheCasDigestResponse = AnyJSON;
export interface GetApiReposOwnerRepoBuildCacheCasDigestInput {
    readonly path: { readonly digest: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/build-cache/cas/{digest} */
export declare const getApiReposOwnerRepoBuildCacheCasDigest: (transport: Transport, input: GetApiReposOwnerRepoBuildCacheCasDigestInput) => Promise<GetApiReposOwnerRepoBuildCacheCasDigestResponse>;
export type PutApiReposOwnerRepoBuildCacheCasDigestResponse = AnyJSON;
export interface PutApiReposOwnerRepoBuildCacheCasDigestInput {
    readonly path: { readonly digest: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/build-cache/cas/{digest} */
export declare const putApiReposOwnerRepoBuildCacheCasDigest: (transport: Transport, input: PutApiReposOwnerRepoBuildCacheCasDigestInput) => Promise<PutApiReposOwnerRepoBuildCacheCasDigestResponse>;
export interface HeadApiReposOwnerRepoBuildCacheCasDigestInput {
    readonly path: { readonly digest: string; readonly owner: string; readonly repo: string; };
}
/** HEAD /api/repos/{owner}/{repo}/build-cache/cas/{digest} */
export declare const headApiReposOwnerRepoBuildCacheCasDigest: (transport: Transport, input: HeadApiReposOwnerRepoBuildCacheCasDigestInput) => Promise<void>;
export type GetApiReposOwnerRepoBuildCacheHealthzResponse = AnyJSON;
export interface GetApiReposOwnerRepoBuildCacheHealthzInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/build-cache/healthz */
export declare const getApiReposOwnerRepoBuildCacheHealthz: (transport: Transport, input: GetApiReposOwnerRepoBuildCacheHealthzInput) => Promise<GetApiReposOwnerRepoBuildCacheHealthzResponse>;
export interface HeadApiReposOwnerRepoBuildCacheHealthzInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** HEAD /api/repos/{owner}/{repo}/build-cache/healthz */
export declare const headApiReposOwnerRepoBuildCacheHealthz: (transport: Transport, input: HeadApiReposOwnerRepoBuildCacheHealthzInput) => Promise<void>;
export type GetApiReposOwnerRepoBuildCacheTokensResponse = AnyJSON;
export interface GetApiReposOwnerRepoBuildCacheTokensInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/build-cache/tokens */
export declare const getApiReposOwnerRepoBuildCacheTokens: (transport: Transport, input: GetApiReposOwnerRepoBuildCacheTokensInput) => Promise<GetApiReposOwnerRepoBuildCacheTokensResponse>;
export type PostApiReposOwnerRepoBuildCacheTokensResponse = AnyJSON;
export interface PostApiReposOwnerRepoBuildCacheTokensInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/build-cache/tokens */
export declare const postApiReposOwnerRepoBuildCacheTokens: (transport: Transport, input: PostApiReposOwnerRepoBuildCacheTokensInput) => Promise<PostApiReposOwnerRepoBuildCacheTokensResponse>;
export type GetApiReposOwnerRepoCachesStatsResponse = AnyJSON;
export interface GetApiReposOwnerRepoCachesStatsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/caches/stats */
export declare const getApiReposOwnerRepoCachesStats: (transport: Transport, input: GetApiReposOwnerRepoCachesStatsInput) => Promise<GetApiReposOwnerRepoCachesStatsResponse>;
export type GetApiReposOwnerRepoChangesResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes */
export declare const getApiReposOwnerRepoChanges: (transport: Transport, input: GetApiReposOwnerRepoChangesInput) => Promise<GetApiReposOwnerRepoChangesResponse>;
export type GetApiReposOwnerRepoChangesChangeIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id} */
export declare const getApiReposOwnerRepoChangesChangeId: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdInput) => Promise<GetApiReposOwnerRepoChangesChangeIdResponse>;
export type GetApiReposOwnerRepoChangesChangeIdConflictsResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdConflictsInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/conflicts */
export declare const getApiReposOwnerRepoChangesChangeIdConflicts: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdConflictsInput) => Promise<GetApiReposOwnerRepoChangesChangeIdConflictsResponse>;
export type GetApiReposOwnerRepoChangesChangeIdDiffResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdDiffInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
    readonly query?: { readonly from?: string; readonly path?: string; readonly to?: number; readonly whitespace?: "hide" | "ignore"; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/diff */
export declare const getApiReposOwnerRepoChangesChangeIdDiff: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdDiffInput) => Promise<GetApiReposOwnerRepoChangesChangeIdDiffResponse>;
export type GetApiReposOwnerRepoChangesChangeIdFilesResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdFilesInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/files */
export declare const getApiReposOwnerRepoChangesChangeIdFiles: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdFilesInput) => Promise<GetApiReposOwnerRepoChangesChangeIdFilesResponse>;
export type GetApiReposOwnerRepoChangesChangeIdFindingsResponse = ChangeFindingsResponse;
export interface GetApiReposOwnerRepoChangesChangeIdFindingsInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
    readonly query?: { readonly rev?: number; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/findings */
export declare const getApiReposOwnerRepoChangesChangeIdFindings: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdFindingsInput) => Promise<GetApiReposOwnerRepoChangesChangeIdFindingsResponse>;
export type GetApiReposOwnerRepoChangesChangeIdOperationsResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdOperationsInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
    readonly query?: { readonly rev?: number; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/operations */
export declare const getApiReposOwnerRepoChangesChangeIdOperations: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdOperationsInput) => Promise<GetApiReposOwnerRepoChangesChangeIdOperationsResponse>;
export type GetApiReposOwnerRepoChangesChangeIdWalkthroughResponse = AnyJSON;
export interface GetApiReposOwnerRepoChangesChangeIdWalkthroughInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/{change_id}/walkthrough */
export declare const getApiReposOwnerRepoChangesChangeIdWalkthrough: (transport: Transport, input: GetApiReposOwnerRepoChangesChangeIdWalkthroughInput) => Promise<GetApiReposOwnerRepoChangesChangeIdWalkthroughResponse>;
export type PutApiReposOwnerRepoChangesChangeIdWalkthroughResponse = AnyJSON;
export interface PutApiReposOwnerRepoChangesChangeIdWalkthroughInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/changes/{change_id}/walkthrough */
export declare const putApiReposOwnerRepoChangesChangeIdWalkthrough: (transport: Transport, input: PutApiReposOwnerRepoChangesChangeIdWalkthroughInput) => Promise<PutApiReposOwnerRepoChangesChangeIdWalkthroughResponse>;
export interface GetApiReposOwnerRepoChangesEventsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/changes/events */
export declare const getApiReposOwnerRepoChangesEvents: (transport: Transport, input: GetApiReposOwnerRepoChangesEventsInput) => Promise<Response>;
export type GetApiReposOwnerRepoCommitsRefStatusesResponse = AnyJSON;
export interface GetApiReposOwnerRepoCommitsRefStatusesInput {
    readonly path: { readonly owner: string; readonly ref: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/commits/{ref}/statuses */
export declare const getApiReposOwnerRepoCommitsRefStatuses: (transport: Transport, input: GetApiReposOwnerRepoCommitsRefStatusesInput) => Promise<GetApiReposOwnerRepoCommitsRefStatusesResponse>;
export type GetApiReposOwnerRepoContentsResponse = AnyJSON;
export interface GetApiReposOwnerRepoContentsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/contents */
export declare const getApiReposOwnerRepoContents: (transport: Transport, input: GetApiReposOwnerRepoContentsInput) => Promise<GetApiReposOwnerRepoContentsResponse>;
export type GetApiReposOwnerRepoContentsPathResponse = AnyJSON;
export interface GetApiReposOwnerRepoContentsPathInput {
    readonly path: { readonly owner: string; readonly path: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/contents/{path} */
export declare const getApiReposOwnerRepoContentsPath: (transport: Transport, input: GetApiReposOwnerRepoContentsPathInput) => Promise<GetApiReposOwnerRepoContentsPathResponse>;
export type GetApiReposOwnerRepoDevtoolsSnapshotsResponse = AnyJSON;
export interface GetApiReposOwnerRepoDevtoolsSnapshotsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/devtools/snapshots */
export declare const getApiReposOwnerRepoDevtoolsSnapshots: (transport: Transport, input: GetApiReposOwnerRepoDevtoolsSnapshotsInput) => Promise<GetApiReposOwnerRepoDevtoolsSnapshotsResponse>;
export type PostApiReposOwnerRepoDevtoolsSnapshotsResponse = AnyJSON;
export interface PostApiReposOwnerRepoDevtoolsSnapshotsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/devtools/snapshots */
export declare const postApiReposOwnerRepoDevtoolsSnapshots: (transport: Transport, input: PostApiReposOwnerRepoDevtoolsSnapshotsInput) => Promise<PostApiReposOwnerRepoDevtoolsSnapshotsResponse>;
export type GetApiReposOwnerRepoDevtoolsSnapshotsLatestResponse = AnyJSON;
export interface GetApiReposOwnerRepoDevtoolsSnapshotsLatestInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/devtools/snapshots/latest */
export declare const getApiReposOwnerRepoDevtoolsSnapshotsLatest: (transport: Transport, input: GetApiReposOwnerRepoDevtoolsSnapshotsLatestInput) => Promise<GetApiReposOwnerRepoDevtoolsSnapshotsLatestResponse>;
export type GetApiReposOwnerRepoEnvironmentImagesResponse = AnyJSON;
export interface GetApiReposOwnerRepoEnvironmentImagesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/environment-images */
export declare const getApiReposOwnerRepoEnvironmentImages: (transport: Transport, input: GetApiReposOwnerRepoEnvironmentImagesInput) => Promise<GetApiReposOwnerRepoEnvironmentImagesResponse>;
export type PostApiReposOwnerRepoEnvironmentImagesResponse = AnyJSON;
export interface PostApiReposOwnerRepoEnvironmentImagesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/environment-images */
export declare const postApiReposOwnerRepoEnvironmentImages: (transport: Transport, input: PostApiReposOwnerRepoEnvironmentImagesInput) => Promise<PostApiReposOwnerRepoEnvironmentImagesResponse>;
export type GetApiReposOwnerRepoFileChangeIdPathResponse = AnyJSON;
export interface GetApiReposOwnerRepoFileChangeIdPathInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly path: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/file/{change_id}/{path} */
export declare const getApiReposOwnerRepoFileChangeIdPath: (transport: Transport, input: GetApiReposOwnerRepoFileChangeIdPathInput) => Promise<GetApiReposOwnerRepoFileChangeIdPathResponse>;
export type GetApiReposOwnerRepoGitRefsResponse = AnyJSON;
export interface GetApiReposOwnerRepoGitRefsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/git/refs */
export declare const getApiReposOwnerRepoGitRefs: (transport: Transport, input: GetApiReposOwnerRepoGitRefsInput) => Promise<GetApiReposOwnerRepoGitRefsResponse>;
export type GetApiReposOwnerRepoGithubAppStatusResponse = AnyJSON;
export interface GetApiReposOwnerRepoGithubAppStatusInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/github-app-status */
export declare const getApiReposOwnerRepoGithubAppStatus: (transport: Transport, input: GetApiReposOwnerRepoGithubAppStatusInput) => Promise<GetApiReposOwnerRepoGithubAppStatusResponse>;
export type GetApiReposOwnerRepoHooksResponse = AnyJSON;
export interface GetApiReposOwnerRepoHooksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/hooks */
export declare const getApiReposOwnerRepoHooks: (transport: Transport, input: GetApiReposOwnerRepoHooksInput) => Promise<GetApiReposOwnerRepoHooksResponse>;
export type PostApiReposOwnerRepoHooksResponse = AnyJSON;
export interface PostApiReposOwnerRepoHooksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/hooks */
export declare const postApiReposOwnerRepoHooks: (transport: Transport, input: PostApiReposOwnerRepoHooksInput) => Promise<PostApiReposOwnerRepoHooksResponse>;
export type GetApiReposOwnerRepoHooksIdDeliveriesResponse = AnyJSON;
export interface GetApiReposOwnerRepoHooksIdDeliveriesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/hooks/{id}/deliveries */
export declare const getApiReposOwnerRepoHooksIdDeliveries: (transport: Transport, input: GetApiReposOwnerRepoHooksIdDeliveriesInput) => Promise<GetApiReposOwnerRepoHooksIdDeliveriesResponse>;
export type GetApiReposOwnerRepoIssuesResponse = Array<Issue>;
export interface GetApiReposOwnerRepoIssuesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly query?: { readonly cursor?: string; readonly limit?: number; readonly state?: "all" | "closed" | "fixed" | "open" | "verified"; readonly view?: string; };
}
/** GET /api/repos/{owner}/{repo}/issues */
export declare const getApiReposOwnerRepoIssues: (transport: Transport, input: GetApiReposOwnerRepoIssuesInput) => Promise<GetApiReposOwnerRepoIssuesResponse>;
export type PostApiReposOwnerRepoIssuesResponse = Issue;
export interface PostApiReposOwnerRepoIssuesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/issues */
export declare const postApiReposOwnerRepoIssues: (transport: Transport, input: PostApiReposOwnerRepoIssuesInput) => Promise<PostApiReposOwnerRepoIssuesResponse>;
export type GetApiReposOwnerRepoIssuesNumberResponse = Issue;
export interface GetApiReposOwnerRepoIssuesNumberInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number} */
export declare const getApiReposOwnerRepoIssuesNumber: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberInput) => Promise<GetApiReposOwnerRepoIssuesNumberResponse>;
export type PatchApiReposOwnerRepoIssuesNumberResponse = Issue;
export interface PatchApiReposOwnerRepoIssuesNumberInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/issues/{number} */
export declare const patchApiReposOwnerRepoIssuesNumber: (transport: Transport, input: PatchApiReposOwnerRepoIssuesNumberInput) => Promise<PatchApiReposOwnerRepoIssuesNumberResponse>;
export type GetApiReposOwnerRepoIssuesNumberCommentsResponse = Array<IssueComment>;
export interface GetApiReposOwnerRepoIssuesNumberCommentsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number}/comments */
export declare const getApiReposOwnerRepoIssuesNumberComments: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberCommentsInput) => Promise<GetApiReposOwnerRepoIssuesNumberCommentsResponse>;
export type PostApiReposOwnerRepoIssuesNumberCommentsResponse = IssueComment;
export interface PostApiReposOwnerRepoIssuesNumberCommentsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/issues/{number}/comments */
export declare const postApiReposOwnerRepoIssuesNumberComments: (transport: Transport, input: PostApiReposOwnerRepoIssuesNumberCommentsInput) => Promise<PostApiReposOwnerRepoIssuesNumberCommentsResponse>;
export interface GetApiReposOwnerRepoIssuesNumberEventsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number}/events */
export declare const getApiReposOwnerRepoIssuesNumberEvents: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberEventsInput) => Promise<Response>;
export type GetApiReposOwnerRepoIssuesNumberLabelsResponse = AnyJSON;
export interface GetApiReposOwnerRepoIssuesNumberLabelsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number}/labels */
export declare const getApiReposOwnerRepoIssuesNumberLabels: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberLabelsInput) => Promise<GetApiReposOwnerRepoIssuesNumberLabelsResponse>;
export type PostApiReposOwnerRepoIssuesNumberLabelsResponse = AnyJSON;
export interface PostApiReposOwnerRepoIssuesNumberLabelsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/issues/{number}/labels */
export declare const postApiReposOwnerRepoIssuesNumberLabels: (transport: Transport, input: PostApiReposOwnerRepoIssuesNumberLabelsInput) => Promise<PostApiReposOwnerRepoIssuesNumberLabelsResponse>;
export type GetApiReposOwnerRepoIssuesStateEventsResponse = IssueStateFactPage;
export interface GetApiReposOwnerRepoIssuesStateEventsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly query?: { readonly after?: number; readonly limit?: number; };
}
/** GET /api/repos/{owner}/{repo}/issues/state-events */
export declare const getApiReposOwnerRepoIssuesStateEvents: (transport: Transport, input: GetApiReposOwnerRepoIssuesStateEventsInput) => Promise<GetApiReposOwnerRepoIssuesStateEventsResponse>;
export interface GetApiReposOwnerRepoIssuesStateEventsStreamInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly query?: { readonly after?: number; };
}
/** GET /api/repos/{owner}/{repo}/issues/state-events/stream */
export declare const getApiReposOwnerRepoIssuesStateEventsStream: (transport: Transport, input: GetApiReposOwnerRepoIssuesStateEventsStreamInput) => Promise<Response>;
export type GetApiReposOwnerRepoKeysResponse = AnyJSON;
export interface GetApiReposOwnerRepoKeysInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/keys */
export declare const getApiReposOwnerRepoKeys: (transport: Transport, input: GetApiReposOwnerRepoKeysInput) => Promise<GetApiReposOwnerRepoKeysResponse>;
export type PostApiReposOwnerRepoKeysResponse = AnyJSON;
export interface PostApiReposOwnerRepoKeysInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/keys */
export declare const postApiReposOwnerRepoKeys: (transport: Transport, input: PostApiReposOwnerRepoKeysInput) => Promise<PostApiReposOwnerRepoKeysResponse>;
export type GetApiReposOwnerRepoLabelsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLabelsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/labels */
export declare const getApiReposOwnerRepoLabels: (transport: Transport, input: GetApiReposOwnerRepoLabelsInput) => Promise<GetApiReposOwnerRepoLabelsResponse>;
export type PostApiReposOwnerRepoLabelsResponse = AnyJSON;
export interface PostApiReposOwnerRepoLabelsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/labels */
export declare const postApiReposOwnerRepoLabels: (transport: Transport, input: PostApiReposOwnerRepoLabelsInput) => Promise<PostApiReposOwnerRepoLabelsResponse>;
export type GetApiReposOwnerRepoLandingsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings */
export declare const getApiReposOwnerRepoLandings: (transport: Transport, input: GetApiReposOwnerRepoLandingsInput) => Promise<GetApiReposOwnerRepoLandingsResponse>;
export type PostApiReposOwnerRepoLandingsResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings */
export declare const postApiReposOwnerRepoLandings: (transport: Transport, input: PostApiReposOwnerRepoLandingsInput) => Promise<PostApiReposOwnerRepoLandingsResponse>;
export type GetApiReposOwnerRepoLandingsNumberResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number} */
export declare const getApiReposOwnerRepoLandingsNumber: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberInput) => Promise<GetApiReposOwnerRepoLandingsNumberResponse>;
export type PatchApiReposOwnerRepoLandingsNumberResponse = AnyJSON;
export interface PatchApiReposOwnerRepoLandingsNumberInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** PATCH /api/repos/{owner}/{repo}/landings/{number} */
export declare const patchApiReposOwnerRepoLandingsNumber: (transport: Transport, input: PatchApiReposOwnerRepoLandingsNumberInput) => Promise<PatchApiReposOwnerRepoLandingsNumberResponse>;
export type GetApiReposOwnerRepoLandingsNumberChangesResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberChangesInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/changes */
export declare const getApiReposOwnerRepoLandingsNumberChanges: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberChangesInput) => Promise<GetApiReposOwnerRepoLandingsNumberChangesResponse>;
export type GetApiReposOwnerRepoLandingsNumberCommentsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberCommentsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/comments */
export declare const getApiReposOwnerRepoLandingsNumberComments: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberCommentsInput) => Promise<GetApiReposOwnerRepoLandingsNumberCommentsResponse>;
export type PostApiReposOwnerRepoLandingsNumberCommentsResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberCommentsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/comments */
export declare const postApiReposOwnerRepoLandingsNumberComments: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberCommentsInput) => Promise<PostApiReposOwnerRepoLandingsNumberCommentsResponse>;
export type GetApiReposOwnerRepoLandingsNumberConflictsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberConflictsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/conflicts */
export declare const getApiReposOwnerRepoLandingsNumberConflicts: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberConflictsInput) => Promise<GetApiReposOwnerRepoLandingsNumberConflictsResponse>;
export type GetApiReposOwnerRepoLandingsNumberDiffResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberDiffInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/diff */
export declare const getApiReposOwnerRepoLandingsNumberDiff: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberDiffInput) => Promise<GetApiReposOwnerRepoLandingsNumberDiffResponse>;
export type GetApiReposOwnerRepoLandingsNumberLandAppendResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberLandAppendInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/land/append */
export declare const getApiReposOwnerRepoLandingsNumberLandAppend: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberLandAppendInput) => Promise<GetApiReposOwnerRepoLandingsNumberLandAppendResponse>;
export type PutApiReposOwnerRepoLandingsNumberLandAppendResponse = AnyJSON;
export interface PutApiReposOwnerRepoLandingsNumberLandAppendInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/landings/{number}/land/append */
export declare const putApiReposOwnerRepoLandingsNumberLandAppend: (transport: Transport, input: PutApiReposOwnerRepoLandingsNumberLandAppendInput) => Promise<PutApiReposOwnerRepoLandingsNumberLandAppendResponse>;
export type GetApiReposOwnerRepoLandingsNumberReviewsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLandingsNumberReviewsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/landings/{number}/reviews */
export declare const getApiReposOwnerRepoLandingsNumberReviews: (transport: Transport, input: GetApiReposOwnerRepoLandingsNumberReviewsInput) => Promise<GetApiReposOwnerRepoLandingsNumberReviewsResponse>;
export type PostApiReposOwnerRepoLandingsNumberReviewsResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberReviewsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/reviews */
export declare const postApiReposOwnerRepoLandingsNumberReviews: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberReviewsInput) => Promise<PostApiReposOwnerRepoLandingsNumberReviewsResponse>;
export type GetApiReposOwnerRepoLfsObjectsResponse = AnyJSON;
export interface GetApiReposOwnerRepoLfsObjectsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/lfs/objects */
export declare const getApiReposOwnerRepoLfsObjects: (transport: Transport, input: GetApiReposOwnerRepoLfsObjectsInput) => Promise<GetApiReposOwnerRepoLfsObjectsResponse>;
export type GetApiReposOwnerRepoMirrorSyncRunIdResponse = GitMirrorSyncRunStatus;
export interface GetApiReposOwnerRepoMirrorSyncRunIdInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly run_id: string; };
}
/** GET /api/repos/{owner}/{repo}/mirror-sync/{run_id} */
export declare const getApiReposOwnerRepoMirrorSyncRunId: (transport: Transport, input: GetApiReposOwnerRepoMirrorSyncRunIdInput) => Promise<GetApiReposOwnerRepoMirrorSyncRunIdResponse>;
export type GetApiReposOwnerRepoOperationsResponse = AnyJSON;
export interface GetApiReposOwnerRepoOperationsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/operations */
export declare const getApiReposOwnerRepoOperations: (transport: Transport, input: GetApiReposOwnerRepoOperationsInput) => Promise<GetApiReposOwnerRepoOperationsResponse>;
export type GetApiReposOwnerRepoProtectedBookmarksResponse = AnyJSON;
export interface GetApiReposOwnerRepoProtectedBookmarksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/protected-bookmarks */
export declare const getApiReposOwnerRepoProtectedBookmarks: (transport: Transport, input: GetApiReposOwnerRepoProtectedBookmarksInput) => Promise<GetApiReposOwnerRepoProtectedBookmarksResponse>;
export type PostApiReposOwnerRepoProtectedBookmarksResponse = AnyJSON;
export interface PostApiReposOwnerRepoProtectedBookmarksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/protected-bookmarks */
export declare const postApiReposOwnerRepoProtectedBookmarks: (transport: Transport, input: PostApiReposOwnerRepoProtectedBookmarksInput) => Promise<PostApiReposOwnerRepoProtectedBookmarksResponse>;
export type GetApiReposOwnerRepoRunsResponse = MultiWorkflowRunsResponse;
export interface GetApiReposOwnerRepoRunsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs */
export declare const getApiReposOwnerRepoRuns: (transport: Transport, input: GetApiReposOwnerRepoRunsInput) => Promise<GetApiReposOwnerRepoRunsResponse>;
export type GetApiReposOwnerRepoRunsIdResponse = MultiWorkflowRun;
export interface GetApiReposOwnerRepoRunsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id} */
export declare const getApiReposOwnerRepoRunsId: (transport: Transport, input: GetApiReposOwnerRepoRunsIdInput) => Promise<GetApiReposOwnerRepoRunsIdResponse>;
export interface GetApiReposOwnerRepoRunsIdEventsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/events */
export declare const getApiReposOwnerRepoRunsIdEvents: (transport: Transport, input: GetApiReposOwnerRepoRunsIdEventsInput) => Promise<Response>;
export interface GetApiReposOwnerRepoRunsIdLogsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/logs */
export declare const getApiReposOwnerRepoRunsIdLogs: (transport: Transport, input: GetApiReposOwnerRepoRunsIdLogsInput) => Promise<Response>;
export type GetApiReposOwnerRepoRunsIdStatusResponse = AnyJSON;
export interface GetApiReposOwnerRepoRunsIdStatusInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/status */
export declare const getApiReposOwnerRepoRunsIdStatus: (transport: Transport, input: GetApiReposOwnerRepoRunsIdStatusInput) => Promise<GetApiReposOwnerRepoRunsIdStatusResponse>;
export interface GetApiReposOwnerRepoRunsIdStatusStreamInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/status/stream */
export declare const getApiReposOwnerRepoRunsIdStatusStream: (transport: Transport, input: GetApiReposOwnerRepoRunsIdStatusStreamInput) => Promise<Response>;
export type GetApiReposOwnerRepoRunsIdStepsResponse = MultiWorkflowStepsResponse;
export interface GetApiReposOwnerRepoRunsIdStepsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/steps */
export declare const getApiReposOwnerRepoRunsIdSteps: (transport: Transport, input: GetApiReposOwnerRepoRunsIdStepsInput) => Promise<GetApiReposOwnerRepoRunsIdStepsResponse>;
export type GetApiReposOwnerRepoSecretsResponse = AnyJSON;
export interface GetApiReposOwnerRepoSecretsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/secrets */
export declare const getApiReposOwnerRepoSecrets: (transport: Transport, input: GetApiReposOwnerRepoSecretsInput) => Promise<GetApiReposOwnerRepoSecretsResponse>;
export type PostApiReposOwnerRepoSecretsResponse = AnyJSON;
export interface PostApiReposOwnerRepoSecretsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/secrets */
export declare const postApiReposOwnerRepoSecrets: (transport: Transport, input: PostApiReposOwnerRepoSecretsInput) => Promise<PostApiReposOwnerRepoSecretsResponse>;
export type GetApiReposOwnerRepoStatusResponse = AnyJSON;
export interface GetApiReposOwnerRepoStatusInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/status */
export declare const getApiReposOwnerRepoStatus: (transport: Transport, input: GetApiReposOwnerRepoStatusInput) => Promise<GetApiReposOwnerRepoStatusResponse>;
export type GetApiReposOwnerRepoTopicsResponse = AnyJSON;
export interface GetApiReposOwnerRepoTopicsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/topics */
export declare const getApiReposOwnerRepoTopics: (transport: Transport, input: GetApiReposOwnerRepoTopicsInput) => Promise<GetApiReposOwnerRepoTopicsResponse>;
export type PutApiReposOwnerRepoTopicsResponse = AnyJSON;
export interface PutApiReposOwnerRepoTopicsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/topics */
export declare const putApiReposOwnerRepoTopics: (transport: Transport, input: PutApiReposOwnerRepoTopicsInput) => Promise<PutApiReposOwnerRepoTopicsResponse>;
export type GetApiReposOwnerRepoVariablesResponse = AnyJSON;
export interface GetApiReposOwnerRepoVariablesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/variables */
export declare const getApiReposOwnerRepoVariables: (transport: Transport, input: GetApiReposOwnerRepoVariablesInput) => Promise<GetApiReposOwnerRepoVariablesResponse>;
export type PostApiReposOwnerRepoVariablesResponse = AnyJSON;
export interface PostApiReposOwnerRepoVariablesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/variables */
export declare const postApiReposOwnerRepoVariables: (transport: Transport, input: PostApiReposOwnerRepoVariablesInput) => Promise<PostApiReposOwnerRepoVariablesResponse>;
export type GetApiReposOwnerRepoWikiResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki */
export declare const getApiReposOwnerRepoWiki: (transport: Transport, input: GetApiReposOwnerRepoWikiInput) => Promise<GetApiReposOwnerRepoWikiResponse>;
export type PostApiReposOwnerRepoWikiResponse = AnyJSON;
export interface PostApiReposOwnerRepoWikiInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/wiki */
export declare const postApiReposOwnerRepoWiki: (transport: Transport, input: PostApiReposOwnerRepoWikiInput) => Promise<PostApiReposOwnerRepoWikiResponse>;
export type GetApiReposOwnerRepoWikiSlugDocumentResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiSlugDocumentInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/{slug}/document */
export declare const getApiReposOwnerRepoWikiSlugDocument: (transport: Transport, input: GetApiReposOwnerRepoWikiSlugDocumentInput) => Promise<GetApiReposOwnerRepoWikiSlugDocumentResponse>;
export type GetApiReposOwnerRepoWikiSlugRevisionsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiSlugRevisionsInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/{slug}/revisions */
export declare const getApiReposOwnerRepoWikiSlugRevisions: (transport: Transport, input: GetApiReposOwnerRepoWikiSlugRevisionsInput) => Promise<GetApiReposOwnerRepoWikiSlugRevisionsResponse>;
export interface GetApiReposOwnerRepoWikiSlugStreamInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/{slug}/stream */
export declare const getApiReposOwnerRepoWikiSlugStream: (transport: Transport, input: GetApiReposOwnerRepoWikiSlugStreamInput) => Promise<Response>;
export type GetApiReposOwnerRepoWikiSlugUpdatesResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiSlugUpdatesInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/{slug}/updates */
export declare const getApiReposOwnerRepoWikiSlugUpdates: (transport: Transport, input: GetApiReposOwnerRepoWikiSlugUpdatesInput) => Promise<GetApiReposOwnerRepoWikiSlugUpdatesResponse>;
export type PostApiReposOwnerRepoWikiSlugUpdatesResponse = AnyJSON;
export interface PostApiReposOwnerRepoWikiSlugUpdatesInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
}
/** POST /api/repos/{owner}/{repo}/wiki/{slug}/updates */
export declare const postApiReposOwnerRepoWikiSlugUpdates: (transport: Transport, input: PostApiReposOwnerRepoWikiSlugUpdatesInput) => Promise<PostApiReposOwnerRepoWikiSlugUpdatesResponse>;
export type GetApiReposOwnerRepoWikiSearchResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiSearchInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/search */
export declare const getApiReposOwnerRepoWikiSearch: (transport: Transport, input: GetApiReposOwnerRepoWikiSearchInput) => Promise<GetApiReposOwnerRepoWikiSearchResponse>;
export type GetApiReposOwnerRepoWorkflowRunsIdArtifactsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowRunsIdArtifactsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflow/runs/{id}/artifacts */
export declare const getApiReposOwnerRepoWorkflowRunsIdArtifacts: (transport: Transport, input: GetApiReposOwnerRepoWorkflowRunsIdArtifactsInput) => Promise<GetApiReposOwnerRepoWorkflowRunsIdArtifactsResponse>;
export type GetApiReposOwnerRepoWorkflowsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows */
export declare const getApiReposOwnerRepoWorkflows: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsInput) => Promise<GetApiReposOwnerRepoWorkflowsResponse>;
export type GetApiReposOwnerRepoWorkflowsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/{id} */
export declare const getApiReposOwnerRepoWorkflowsId: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsIdInput) => Promise<GetApiReposOwnerRepoWorkflowsIdResponse>;
export type GetApiReposOwnerRepoWorkflowsIdRunsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsIdRunsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/{id}/runs */
export declare const getApiReposOwnerRepoWorkflowsIdRuns: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsIdRunsInput) => Promise<GetApiReposOwnerRepoWorkflowsIdRunsResponse>;
export type GetApiReposOwnerRepoWorkflowsRunsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsRunsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/runs */
export declare const getApiReposOwnerRepoWorkflowsRuns: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsRunsInput) => Promise<GetApiReposOwnerRepoWorkflowsRunsResponse>;
export type GetApiReposOwnerRepoWorkflowsRunsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsRunsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/runs/{id} */
export declare const getApiReposOwnerRepoWorkflowsRunsId: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsRunsIdInput) => Promise<GetApiReposOwnerRepoWorkflowsRunsIdResponse>;
export interface GetApiReposOwnerRepoWorkflowsRunsIdEventsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/runs/{id}/events */
export declare const getApiReposOwnerRepoWorkflowsRunsIdEvents: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsRunsIdEventsInput) => Promise<Response>;
export type GetApiReposOwnerRepoWorkflowsRunsIdNodesNodeidResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkflowsRunsIdNodesNodeidInput {
    readonly path: { readonly id: string; readonly nodeId: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workflows/runs/{id}/nodes/{nodeId} */
export declare const getApiReposOwnerRepoWorkflowsRunsIdNodesNodeid: (transport: Transport, input: GetApiReposOwnerRepoWorkflowsRunsIdNodesNodeidInput) => Promise<GetApiReposOwnerRepoWorkflowsRunsIdNodesNodeidResponse>;
export type GetApiReposOwnerRepoWorkspaceSnapshotsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSnapshotsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace-snapshots */
export declare const getApiReposOwnerRepoWorkspaceSnapshots: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSnapshotsInput) => Promise<GetApiReposOwnerRepoWorkspaceSnapshotsResponse>;
export type PostApiReposOwnerRepoWorkspaceSnapshotsResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspaceSnapshotsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspace-snapshots */
export declare const postApiReposOwnerRepoWorkspaceSnapshots: (transport: Transport, input: PostApiReposOwnerRepoWorkspaceSnapshotsInput) => Promise<PostApiReposOwnerRepoWorkspaceSnapshotsResponse>;
export type GetApiReposOwnerRepoWorkspaceSessionsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSessionsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions */
export declare const getApiReposOwnerRepoWorkspaceSessions: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsInput) => Promise<GetApiReposOwnerRepoWorkspaceSessionsResponse>;
export type PostApiReposOwnerRepoWorkspaceSessionsResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspaceSessionsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspace/sessions */
export declare const postApiReposOwnerRepoWorkspaceSessions: (transport: Transport, input: PostApiReposOwnerRepoWorkspaceSessionsInput) => Promise<PostApiReposOwnerRepoWorkspaceSessionsResponse>;
export type GetApiReposOwnerRepoWorkspaceSessionsIdResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSessionsIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions/{id} */
export declare const getApiReposOwnerRepoWorkspaceSessionsId: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsIdInput) => Promise<GetApiReposOwnerRepoWorkspaceSessionsIdResponse>;
export type GetApiReposOwnerRepoWorkspaceSessionsIdLspResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSessionsIdLspInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions/{id}/lsp */
export declare const getApiReposOwnerRepoWorkspaceSessionsIdLsp: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsIdLspInput) => Promise<GetApiReposOwnerRepoWorkspaceSessionsIdLspResponse>;
export type GetApiReposOwnerRepoWorkspaceSessionsIdSshResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSessionsIdSshInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions/{id}/ssh */
export declare const getApiReposOwnerRepoWorkspaceSessionsIdSsh: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsIdSshInput) => Promise<GetApiReposOwnerRepoWorkspaceSessionsIdSshResponse>;
export interface GetApiReposOwnerRepoWorkspaceSessionsIdStreamInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions/{id}/stream */
export declare const getApiReposOwnerRepoWorkspaceSessionsIdStream: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsIdStreamInput) => Promise<Response>;
export type GetApiReposOwnerRepoWorkspaceSessionsIdTerminalResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspaceSessionsIdTerminalInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspace/sessions/{id}/terminal */
export declare const getApiReposOwnerRepoWorkspaceSessionsIdTerminal: (transport: Transport, input: GetApiReposOwnerRepoWorkspaceSessionsIdTerminalInput) => Promise<GetApiReposOwnerRepoWorkspaceSessionsIdTerminalResponse>;
export type GetApiReposOwnerRepoWorkspacesResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces */
export declare const getApiReposOwnerRepoWorkspaces: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesInput) => Promise<GetApiReposOwnerRepoWorkspacesResponse>;
export type PostApiReposOwnerRepoWorkspacesResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces */
export declare const postApiReposOwnerRepoWorkspaces: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesInput) => Promise<PostApiReposOwnerRepoWorkspacesResponse>;
export type GetApiReposOwnerRepoWorkspacesIdCodingRevisionsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdCodingRevisionsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/coding/revisions */
export declare const getApiReposOwnerRepoWorkspacesIdCodingRevisions: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdCodingRevisionsInput) => Promise<GetApiReposOwnerRepoWorkspacesIdCodingRevisionsResponse>;
export type GetApiReposOwnerRepoWorkspacesIdEgressResponse = SandboxEgressAuditEntries;
export interface GetApiReposOwnerRepoWorkspacesIdEgressInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly query?: { readonly cursor?: string; readonly limit?: number; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/egress */
export declare const getApiReposOwnerRepoWorkspacesIdEgress: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdEgressInput) => Promise<GetApiReposOwnerRepoWorkspacesIdEgressResponse>;
export type GetApiReposOwnerRepoWorkspacesIdFilesResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdFilesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/files */
export declare const getApiReposOwnerRepoWorkspacesIdFiles: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdFilesInput) => Promise<GetApiReposOwnerRepoWorkspacesIdFilesResponse>;
export type GetApiReposOwnerRepoWorkspacesIdFilesContentResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdFilesContentInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/files/content */
export declare const getApiReposOwnerRepoWorkspacesIdFilesContent: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdFilesContentInput) => Promise<GetApiReposOwnerRepoWorkspacesIdFilesContentResponse>;
export type PutApiReposOwnerRepoWorkspacesIdFilesContentResponse = AnyJSON;
export interface PutApiReposOwnerRepoWorkspacesIdFilesContentInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/workspaces/{id}/files/content */
export declare const putApiReposOwnerRepoWorkspacesIdFilesContent: (transport: Transport, input: PutApiReposOwnerRepoWorkspacesIdFilesContentInput) => Promise<PutApiReposOwnerRepoWorkspacesIdFilesContentResponse>;
export type GetApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoPreviewResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoPreviewInput {
    readonly path: { readonly id: string; readonly op_id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/operations/{op_id}/undo/preview */
export declare const getApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoPreview: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoPreviewInput) => Promise<GetApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoPreviewResponse>;
export type GetApiReposOwnerRepoWorkspacesIdServicesResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdServicesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/services */
export declare const getApiReposOwnerRepoWorkspacesIdServices: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdServicesInput) => Promise<GetApiReposOwnerRepoWorkspacesIdServicesResponse>;
export type PostApiReposOwnerRepoWorkspacesIdServicesBody = AnyJSON;
export type PostApiReposOwnerRepoWorkspacesIdServicesResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdServicesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoWorkspacesIdServicesBody;
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/services */
export declare const postApiReposOwnerRepoWorkspacesIdServices: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdServicesInput) => Promise<PostApiReposOwnerRepoWorkspacesIdServicesResponse>;
export type GetApiReposOwnerRepoWorkspacesIdSshResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdSshInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/ssh */
export declare const getApiReposOwnerRepoWorkspacesIdSsh: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdSshInput) => Promise<GetApiReposOwnerRepoWorkspacesIdSshResponse>;
export interface GetApiReposOwnerRepoWorkspacesIdStreamInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/stream */
export declare const getApiReposOwnerRepoWorkspacesIdStream: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdStreamInput) => Promise<Response>;
export type GetApiUserRepositoryTransfersResponse = Array<RepositoryTransferRequest>;
/** GET /api/user/repository-transfers: List incoming and outgoing pending repository transfers */
export declare const getApiUserRepositoryTransfers: (transport: Transport) => Promise<GetApiUserRepositoryTransfersResponse>;
export type PostApiUserRepositoryTransfersTransferIdAcceptResponse = AnyJSON;
export interface PostApiUserRepositoryTransfersTransferIdAcceptInput {
    readonly path: { readonly transfer_id: number; };
}
/** POST /api/user/repository-transfers/{transfer_id}/accept: Accept an incoming repository transfer */
export declare const postApiUserRepositoryTransfersTransferIdAccept: (transport: Transport, input: PostApiUserRepositoryTransfersTransferIdAcceptInput) => Promise<PostApiUserRepositoryTransfersTransferIdAcceptResponse>;
export interface PostApiUserRepositoryTransfersTransferIdDeclineInput {
    readonly path: { readonly transfer_id: number; };
}
/** POST /api/user/repository-transfers/{transfer_id}/decline: Decline an incoming repository transfer */
export declare const postApiUserRepositoryTransfersTransferIdDecline: (transport: Transport, input: PostApiUserRepositoryTransfersTransferIdDeclineInput) => Promise<void>;
export interface PostApiUserRepositoryTransfersTransferIdCancelInput {
    readonly path: { readonly transfer_id: number; };
}
/** POST /api/user/repository-transfers/{transfer_id}/cancel: Cancel an outgoing repository transfer */
export declare const postApiUserRepositoryTransfersTransferIdCancel: (transport: Transport, input: PostApiUserRepositoryTransfersTransferIdCancelInput) => Promise<void>;
export type PatchApiReposOwnerRepoLandingsNumberReviewsReviewIdResponse = AnyJSON;
export interface PatchApiReposOwnerRepoLandingsNumberReviewsReviewIdInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; readonly review_id: string; };
}
/** PATCH /api/repos/{owner}/{repo}/landings/{number}/reviews/{review_id} */
export declare const patchApiReposOwnerRepoLandingsNumberReviewsReviewId: (transport: Transport, input: PatchApiReposOwnerRepoLandingsNumberReviewsReviewIdInput) => Promise<PatchApiReposOwnerRepoLandingsNumberReviewsReviewIdResponse>;
export type PostApiReposOwnerRepoActionsRunsIdCancelResponse = AnyJSON;
export interface PostApiReposOwnerRepoActionsRunsIdCancelInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/actions/runs/{id}/cancel */
export declare const postApiReposOwnerRepoActionsRunsIdCancel: (transport: Transport, input: PostApiReposOwnerRepoActionsRunsIdCancelInput) => Promise<PostApiReposOwnerRepoActionsRunsIdCancelResponse>;
export type PostApiReposOwnerRepoActionsRunsIdRerunResponse = AnyJSON;
export interface PostApiReposOwnerRepoActionsRunsIdRerunInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/actions/runs/{id}/rerun */
export declare const postApiReposOwnerRepoActionsRunsIdRerun: (transport: Transport, input: PostApiReposOwnerRepoActionsRunsIdRerunInput) => Promise<PostApiReposOwnerRepoActionsRunsIdRerunResponse>;
export type PostApiReposOwnerRepoApprovalsIdDecideResponse = AnyJSON;
export interface PostApiReposOwnerRepoApprovalsIdDecideInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/approvals/{id}/decide */
export declare const postApiReposOwnerRepoApprovalsIdDecide: (transport: Transport, input: PostApiReposOwnerRepoApprovalsIdDecideInput) => Promise<PostApiReposOwnerRepoApprovalsIdDecideResponse>;
export type PostApiReposOwnerRepoArchiveResponse = AnyJSON;
export interface PostApiReposOwnerRepoArchiveInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/archive */
export declare const postApiReposOwnerRepoArchive: (transport: Transport, input: PostApiReposOwnerRepoArchiveInput) => Promise<PostApiReposOwnerRepoArchiveResponse>;
export type PostApiReposOwnerRepoBranchLocksAcquireResponse = AnyJSON;
export interface PostApiReposOwnerRepoBranchLocksAcquireInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/branch-locks/acquire */
export declare const postApiReposOwnerRepoBranchLocksAcquire: (transport: Transport, input: PostApiReposOwnerRepoBranchLocksAcquireInput) => Promise<PostApiReposOwnerRepoBranchLocksAcquireResponse>;
export type PostApiReposOwnerRepoBranchLocksHeartbeatResponse = AnyJSON;
export interface PostApiReposOwnerRepoBranchLocksHeartbeatInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/branch-locks/heartbeat */
export declare const postApiReposOwnerRepoBranchLocksHeartbeat: (transport: Transport, input: PostApiReposOwnerRepoBranchLocksHeartbeatInput) => Promise<PostApiReposOwnerRepoBranchLocksHeartbeatResponse>;
export type PostApiReposOwnerRepoBranchLocksJoinRequestsIdDecideResponse = AnyJSON;
export interface PostApiReposOwnerRepoBranchLocksJoinRequestsIdDecideInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/branch-locks/join-requests/{id}/decide */
export declare const postApiReposOwnerRepoBranchLocksJoinRequestsIdDecide: (transport: Transport, input: PostApiReposOwnerRepoBranchLocksJoinRequestsIdDecideInput) => Promise<PostApiReposOwnerRepoBranchLocksJoinRequestsIdDecideResponse>;
export type PostApiReposOwnerRepoBranchLocksReleaseResponse = AnyJSON;
export interface PostApiReposOwnerRepoBranchLocksReleaseInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/branch-locks/release */
export declare const postApiReposOwnerRepoBranchLocksRelease: (transport: Transport, input: PostApiReposOwnerRepoBranchLocksReleaseInput) => Promise<PostApiReposOwnerRepoBranchLocksReleaseResponse>;
export type PostApiReposOwnerRepoBuildCacheCasFindmissingResponse = AnyJSON;
export interface PostApiReposOwnerRepoBuildCacheCasFindmissingInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/build-cache/cas/findMissing */
export declare const postApiReposOwnerRepoBuildCacheCasFindmissing: (transport: Transport, input: PostApiReposOwnerRepoBuildCacheCasFindmissingInput) => Promise<PostApiReposOwnerRepoBuildCacheCasFindmissingResponse>;
export type PostApiReposOwnerRepoChangesChangeIdConflictsResolveBody = ResolveChangeConflictRequest;
export type PostApiReposOwnerRepoChangesChangeIdConflictsResolveResponse = ResolveChangeConflictResponse;
export interface PostApiReposOwnerRepoChangesChangeIdConflictsResolveInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoChangesChangeIdConflictsResolveBody;
}
/** POST /api/repos/{owner}/{repo}/changes/{change_id}/conflicts/resolve */
export declare const postApiReposOwnerRepoChangesChangeIdConflictsResolve: (transport: Transport, input: PostApiReposOwnerRepoChangesChangeIdConflictsResolveInput) => Promise<PostApiReposOwnerRepoChangesChangeIdConflictsResolveResponse>;
export type PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdDispatchResponse = AnyJSON;
export interface PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdDispatchInput {
    readonly path: { readonly change_id: string; readonly finding_id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/changes/{change_id}/findings/{finding_id}/dispatch */
export declare const postApiReposOwnerRepoChangesChangeIdFindingsFindingIdDispatch: (transport: Transport, input: PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdDispatchInput) => Promise<PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdDispatchResponse>;
export type PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdFeedbackResponse = AnyJSON;
export interface PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdFeedbackInput {
    readonly path: { readonly change_id: string; readonly finding_id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/changes/{change_id}/findings/{finding_id}/feedback */
export declare const postApiReposOwnerRepoChangesChangeIdFindingsFindingIdFeedback: (transport: Transport, input: PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdFeedbackInput) => Promise<PostApiReposOwnerRepoChangesChangeIdFindingsFindingIdFeedbackResponse>;
export type PostApiReposOwnerRepoChangesChangeIdRevertResponse = AnyJSON;
export interface PostApiReposOwnerRepoChangesChangeIdRevertInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/changes/{change_id}/revert */
export declare const postApiReposOwnerRepoChangesChangeIdRevert: (transport: Transport, input: PostApiReposOwnerRepoChangesChangeIdRevertInput) => Promise<PostApiReposOwnerRepoChangesChangeIdRevertResponse>;
export type PostApiReposOwnerRepoChangesChangeIdSplitResponse = AnyJSON;
export interface PostApiReposOwnerRepoChangesChangeIdSplitInput {
    readonly path: { readonly change_id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/changes/{change_id}/split */
export declare const postApiReposOwnerRepoChangesChangeIdSplit: (transport: Transport, input: PostApiReposOwnerRepoChangesChangeIdSplitInput) => Promise<PostApiReposOwnerRepoChangesChangeIdSplitResponse>;
export type PostApiReposOwnerRepoForkResponse = AnyJSON;
export interface PostApiReposOwnerRepoForkInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/fork */
export declare const postApiReposOwnerRepoFork: (transport: Transport, input: PostApiReposOwnerRepoForkInput) => Promise<PostApiReposOwnerRepoForkResponse>;
export type PostApiReposOwnerRepoForksResponse = AnyJSON;
export interface PostApiReposOwnerRepoForksInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/forks */
export declare const postApiReposOwnerRepoForks: (transport: Transport, input: PostApiReposOwnerRepoForksInput) => Promise<PostApiReposOwnerRepoForksResponse>;
export type PostApiReposOwnerRepoGithubProxyResponse = AnyJSON;
export interface PostApiReposOwnerRepoGithubProxyInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/github-proxy */
export declare const postApiReposOwnerRepoGithubProxy: (transport: Transport, input: PostApiReposOwnerRepoGithubProxyInput) => Promise<PostApiReposOwnerRepoGithubProxyResponse>;
export type PostApiReposOwnerRepoGithubMirrorRefsRefRetryResponse = SyncRunAccepted;
export interface PostApiReposOwnerRepoGithubMirrorRefsRefRetryInput {
    readonly path: { readonly owner: string; readonly ref: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/github/mirror/refs/{ref}/retry */
export declare const postApiReposOwnerRepoGithubMirrorRefsRefRetry: (transport: Transport, input: PostApiReposOwnerRepoGithubMirrorRefsRefRetryInput) => Promise<PostApiReposOwnerRepoGithubMirrorRefsRefRetryResponse>;
export type PostApiReposOwnerRepoGithubReconcileResponse = AnyJSON;
export interface PostApiReposOwnerRepoGithubReconcileInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/github/reconcile */
export declare const postApiReposOwnerRepoGithubReconcile: (transport: Transport, input: PostApiReposOwnerRepoGithubReconcileInput) => Promise<PostApiReposOwnerRepoGithubReconcileResponse>;
export type PostApiReposOwnerRepoHooksIdDeliveriesDeliveryIdRedeliverResponse = AnyJSON;
export interface PostApiReposOwnerRepoHooksIdDeliveriesDeliveryIdRedeliverInput {
    readonly path: { readonly delivery_id: string; readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/hooks/{id}/deliveries/{delivery_id}/redeliver */
export declare const postApiReposOwnerRepoHooksIdDeliveriesDeliveryIdRedeliver: (transport: Transport, input: PostApiReposOwnerRepoHooksIdDeliveriesDeliveryIdRedeliverInput) => Promise<PostApiReposOwnerRepoHooksIdDeliveriesDeliveryIdRedeliverResponse>;
export type PostApiReposOwnerRepoHooksIdTestsResponse = AnyJSON;
export interface PostApiReposOwnerRepoHooksIdTestsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/hooks/{id}/tests */
export declare const postApiReposOwnerRepoHooksIdTests: (transport: Transport, input: PostApiReposOwnerRepoHooksIdTestsInput) => Promise<PostApiReposOwnerRepoHooksIdTestsResponse>;
export type PostApiReposOwnerRepoInvokeResponse = AnyJSON;
export interface PostApiReposOwnerRepoInvokeInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/invoke */
export declare const postApiReposOwnerRepoInvoke: (transport: Transport, input: PostApiReposOwnerRepoInvokeInput) => Promise<PostApiReposOwnerRepoInvokeResponse>;
export type PostApiReposOwnerRepoLandingsNumberReviewRequestsResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberReviewRequestsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/review-requests */
export declare const postApiReposOwnerRepoLandingsNumberReviewRequests: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberReviewRequestsInput) => Promise<PostApiReposOwnerRepoLandingsNumberReviewRequestsResponse>;
export type PostApiReposOwnerRepoLandingsNumberThreadsIdAckResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberThreadsIdAckInput {
    readonly path: { readonly id: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/threads/{id}/ack */
export declare const postApiReposOwnerRepoLandingsNumberThreadsIdAck: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberThreadsIdAckInput) => Promise<PostApiReposOwnerRepoLandingsNumberThreadsIdAckResponse>;
export type PostApiReposOwnerRepoLandingsNumberThreadsIdDoneResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberThreadsIdDoneInput {
    readonly path: { readonly id: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/threads/{id}/done */
export declare const postApiReposOwnerRepoLandingsNumberThreadsIdDone: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberThreadsIdDoneInput) => Promise<PostApiReposOwnerRepoLandingsNumberThreadsIdDoneResponse>;
export type PostApiReposOwnerRepoLandingsNumberThreadsIdReopenResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsNumberThreadsIdReopenInput {
    readonly path: { readonly id: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/{number}/threads/{id}/reopen */
export declare const postApiReposOwnerRepoLandingsNumberThreadsIdReopen: (transport: Transport, input: PostApiReposOwnerRepoLandingsNumberThreadsIdReopenInput) => Promise<PostApiReposOwnerRepoLandingsNumberThreadsIdReopenResponse>;
export type PostApiReposOwnerRepoLandingsAppendPrepareResponse = AnyJSON;
export interface PostApiReposOwnerRepoLandingsAppendPrepareInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/landings/append/prepare */
export declare const postApiReposOwnerRepoLandingsAppendPrepare: (transport: Transport, input: PostApiReposOwnerRepoLandingsAppendPrepareInput) => Promise<PostApiReposOwnerRepoLandingsAppendPrepareResponse>;
export type PostApiReposOwnerRepoLfsBatchResponse = AnyJSON;
export interface PostApiReposOwnerRepoLfsBatchInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/lfs/batch */
export declare const postApiReposOwnerRepoLfsBatch: (transport: Transport, input: PostApiReposOwnerRepoLfsBatchInput) => Promise<PostApiReposOwnerRepoLfsBatchResponse>;
export type PostApiReposOwnerRepoLfsConfirmResponse = AnyJSON;
export interface PostApiReposOwnerRepoLfsConfirmInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/lfs/confirm */
export declare const postApiReposOwnerRepoLfsConfirm: (transport: Transport, input: PostApiReposOwnerRepoLfsConfirmInput) => Promise<PostApiReposOwnerRepoLfsConfirmResponse>;
export type PostApiReposOwnerRepoLfsObjectsBatchResponse = AnyJSON;
export interface PostApiReposOwnerRepoLfsObjectsBatchInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/lfs/objects/batch */
export declare const postApiReposOwnerRepoLfsObjectsBatch: (transport: Transport, input: PostApiReposOwnerRepoLfsObjectsBatchInput) => Promise<PostApiReposOwnerRepoLfsObjectsBatchResponse>;
export interface PostApiReposOwnerRepoLfsVerifyInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/lfs/verify */
export declare const postApiReposOwnerRepoLfsVerify: (transport: Transport, input: PostApiReposOwnerRepoLfsVerifyInput) => Promise<void>;
export type PostApiReposOwnerRepoMirrorSyncResponse = SyncRunAccepted;
export interface PostApiReposOwnerRepoMirrorSyncInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/mirror-sync */
export declare const postApiReposOwnerRepoMirrorSync: (transport: Transport, input: PostApiReposOwnerRepoMirrorSyncInput) => Promise<PostApiReposOwnerRepoMirrorSyncResponse>;
export type PostApiReposOwnerRepoRunsIdCancelResponse = AnyJSON;
export interface PostApiReposOwnerRepoRunsIdCancelInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/runs/{id}/cancel */
export declare const postApiReposOwnerRepoRunsIdCancel: (transport: Transport, input: PostApiReposOwnerRepoRunsIdCancelInput) => Promise<PostApiReposOwnerRepoRunsIdCancelResponse>;
export type PostApiReposOwnerRepoRunsIdRerunResponse = AnyJSON;
export interface PostApiReposOwnerRepoRunsIdRerunInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/runs/{id}/rerun */
export declare const postApiReposOwnerRepoRunsIdRerun: (transport: Transport, input: PostApiReposOwnerRepoRunsIdRerunInput) => Promise<PostApiReposOwnerRepoRunsIdRerunResponse>;
export type PostApiReposOwnerRepoRunsIdResumeResponse = AnyJSON;
export interface PostApiReposOwnerRepoRunsIdResumeInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/runs/{id}/resume */
export declare const postApiReposOwnerRepoRunsIdResume: (transport: Transport, input: PostApiReposOwnerRepoRunsIdResumeInput) => Promise<PostApiReposOwnerRepoRunsIdResumeResponse>;
export type PostApiReposOwnerRepoStatusesShaResponse = AnyJSON;
export interface PostApiReposOwnerRepoStatusesShaInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly sha: string; };
}
/** POST /api/repos/{owner}/{repo}/statuses/{sha} */
export declare const postApiReposOwnerRepoStatusesSha: (transport: Transport, input: PostApiReposOwnerRepoStatusesShaInput) => Promise<PostApiReposOwnerRepoStatusesShaResponse>;
export type PostApiReposOwnerRepoSyncResponse = AnyJSON;
export interface PostApiReposOwnerRepoSyncInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/sync */
export declare const postApiReposOwnerRepoSync: (transport: Transport, input: PostApiReposOwnerRepoSyncInput) => Promise<PostApiReposOwnerRepoSyncResponse>;
export type PostApiReposOwnerRepoTransferBody = { new_owner: string; };
export type PostApiReposOwnerRepoTransferResponse = RepositoryTransferResponse;
export interface PostApiReposOwnerRepoTransferInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoTransferBody;
}
/** POST /api/repos/{owner}/{repo}/transfer: Request a repository transfer */
export declare const postApiReposOwnerRepoTransfer: (transport: Transport, input: PostApiReposOwnerRepoTransferInput) => Promise<PostApiReposOwnerRepoTransferResponse>;
export type PostApiReposOwnerRepoUnarchiveResponse = AnyJSON;
export interface PostApiReposOwnerRepoUnarchiveInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/unarchive */
export declare const postApiReposOwnerRepoUnarchive: (transport: Transport, input: PostApiReposOwnerRepoUnarchiveInput) => Promise<PostApiReposOwnerRepoUnarchiveResponse>;
export type PostApiReposOwnerRepoWorkflowsIdDispatchesResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkflowsIdDispatchesInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workflows/{id}/dispatches */
export declare const postApiReposOwnerRepoWorkflowsIdDispatches: (transport: Transport, input: PostApiReposOwnerRepoWorkflowsIdDispatchesInput) => Promise<PostApiReposOwnerRepoWorkflowsIdDispatchesResponse>;
export type PostApiReposOwnerRepoWorkflowsNameDispatchResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkflowsNameDispatchInput {
    readonly path: { readonly name: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workflows/{name}/dispatch */
export declare const postApiReposOwnerRepoWorkflowsNameDispatch: (transport: Transport, input: PostApiReposOwnerRepoWorkflowsNameDispatchInput) => Promise<PostApiReposOwnerRepoWorkflowsNameDispatchResponse>;
export type PostApiReposOwnerRepoWorkflowsRunsIdCancelResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkflowsRunsIdCancelInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workflows/runs/{id}/cancel */
export declare const postApiReposOwnerRepoWorkflowsRunsIdCancel: (transport: Transport, input: PostApiReposOwnerRepoWorkflowsRunsIdCancelInput) => Promise<PostApiReposOwnerRepoWorkflowsRunsIdCancelResponse>;
export type PostApiReposOwnerRepoWorkflowsRunsIdRerunResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkflowsRunsIdRerunInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workflows/runs/{id}/rerun */
export declare const postApiReposOwnerRepoWorkflowsRunsIdRerun: (transport: Transport, input: PostApiReposOwnerRepoWorkflowsRunsIdRerunInput) => Promise<PostApiReposOwnerRepoWorkflowsRunsIdRerunResponse>;
export type PostApiReposOwnerRepoWorkflowsRunsIdResumeResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkflowsRunsIdResumeInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workflows/runs/{id}/resume */
export declare const postApiReposOwnerRepoWorkflowsRunsIdResume: (transport: Transport, input: PostApiReposOwnerRepoWorkflowsRunsIdResumeInput) => Promise<PostApiReposOwnerRepoWorkflowsRunsIdResumeResponse>;
export type PostApiReposOwnerRepoWorkspaceSessionsIdDestroyResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspaceSessionsIdDestroyInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspace/sessions/{id}/destroy */
export declare const postApiReposOwnerRepoWorkspaceSessionsIdDestroy: (transport: Transport, input: PostApiReposOwnerRepoWorkspaceSessionsIdDestroyInput) => Promise<PostApiReposOwnerRepoWorkspaceSessionsIdDestroyResponse>;
export type PostApiReposOwnerRepoWorkspacesIdCodingOperationsResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdCodingOperationsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/coding/operations */
export declare const postApiReposOwnerRepoWorkspacesIdCodingOperations: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdCodingOperationsInput) => Promise<PostApiReposOwnerRepoWorkspacesIdCodingOperationsResponse>;
export type PostApiReposOwnerRepoWorkspacesIdDesktopInputResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdDesktopInputInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/desktop/input */
export declare const postApiReposOwnerRepoWorkspacesIdDesktopInput: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdDesktopInputInput) => Promise<PostApiReposOwnerRepoWorkspacesIdDesktopInputResponse>;
export type PostApiReposOwnerRepoWorkspacesIdDesktopObserveResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdDesktopObserveInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/desktop/observe */
export declare const postApiReposOwnerRepoWorkspacesIdDesktopObserve: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdDesktopObserveInput) => Promise<PostApiReposOwnerRepoWorkspacesIdDesktopObserveResponse>;
export type PostApiReposOwnerRepoWorkspacesIdDesktopSessionResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdDesktopSessionInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/desktop/session */
export declare const postApiReposOwnerRepoWorkspacesIdDesktopSession: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdDesktopSessionInput) => Promise<PostApiReposOwnerRepoWorkspacesIdDesktopSessionResponse>;
export type PostApiReposOwnerRepoWorkspacesIdForkResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdForkInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/fork */
export declare const postApiReposOwnerRepoWorkspacesIdFork: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdForkInput) => Promise<PostApiReposOwnerRepoWorkspacesIdForkResponse>;
export type PostApiReposOwnerRepoWorkspacesIdHeadResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdHeadInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/head */
export declare const postApiReposOwnerRepoWorkspacesIdHead: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdHeadInput) => Promise<PostApiReposOwnerRepoWorkspacesIdHeadResponse>;
export type PostApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoInput {
    readonly path: { readonly id: string; readonly op_id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/operations/{op_id}/undo */
export declare const postApiReposOwnerRepoWorkspacesIdOperationsOpIdUndo: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoInput) => Promise<PostApiReposOwnerRepoWorkspacesIdOperationsOpIdUndoResponse>;
export type PostApiReposOwnerRepoWorkspacesIdLeaseResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdLeaseInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/lease */
export declare const postApiReposOwnerRepoWorkspacesIdLease: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdLeaseInput) => Promise<PostApiReposOwnerRepoWorkspacesIdLeaseResponse>;
export type PostApiReposOwnerRepoWorkspacesIdResumeResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdResumeInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/resume */
export declare const postApiReposOwnerRepoWorkspacesIdResume: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdResumeInput) => Promise<PostApiReposOwnerRepoWorkspacesIdResumeResponse>;
export type PostApiReposOwnerRepoWorkspacesIdServicesNameActionResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdServicesNameActionInput {
    readonly path: { readonly action: string; readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/services/{name}/{action} */
export declare const postApiReposOwnerRepoWorkspacesIdServicesNameAction: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdServicesNameActionInput) => Promise<PostApiReposOwnerRepoWorkspacesIdServicesNameActionResponse>;
export type PostApiReposOwnerRepoWorkspacesIdSnapshotResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdSnapshotInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/snapshot */
export declare const postApiReposOwnerRepoWorkspacesIdSnapshot: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdSnapshotInput) => Promise<PostApiReposOwnerRepoWorkspacesIdSnapshotResponse>;
export type PostApiReposOwnerRepoWorkspacesIdSuspendResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdSuspendInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/suspend */
export declare const postApiReposOwnerRepoWorkspacesIdSuspend: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdSuspendInput) => Promise<PostApiReposOwnerRepoWorkspacesIdSuspendResponse>;
export type PostApiReposFromTemplateResponse = AnyJSON;
/** POST /api/repos/from-template */
export declare const postApiReposFromTemplate: (transport: Transport) => Promise<PostApiReposFromTemplateResponse>;
export type PutApiReposOwnerRepoLandingsNumberLandResponse = AnyJSON;
export interface PutApiReposOwnerRepoLandingsNumberLandInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** PUT /api/repos/{owner}/{repo}/landings/{number}/land */
export declare const putApiReposOwnerRepoLandingsNumberLand: (transport: Transport, input: PutApiReposOwnerRepoLandingsNumberLandInput) => Promise<PutApiReposOwnerRepoLandingsNumberLandResponse>;
export type PutApiReposOwnerRepoLandingsRequestsRequestUuidResponse = AnyJSON;
export interface PutApiReposOwnerRepoLandingsRequestsRequestUuidInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly request_uuid: string; };
}
/** PUT /api/repos/{owner}/{repo}/landings/requests/{request_uuid} */
export declare const putApiReposOwnerRepoLandingsRequestsRequestUuid: (transport: Transport, input: PutApiReposOwnerRepoLandingsRequestsRequestUuidInput) => Promise<PutApiReposOwnerRepoLandingsRequestsRequestUuidResponse>;
export type GetApiReposOwnerRepoHomeResponse = AnyJSON;
export interface GetApiReposOwnerRepoHomeInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/home */
export declare const getApiReposOwnerRepoHome: (transport: Transport, input: GetApiReposOwnerRepoHomeInput) => Promise<GetApiReposOwnerRepoHomeResponse>;
export type GetApiReposOwnerRepoIssuesSyncChannelsResponse = AnyJSON;
export interface GetApiReposOwnerRepoIssuesSyncChannelsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/sync/channels */
export declare const getApiReposOwnerRepoIssuesSyncChannels: (transport: Transport, input: GetApiReposOwnerRepoIssuesSyncChannelsInput) => Promise<GetApiReposOwnerRepoIssuesSyncChannelsResponse>;
export type PutApiReposOwnerRepoIssuesSyncChannelsBody = AnyJSON;
export type PutApiReposOwnerRepoIssuesSyncChannelsResponse = AnyJSON;
export interface PutApiReposOwnerRepoIssuesSyncChannelsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoIssuesSyncChannelsBody;
}
/** PUT /api/repos/{owner}/{repo}/issues/sync/channels */
export declare const putApiReposOwnerRepoIssuesSyncChannels: (transport: Transport, input: PutApiReposOwnerRepoIssuesSyncChannelsInput) => Promise<PutApiReposOwnerRepoIssuesSyncChannelsResponse>;
export type GetApiReposOwnerRepoIssuesSyncDeliveriesResponse = AnyJSON;
export interface GetApiReposOwnerRepoIssuesSyncDeliveriesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/sync/deliveries */
export declare const getApiReposOwnerRepoIssuesSyncDeliveries: (transport: Transport, input: GetApiReposOwnerRepoIssuesSyncDeliveriesInput) => Promise<GetApiReposOwnerRepoIssuesSyncDeliveriesResponse>;
export type GetApiReposOwnerRepoIssuesNumberCommentsCommentReactionsResponse = AnyJSON;
export interface GetApiReposOwnerRepoIssuesNumberCommentsCommentReactionsInput {
    readonly path: { readonly comment: string; readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number}/comments/{comment}/reactions */
export declare const getApiReposOwnerRepoIssuesNumberCommentsCommentReactions: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberCommentsCommentReactionsInput) => Promise<GetApiReposOwnerRepoIssuesNumberCommentsCommentReactionsResponse>;
export type PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsBody = AnyJSON;
export type PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsResponse = AnyJSON;
export interface PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsInput {
    readonly path: { readonly comment: string; readonly number: string; readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsBody;
}
/** PUT /api/repos/{owner}/{repo}/issues/{number}/comments/{comment}/reactions */
export declare const putApiReposOwnerRepoIssuesNumberCommentsCommentReactions: (transport: Transport, input: PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsInput) => Promise<PutApiReposOwnerRepoIssuesNumberCommentsCommentReactionsResponse>;
export type GetApiReposOwnerRepoIssuesNumberSyncResponse = AnyJSON;
export interface GetApiReposOwnerRepoIssuesNumberSyncInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/issues/{number}/sync */
export declare const getApiReposOwnerRepoIssuesNumberSync: (transport: Transport, input: GetApiReposOwnerRepoIssuesNumberSyncInput) => Promise<GetApiReposOwnerRepoIssuesNumberSyncResponse>;
export type PutApiReposOwnerRepoIssuesNumberSyncBody = AnyJSON;
export type PutApiReposOwnerRepoIssuesNumberSyncResponse = AnyJSON;
export interface PutApiReposOwnerRepoIssuesNumberSyncInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoIssuesNumberSyncBody;
}
/** PUT /api/repos/{owner}/{repo}/issues/{number}/sync */
export declare const putApiReposOwnerRepoIssuesNumberSync: (transport: Transport, input: PutApiReposOwnerRepoIssuesNumberSyncInput) => Promise<PutApiReposOwnerRepoIssuesNumberSyncResponse>;
export type GetApiReposOwnerRepoMythicalResponse = AnyJSON;
export interface GetApiReposOwnerRepoMythicalInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/mythical */
export declare const getApiReposOwnerRepoMythical: (transport: Transport, input: GetApiReposOwnerRepoMythicalInput) => Promise<GetApiReposOwnerRepoMythicalResponse>;
export type GetApiReposOwnerRepoMythicalEventsResponse = AnyJSON;
export interface GetApiReposOwnerRepoMythicalEventsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/mythical/events */
export declare const getApiReposOwnerRepoMythicalEvents: (transport: Transport, input: GetApiReposOwnerRepoMythicalEventsInput) => Promise<GetApiReposOwnerRepoMythicalEventsResponse>;
export type GetApiReposOwnerRepoRepositoryJobsResponse = AnyJSON;
export interface GetApiReposOwnerRepoRepositoryJobsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/repository-jobs */
export declare const getApiReposOwnerRepoRepositoryJobs: (transport: Transport, input: GetApiReposOwnerRepoRepositoryJobsInput) => Promise<GetApiReposOwnerRepoRepositoryJobsResponse>;
export type GetApiReposOwnerRepoRepositoryJobsJobApprovalsResponse = AnyJSON;
export interface GetApiReposOwnerRepoRepositoryJobsJobApprovalsInput {
    readonly path: { readonly job: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/repository-jobs/{job}/approvals */
export declare const getApiReposOwnerRepoRepositoryJobsJobApprovals: (transport: Transport, input: GetApiReposOwnerRepoRepositoryJobsJobApprovalsInput) => Promise<GetApiReposOwnerRepoRepositoryJobsJobApprovalsResponse>;
export type PostApiReposOwnerRepoRepositoryJobsJobApprovalsBody = AnyJSON;
export type PostApiReposOwnerRepoRepositoryJobsJobApprovalsResponse = AnyJSON;
export interface PostApiReposOwnerRepoRepositoryJobsJobApprovalsInput {
    readonly path: { readonly job: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoRepositoryJobsJobApprovalsBody;
}
/** POST /api/repos/{owner}/{repo}/repository-jobs/{job}/approvals */
export declare const postApiReposOwnerRepoRepositoryJobsJobApprovals: (transport: Transport, input: PostApiReposOwnerRepoRepositoryJobsJobApprovalsInput) => Promise<PostApiReposOwnerRepoRepositoryJobsJobApprovalsResponse>;
export type GetApiReposOwnerRepoRepositoryJobsJobDispatchesResponse = AnyJSON;
export interface GetApiReposOwnerRepoRepositoryJobsJobDispatchesInput {
    readonly path: { readonly job: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/repository-jobs/{job}/dispatches */
export declare const getApiReposOwnerRepoRepositoryJobsJobDispatches: (transport: Transport, input: GetApiReposOwnerRepoRepositoryJobsJobDispatchesInput) => Promise<GetApiReposOwnerRepoRepositoryJobsJobDispatchesResponse>;
export type GetApiReposOwnerRepoRepositorySourceResponse = AnyJSON;
export interface GetApiReposOwnerRepoRepositorySourceInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/repository-source */
export declare const getApiReposOwnerRepoRepositorySource: (transport: Transport, input: GetApiReposOwnerRepoRepositorySourceInput) => Promise<GetApiReposOwnerRepoRepositorySourceResponse>;
export type GetApiReposOwnerRepoRunsIdArtifactsResponse = AnyJSON;
export interface GetApiReposOwnerRepoRunsIdArtifactsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/artifacts */
export declare const getApiReposOwnerRepoRunsIdArtifacts: (transport: Transport, input: GetApiReposOwnerRepoRunsIdArtifactsInput) => Promise<GetApiReposOwnerRepoRunsIdArtifactsResponse>;
export type GetApiReposOwnerRepoRunsIdArtifactsNameDownloadResponse = AnyJSON;
export interface GetApiReposOwnerRepoRunsIdArtifactsNameDownloadInput {
    readonly path: { readonly id: string; readonly name: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/runs/{id}/artifacts/{name}/download */
export declare const getApiReposOwnerRepoRunsIdArtifactsNameDownload: (transport: Transport, input: GetApiReposOwnerRepoRunsIdArtifactsNameDownloadInput) => Promise<GetApiReposOwnerRepoRunsIdArtifactsNameDownloadResponse>;
export type GetApiReposOwnerRepoUserRefsResponse = AnyJSON;
export interface GetApiReposOwnerRepoUserRefsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/user-refs */
export declare const getApiReposOwnerRepoUserRefs: (transport: Transport, input: GetApiReposOwnerRepoUserRefsInput) => Promise<GetApiReposOwnerRepoUserRefsResponse>;
export type GetApiReposOwnerRepoWikiHistoryEventsResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiHistoryEventsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/history/events */
export declare const getApiReposOwnerRepoWikiHistoryEvents: (transport: Transport, input: GetApiReposOwnerRepoWikiHistoryEventsInput) => Promise<GetApiReposOwnerRepoWikiHistoryEventsResponse>;
export type GetApiReposOwnerRepoWikiHistoryPageResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiHistoryPageInput {
    readonly path: { readonly owner: string; readonly pageID: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/history/{pageID} */
export declare const getApiReposOwnerRepoWikiHistoryPage: (transport: Transport, input: GetApiReposOwnerRepoWikiHistoryPageInput) => Promise<GetApiReposOwnerRepoWikiHistoryPageResponse>;
export type GetApiReposOwnerRepoWikiHistoryPageRevisionContentResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiHistoryPageRevisionContentInput {
    readonly path: { readonly owner: string; readonly pageID: string; readonly repo: string; readonly revision: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/history/{pageID}/{revision}/content */
export declare const getApiReposOwnerRepoWikiHistoryPageRevisionContent: (transport: Transport, input: GetApiReposOwnerRepoWikiHistoryPageRevisionContentInput) => Promise<GetApiReposOwnerRepoWikiHistoryPageRevisionContentResponse>;
export type GetApiReposOwnerRepoWikiNavigationIndexResponse = AnyJSON;
export interface GetApiReposOwnerRepoWikiNavigationIndexInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/wiki/navigation/index */
export declare const getApiReposOwnerRepoWikiNavigationIndex: (transport: Transport, input: GetApiReposOwnerRepoWikiNavigationIndexInput) => Promise<GetApiReposOwnerRepoWikiNavigationIndexResponse>;
export type GetApiReposOwnerRepoWorkspacesIdCommandRunsOperationResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdCommandRunsOperationInput {
    readonly path: { readonly id: string; readonly operationID: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/command-runs/{operationID} */
export declare const getApiReposOwnerRepoWorkspacesIdCommandRunsOperation: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdCommandRunsOperationInput) => Promise<GetApiReposOwnerRepoWorkspacesIdCommandRunsOperationResponse>;
export type GetApiReposOwnerRepoWorkspacesIdPreviewPortResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdPreviewPortInput {
    readonly path: { readonly id: string; readonly owner: string; readonly port: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/preview/{port} */
export declare const getApiReposOwnerRepoWorkspacesIdPreviewPort: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdPreviewPortInput) => Promise<GetApiReposOwnerRepoWorkspacesIdPreviewPortResponse>;
export type GetApiReposOwnerRepoWorkspacesIdPreviewPortPathResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdPreviewPortPathInput {
    readonly path: { readonly id: string; readonly owner: string; readonly path: string; readonly port: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/preview/{port}/{path} */
export declare const getApiReposOwnerRepoWorkspacesIdPreviewPortPath: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdPreviewPortPathInput) => Promise<GetApiReposOwnerRepoWorkspacesIdPreviewPortPathResponse>;
export type GetApiReposOwnerRepoWorkspacesIdServicesPortVisibilityResponse = AnyJSON;
export interface GetApiReposOwnerRepoWorkspacesIdServicesPortVisibilityInput {
    readonly path: { readonly id: string; readonly owner: string; readonly port: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/services/{port}/visibility */
export declare const getApiReposOwnerRepoWorkspacesIdServicesPortVisibility: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdServicesPortVisibilityInput) => Promise<GetApiReposOwnerRepoWorkspacesIdServicesPortVisibilityResponse>;
export type PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityBody = AnyJSON;
export type PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityResponse = AnyJSON;
export interface PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityInput {
    readonly path: { readonly id: string; readonly owner: string; readonly port: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityBody;
}
/** PUT /api/repos/{owner}/{repo}/workspaces/{id}/services/{port}/visibility */
export declare const putApiReposOwnerRepoWorkspacesIdServicesPortVisibility: (transport: Transport, input: PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityInput) => Promise<PutApiReposOwnerRepoWorkspacesIdServicesPortVisibilityResponse>;
export type PutApiReposOwnerRepoIssuesSyncDeliveriesIdBody = AnyJSON;
export type PutApiReposOwnerRepoIssuesSyncDeliveriesIdResponse = AnyJSON;
export interface PutApiReposOwnerRepoIssuesSyncDeliveriesIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoIssuesSyncDeliveriesIdBody;
}
/** PUT /api/repos/{owner}/{repo}/issues/sync/deliveries/{id} */
export declare const putApiReposOwnerRepoIssuesSyncDeliveriesId: (transport: Transport, input: PutApiReposOwnerRepoIssuesSyncDeliveriesIdInput) => Promise<PutApiReposOwnerRepoIssuesSyncDeliveriesIdResponse>;
export type PostApiReposOwnerRepoIssuesSyncDeliveriesIdBody = AnyJSON;
export type PostApiReposOwnerRepoIssuesSyncDeliveriesIdResponse = AnyJSON;
export interface PostApiReposOwnerRepoIssuesSyncDeliveriesIdInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoIssuesSyncDeliveriesIdBody;
}
/** POST /api/repos/{owner}/{repo}/issues/sync/deliveries/{id} */
export declare const postApiReposOwnerRepoIssuesSyncDeliveriesId: (transport: Transport, input: PostApiReposOwnerRepoIssuesSyncDeliveriesIdInput) => Promise<PostApiReposOwnerRepoIssuesSyncDeliveriesIdResponse>;
export type PostApiReposOwnerRepoIssuesSyncEventsBody = AnyJSON;
export type PostApiReposOwnerRepoIssuesSyncEventsResponse = AnyJSON;
export interface PostApiReposOwnerRepoIssuesSyncEventsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoIssuesSyncEventsBody;
}
/** POST /api/repos/{owner}/{repo}/issues/sync/events */
export declare const postApiReposOwnerRepoIssuesSyncEvents: (transport: Transport, input: PostApiReposOwnerRepoIssuesSyncEventsInput) => Promise<PostApiReposOwnerRepoIssuesSyncEventsResponse>;
export type PostApiReposOwnerRepoMythicalBackfillBody = AnyJSON;
export type PostApiReposOwnerRepoMythicalBackfillResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalBackfillInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoMythicalBackfillBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/backfill */
export declare const postApiReposOwnerRepoMythicalBackfill: (transport: Transport, input: PostApiReposOwnerRepoMythicalBackfillInput) => Promise<PostApiReposOwnerRepoMythicalBackfillResponse>;
export type PostApiReposOwnerRepoMythicalBootstrapBody = AnyJSON;
export type PostApiReposOwnerRepoMythicalBootstrapResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalBootstrapInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoMythicalBootstrapBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/bootstrap */
export declare const postApiReposOwnerRepoMythicalBootstrap: (transport: Transport, input: PostApiReposOwnerRepoMythicalBootstrapInput) => Promise<PostApiReposOwnerRepoMythicalBootstrapResponse>;
export type GetApiReposOwnerRepoMythicalItemsRefResponse = AnyJSON;
export interface GetApiReposOwnerRepoMythicalItemsRefInput {
    readonly path: { readonly owner: string; readonly ref: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/mythical/items/{ref} */
export declare const getApiReposOwnerRepoMythicalItemsRef: (transport: Transport, input: GetApiReposOwnerRepoMythicalItemsRefInput) => Promise<GetApiReposOwnerRepoMythicalItemsRefResponse>;
export type PostApiReposOwnerRepoMythicalItemsIdLandBody = { head: string; };
export type PostApiReposOwnerRepoMythicalItemsIdLandResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalItemsIdLandInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoMythicalItemsIdLandBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/items/{id}/land */
export declare const postApiReposOwnerRepoMythicalItemsIdLand: (transport: Transport, input: PostApiReposOwnerRepoMythicalItemsIdLandInput) => Promise<PostApiReposOwnerRepoMythicalItemsIdLandResponse>;
export type PostApiReposOwnerRepoMythicalItemsIdRetryBody = AnyJSON;
export type PostApiReposOwnerRepoMythicalItemsIdRetryResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalItemsIdRetryInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoMythicalItemsIdRetryBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/items/{id}/retry */
export declare const postApiReposOwnerRepoMythicalItemsIdRetry: (transport: Transport, input: PostApiReposOwnerRepoMythicalItemsIdRetryInput) => Promise<PostApiReposOwnerRepoMythicalItemsIdRetryResponse>;
export type PostApiReposOwnerRepoMythicalTodosBody = { body?: string; title: string; };
export type PostApiReposOwnerRepoMythicalTodosResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalTodosInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoMythicalTodosBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/todos */
export declare const postApiReposOwnerRepoMythicalTodos: (transport: Transport, input: PostApiReposOwnerRepoMythicalTodosInput) => Promise<PostApiReposOwnerRepoMythicalTodosResponse>;
export type PostApiReposOwnerRepoMythicalWikiBody = AnyJSON;
export type PostApiReposOwnerRepoMythicalWikiResponse = AnyJSON;
export interface PostApiReposOwnerRepoMythicalWikiInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoMythicalWikiBody;
}
/** POST /api/repos/{owner}/{repo}/mythical/wiki */
export declare const postApiReposOwnerRepoMythicalWiki: (transport: Transport, input: PostApiReposOwnerRepoMythicalWikiInput) => Promise<PostApiReposOwnerRepoMythicalWikiResponse>;
export type PostApiReposOwnerRepoRepositoryJobsJobPauseBody = AnyJSON;
export type PostApiReposOwnerRepoRepositoryJobsJobPauseResponse = AnyJSON;
export interface PostApiReposOwnerRepoRepositoryJobsJobPauseInput {
    readonly path: { readonly job: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoRepositoryJobsJobPauseBody;
}
/** POST /api/repos/{owner}/{repo}/repository-jobs/{job}/pause */
export declare const postApiReposOwnerRepoRepositoryJobsJobPause: (transport: Transport, input: PostApiReposOwnerRepoRepositoryJobsJobPauseInput) => Promise<PostApiReposOwnerRepoRepositoryJobsJobPauseResponse>;
export type PostApiReposOwnerRepoRepositorySourceRetainBody = AnyJSON;
export type PostApiReposOwnerRepoRepositorySourceRetainResponse = AnyJSON;
export interface PostApiReposOwnerRepoRepositorySourceRetainInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoRepositorySourceRetainBody;
}
/** POST /api/repos/{owner}/{repo}/repository-source/retain */
export declare const postApiReposOwnerRepoRepositorySourceRetain: (transport: Transport, input: PostApiReposOwnerRepoRepositorySourceRetainInput) => Promise<PostApiReposOwnerRepoRepositorySourceRetainResponse>;
export type PostApiReposOwnerRepoUserRefsRenewBody = AnyJSON;
export type PostApiReposOwnerRepoUserRefsRenewResponse = AnyJSON;
export interface PostApiReposOwnerRepoUserRefsRenewInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoUserRefsRenewBody;
}
/** POST /api/repos/{owner}/{repo}/user-refs/renew */
export declare const postApiReposOwnerRepoUserRefsRenew: (transport: Transport, input: PostApiReposOwnerRepoUserRefsRenewInput) => Promise<PostApiReposOwnerRepoUserRefsRenewResponse>;
export type PostApiReposOwnerRepoWorkspacesIdCommandRunsBody = AnyJSON;
export type PostApiReposOwnerRepoWorkspacesIdCommandRunsResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdCommandRunsInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoWorkspacesIdCommandRunsBody;
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/command-runs */
export declare const postApiReposOwnerRepoWorkspacesIdCommandRuns: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdCommandRunsInput) => Promise<PostApiReposOwnerRepoWorkspacesIdCommandRunsResponse>;
export type PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelBody = AnyJSON;
export type PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelInput {
    readonly path: { readonly id: string; readonly operationID: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelBody;
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/command-runs/{operationID}/cancel */
export declare const postApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancel: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelInput) => Promise<PostApiReposOwnerRepoWorkspacesIdCommandRunsOperationCancelResponse>;
export type PostApiReposOwnerRepoWorkspacesIdUserSourceBody = AnyJSON;
export type PostApiReposOwnerRepoWorkspacesIdUserSourceResponse = AnyJSON;
export interface PostApiReposOwnerRepoWorkspacesIdUserSourceInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body?: PostApiReposOwnerRepoWorkspacesIdUserSourceBody;
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/user-source */
export declare const postApiReposOwnerRepoWorkspacesIdUserSource: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdUserSourceInput) => Promise<PostApiReposOwnerRepoWorkspacesIdUserSourceResponse>;
export type PutApiReposOwnerRepoLandingsNumberGithubPullBody = AnyJSON;
export type PutApiReposOwnerRepoLandingsNumberGithubPullResponse = AnyJSON;
export interface PutApiReposOwnerRepoLandingsNumberGithubPullInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoLandingsNumberGithubPullBody;
}
/** PUT /api/repos/{owner}/{repo}/landings/{number}/github/pull */
export declare const putApiReposOwnerRepoLandingsNumberGithubPull: (transport: Transport, input: PutApiReposOwnerRepoLandingsNumberGithubPullInput) => Promise<PutApiReposOwnerRepoLandingsNumberGithubPullResponse>;
export type PutApiReposOwnerRepoMythicalConfigBody = AnyJSON;
export type PutApiReposOwnerRepoMythicalConfigResponse = AnyJSON;
export interface PutApiReposOwnerRepoMythicalConfigInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoMythicalConfigBody;
}
/** PUT /api/repos/{owner}/{repo}/mythical/config */
export declare const putApiReposOwnerRepoMythicalConfig: (transport: Transport, input: PutApiReposOwnerRepoMythicalConfigInput) => Promise<PutApiReposOwnerRepoMythicalConfigResponse>;
export type PutApiReposOwnerRepoMythicalLanesBody = AnyJSON;
export type PutApiReposOwnerRepoMythicalLanesResponse = AnyJSON;
export interface PutApiReposOwnerRepoMythicalLanesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body?: PutApiReposOwnerRepoMythicalLanesBody;
}
/** PUT /api/repos/{owner}/{repo}/mythical/lanes */
export declare const putApiReposOwnerRepoMythicalLanes: (transport: Transport, input: PutApiReposOwnerRepoMythicalLanesInput) => Promise<PutApiReposOwnerRepoMythicalLanesResponse>;
export type PutApiReposOwnerRepoWikiAttachmentsSlugBody = AnyJSON;
export type PutApiReposOwnerRepoWikiAttachmentsSlugResponse = AnyJSON;
export interface PutApiReposOwnerRepoWikiAttachmentsSlugInput {
    readonly path: { readonly owner: string; readonly repo: string; readonly slug: string; };
    readonly body?: PutApiReposOwnerRepoWikiAttachmentsSlugBody;
}
/** PUT /api/repos/{owner}/{repo}/wiki/attachments/{slug} */
export declare const putApiReposOwnerRepoWikiAttachmentsSlug: (transport: Transport, input: PutApiReposOwnerRepoWikiAttachmentsSlugInput) => Promise<PutApiReposOwnerRepoWikiAttachmentsSlugResponse>;
export type GetApiReposOwnerRepoEgressPolicyResponse = { allow_domains: Array<string>; updated_at?: string; };
export interface GetApiReposOwnerRepoEgressPolicyInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/egress-policy */
export declare const getApiReposOwnerRepoEgressPolicy: (transport: Transport, input: GetApiReposOwnerRepoEgressPolicyInput) => Promise<GetApiReposOwnerRepoEgressPolicyResponse>;
export type PatchApiReposOwnerRepoEgressPolicyBody = { add?: Array<string>; remove?: Array<string>; };
export type PatchApiReposOwnerRepoEgressPolicyResponse = { allow_domains: Array<string>; reloads: Array<{ error?: string; reloaded: boolean; sandbox_id: string; }>; updated_at?: string; };
export interface PatchApiReposOwnerRepoEgressPolicyInput {
    readonly path: { readonly owner: string; readonly repo: string; };
    readonly body: PatchApiReposOwnerRepoEgressPolicyBody;
}
/** PATCH /api/repos/{owner}/{repo}/egress-policy */
export declare const patchApiReposOwnerRepoEgressPolicy: (transport: Transport, input: PatchApiReposOwnerRepoEgressPolicyInput) => Promise<PatchApiReposOwnerRepoEgressPolicyResponse>;
export type GetApiReposOwnerRepoWorkspacesIdChildrenResponse = Array<{ batch_id: string; expires_at: string; failure_message?: string; ordinal: number; profile: "build" | "small"; snapshot_id?: string; started_at?: string; status: string; stop_reason?: "abandoned" | "expired" | "failed" | "idle" | "parent_stopped" | "requested"; stopped_at?: string; vm_id?: string; workspace_id: string; }>;
export interface GetApiReposOwnerRepoWorkspacesIdChildrenInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/repos/{owner}/{repo}/workspaces/{id}/children: List a workspace's children */
export declare const getApiReposOwnerRepoWorkspacesIdChildren: (transport: Transport, input: GetApiReposOwnerRepoWorkspacesIdChildrenInput) => Promise<GetApiReposOwnerRepoWorkspacesIdChildrenResponse>;
export type PostApiReposOwnerRepoWorkspacesIdChildrenBody = { count: number; profile?: "build" | "small"; ttl_secs?: number; };
export type PostApiReposOwnerRepoWorkspacesIdChildrenResponse = { children: Array<{ batch_id: string; expires_at: string; failure_message?: string; ordinal: number; profile: "build" | "small"; snapshot_id?: string; started_at?: string; status: string; stop_reason?: "abandoned" | "expired" | "failed" | "idle" | "parent_stopped" | "requested"; stopped_at?: string; vm_id?: string; workspace_id: string; }>; expires_at: string; id: string; parent_workspace_id: string; profile: "build" | "small"; };
export interface PostApiReposOwnerRepoWorkspacesIdChildrenInput {
    readonly path: { readonly id: string; readonly owner: string; readonly repo: string; };
    readonly body: PostApiReposOwnerRepoWorkspacesIdChildrenBody;
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/children: Spawn children of a workspace */
export declare const postApiReposOwnerRepoWorkspacesIdChildren: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdChildrenInput) => Promise<PostApiReposOwnerRepoWorkspacesIdChildrenResponse>;
export type PostApiReposOwnerRepoWorkspacesIdChildrenChildIdStopResponse = { batch_id: string; expires_at: string; failure_message?: string; ordinal: number; profile: "build" | "small"; snapshot_id?: string; started_at?: string; status: string; stop_reason?: "abandoned" | "expired" | "failed" | "idle" | "parent_stopped" | "requested"; stopped_at?: string; vm_id?: string; workspace_id: string; };
export interface PostApiReposOwnerRepoWorkspacesIdChildrenChildIdStopInput {
    readonly path: { readonly child_id: string; readonly id: string; readonly owner: string; readonly repo: string; };
}
/** POST /api/repos/{owner}/{repo}/workspaces/{id}/children/{child_id}/stop: Stop a workspace's child */
export declare const postApiReposOwnerRepoWorkspacesIdChildrenChildIdStop: (transport: Transport, input: PostApiReposOwnerRepoWorkspacesIdChildrenChildIdStopInput) => Promise<PostApiReposOwnerRepoWorkspacesIdChildrenChildIdStopResponse>;
export type GetApiRepoConnectionResponse = AnyJSON;
/** GET /api/repo-connection */
export declare const getApiRepoConnection: (transport: Transport) => Promise<GetApiRepoConnectionResponse>;
export type PostApiRepoConnectionResponse = AnyJSON;
/** POST /api/repo-connection */
export declare const postApiRepoConnection: (transport: Transport) => Promise<PostApiRepoConnectionResponse>;
/** DELETE /api/repo-connection */
export declare const deleteApiRepoConnection: (transport: Transport) => Promise<void>;
export type GetApiRepositorySetupOperationResponse = AnyJSON;
export interface GetApiRepositorySetupOperationInput {
    readonly path: { readonly operation: string; };
}
/** GET /api/repository-setup/{operation} */
export declare const getApiRepositorySetupOperation: (transport: Transport, input: GetApiRepositorySetupOperationInput) => Promise<GetApiRepositorySetupOperationResponse>;
export type PostApiRepositorySetupOperationBody = AnyJSON;
export type PostApiRepositorySetupOperationResponse = AnyJSON;
export interface PostApiRepositorySetupOperationInput {
    readonly path: { readonly operation: string; };
    readonly body?: PostApiRepositorySetupOperationBody;
}
/** POST /api/repository-setup/{operation} */
export declare const postApiRepositorySetupOperation: (transport: Transport, input: PostApiRepositorySetupOperationInput) => Promise<PostApiRepositorySetupOperationResponse>;
export type GetApiSearchCodeResponse = AnyJSON;
/** GET /api/search/code */
export declare const getApiSearchCode: (transport: Transport) => Promise<GetApiSearchCodeResponse>;
export type GetApiSearchIssuesResponse = AnyJSON;
/** GET /api/search/issues */
export declare const getApiSearchIssues: (transport: Transport) => Promise<GetApiSearchIssuesResponse>;
export type GetApiSearchRepositoriesResponse = AnyJSON;
/** GET /api/search/repositories */
export declare const getApiSearchRepositories: (transport: Transport) => Promise<GetApiSearchRepositoriesResponse>;
export type GetApiSearchUsersResponse = AnyJSON;
/** GET /api/search/users */
export declare const getApiSearchUsers: (transport: Transport) => Promise<GetApiSearchUsersResponse>;
export type GetApiShareListingsListingDResponse = AnyJSON;
export interface GetApiShareListingsListingDInput {
    readonly path: { readonly listingId: string; };
}
/** GET /api/share/listings/{listingId} */
export declare const getApiShareListingsListingD: (transport: Transport, input: GetApiShareListingsListingDInput) => Promise<GetApiShareListingsListingDResponse>;
export type DeleteApiShareListingsListingDResponse = AnyJSON;
export interface DeleteApiShareListingsListingDInput {
    readonly path: { readonly listingId: string; };
}
/** DELETE /api/share/listings/{listingId} */
export declare const deleteApiShareListingsListingD: (transport: Transport, input: DeleteApiShareListingsListingDInput) => Promise<DeleteApiShareListingsListingDResponse>;
export type GetApiShareListingsResponse = AnyJSON;
/** GET /api/share/listings */
export declare const getApiShareListings: (transport: Transport) => Promise<GetApiShareListingsResponse>;
export type PostApiShareListingsBody = AnyJSON;
export type PostApiShareListingsResponse = AnyJSON;
export interface PostApiShareListingsInput {
    readonly body?: PostApiShareListingsBody;
}
/** POST /api/share/listings */
export declare const postApiShareListings: (transport: Transport, input?: PostApiShareListingsInput) => Promise<PostApiShareListingsResponse>;
export type GetApiShareMyListingsResponse = AnyJSON;
/** GET /api/share/my/listings */
export declare const getApiShareMyListings: (transport: Transport) => Promise<GetApiShareMyListingsResponse>;
export type PostApiShareListingsListingDEventsBody = AnyJSON;
export type PostApiShareListingsListingDEventsResponse = AnyJSON;
export interface PostApiShareListingsListingDEventsInput {
    readonly path: { readonly listingId: string; };
    readonly body?: PostApiShareListingsListingDEventsBody;
}
/** POST /api/share/listings/{listingId}/events */
export declare const postApiShareListingsListingDEvents: (transport: Transport, input: PostApiShareListingsListingDEventsInput) => Promise<PostApiShareListingsListingDEventsResponse>;
export type PostApiTelemetryErrorsResponse = AnyJSON;
/** POST /api/telemetry/errors */
export declare const postApiTelemetryErrors: (transport: Transport) => Promise<PostApiTelemetryErrorsResponse>;
export interface DeleteApiUserConnectionsIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/user/connections/{id} */
export declare const deleteApiUserConnectionsId: (transport: Transport, input: DeleteApiUserConnectionsIdInput) => Promise<void>;
export type PostApiUserDevicesResponse = AnyJSON;
/** POST /api/user/devices */
export declare const postApiUserDevices: (transport: Transport) => Promise<PostApiUserDevicesResponse>;
/** DELETE /api/user/devices */
export declare const deleteApiUserDevices: (transport: Transport) => Promise<void>;
export interface DeleteApiUserEmailsIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/user/emails/{id} */
export declare const deleteApiUserEmailsId: (transport: Transport, input: DeleteApiUserEmailsIdInput) => Promise<void>;
export type GetApiUserKeysIdResponse = SSHKey;
export interface GetApiUserKeysIdInput {
    readonly path: { readonly id: number; };
}
/** GET /api/user/keys/{id} */
export declare const getApiUserKeysId: (transport: Transport, input: GetApiUserKeysIdInput) => Promise<GetApiUserKeysIdResponse>;
export interface DeleteApiUserKeysIdInput {
    readonly path: { readonly id: number; };
}
/** DELETE /api/user/keys/{id} */
export declare const deleteApiUserKeysId: (transport: Transport, input: DeleteApiUserKeysIdInput) => Promise<void>;
export type GetApiUserProviderConnectionsIdResponse = AnyJSON;
export interface GetApiUserProviderConnectionsIdInput {
    readonly path: { readonly id: string; };
}
/** GET /api/user/provider-connections/{id} */
export declare const getApiUserProviderConnectionsId: (transport: Transport, input: GetApiUserProviderConnectionsIdInput) => Promise<GetApiUserProviderConnectionsIdResponse>;
export interface DeleteApiUserProviderConnectionsIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/user/provider-connections/{id} */
export declare const deleteApiUserProviderConnectionsId: (transport: Transport, input: DeleteApiUserProviderConnectionsIdInput) => Promise<void>;
export interface DeleteApiUserProviderConnectionsIdGrantsGrantidInput {
    readonly path: { readonly grantID: string; readonly id: string; };
}
/** DELETE /api/user/provider-connections/{id}/grants/{grantID} */
export declare const deleteApiUserProviderConnectionsIdGrantsGrantid: (transport: Transport, input: DeleteApiUserProviderConnectionsIdGrantsGrantidInput) => Promise<void>;
export interface DeleteApiUserSessionsIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/user/sessions/{id} */
export declare const deleteApiUserSessionsId: (transport: Transport, input: DeleteApiUserSessionsIdInput) => Promise<void>;
export interface DeleteApiUserTokensIdInput {
    readonly path: { readonly id: string; };
}
/** DELETE /api/user/tokens/{id} */
export declare const deleteApiUserTokensId: (transport: Transport, input: DeleteApiUserTokensIdInput) => Promise<void>;
export type GetApiUserResponse = AnyJSON;
/** GET /api/user */
export declare const getApiUser: (transport: Transport) => Promise<GetApiUserResponse>;
export type PatchApiUserResponse = AnyJSON;
/** PATCH /api/user */
export declare const patchApiUser: (transport: Transport) => Promise<PatchApiUserResponse>;
export type GetApiUserConnectionsResponse = AnyJSON;
/** GET /api/user/connections */
export declare const getApiUserConnections: (transport: Transport) => Promise<GetApiUserConnectionsResponse>;
export type GetApiUserEmailsResponse = AnyJSON;
/** GET /api/user/emails */
export declare const getApiUserEmails: (transport: Transport) => Promise<GetApiUserEmailsResponse>;
export type PostApiUserEmailsResponse = AnyJSON;
/** POST /api/user/emails */
export declare const postApiUserEmails: (transport: Transport) => Promise<PostApiUserEmailsResponse>;
export type GetApiUserEmailsVerifyTokenResponse = AnyJSON;
/** GET /api/user/emails/verify-token */
export declare const getApiUserEmailsVerifyToken: (transport: Transport) => Promise<GetApiUserEmailsVerifyTokenResponse>;
export type PostApiUserEmailsVerifyTokenResponse = AnyJSON;
/** POST /api/user/emails/verify-token */
export declare const postApiUserEmailsVerifyToken: (transport: Transport) => Promise<PostApiUserEmailsVerifyTokenResponse>;
export type GetApiUserGithubAccessOwnerRepoResponse = AnyJSON;
export interface GetApiUserGithubAccessOwnerRepoInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-access/{owner}/{repo} */
export declare const getApiUserGithubAccessOwnerRepo: (transport: Transport, input: GetApiUserGithubAccessOwnerRepoInput) => Promise<GetApiUserGithubAccessOwnerRepoResponse>;
export type GetApiUserGithubAppInstallationsResponse = { repos: Array<{ fullName: string; installationId: number; pushedAt: string; }>; };
/** GET /api/user/github-app/installations */
export declare const getApiUserGithubAppInstallations: (transport: Transport) => Promise<GetApiUserGithubAppInstallationsResponse>;
export type GetApiUserGithubAppInstallationsInstallationIdResponse = { repos: Array<{ fullName: string; installationId: number; pushedAt: string; }>; };
export interface GetApiUserGithubAppInstallationsInstallationIdInput {
    readonly path: { readonly installationId: string; };
}
/** GET /api/user/github-app/installations/{installationId} */
export declare const getApiUserGithubAppInstallationsInstallationId: (transport: Transport, input: GetApiUserGithubAppInstallationsInstallationIdInput) => Promise<GetApiUserGithubAppInstallationsInstallationIdResponse>;
export type GetApiUserGithubReposResponse = AnyJSON;
/** GET /api/user/github-repos */
export declare const getApiUserGithubRepos: (transport: Transport) => Promise<GetApiUserGithubReposResponse>;
export type GetApiUserGithubReposOwnerRepoResponse = AnyJSON;
export interface GetApiUserGithubReposOwnerRepoInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo} */
export declare const getApiUserGithubReposOwnerRepo: (transport: Transport, input: GetApiUserGithubReposOwnerRepoInput) => Promise<GetApiUserGithubReposOwnerRepoResponse>;
export type GetApiUserGithubReposOwnerRepoIssuesResponse = AnyJSON;
export interface GetApiUserGithubReposOwnerRepoIssuesInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo}/issues */
export declare const getApiUserGithubReposOwnerRepoIssues: (transport: Transport, input: GetApiUserGithubReposOwnerRepoIssuesInput) => Promise<GetApiUserGithubReposOwnerRepoIssuesResponse>;
export type GetApiUserGithubReposOwnerRepoIssuesNumberCommentsResponse = AnyJSON;
export interface GetApiUserGithubReposOwnerRepoIssuesNumberCommentsInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo}/issues/{number}/comments */
export declare const getApiUserGithubReposOwnerRepoIssuesNumberComments: (transport: Transport, input: GetApiUserGithubReposOwnerRepoIssuesNumberCommentsInput) => Promise<GetApiUserGithubReposOwnerRepoIssuesNumberCommentsResponse>;
export type GetApiUserGithubReposOwnerRepoPullsResponse = AnyJSON;
export interface GetApiUserGithubReposOwnerRepoPullsInput {
    readonly path: { readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo}/pulls */
export declare const getApiUserGithubReposOwnerRepoPulls: (transport: Transport, input: GetApiUserGithubReposOwnerRepoPullsInput) => Promise<GetApiUserGithubReposOwnerRepoPullsResponse>;
export type GetApiUserGithubReposOwnerRepoPullsNumberResponse = { [key: string]: unknown; base?: { [key: string]: unknown; ref?: string; sha?: string; }; body?: string; draft?: boolean; head?: { [key: string]: unknown; ref?: string; sha?: string; }; html_url?: string; merged?: boolean; number: number; state: "closed" | "open"; title: string; user?: { [key: string]: unknown; login?: string; }; };
export interface GetApiUserGithubReposOwnerRepoPullsNumberInput {
    readonly path: { readonly number: number; readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo}/pulls/{number}: Get one GitHub pull request */
export declare const getApiUserGithubReposOwnerRepoPullsNumber: (transport: Transport, input: GetApiUserGithubReposOwnerRepoPullsNumberInput) => Promise<GetApiUserGithubReposOwnerRepoPullsNumberResponse>;
export type GetApiUserGithubReposOwnerRepoPullsNumberDiffResponse = AnyJSON;
export interface GetApiUserGithubReposOwnerRepoPullsNumberDiffInput {
    readonly path: { readonly number: string; readonly owner: string; readonly repo: string; };
}
/** GET /api/user/github-repos/{owner}/{repo}/pulls/{number}/diff */
export declare const getApiUserGithubReposOwnerRepoPullsNumberDiff: (transport: Transport, input: GetApiUserGithubReposOwnerRepoPullsNumberDiffInput) => Promise<GetApiUserGithubReposOwnerRepoPullsNumberDiffResponse>;
export type ListUserGithubReposResponse = AnyJSON;
/** GET /api/user/github/repos */
export declare const listUserGithubRepos: (transport: Transport) => Promise<ListUserGithubReposResponse>;
export type GetApiUserKeysResponse = Array<SSHKey>;
/** GET /api/user/keys */
export declare const getApiUserKeys: (transport: Transport) => Promise<GetApiUserKeysResponse>;
export type PostApiUserKeysBody = { key: string; title: string; };
export type PostApiUserKeysResponse = SSHKey;
export interface PostApiUserKeysInput {
    readonly body: PostApiUserKeysBody;
}
/** POST /api/user/keys */
export declare const postApiUserKeys: (transport: Transport, input: PostApiUserKeysInput) => Promise<PostApiUserKeysResponse>;
export type GetApiUserOrgsResponse = AnyJSON;
/** GET /api/user/orgs */
export declare const getApiUserOrgs: (transport: Transport) => Promise<GetApiUserOrgsResponse>;
export type GetApiUserProviderConnectionsResponse = AnyJSON;
/** GET /api/user/provider-connections */
export declare const getApiUserProviderConnections: (transport: Transport) => Promise<GetApiUserProviderConnectionsResponse>;
export type PostApiUserProviderConnectionsResponse = AnyJSON;
/** POST /api/user/provider-connections */
export declare const postApiUserProviderConnections: (transport: Transport) => Promise<PostApiUserProviderConnectionsResponse>;
export type GetApiUserReadableReposResponse = AnyJSON;
/** GET /api/user/readable-repos */
export declare const getApiUserReadableRepos: (transport: Transport) => Promise<GetApiUserReadableReposResponse>;
export type GetApiUserReposResponse = AnyJSON;
/** GET /api/user/repos */
export declare const getApiUserRepos: (transport: Transport) => Promise<GetApiUserReposResponse>;
export type PostApiUserReposResponse = AnyJSON;
/** POST /api/user/repos */
export declare const postApiUserRepos: (transport: Transport) => Promise<PostApiUserReposResponse>;
export type GetApiUserSessionsResponse = AnyJSON;
/** GET /api/user/sessions */
export declare const getApiUserSessions: (transport: Transport) => Promise<GetApiUserSessionsResponse>;
export type GetApiUserSettingsNotificationsResponse = AnyJSON;
/** GET /api/user/settings/notifications */
export declare const getApiUserSettingsNotifications: (transport: Transport) => Promise<GetApiUserSettingsNotificationsResponse>;
export type PutApiUserSettingsNotificationsResponse = AnyJSON;
/** PUT /api/user/settings/notifications */
export declare const putApiUserSettingsNotifications: (transport: Transport) => Promise<PutApiUserSettingsNotificationsResponse>;
export type GetApiUserSettingsSignupResponse = { profile: { account: string; answers: Record<string, Array<string> | string>; name: string; question: number; repo?: string; stage: "done" | "poll" | "ready"; }; updated_at?: string; };
/** GET /api/user/settings/signup */
export declare const getApiUserSettingsSignup: (transport: Transport) => Promise<GetApiUserSettingsSignupResponse>;
export type PutApiUserSettingsSignupBody = { account: string; answers: Record<string, Array<string> | string>; name: string; question: number; repo?: string; stage: "done" | "poll" | "ready"; };
export type PutApiUserSettingsSignupResponse = { profile: { account: string; answers: Record<string, Array<string> | string>; name: string; question: number; repo?: string; stage: "done" | "poll" | "ready"; }; updated_at?: string; };
export interface PutApiUserSettingsSignupInput {
    readonly body: PutApiUserSettingsSignupBody;
}
/** PUT /api/user/settings/signup */
export declare const putApiUserSettingsSignup: (transport: Transport, input: PutApiUserSettingsSignupInput) => Promise<PutApiUserSettingsSignupResponse>;
export type GetApiUserTokensResponse = AnyJSON;
/** GET /api/user/tokens */
export declare const getApiUserTokens: (transport: Transport) => Promise<GetApiUserTokensResponse>;
export type PostApiUserTokensResponse = AnyJSON;
/** POST /api/user/tokens */
export declare const postApiUserTokens: (transport: Transport) => Promise<PostApiUserTokensResponse>;
export type GetApiUserWorkflowRunsActiveCountResponse = AnyJSON;
/** GET /api/user/workflow-runs/active-count */
export declare const getApiUserWorkflowRunsActiveCount: (transport: Transport) => Promise<GetApiUserWorkflowRunsActiveCountResponse>;
export type GetApiUserWorkspacesResponse = AnyJSON;
/** GET /api/user/workspaces */
export declare const getApiUserWorkspaces: (transport: Transport) => Promise<GetApiUserWorkspacesResponse>;
export type PostApiUserEmailsIdVerifyResponse = AnyJSON;
export interface PostApiUserEmailsIdVerifyInput {
    readonly path: { readonly id: string; };
}
/** POST /api/user/emails/{id}/verify */
export declare const postApiUserEmailsIdVerify: (transport: Transport, input: PostApiUserEmailsIdVerifyInput) => Promise<PostApiUserEmailsIdVerifyResponse>;
export type PostApiUserProviderConnectionsIdGrantsResponse = AnyJSON;
export interface PostApiUserProviderConnectionsIdGrantsInput {
    readonly path: { readonly id: string; };
}
/** POST /api/user/provider-connections/{id}/grants */
export declare const postApiUserProviderConnectionsIdGrants: (transport: Transport, input: PostApiUserProviderConnectionsIdGrantsInput) => Promise<PostApiUserProviderConnectionsIdGrantsResponse>;
export type PostApiUserProviderConnectionsIdRefreshResponse = AnyJSON;
export interface PostApiUserProviderConnectionsIdRefreshInput {
    readonly path: { readonly id: string; };
}
/** POST /api/user/provider-connections/{id}/refresh */
export declare const postApiUserProviderConnectionsIdRefresh: (transport: Transport, input: PostApiUserProviderConnectionsIdRefreshInput) => Promise<PostApiUserProviderConnectionsIdRefreshResponse>;
export type PostApiUserProviderConnectionsCodexDeviceBody = AnyJSON;
export type PostApiUserProviderConnectionsCodexDeviceResponse = AnyJSON;
export interface PostApiUserProviderConnectionsCodexDeviceInput {
    readonly body?: PostApiUserProviderConnectionsCodexDeviceBody;
}
/** POST /api/user/provider-connections/codex/device */
export declare const postApiUserProviderConnectionsCodexDevice: (transport: Transport, input?: PostApiUserProviderConnectionsCodexDeviceInput) => Promise<PostApiUserProviderConnectionsCodexDeviceResponse>;
export type PostApiUserProviderConnectionsCodexDeviceIdBody = AnyJSON;
export type PostApiUserProviderConnectionsCodexDeviceIdResponse = AnyJSON;
export interface PostApiUserProviderConnectionsCodexDeviceIdInput {
    readonly path: { readonly id: string; };
    readonly body?: PostApiUserProviderConnectionsCodexDeviceIdBody;
}
/** POST /api/user/provider-connections/codex/device/{id} */
export declare const postApiUserProviderConnectionsCodexDeviceId: (transport: Transport, input: PostApiUserProviderConnectionsCodexDeviceIdInput) => Promise<PostApiUserProviderConnectionsCodexDeviceIdResponse>;
export type PutApiUserProviderConnectionsOrderBody = AnyJSON;
export type PutApiUserProviderConnectionsOrderResponse = AnyJSON;
export interface PutApiUserProviderConnectionsOrderInput {
    readonly body?: PutApiUserProviderConnectionsOrderBody;
}
/** PUT /api/user/provider-connections/order */
export declare const putApiUserProviderConnectionsOrder: (transport: Transport, input?: PutApiUserProviderConnectionsOrderInput) => Promise<PutApiUserProviderConnectionsOrderResponse>;
export type GetApiUsersUsernameResponse = AnyJSON;
export interface GetApiUsersUsernameInput {
    readonly path: { readonly username: string; };
}
/** GET /api/users/{username} */
export declare const getApiUsersUsername: (transport: Transport, input: GetApiUsersUsernameInput) => Promise<GetApiUsersUsernameResponse>;
export type GetApiUsersUsernameActivityResponse = AnyJSON;
export interface GetApiUsersUsernameActivityInput {
    readonly path: { readonly username: string; };
}
/** GET /api/users/{username}/activity */
export declare const getApiUsersUsernameActivity: (transport: Transport, input: GetApiUsersUsernameActivityInput) => Promise<GetApiUsersUsernameActivityResponse>;
export type GetApiUsersUsernameReposResponse = AnyJSON;
export interface GetApiUsersUsernameReposInput {
    readonly path: { readonly username: string; };
}
/** GET /api/users/{username}/repos */
export declare const getApiUsersUsernameRepos: (transport: Transport, input: GetApiUsersUsernameReposInput) => Promise<GetApiUsersUsernameReposResponse>;
export type PostApiV1SseTicketResponse = AnyJSON;
/** POST /api/v1/sse/ticket */
export declare const postApiV1SseTicket: (transport: Transport) => Promise<PostApiV1SseTicketResponse>;
export type PostApiWorkflowProvisionBody = AnyJSON;
export type PostApiWorkflowProvisionResponse = AnyJSON;
export interface PostApiWorkflowProvisionInput {
    readonly body?: PostApiWorkflowProvisionBody;
}
/** POST /api/workflow/provision */
export declare const postApiWorkflowProvision: (transport: Transport, input?: PostApiWorkflowProvisionInput) => Promise<PostApiWorkflowProvisionResponse>;
export type PostApiWorkflowRpcBody = AnyJSON;
export type PostApiWorkflowRpcResponse = AnyJSON;
export interface PostApiWorkflowRpcInput {
    readonly body?: PostApiWorkflowRpcBody;
}
/** POST /api/workflow/rpc */
export declare const postApiWorkflowRpc: (transport: Transport, input?: PostApiWorkflowRpcInput) => Promise<PostApiWorkflowRpcResponse>;