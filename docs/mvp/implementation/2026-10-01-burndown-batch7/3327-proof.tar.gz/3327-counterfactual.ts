import {readFileSync, writeFileSync} from "node:fs"
import {checkRealE2E} from "/private/tmp/smithers-burndown-20260930/apps/app/e2e/real/coverage/gate.ts"
import {UNSCENARIOED_ACTIONS, RELEASE_CRITICAL_ACTIONS} from "/private/tmp/smithers-burndown-20260930/apps/app/e2e/real/coverage/deferrals.ts"
const root="/private/tmp/smithers-burndown-20260930/apps/app"
const dir="/tmp/smithers-burndown-20260930-receipts/runtime-batch5"
const options={realDir:`${root}/e2e/real`,flowNameFile:`${root}/src/mainview/flows/FlowName.ts`,releaseCritical:RELEASE_CRITICAL_ACTIONS}
const current=checkRealE2E({...options,deferred:UNSCENARIOED_ACTIONS})
const families=["branches","commits","files","history","search"]
const removed=[]
for(const family of families){
 const before=await import(`${dir}/3327-before/${family}.ts`)
 const after=await import(`${root}/e2e/real/coverage/deferrals/${family}.ts`)
 const previous=before[family], next=after[family]
 if(next.some(action=>!previous.includes(action)))throw new Error(`Unexpected addition: ${family}`)
 removed.push(...previous.filter(action=>!next.includes(action)))
}
if(removed.length!==12 || current.findings.some(f=>f.code==="stale-deferral"))throw new Error("Unexpected removal/stale inventory")
const evidence=[]
for(const action of removed){
 const scenarios=current.scenarios.filter(s=>s.actions.includes(action))
 if(!scenarios.length)throw new Error(`No scenario: ${action}`)
 const replay=checkRealE2E({...options,deferred:{...UNSCENARIOED_ACTIONS,owed:[...UNSCENARIOED_ACTIONS.owed,action]}})
 const stale=replay.findings.filter(f=>f.code==="stale-deferral")
 if(stale.length!==1 || stale[0].message!==`${action} has a real scenario; delete its deferral`)throw new Error(`Gate did not independently reject restored deferral: ${action}`)
 evidence.push({action,scenarios:scenarios.map(({id,file,line,hosts,completionEvidence})=>({id,file,line,hosts,completionEvidence})),reintroducedDeferralFinding:stale[0]})
}
const restored=checkRealE2E({...options,deferred:{...UNSCENARIOED_ACTIONS,owed:[...UNSCENARIOED_ACTIONS.owed,...removed]}})
if(JSON.stringify(current.gaps)!==JSON.stringify(restored.gaps))throw new Error("Scenario gaps changed with ledger cleanup")
writeFileSync(`${dir}/3327-reconciliation.json`,JSON.stringify({removed,evidence,remainingDeferred:current.deferred,remainingFindings:current.findings,originalLedgerGaps:restored.gaps,originalLedgerFindings:restored.findings,unchangedGaps:true,limit:"Scenario metadata and strict declaration gate only; no deployed/browser scenario execution."},null,2)+"\n")
console.log(JSON.stringify({removed:removed.length,counterfactualsPassed:evidence.length,remainingStaleDeferrals:0}))
