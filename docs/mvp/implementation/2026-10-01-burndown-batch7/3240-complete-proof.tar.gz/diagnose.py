import concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/smithers-burndown-20260930');out=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch5/backend-3240');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=set(subprocess.check_output(['rg','--files','packages/backend'],cwd=root,text=True).splitlines());paths.update(['docs/api/failure-codes.json']);paths={p for p in paths if (root/p).is_file()}
def capture(n):
 d={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(root/p) for p in sorted(paths)}};(out/n).write_text(json.dumps(d,indent=2)+'\n');return d
before=capture('named-inputs-before.json');env=dict(os.environ,SMITHERS_TEST_DATABASE_URL='postgres://williamcory@127.0.0.1:55491/postgres?sslmode=disable',SMITHERS_REQUIRE_DATABASE_TESTS='1',SMITHERS_FFI_LIBRARY_PATH='/Users/williamcory/smithers/target/debug/libsmithers_ffi.dylib');checks=[('named-services','./internal/services','^(TestRuntimeForkLostWorkerKeepsTypedFailureOnRow|TestRuntimeCreateSnapshotLostWorkerIsInfra|TestRepositorySetup.*|TestRepositoryDeletionRemovesSetupRequestsAndSettlesTheirJob|TestInvokedFlowJournalAndFailureReachTheRunLog|TestWorkspaceProviderPoolRotationDoesNotPersistBootAccountModel)$'),('named-db','./internal/db','^(TestWorkflowLogRetention.*|TestWorkflowsSQL_H_.*)$'),('named-routes','./internal/routes','^TestFailureCodes'),('composition-setup','./internal/compose','^TestRepositorySetup')]
def run(c):
 n,p,pattern=c;a=['go','test','-count=1','-json','-timeout=5m',p,'-run',pattern];start=time.monotonic();log=out/(n+'.jsonl')
 with log.open('w') as f:r=subprocess.run(a,cwd=root/'packages/backend',env=env,stdout=f,stderr=subprocess.STDOUT)
 events=[]
 for line in log.read_text().splitlines():
  try:events.append(json.loads(line))
  except json.JSONDecodeError:pass
 d={'name':n,'argv':a,'cwd':str(root/'packages/backend'),'exitCode':r.returncode,'seconds':round(time.monotonic()-start,2),'receipt':str(log),'sha256':sha(log),'passed':[e['Test'] for e in events if e.get('Action')=='pass' and 'Test' in e],'failed':[e['Test'] for e in events if e.get('Action')=='fail' and 'Test' in e],'skipped':[e['Test'] for e in events if e.get('Action')=='skip' and 'Test' in e]};(out/(n+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:result=list(pool.map(run,checks))
after=capture('named-inputs-after.json');(out/'named-result.json').write_text(json.dumps({'checks':result,'checkedCandidate':before['head'],'headAfterChecks':after['head'],'changedDuringChecks':[p for p in paths if before['files'][p]!=after['files'][p]]},indent=2)+'\n')
