import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
const repository = '/private/tmp/smithers-burndown-20260930';
const receipts = '/tmp/smithers-burndown-20260930-receipts/api-batch5/admission-3030';
const host = mkdtempSync('/private/tmp/smithers-retired-burndown-');
const hash = (file) => createHash('sha256').update(readFileSync(file)).digest('hex');
const inputs = ['packages/smithers/src/bin.ts','packages/smithers/src/Command.ts','packages/smithers/src/NodeRegistry.ts','flows/pack.test.mjs','.smithers/factory.json','pnpm-lock.yaml'];
const before = Object.fromEntries(inputs.map(p => [p,hash(join(repository,p))]));
const executions = [];
const env = { PATH:process.env.PATH, HOME:join(host,'home'), TMPDIR:'/private/tmp', XDG_CONFIG_HOME:join(host,'config'), XDG_DATA_HOME:join(host,'data'), XDG_CACHE_HOME:join(host,'cache'), SMITHERS_WORKSPACE_JJ_EXPORT_BINARY:'/Users/williamcory/smithers/target/debug/smithers-jj-export' };
const invoke = (label,args) => {
 const result = spawnSync(process.execPath,['--no-warnings',join(repository,'packages/smithers/src/bin.ts'),...args,'--root',host,'--json'],{cwd:host,env,encoding:'utf8',timeout:60_000,maxBuffer:16*1024*1024});
 writeFileSync(join(receipts,label+'.stdout'),result.stdout??'');writeFileSync(join(receipts,label+'.stderr'),result.stderr??'');
 executions.push({label,args,status:result.status,signal:result.signal,error:result.error?.message});return result;
};
try {
 cpSync(join(repository,'flows'),join(host,'flows'),{recursive:true,filter:p=>!p.split('/').includes('node_modules')});
 symlinkSync(join(repository,'node_modules'),join(host,'node_modules'),'dir');
 mkdirSync(env.HOME);
 const listed = invoke('default-catalog',['ls']);
 assert.equal(listed.status,0,listed.stdout+listed.stderr);
 const document = JSON.parse(listed.stdout);
 const names = document.flows.map(f=>f.name);
 assert.ok(names.includes('create-flow'));assert.ok(names.includes('issue-triage'));
 for (const name of ['burndown','burndown/worker','burndown/monitor']) assert.ok(!names.includes(name),name);
 const refusals = [];
 for (const name of ['burndown','burndown/worker']) {
  const result = invoke(name.replaceAll('/','-')+'-admission',['flow','start',name,'-d']);
  assert.notEqual(result.status,0,result.stdout+result.stderr);
  const error = JSON.parse(result.stdout);
  assert.match(error.message,/not found|unknown flow|no flow|unavailable/i);
  assert.ok(!/body_unavailable|cannot pin|untracked imports/i.test(error.message));
  refusals.push({name,status:result.status,error});
 }
 const runs=[];
 const walk = (dir)=>{if(!existsSync(dir)) return;for(const name of readdirSync(dir,{withFileTypes:true})){const file=join(dir,name.name);if(name.isDirectory())walk(file);else if(name.name.endsWith('.db')||name.name.endsWith('.sqlite')){const db=new DatabaseSync(file,{readOnly:true});try{for(const t of db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND (name='control_runs' OR name='engine_executions')").all()){const row=db.prepare('SELECT count(*) AS count FROM '+t.name).get();assert.equal(row.count,0);runs.push({file:file.slice(host.length+1),table:t.name,count:row.count});}}finally{db.close();}}}};
 walk(join(host,'.flows'));
 assert.ok(!existsSync(join(host,'.git')));assert.ok(!existsSync(join(host,'.jj')));
 const after = Object.fromEntries(inputs.map(p=>[p,hash(join(repository,p))]));assert.deepEqual(after,before);
 const report={node:process.version,host,sourceHashes:before,sourceDrift:false,ordinaryDefaultCatalogCount:names.length,retiredNamesAbsent:['burndown','burndown/worker','burndown/monitor'],refusals,durableRuns:runs,zeroLaunches:true,zeroLanding:true,launchReason:'unknown-flow refusal before any approval or executor',executions};
 writeFileSync(join(receipts,'actual-cli-catalog-result.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({catalog:names.length,refusals:refusals.map(r=>({name:r.name,status:r.status,code:r.error.code})),durableRuns:runs,sourceDrift:false}));
} finally {rmSync(host,{recursive:true,force:true});}
