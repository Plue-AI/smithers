import concurrent.futures,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/smithers-burndown-20260930');out=pathlib.Path(__file__).parent
env=dict(os.environ,PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+os.environ['PATH'],TMPDIR='/private/tmp')
files=subprocess.check_output(['git','ls-files','flows','packages/smithers/flows/patterns','scripts/repo-contract/public-export-maps.test.mjs','scripts/fixtures/public-export-surface.json','pnpm-lock.yaml','packages/repo-targets/scripts/private-effect-adapters.mjs','scripts/private-effect-adapters.test.mjs','scripts/release-consumers.mjs'],cwd=root,text=True).splitlines()
def hashes():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files if (root/p).is_file()}
before={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sources':hashes()};(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
jobs=[
('flows-noemit','flows',['pnpm','exec','tsc','-p','tsconfig.json','--noEmit']),
('flows-calibration','',['node','--test','flows/test/registration-calibration.test.ts']),
('flows-issue-sweep','',['node','--test','flows/issue-sweep/test/accounts.test.ts','flows/issue-sweep/test/decide.test.ts','flows/issue-sweep/test/land.test.ts','flows/issue-sweep/test/work.test.ts']),
('patterns-unit','packages/smithers/flows/patterns',['pnpm','exec','vitest','run','test/Burndown.test.ts','test/Pattern.test.ts','test/WithRetry.test.ts','--coverage.enabled=false']),
('patterns-source-types','packages/smithers/flows/patterns',['pnpm','exec','tsc','-p','tsconfig.json','--noEmit']),
('patterns-test-types','packages/smithers/flows/patterns',['pnpm','exec','tsc','-p','tsconfig.test.json','--noEmit']),
('public-export-gate','',['node','--test','scripts/repo-contract/public-export-maps.test.mjs'])]
def run(job):
 name,cwd,argv=job;start=time.time()
 with (out/(name+'.log')).open('w') as f: result=subprocess.run(argv,cwd=root/cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'cwd':str(root/cwd),'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-start,2)}
 (out/(name+'-result.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(run,jobs))
after=hashes();(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
summary={'head':before['head'],'results':results,'inputDrift':[p for p,h in before['sources'].items() if after.get(p)!=h],'limits':['Focused tests only; coverage disabled, configured thresholds unchanged','No fresh release cohort or actual published consumer claim','No source modifications by API agent']}
summary['receipts']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.glob('*')) if p.is_file()}
(out/'checkpoint-evidence.json').write_text(json.dumps(summary,indent=2)+'\n');print('manifestSHA256',hashlib.sha256((out/'checkpoint-evidence.json').read_bytes()).hexdigest(),flush=True)
