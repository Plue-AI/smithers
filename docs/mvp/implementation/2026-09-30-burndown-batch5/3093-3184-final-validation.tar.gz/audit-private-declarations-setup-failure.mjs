import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {dirname,join,relative,resolve} from 'node:path';
import {createHash} from 'node:crypto';
const root='/private/tmp/smithers-burndown-20260930',base='/tmp/smithers-burndown-20260930-receipts/api-batch3/final-cohort-be30bf194f';
const req=createRequire(root+'/package.json'),ts=req('typescript'),sha=b=>createHash('sha256').update(b).digest('hex');
const inventory=JSON.parse(fs.readFileSync(base+'/canonical50-artifact-inventory.json')),surface=JSON.parse(fs.readFileSync(base+'/actual-api-surface.json')).packages;
const files=inventory.declarations.filter(f=>f.path.includes('/dist/vendor/'));
const keys={'node':'@effect/platform-node','node-shared':'@effect/platform-node-shared','bun':'@effect/platform-bun'};
const within=(dir,file)=>{const part=relative(dir,file);return part!== '..'&&!part.startsWith('../')&&!part.startsWith('/')};
const adapterId=(path)=>{if(path.startsWith('cjs/'))path=path.slice(4);for(const [key,name]of Object.entries(keys)){if(path===`platform-${key}.js`)return `${name}/index.js`;if(path.startsWith(key+'/'))return name+'/'+path.slice(key.length+1);}throw Error('Unrecognized private reference '+path)};
const parse=(text)=>{const ast=ts.createSourceFile('audit.d.ts',text,ts.ScriptTarget.Latest,true);assert.equal(ast.parseDiagnostics.length,0);return ast};
function normalize(text,origin,namespaceException){
 const ast=parse(text),edits=[];
 const visit=node=>{let literal;if(ts.isImportDeclaration(node)||ts.isExportDeclaration(node))literal=node.moduleSpecifier;else if(ts.isImportTypeNode(node)&&ts.isLiteralTypeNode(node.argument))literal=node.argument.literal;
  if(literal&&ts.isStringLiteral(literal)){let value=literal.text;
   if(value.startsWith('.')){
    const selected=resolve(dirname(origin.file),value);
    if(origin.kind==='upstream'){assert.ok(within(origin.dist,selected),'Upstream reference escape');value=origin.name+'/'+relative(origin.dist,selected)}
    else {assert.ok(within(origin.vendor,selected),'Private reference escape');value=adapterId(relative(origin.vendor,selected))}
   }else if(value.startsWith('@effect/platform-')){const name=Object.values(keys).find(n=>value===n||value.startsWith(n+'/'));assert.ok(name,'Unexpected adapter');value=value===name?name+'/index.js':value+'.js'}
   edits.push([literal.getStart(ast),literal.end,JSON.stringify(value)]);
  }
  ts.forEachChild(node,visit)
 };visit(ast);
 if(namespaceException){
  const imports=ast.statements.filter(n=>ts.isImportDeclaration(n)&&ts.isStringLiteral(n.moduleSpecifier)&&n.moduleSpecifier.text==='ws'&&n.importClause?.namedBindings&&ts.isNamespaceImport(n.importClause.namedBindings));
  assert.equal(imports.length,1);const node=imports[0],alias=node.importClause.namedBindings.name.text;assert.equal(alias,'NodeWS');
  const idx=ast.statements.indexOf(node),next=ast.statements[idx+1];assert.ok(ts.isExportDeclaration(next)&&!next.moduleSpecifier&&next.exportClause&&ts.isNamedExports(next.exportClause));assert.equal(next.exportClause.elements.length,1);assert.equal(next.exportClause.elements[0].name.text,alias);assert.equal(next.exportClause.elements[0].propertyName,undefined);
  const start=node.getStart(ast),end=next.end;
  for(let i=edits.length-1;i>=0;i--)if(edits[i][0]>=start&&edits[i][1]<=end)edits.splice(i,1);
  edits.push([start,end,`export * as ${alias} from "ws";`]);
 }
 for(const [start,end,value]of edits.sort((a,b)=>b[0]-a[0]))text=text.slice(0,start)+value+text.slice(end);
 return text
}
const rows=[],inputRows=[],namespaceExceptions=[];
for(const [owner,pkg] of Object.entries(surface)){
 const privateFiles=files.filter(f=>f.path.startsWith(pkg.dir+'/dist/vendor/'));if(!privateFiles.length)continue;
 const vendor=join(base,'retained-canonical-output',pkg.dir,'dist/vendor'),ownerReq=createRequire(join(root,pkg.dir,'package.json'));const receipt=JSON.parse(fs.readFileSync(join(vendor,'adapters.json')));assert.equal(receipt.version,'4.0.0-rc.115');
 const inputRoots=new Map();
 for(const input of receipt.inputs){let upstream=inputRoots.get(input.name);if(!upstream){const manifest=ownerReq.resolve(input.name+'/package.json');upstream=dirname(manifest);inputRoots.set(input.name,upstream);assert.equal(JSON.parse(fs.readFileSync(manifest)).version,'4.0.0-rc.115')}
  const bytes=fs.readFileSync(join(upstream,input.path));assert.equal(sha(bytes),input.sha256);inputRows.push({owner,name:input.name,path:input.path,sha256:input.sha256})
 }
 for(const file of privateFiles){
  let path=relative(vendor,join(base,'retained-canonical-output',file.path)),branch='esm';if(path.startsWith('cjs/')){branch='cjs';path=path.slice(4)}
  let key,sourcePath;
  if(path.startsWith('platform-')){key=path.slice('platform-'.length,-'.d.ts'.length);sourcePath='index.d.ts'}else{key=path.split('/')[0];sourcePath=path.slice(key.length+1)}
  const name=keys[key];assert.ok(name);const dist=join(inputRoots.get(name),'dist'),source=join(dist,sourcePath),target=join(vendor,branch==='cjs'?'cjs':'',path),oldText=fs.readFileSync(source,'utf8'),newText=fs.readFileSync(target,'utf8');
  const exception=branch==='cjs'&&name==='@effect/platform-node-shared'&&sourcePath==='NodeSocket.d.ts';
  assert.equal(normalize(newText,{kind:'private',file:target,vendor},exception),normalize(oldText,{kind:'upstream',file:source,dist,name},false),owner+' '+path+' declaration differs beyond approved module-reference relocation / NodeWS namespace correction');
  rows.push({owner,file:file.path,source,sourceSha256:sha(Buffer.from(oldText)),emittedSha256:file.sha256,moduleReferenceRelocationOnly:!exception,cjsNamespaceException:exception});if(exception)namespaceExceptions.push({owner,file:file.path,binding:'NodeWS',upstream:'export * as NodeWS from "ws";',emitted:'import * as NodeWS from "ws"; export { NodeWS };'})
 }
}
assert.equal(rows.length,848);assert.equal(namespaceExceptions.length,8);
const result={head:inventory.head,passed:true,privateDeclarationCount:rows.length,owners:new Set(rows.map(x=>x.owner)).size,pinnedInputIdentitiesVerified:inputRows.length,namespaceExceptionCount:namespaceExceptions.length,namespaceExceptions,method:'Independent TypeScript AST module-reference normalization and exact remaining text comparison against actual owner-resolved rc.115 upstream bytes; no shared-producer rewrite invoked. All adapter input/license hashes independently rechecked.',rows,inputRows};
fs.writeFileSync(base+'/private-declaration-upstream-audit.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({passed:true,privateDeclarations:rows.length,owners:result.owners,inputs:inputRows.length,namespaceExceptions:namespaceExceptions.length}));
