import subprocess,os,sys,json,time,signal,hashlib
from pathlib import Path
b=Path(__file__).parent; root=Path('/private/tmp/smithers-burndown-20260930'); cwd=root/'packages/smithers'
lane=sys.argv[1]; env=os.environ.copy(); env.update(PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+env['PATH'], TMPDIR='/private/tmp', SMITHERS_JJ_EXPORT_HELPER='/Users/williamcory/smithers/target/release/smithers-jj-export')
if lane=='focused':
 cmd=['pnpm','exec','vitest','run','--config','vitest.config.ts','--environment','node','--coverage.enabled=false','--maxWorkers=1','--reporter=verbose','--reporter=json','--outputFile='+str(b/'3020-focused.json'),'test/BackendWorkspaceShell.test.ts','test/BackendCopy.test.ts','test/BackendWorkspace.test.ts','test/BackendProcess.test.ts']; bound=180
elif lane=='types-source': cmd=['pnpm','exec','tsc','-p','tsconfig.json','--noEmit']; bound=180
elif lane=='types-tests': cmd=['pnpm','exec','tsc','-p','tsconfig.test.json','--noEmit']; bound=180
elif lane=='broad':
 files=sorted(str(p.relative_to(cwd)) for p in (cwd/'test').glob('Backend*.test.ts'))+['test/Presentation.test.ts','test/Rendering.test.ts']
 (b/'3020-broad-selector.json').write_text(json.dumps({'files':files,'sha256':{f:hashlib.sha256((cwd/f).read_bytes()).hexdigest() for f in files}},indent=2)+'\n')
 cmd=['pnpm','exec','vitest','run','--config','vitest.config.ts','--environment','node','--coverage.enabled=false','--maxWorkers=1','--reporter=verbose','--reporter=json','--outputFile='+str(b/'3020-broad.json')]+files; bound=600
else: raise SystemExit('unknown lane')
started=time.monotonic(); timedout=False
with (b/('3020-'+lane+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try: code=p.wait(timeout=bound)
 except subprocess.TimeoutExpired:
  timedout=True; os.killpg(p.pid,signal.SIGTERM)
  try: p.wait(timeout=10)
  except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);p.wait()
  code=124
receipt={'lane':lane,'command':cmd,'cwd':str(cwd),'outerBoundSeconds':bound,'elapsedSeconds':round(time.monotonic()-started,3),'exit':code,'timedOut':timedout,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(b/('3020-'+lane+'-command.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(code)
