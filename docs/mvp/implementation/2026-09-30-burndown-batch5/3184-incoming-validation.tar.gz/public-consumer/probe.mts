import assert from "node:assert/strict"
import * as Action from "@smthrs/flow/Action"
import * as Burndown from "@smthrs/patterns/Burndown"
import { Deferred, Effect, Exit, Fiber } from "effect"

const duplicate = new Action.DuplicateImplementation({ name: "public/probe" })
const message: string = duplicate.message
assert.equal(duplicate.name, "public/probe")
assert.equal(message, 'Action "public/probe" already has an implementation in this registry; provide its layer once, or pass override: true to replace it')
assert.ok(String(duplicate).includes(message))
type IsAny<T> = 0 extends (1 & T) ? true : false
const messageNotAny: IsAny<typeof duplicate.message> = false
const resultNotAny: IsAny<ReturnType<typeof Burndown.round>> = false
assert.equal(messageNotAny, false); assert.equal(resultNotAny, false)

const released: string[] = []
const options: Burndown.RoundOptions<undefined, { id: string }, string, never, never, { commitId: string }> = {
  key: "public", concurrency: 2,
  claim: () => Effect.void,
  work: ({ item }) => item.id === "cancelled-child" ? Effect.interrupt : Effect.succeed(item.id),
  land: ({ output }) => Effect.succeed({ commitId: "landed-" + output }),
  detail: (output, landing) => output + ":" + landing?.commitId,
  release: ({ item, status, detail }) => Effect.sync(() => { const typedDetail: string = detail; released.push(item.id + ":" + status + ":" + typedDetail) })
}
const result = await Effect.runPromise(Burndown.round({ input: undefined, round: 0, items: [{ id: "cancelled-child" }, { id: "peer" }] }, options))
assert.deepEqual(result.rows, [{ id: "cancelled-child", status: "failed", detail: "work: interrupted" }, { id: "peer", status: "landed", detail: "peer:landed-peer" }])
assert.deepEqual(released, ["cancelled-child:failed:work: interrupted", "peer:landed:peer:landed-peer"])
const cancelledReleases: string[] = []
const cancelled = await Effect.runPromise(Effect.gen(function* () {
  const entered = yield* Deferred.make<void>()
  const running = yield* Effect.forkChild(Burndown.round({ input: undefined, round: 0, items: [{ id: "outer" }] }, {
    ...options,
    work: () => Deferred.succeed(entered, undefined).pipe(Effect.andThen(Effect.never)),
    release: ({ status }) => Effect.sync(() => { cancelledReleases.push(status) })
  }))
  yield* Deferred.await(entered)
  yield* Fiber.interrupt(running)
  return yield* Fiber.await(running)
}))
assert.ok(Exit.hasInterrupts(cancelled))
assert.deepEqual(cancelledReleases, ["failed"])
console.log(JSON.stringify({ publicDevelopmentImports: ["@smthrs/flow/Action", "@smthrs/patterns/Burndown"], duplicateMessage: message, interruptionRows: result.rows, parentInterruptionPreserved: true, typedLandingAndReleaseDetail: true, negativeAnyControls: true }))
