Read-only declaration review for #3184

Fourteen requested package groups; 71 changed/new captured compiler declaration entries. Read-only review; no source or baseline edits.

Captured source: ed02fdb594cfb1f9aa537c11f563b89812bd1136; source-history anchor: 3017c54ddf6d2d12db78d284137b84cb6839fc41.
Fresh bytes for all 71 inventory entries were rehashed successfully. Authenticated old changed text exists only for @smthrs/journal/JournalEvent.d.ts; the other packages use actual fresh DTS and explicit source-history comparisons.

Required migration: DurableEngineState implementations must include completion digests, return boolean from consumeDeferred and ClockRow[] from completeRunClocks. These are actual source-level changes, so an additive-only compatibility claim would be incorrect.

@smthrs/capability
Capability.format accepts Action | PatternAction and returns string. CapabilitySet exposes fromGroups, within and attenuateGroups. New public InvalidCapabilityAction is a YieldableError with invalid_capability_action code.
Authority intersections/attenuation remain explicit; invalid capability input must be handled as a typed failure. These source files did not change between the captured anchor and cohort; declaration hash drift alone does not prove a signature change.

@smthrs/database
DurableWriter.Service.write<A,E,R> preserves A/R and maps SqlError to DatabaseError. afterCommit returns Effect<boolean>. NodeDatabaseOptions keeps filename, optional mode/busyTimeout/sqlite/readOnly. NodeDatabase.postgresLocation(filename) returns {url,schema} | undefined.
postgresLocation is an additive source-history export. Read-only busy timeout is documented as 1 second, writer default zero. Low-level consumers should handle DatabaseError codes busy/constraint/io/schema/unsupported/unknown; no evidence that all changed hashes are breaking.

@smthrs/engine-store
New declaration cohort includes ReplayOnly, DeferredClockFold and StepCacheFold. ReplayOnly.observe receives replayed/resumes/would-execute dispatches; WouldExecute records runId/stepKeyDigest/attempt/action. DeferredClockFold exposes digest-aware capture/checkpointState/rebuild, typed FoldIncomplete, and SqlClient/Journal/DurableWriter requirements. StepCacheFold rebuild is journal-reference-based.
Verified source-history breaking service-shape changes: CompleteDeferredOutcome.Completed and Existing now require digest:{exit:string,metadata:string|null}; consumeDeferred returns Effect<boolean>, not Effect<void>; completeRunClocks returns Effect<ReadonlyArray<ClockRow>>, not Effect<void>. Custom implementations and mocks returning void must migrate. Clock/deferred completion and consumption journal events and migration 0009 carry durable provenance; do not bypass the supplied migration or treat unjoined snapshots as complete.

@smthrs/flow
Deadline exports start, bound, within and remainingMs using Duration.Input and LineageDeadline {startedAtMs,deadlineMs}. FlowHandoff carries optional deadline/capabilityCeilings; FlowInstance optional lineageDeadline. DeadlineExceeded retains flow/execution/timing identity.
Document whole-run lineage deadline semantics and cancellation of attached descendants. New Deadline operations may require FlowInstance/FlowRuntime/Crypto composition. This review does not infer earlier declarations from absent authenticated old text or assert runtime parity solely from declarations.

@smthrs/integrations
Slack IssuePost/Update/Delete/React/Reconcile remain canonical Flow/action declarations. Reconciliation distinguishes found, absent and inconclusive, with bounded search options. Catchup/run expose typed IntegrationError | UnknownError.
Callers must retain inconclusive rather than treating bounded search as proven absence of an ambiguous write. Captured source history shows no corresponding source delta; no hosted Slack/provider qualification is claimed.

@smthrs/jj
Changed declaration is internal/JjInternalFault: typed YieldableError class with reactor/metadata/wasi/lock-timeout fault codes.
An internal fault export is not a new supported public subpath. Native/WASM compatibility is outside this declaration review and must use separately retained ABI qualification.

@smthrs/journal
Consensus.Service provides claim/activate/heartbeat/release/steal/recover/guard, typed outcome/refusal reasons and fenced LivenessEvidence. SqlConsensus.make/layer require SqlClient + DurableWriter. SqlJournal.make/layerWith require Consensus; normal SqlJournal.layer composes it internally. JournalEvent adds companionPrefix, contentDigest, companionRunId and isCompanionRunId. RedactionDepthError is typed depth_exceeded.
One changed declaration has authenticated old text: JournalEvent.d.ts. Comparison after comments are removed shows existing event fields/brands retained with property-order reflow and four additive companion/digest exports. Low-level custom SQL composition must provide canonical Consensus; depth failures should be handled by code. Other changed journal declarations lack authenticated old text; these are current contracts, not an asserted historical binary comparison.

@smthrs/observability
OtlpOptions requires baseUrl with optional headers/interval. layer has InvalidResourceConfiguration | InvalidExporterEndpoint errors; Fetch variants eliminate the HttpClient requirement. defaultServiceVersion is the literal 1.0.0-rc.1.
Endpoint/configuration errors stay explicit. The literal default is reported from actual captured text, with no old-declaration literal-compatibility assertion or live collector proof.

@smthrs/run-store
Ownership owner/liveness identities come from canonical journal consensus. RunStore.make and layerWith require Consensus + DurableWriter + SqlClient; ordinary layer supplies consensus. Public recovery/claim outcomes preserve typed fences and evidence.
Custom low-level compositions must install canonical consensus and preserve rejection handling; the default SQL layer retains its two-service external composition. Ownership timing behavior is backed by separate lease receipts, not inferred from DTS.

@smthrs/std
TestRun structured outcomes expose invalidProbe (unknown command/test/path/module/environment), bounded tail truncation and dropped bytes, and baseline introduced/preexisting/fixed comparisons. Runner options include root/container/env/baseRef/baseline/timeout.
Consumers matching outcomes must retain invalid probes and truncation metadata. The authoring wrapper remains lowered into canonical Flow with FlowActionRequirement; no second flow model or new production source change is claimed from baseline hash drift.

@smthrs/step-cache
CacheStore.sweepExpired accepts optional canReclaimRecorded reference predicate returning Effect<boolean,CacheStoreError>. rebuildHeads consumes Iterable<RecordedRef> and needs SQL + DurableWriter.
Durable reference ownership must gate reclamation. These signatures do not establish default cache eligibility or permit bypass of incomplete cache identities.

@smthrs/targets
ExecSandbox forwards canonical ProcessSandbox types, selection and enforceability, including Unenforceable refusals. Input accepts AbortSignal and bounded scan/digest options. Install exposes pinned pnpm versions 11.21.0/11.25.0, typed runtime/package-manager/manifest/lock/workspace handling. FactoryOptions has required summary and optional flows/on/github/machine/issueViews; policy/rule options preserve tagged declaration/projection validation. LlmLint review/promptEngine use explicit workspaceRoot, seat/transport/model, required/budget/security/context inputs; reports preserve completed/refused/incomplete and bounded coverage/missingContext. Outward.refuse returns missing_secret/approval_unsatisfied.
Configured reviewer engine/model choices remain product policy; no local mandatory Fable requirement is reintroduced. Existing tool-free/seat/CLI transport identity and incomplete-review outcomes must remain visible. Package-manager and runtime literals need release documentation and actual consumer validation separately; declarations alone are not installation or cross-platform execution proof.

@smthrs/testing
TestHost includes canonical Kernel.ProcessConfinement; HostBundle includes FileSystem/Path/ProcessSpawner/Jj/HttpClient, and hostSuite shell execution uses ChildProcess.Command interruption.
Custom test-host bundles must provide confinement and declared services. This review retains the fresh compiler-produced contract and does not revive retired ProcessConfinement adapters or claim old DTS equality.

@smthrs/time-travel
Snapshot optionally records operationId/planDigest. ForkOptions adds optional rebind(childRunId)->Effect<Rebinding,TimeTravelError>; createFork extends its existing four parameters with optional rebinding. CarriedChild names from/to and optional payload. Memory JournalRecord adds optional emittedAtMs.
Source history verifies optional argument/field additions rather than mandatory custom Service methods. Existing calls retain their original arity. Rebinding must preserve parent history, child ancestry and cut-time restrictions; new callbacks must return typed TimeTravelError. Actual fork behavior/VM/provider compatibility remains separately qualified.

Release notes required
- DurableEngineState custom implementations must return boolean from consumeDeferred, ClockRow[] from completeRunClocks, and include DeferredDigest in Completed/Existing outcomes. This is a real source-level migration, not additive-only compatibility.
- Document DeferredClockFold/StepCacheFold journal provenance, new durable completion/consumption facts and migration 0009; ReplayOnly refuses would-execute actions.
- Document canonical Consensus/SqlConsensus composition for low-level SqlJournal/RunStore factories and explicit fencing/refusal outcomes.
- Document inherited Deadline authority and optional TimeTravel rebind/carried-child behavior.
- Document typed diagnostic depth failure, invalid capability/probe/refusal/incomplete states and supported pinned install toolchain choices.

Limits
- Fresh declaration review is not a published-consumer/runtime qualification; use the separately executed canonical compiler, packed manifests and consumer receipts.
- No missing old declarations were reconstructed, guessed or substituted from hash-mismatched prior archives. Source-history equality cannot establish compiler-output compatibility.
- No source, declaration baseline, generated file, Git state or issue modified. Review applies to retained ed02 canonical output; parent owns current-source/build-input equivalence and release cohort acceptance.
- Large schema expansions were reviewed via actual captured declaration text and compact comment-only stripped text, with focused inspection of public option/error/Effect signatures; no automatic blanket semantic-compatibility assertion.
