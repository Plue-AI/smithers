const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const { createRequire } = require('node:module');
const root = '/private/tmp/smithers-burndown-20260930';
const out = '/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2';
const app = path.join(root, 'apps/app');
const appRequire = createRequire(path.join(app, 'package.json'));
const tsPath = appRequire.resolve('typescript');
const ts = appRequire('typescript');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const normalize = file => path.resolve(file);
const relative = file => path.relative(root, file);
const reference = cp.execFileSync('git', ['rev-parse', 'a9484f39a0'], { cwd: root, encoding: 'utf8' }).trim();
const own = JSON.parse(fs.readFileSync(path.join(out, '3264-final-ready.json'), 'utf8')).ownedPaths;
const fresh = path.join(root, 'apps/app/src/mainview/state/EgressRequests.test.ts');
const baseline = new Map();
const overlayInputs = own.filter(row => path.join(root, row.path) !== fresh).map(row => {
  const text = cp.execFileSync('git', ['show', `${reference}:${row.path}`], { cwd: root, encoding: 'utf8' });
  baseline.set(path.join(root, row.path), text);
  return { path: row.path, baselineSha256: hash(text), currentSha256: hash(fs.readFileSync(path.join(root, row.path))) };
});
const cache = new Map();
const readFile = file => {
  file = normalize(file);
  if (!cache.has(file)) cache.set(file, ts.sys.readFile(file));
  return cache.get(file);
};
const parsed = ts.getParsedCommandLineOfConfigFile(path.join(app, 'tsconfig.json'), {}, {
  ...ts.sys, readFile, onUnRecoverableConfigFileDiagnostic: d => { throw new Error(ts.flattenDiagnosticMessageText(d.messageText, '\n')); }
});
if (!parsed) throw new Error('config parse refused');
const sourceInputs = new Map();
function run(isBaseline) {
  const host = ts.createCompilerHost(parsed.options, true);
  host.readFile = file => isBaseline && baseline.has(normalize(file)) ? baseline.get(normalize(file)) : readFile(file);
  host.getSourceFile = (file, languageVersion, onError) => {
    try {
      const text = host.readFile(file);
      if (text === undefined) return undefined;
      sourceInputs.set(normalize(file), hash(readFile(file)));
      return ts.createSourceFile(file, text, languageVersion, true);
    } catch (error) { if (onError) onError(String(error)); return undefined; }
  };
  host.writeFile = () => { throw new Error('Read-only proof forbids emission'); };
  const names = isBaseline ? parsed.fileNames.filter(file => normalize(file) !== fresh) : parsed.fileNames;
  const program = ts.createProgram({ rootNames: names, options: parsed.options, projectReferences: parsed.projectReferences, host });
  const diagnostics = [...parsed.errors, ...ts.getPreEmitDiagnostics(program)].map(d => ({
    path: d.file ? relative(normalize(d.file.fileName)) : null,
    code: d.code, category: d.category, start: d.start ?? null, length: d.length ?? null,
    message: ts.flattenDiagnosticMessageText(d.messageText, '\n')
  })).sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  return { rootCount: names.length, sourceCount: program.getSourceFiles().length, diagnostics };
}
const started = new Date().toISOString();
const current = run(false);
const prior = run(true);
const asSet = rows => new Set(rows.map(row => JSON.stringify(row)));
const currentSet = asSet(current.diagnostics), priorSet = asSet(prior.diagnostics);
const added = [...currentSet].filter(row => !priorSet.has(row)).map(JSON.parse);
const removed = [...priorSet].filter(row => !currentSet.has(row)).map(JSON.parse);
const diskDrift = [...cache].filter(([file, text]) => ts.sys.readFile(file) !== text).map(([file]) => relative(file));
const configs = [...cache].filter(([file]) => /(?:tsconfig[^/]*|package)\.json$/.test(file) && file.startsWith(root)).map(([file,text]) => ({ path: relative(file), sha256: text === undefined ? null : hash(text) }));
const result = {
  reference, currentHeadAtFinish: cp.execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  started, finished: new Date().toISOString(), compiler: { version: ts.version, path: fs.realpathSync(tsPath), sha256: hash(fs.readFileSync(tsPath)) },
  method: 'Actual installed TypeScript Compiler API; same current parsed config/options/rootnames and cached disk inputs for both programs. Baseline overlays exactly eight tracked file texts from explicit reference and omits only the newly authored EgressRequests.test.ts root. No emit, source changes, assertions/casts, options changes or dependency copies.',
  options: parsed.options, configuredSkipLibCheck: parsed.options.skipLibCheck,
  skipLibCheckQualification: 'Existing apps/app/tsconfig.json has skipLibCheck:true. This proof does not add or modify it; it compares the actual full owning gate configuration.',
  overlayInputs, omittedBaselineRoot: relative(fresh), current, baseline: prior,
  addedDiagnostics: added, removedDiagnostics: removed, equal: added.length === 0 && removed.length === 0,
  diskDrift, configs, sourceInputs: [...sourceInputs].map(([file,sha256]) => ({ path: relative(file), sha256 }))
};
const target = path.join(out, '3264-type-overlay-proof.json');
fs.writeFileSync(target, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ result: target, sha256: hash(fs.readFileSync(target)), compiler: ts.version, current: current.diagnostics.length, baseline: prior.diagnostics.length, added: added.length, removed: removed.length, diskDrift, seconds: (Date.parse(result.finished)-Date.parse(started))/1000 }, null, 2));
process.exitCode = added.length || removed.length || diskDrift.length ? 1 : 0;
