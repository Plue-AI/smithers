/**
 * The authoring surface for a model-backed step.
 *
 * `packages/smithers/flows/flow/src/Graph.ts` records the decision this module is built on:
 * the model-shaped `Dynamic` node did not come across, because **a model call
 * is an ordinary action**. That decision is right and it left a hole. The
 * runtime to run one already existed — {@link module:Agent} assembles the whole
 * cell loop and returns its `Stream<AgentEvent>` — but the only ways to reach it
 * were a markdown flow run whole by {@link module:AgentSession}, where the agent
 * *is* the flow, or a hand-registered flow body at a composition root. Neither
 * is something a workflow author can write as one step among other steps.
 *
 * {@link make} is that missing constructor. It declares an ordinary
 * `Action` — same tag, same payload schema, same `.call()`, same plan node,
 * same durable replay — and ships the implementation with it: seat, system
 * teaching, a prompt built from the step payload, and a declared output schema
 * that the answer must satisfy. Nothing about the graph changes; what changes
 * is that the author no longer supplies the implementation, because a model
 * call has exactly one.
 *
 * Structured output is enforced at this boundary by
 * `@smthrs/harness/StructuredOutput`, whose own module documentation states
 * the recovery contract: the declared schema is rendered
 * into the run's system teaching, every `complete` transition's `output` is
 * decoded by it, and a decode miss spends a correction slot on handing the
 * answer back to the same session, or on a fresh-session re-prompt when that
 * session has no frame left, before it becomes a typed
 * `StructuredOutputFailure`.
 *
 * The host half is two services. {@link Host} carries the registry, the sandbox
 * budget, and the catalog every model-backed action in a composition shares;
 * `SeatResolver` turns the declared seat string into a live model. An author's
 * declaration therefore names no model credentials and no host wiring, and a
 * test swaps the whole model for a scripted one by providing a different
 * `SeatResolver`.
 *
 * Reference consulted: `reference/effect`
 * `packages/effect/src/unstable/ai/LanguageModel.ts` (`generateObject`) for the
 * declare-schema / decode-with-typed-failure shape, and `reference/opencode`
 * `packages/llm` for keeping provider resolution behind a host-supplied seam
 * rather than in the authoring call. Deviation from effect: `generateObject`
 * sends the schema as a provider `responseFormat`; `@smthrs/model` has no such
 * request field and the cell loop's answer is a `Cell.Complete` string, so the
 * schema travels in the prompt and is enforced locally.
 *
 * @since 0.1.0
 */
import type * as Capability from "@smthrs/capability/Capability";
import { Action, type Flow, FlowRuntime } from "@smthrs/flow";
import type * as CellCalls from "@smthrs/harness/CellCalls";
import type * as FlowBinding from "@smthrs/harness/FlowBinding";
import { HarnessError } from "@smthrs/harness/HarnessError";
import type * as Sandbox from "@smthrs/harness/Sandbox";
import type * as Steering from "@smthrs/harness/Steering";
import * as StructuredOutput from "@smthrs/harness/StructuredOutput";
import type * as MemorySnapshot from "@smthrs/memory/SnapshotRecorder";
import type * as Evaluator from "@smthrs/model/Evaluator";
import type * as Model from "@smthrs/model/Model";
import type * as ModelRequest from "@smthrs/model/ModelRequest";
import type { FlowsHooks, PluginInput } from "@smthrs/plugin";
import type { FlowsConfig } from "@smthrs/plugin/Config";
import { PluginError } from "@smthrs/plugin/PluginError";
import { ModelSelection } from "@smthrs/registry/Descriptor";
import type * as Registry from "@smthrs/registry/Registry";
import * as Context from "effect/Context";
import type * as Crypto from "effect/Crypto";
import * as Layer from "effect/Layer";
import type * as Schedule from "effect/Schedule";
import * as Schema from "effect/Schema";
import { Agent, type Options as AgentOptions } from "./Agent.ts";
import * as Budget from "./Budget.ts";
import * as QuotaPolicy from "./QuotaPolicy.ts";
import * as Seat from "./Seat.ts";
import { SeatResolver } from "./SeatResolver.ts";
import * as SeatRouter from "./SeatRouter.ts";
/**
 * The host composition every model-backed action in a run shares.
 *
 * This is half of the seam a test replaces: an in-memory registry here and a
 * scripted `Model` behind `SeatResolver` are the whole difference between a
 * deterministic run and a live one. Nothing here is declared by the author, and
 * nothing the author declares can widen it — the capability envelope and the
 * executable catalog are the host's.
 *
 * @category models
 * @since 0.1.0
 */
export interface Host {
    /** Workspace instruction files judged for each action's own task. */
    readonly instructions?: AgentOptions["instructions"];
    /** Flow sources always visible to a judged action. */
    readonly pinnedSources?: AgentOptions["pinnedSources"];
    /** The catalog a cell is shown and the registry its calls resolve against. */
    readonly registry: Registry.Registry;
    /** The explicit sandbox budget every cell runs under. Never unlimited. */
    readonly limits: Sandbox.Limits;
    /** Wall-clock limit for one model call, supplied by the host. */
    readonly modelCallMs?: number | undefined;
    /** Host executable-flow sources composed into every run's catalog. */
    readonly flows?: ReadonlyArray<FlowBinding.Source> | undefined;
    /** Host implementations for module-backed flows, keyed by flow name. */
    readonly implementations?: ReadonlyMap<string, CellCalls.Implementation> | undefined;
    /** Runs rendered markdown children; the host closes over their runtime dependencies. */
    readonly promptRunner?: CellCalls.PromptRunner | undefined;
    readonly plugins?: PluginInput<FlowsHooks> | undefined;
    readonly config?: FlowsConfig | undefined;
    /** Stable system teaching placed ahead of every action's own. */
    readonly system?: ReadonlyArray<string> | undefined;
    readonly capabilityEnvelope?: ReadonlyArray<Capability.CapabilityPattern> | undefined;
    readonly maxFrames?: number | undefined;
    /**
     * Forwarded to `Agent.Options.claimCap`.
     *
     * Zero disarms the completion claim brake for actions whose completions are
     * answers rather than workspace claims.
     */
    readonly claimCap?: number | undefined;
    /** Whether this host can answer a parked agent step. Unattended hosts default to false. */
    readonly approvalChannel?: boolean | undefined;
    /**
     * Provider-run tools every model call of an action may use, such as the
     * provider's own web search. Forwarded to `Agent.Options.serverTools`.
     */
    readonly serverTools?: ReadonlyArray<ModelRequest.ServerTool> | undefined;
    /**
     * How many times a decode miss may be re-prompted when an action declares no
     * budget of its own.
     *
     * This is the composition-wide default the old engine spelled
     * `maxSchemaRetries`: one number an operator raises for a whole run rather
     * than editing every declaration. {@link Options.corrections} always wins,
     * including when it is zero, so a step that has declared a first miss
     * terminal stays terminal under a generous host. Omitting both leaves the
     * budget at one.
     */
    readonly defaultCorrections?: number | undefined;
    /**
     * Overrides the bounded transport retry schedule at the model boundary for
     * every model-backed action in this composition.
     *
     * Forwarded to `Agent.Options.modelRetryPolicy`. A host that classifies its
     * own quota parks (see {@link module:QuotaPolicy}) sets this to keep the
     * transport ladder from spending a run's wall clock on a refusal a park will
     * wait out properly.
     */
    readonly modelRetryPolicy?: Schedule.Schedule<unknown, Model.ModelFailure> | undefined;
    /**
     * How many times one ask may park on a quota refusal before the refusal is
     * reported.
     *
     * Defaults to {@link module:QuotaPolicy.defaultMaxParks}. The bound is per
     * ask: a step that parks, answers, and is then corrected starts its next ask
     * with a full allowance, because the correction is a different question.
     */
    readonly maxQuotaParks?: number | undefined;
    /**
     * Whether the host's `Evaluator` is a real judge. Forwarded to each step's
     * `Agent.Options.judged`, so every subagent is armed on its own session.
     */
    readonly judged?: boolean | undefined;
    /**
     * What each step's supervisor may do: its memory bank, whether it writes,
     * its monitors and its stance. Forwarded to each step's
     * `Agent.Options.supervisor`, so a subagent recalls from the run's bank and
     * is taught the operator's stance.
     */
    readonly supervisor?: AgentOptions["supervisor"];
}
/**
 * Context service for the shared host composition.
 *
 * @category services
 * @since 0.1.0
 */
export declare const Host: Context.Service<Host, Host>;
/**
 * Constructs a host composition value.
 *
 * A composition default that is not a non-negative safe integer is refused
 * here rather than at the first decode miss, for the same reason a declaration
 * is: an unbounded correction budget is a run that re-prompts forever, and the
 * cheapest place to say so is where the number was written.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeHost: (host: Host) => Host;
/**
 * Reads the static stance shared by judged hosts. Invalid configuration is
 * refused before acquiring host resources.
 * @category constructors
 * @since 1.0.0
 */
export declare const supervisorStance: (environment: Readonly<Record<string, string | undefined>>) => "careful" | "paranoid";
/**
 * Provides one host composition to every model-backed action in a run.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerHost: (host: Host) => Layer.Layer<Host>;
/**
 * Everything a model-backed action can fail with.
 *
 * `StructuredOutputFailure` is the one an author handles: the model answered
 * and the answer did not fit the declared schema after its correction budget.
 * `SeatUnresolved` is the host having no model for the declared seat, and
 * `SeatUnrouted` is Jev not picking one for a step that declared `auto`.
 * `BudgetExceeded` is the run having spent what it was approved for, reported
 * at the step that would have overspent. `Budget.Skipped` is every later model
 * call in a run whose budget declared `skip-remaining`: a verdict no retry can
 * change, which is why {@link module:Budget.neverRetrySkipped} exists. The
 * other two are the composition failing underneath it.
 *
 * @category models
 * @since 0.1.0
 */
export declare const AgentFailure: Schema.Union<readonly [typeof StructuredOutput.StructuredOutputFailure, typeof Seat.SeatUnresolved, typeof Seat.SeatUnrouted, typeof Budget.BudgetExceeded, typeof Budget.Skipped, typeof HarnessError, typeof PluginError]>;
/**
 * Everything a model-backed action can fail with.
 *
 * @category models
 * @since 0.1.0
 */
export type AgentFailure = typeof AgentFailure.Type;
/**
 * The schema a payload declaration resolves to: a field record becomes a
 * `Schema.Struct`, a schema stays itself. The same widening `Flow.make` and
 * `Action.make` perform, restated because neither exports it.
 *
 * @category models
 * @since 0.1.0
 */
export type PayloadSchemaOf<Payload extends Schema.Struct.Fields | Flow.AnyStructSchema> = Payload extends Schema.Struct.Fields ? Schema.Struct<Payload> : Payload;
/**
 * The bounded repair ask made after a correction budget is spent.
 *
 * @category models
 * @since 0.1.0
 */
export interface Repair<Payload> {
    /**
     * The repair prompt, written from the failure and the step's own payload.
     *
     * The failure carries the declared schema's digest, the issues the last
     * candidate raised, and how many corrections were spent, so a prompt can say
     * what to fix without the author restating the schema.
     */
    readonly prompt: (failure: StructuredOutput.StructuredOutputFailure, payload: Payload) => string;
    /** The seat the repair runs on. Defaults to the step's own seat. */
    readonly seat?: string | undefined;
    /** Stable system teaching for the repair. Defaults to the step's own. */
    readonly system?: ReadonlyArray<string> | undefined;
}
/**
 * What an author declares about one model-backed step.
 *
 * @category models
 * @since 0.1.0
 */
export interface Options<Payload extends Schema.Struct.Fields | Flow.AnyStructSchema, Output extends Schema.Top> {
    /** The step's typed input, exactly as `Action.make` takes it. */
    readonly payload: Payload;
    /** The schema the answer must satisfy. Rendered into the prompt and enforced. */
    readonly output: Output;
    /**
     * A seat id or a non-empty ordered list resolved by the host. The first
     * seat is primary; the rest are fallbacks after capacity refusal, context
     * overflow, or HTTP 5xx failure.
     *
     * A callback is evaluated once per execution against the decoded payload.
     * The resolver owns seat names, including provider model ids and aliases.
     *
     * `"auto"` ({@link Seat.auto}), written or returned, routes through
     * {@link module:SeatRouter} once per execution: Jev classifies the prompt
     * and the routing graph picks the seat, its backups and the system variant,
     * so each subagent routes on its own prompt. A route to a panel runs the
     * step once per member seat and then on the merger, given the members'
     * answers. Every correction and the repair run on the routed seat unless
     * {@link Repair.seat} names one. A role the host's resolver routes by the
     * graph (`SeatResolver.routedAs`) routes the same way, as the host's phase
     * unless {@link Options.phase} names one.
     */
    readonly seat: ModelSelection | ((payload: PayloadSchemaOf<Payload>["Type"]) => ModelSelection);
    /** The phase of work an `auto` seat routes as; Jev classifies it when absent. */
    readonly phase?: SeatRouter.Phase | undefined;
    /** The task, built from the decoded payload. */
    readonly prompt: (payload: PayloadSchemaOf<Payload>["Type"]) => string;
    /** Stable system teaching for this step, after the host's and before the schema's. */
    readonly system?: ReadonlyArray<string> | undefined;
    /**
     * How many times a decode miss may be corrected before the step fails.
     *
     * A miss goes back to the same session while it has a frame to answer in,
     * and to a fresh session otherwise; each correction of either kind spends
     * one.
     *
     * Falls back to {@link Host.defaultCorrections}, and then to one, which
     * matches the harness's existing "correct once, then report" posture. Zero
     * declares that a first miss is terminal, and beats a generous host default
     * rather than being read as "unset".
     */
    readonly corrections?: number | undefined;
    /**
     * One bounded repair ask made after the correction budget is spent.
     *
     * A correction re-prompt repeats the task verbatim and adds the validation
     * issues: it assumes the model can still answer the question it was asked. A
     * repair does not. It is the author's own prompt, written about the failure,
     * and it is asked exactly once — the old engine's repair task, which ran
     * after `maxSchemaRetries` was exhausted rather than as another rung of the
     * same ladder.
     *
     * Its answer is decoded by the same declared schema. A repair that does not
     * validate either fails the action with its own failure, which is the last
     * evidence the boundary has.
     */
    readonly repair?: Repair<PayloadSchemaOf<Payload>["Type"]> | undefined;
    readonly modelParams?: ModelRequest.GenerationParams | undefined;
    readonly maxFrames?: number | undefined;
    /**
     * The idle bound for an action whose frames are meant to change files:
     * consecutive frames that write nothing before the run is asked for an
     * edit, and twice that before it fails `read_only_cap`. Omitted disarms it,
     * which is right for an action that only answers.
     */
    readonly readOnlyCap?: number | undefined;
    /**
     * Opening memory rows for this step, built from the decoded payload.
     *
     * They reach the model only as the run's opening memory: a judged step's
     * run-start relevance reading withholds each row Jev is confident the task
     * does not need, and journals what it kept and withheld as the step's
     * `relevance-settled` row. Keep the rows out of {@link prompt}, or they
     * bypass that gate. No rows declares no memory.
     */
    readonly memory?: ((payload: PayloadSchemaOf<Payload>["Type"]) => ReadonlyArray<MemorySnapshot.Row>) | undefined;
}
declare const InvalidCorrectionBudget_base: Schema.Class<InvalidCorrectionBudget, Schema.TaggedStruct<"flows/agent/InvalidCorrectionBudget", {
    readonly corrections: Schema.Number;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * Raised synchronously when an action declaration has an unbounded correction
 * budget.
 *
 * @category errors
 * @since 0.1.0
 */
export declare class InvalidCorrectionBudget extends InvalidCorrectionBudget_base {
}
/**
 * The journal event one rejected answer writes.
 *
 * A run that answered three times is one run with one final failure, and the
 * failure says only how the LAST candidate was wrong. The record is the rest of
 * the story: which attempt was rejected, against which schema, and a digest of
 * the issues, so two runs that spent their budget the same way can be told
 * apart without the answers themselves being journaled.
 *
 * @category records
 * @since 0.1.0
 */
export declare const structuredOutputRejectedEvent = "flows.agent.structured-output-rejected.v1";
/**
 * A declared model-backed action, plus the layer that implements it.
 *
 * The declaration half is an ordinary `Action.Declared`: `.call()` records the
 * same plan node any other action records. The {@link AgentAction.layer} half
 * is what {@link make} adds — an author never writes `toLayer` for a model
 * call, because there is only one implementation and it ships here.
 *
 * @category models
 * @since 0.1.0
 */
export interface AgentAction<Tag extends string, Payload extends Flow.AnyStructSchema, Output extends Schema.Top> extends Action.Declared<Tag, Payload, Output, typeof AgentFailure> {
    readonly layer: Layer.Layer<Action.Requirement<Tag>, never, Agent | FlowRuntime.FlowRuntime | Host | Sandbox.Sandbox | SeatResolver | Steering.Source | Crypto.Crypto | Budget.Budget | QuotaPolicy.QuotaClassifier | Evaluator.Evaluator | Payload["DecodingServices"] | Payload["EncodingServices"] | Output["DecodingServices"] | Output["EncodingServices"]>;
}
/**
 * Declares a model-backed action and ships its implementation.
 *
 * The returned value is used exactly like any other declared action — `.call()`
 * in a flow body, `.layer` in the composition — with one difference: the layer
 * is already written. What it does is resolve the seat through `SeatResolver`,
 * run one agent loop through {@link module:Agent} inside the current flow
 * execution, and decode the run's final answer with the declared output schema,
 * spending {@link Options.corrections} re-prompts before it reports a typed
 * `StructuredOutputFailure`.
 *
 * @example
 * ```ts
 * import * as AgentAction from "@smthrs/agent/AgentAction"
 * import * as Schema from "effect/Schema"
 *
 * const Research = AgentAction.make("docs/Research", {
 *   payload: { topic: Schema.String },
 *   output: Schema.Struct({ summary: Schema.String }),
 *   seat: "anthropic:claude-sonnet-4-5",
 *   system: ["You are a research assistant."],
 *   prompt: ({ topic }) => `Research ${topic}.`
 * })
 * ```
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const make: <const Tag extends string, Payload extends Schema.Struct.Fields | Flow.AnyStructSchema, Output extends Schema.Top>(tag: Tag, options: Options<Payload, Output>) => AgentAction<Tag, PayloadSchemaOf<Payload>, Output>;
/**
 * Implements an existing ordinary action with the agent loop.
 *
 * The action owns its schemas and identity. A host uses this bridge for a
 * canonical prompt flow without declaring or rebuilding that flow.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const implement: <const Tag extends string, PayloadSchema extends Flow.AnyStructSchema, Output extends Schema.Top>(declared: Action.Declared<Tag, PayloadSchema, Output, typeof AgentFailure>, policy: Omit<Options<PayloadSchema, Output>, "payload" | "output">) => AgentAction<Tag, PayloadSchema, Output>["layer"];
export {};
