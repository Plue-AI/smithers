/**
 * The durable half of {@link ChildFlows}: detached children as real runs.
 *
 * `ChildFlows` declares `agent/spawn`, `agent/send`, and `agent/await` and
 * leaves the lifecycle behind the injected {@link ChildFlows.Children} port,
 * because nothing in a browser-safe package can honestly claim to persist a
 * detached run. This module is the implementation a host with a durable engine
 * supplies. Every operation is a durable one:
 *
 * - `spawn` starts a run of its own — a separate row, a separate claim, a
 *   separate journal — linked to the caller through the engine's parent-edge
 *   table. It is spawned with the result DISCARDED, which is what records
 *   `onParentExit: "detach"` on the child, so the child outlives the run that
 *   started it instead of being cancelled with it.
 * - `await` reads the child's settled result out of the run store, so it works
 *   from a different engine, a different process, and a later incarnation than
 *   the one that spawned it.
 * - `send` steers the child through the control plane, which admits a durable
 *   `human-steer` message the child drains at its next turn boundary.
 *
 * **What it is allowed to touch.** Three services and no more: the flow
 * runtime that starts and polls executions, the run store that says whether a
 * child exists, and the control plane that steers one. It reaches into no
 * engine internals — the engine's own state document is read through the one
 * public field `RunStore.RunRow.stateJson`, projected down to the single key
 * this port needs (see {@link ChildState}) — so the port composes over any
 * runtime that satisfies those three contracts rather than over one engine
 * implementation.
 *
 * **Whose children it reaches.** `await` and `send` take the child id as a
 * plain string a cell writes, so a call made inside a run is restricted to
 * that run's own child namespace — the ids `childExecutionId` derives from its
 * execution id. Without that, the string was a selector over every run the host
 * could see, and a cell that learned another run's id read its result and
 * steered it. A call made from OUTSIDE any run is the host collecting a child
 * of its own, which is the cross-process path below and is not model-reachable:
 * such a caller composed this port and already holds the run store and the
 * control plane it reads and steers through.
 *
 * The one thing it does not do is park the caller. `await` waits by re-reading
 * the child's run row on an interval rather than suspending the run, so a cell
 * that awaits a long child holds its round open. That is a bounded, honest cost of
 * the port's shape — `Children.await` answers with a value — and the note is
 * here rather than in a comment on the loop because it is the operation's
 * contract, not an implementation detail.
 *
 * @since 0.1.0
 */
import { Control } from "@smthrs/control/Control";
import type { Flow } from "@smthrs/flow";
import { FlowRuntime } from "@smthrs/flow";
import { RunStore } from "@smthrs/run-store";
import * as Crypto from "effect/Crypto";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Schema from "effect/Schema";
import * as ChildFlows from "./ChildFlows.ts";
/**
 * How a host wires detached children onto its engine.
 *
 * @category models
 * @since 0.1.0
 */
export interface Options {
    /**
     * The flows a child may run, by `_tag`.
     *
     * This is the authority behind `ChildError { code: "not_found" }`: a name
     * that is not here names nothing this host can start, and saying so is
     * data the cell can route around. Registering the flow with the runtime is
     * separate and still required — this list is what the child lifecycle is
     * allowed to reach, not what the engine knows how to run.
     */
    readonly flows: ReadonlyArray<Flow.Any>;
    /**
     * How long `await` waits before re-reading a child that has not settled,
     * and how long `spawn` waits between checks for the child's run row.
     *
     * Defaults to 250 ms.
     */
    readonly pollInterval?: Duration.Input | undefined;
    /**
     * How long `spawn` waits for the child's run row to exist before reporting
     * that the child never started.
     *
     * `spawn` returns an id, so the id has to name something durable by the time
     * it does — otherwise a later `await` from another process would be waiting
     * on a run that was never created. Defaults to 30 seconds.
     */
    readonly startTimeout?: Duration.Input | undefined;
    /**
     * How long `await` polls a child that has not settled before answering
     * `still_running`, when the call names no `timeoutSeconds`.
     *
     * A child parked on an approval nobody answers would otherwise hold the
     * parent's cell call in a poll loop forever. Defaults to 10 minutes.
     */
    readonly awaitTimeout?: Duration.Input | undefined;
}
/**
 * The execution id a labelled child of `parentExecutionId` runs under.
 *
 * Derived rather than minted, so a parent that is re-driven — a resume, a
 * reclaim, a replayed cell — spawns the SAME child rather than a second one:
 * the engine's create is idempotent on the execution id. The label is
 * therefore the child's identity within its parent, and two concurrent
 * children need two labels.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const childExecutionId: (parentExecutionId: string, label: string) => string;
/**
 * The one thing this port reads out of a child run's state document.
 *
 * `RunStore` publishes a run's state as `RunRow.stateJson`, an opaque string
 * it neither writes nor interprets, and a runtime fills it with whatever it
 * needs to resume the run. `await` needs exactly one key out of it: the name
 * of the flow the child is running, because `FlowRuntime.poll` addresses an
 * execution by declaration and a cell only ever has the child's id.
 *
 * Declared here, narrow, rather than imported from an engine: a projection
 * that names one field is a dependency on that field, which is the smallest
 * one that can answer the question. Excess keys decode away, so a runtime
 * that records more than this — every runtime does — still satisfies it.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const ChildState: Schema.Struct<{
    readonly flowName: Schema.String;
}>;
/**
 * Builds the durable child port over this host's engine and run store.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const make: (options: Options) => Effect.Effect<ChildFlows.Children, never, Control | Crypto.Crypto | FlowRuntime.FlowRuntime | RunStore.RunStore>;
/**
 * Provides {@link ChildFlows.Children} over this host's durable engine.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layer: (options: Options) => Layer.Layer<ChildFlows.Children, never, Control | Crypto.Crypto | FlowRuntime.FlowRuntime | RunStore.RunStore>;
