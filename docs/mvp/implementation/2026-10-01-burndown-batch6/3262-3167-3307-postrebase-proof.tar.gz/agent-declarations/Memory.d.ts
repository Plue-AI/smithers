/**
 * Memory: the context a task needs, as one ordinary sealed flow named
 * `memory`.
 *
 * A cell reaches it the way it reaches every capability:
 * `ctx.call("memory", { task, query?, paths?, sources?, maxBytes? })`. There
 * is no `ctx.memory`. A host binds it with {@link plugin} (through
 * `CellPlugin.fromBindings`), and runs the same selection once before frame 0
 * with {@link opening}, whose value is `Agent.Options.memory`.
 *
 * Selection is deterministic shortlisting plus one Jev boolean per candidate:
 *
 * - **Seeds**: paths and commit ids the task or `paths` name. Kept, never
 *   judged.
 * - **Wiki**: the page catalog, skills and imported dependency pages, the
 *   top {@link shortlist} by keyword, each asked `memory/needed`.
 * - **Repo**: a README-guided walk. Each level asks `memory/descend` of every
 *   child directory, from the root README down, at most {@link maxLevels}
 *   levels, {@link maxChildren} children per directory and {@link maxDirs}
 *   directories. The files of the kept directories, of the seeds'
 *   directories and of the paths kept pages cite are then asked
 *   `memory/needed`.
 * - **Commits**: commits that touched the kept and seeded files, with their
 *   mythical notes, asked `memory/needed`.
 * - **Facts**: remembered rows from `@smthrs/memory`, withheld by the
 *   existing `relevance/unnecessary` reading at `Relevance.withholdAt`.
 *
 * Every decision has its own threshold on a calibrated scale
 * (`MemoryCalibration`). The winners are packed into one byte-stable fenced
 * block under `maxBytes`. The result enters a run as a call result in the
 * append-only tail, or at frame 0 as `Agent.Options.memory` rows, so the
 * prompt-cache prefix is never rewritten.
 *
 * A Jev that is unavailable (unreachable, timed out, or refusing with a 429
 * or a 5xx, as `EvaluatorBackup.withFallback` reads it), or a host with no
 * judge (reason `unconfigured`), leaves the call with its seeds and its
 * recalled facts, and `unjudged` set; the run-start relevance reading still
 * judges the facts. Any other Jev failure fails the call with
 * {@link MemoryFailed}.
 *
 * @since 1.0.0
 */
import * as Capability from "@smthrs/capability/Capability";
import * as Flow from "@smthrs/core/Flow";
import * as FlowBinding from "@smthrs/harness/FlowBinding";
import * as Judgement from "@smthrs/harness/Judgement";
import type * as MemoryStore from "@smthrs/memory/MemoryStore";
import * as Recall from "@smthrs/memory/Recall";
import * as MemorySource from "@smthrs/memory/Source";
import * as Evaluator from "@smthrs/model/Evaluator";
import type { FlowsHooks, FlowsPlugin } from "@smthrs/plugin";
import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import * as Schema from "effect/Schema";
import type { ChildProcessSpawner } from "effect/unstable/process/ChildProcessSpawner";
import * as Wiki from "./internal/memory/wiki.ts";
import * as MemoryCalibration from "./MemoryCalibration.ts";
/**
 * The flow's name, and the plugin's.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const name = "memory";
/**
 * The block size a call packs to when it names none, in UTF-8 bytes.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const defaultMaxBytes: number;
/**
 * The largest block a call may ask for: `Recall.MAX_RECALL_TOKENS`.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxMaxBytes: number;
/**
 * The block size the host's frame-0 call packs to.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const openingMaxBytes: number;
/**
 * Wiki candidates Jev reads per call, best keyword matches first.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const shortlist = 30;
/**
 * README walk bounds: levels below the root, children kept per directory,
 * and directories kept in all.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxLevels = 4;
/**
 * Children the walk descends into per directory.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxChildren = 8;
/**
 * Directories the walk keeps in all.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxDirs = 48;
/**
 * Files per directory, and files in all, that one call asks Jev about.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxFilesPerDir = 64;
/**
 * Files one call asks Jev about in all.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxFiles = 256;
/**
 * The most of one candidate Jev reads.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const headBytes = 1024;
/**
 * The most of a directory's README Jev reads. Short on purpose: measured on
 * 2026-09-28, a 300-byte head beside the path separated the directory a task
 * needed from its siblings better than a 1 KiB one.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const aboutBytes = 300;
/**
 * Items listed in `omitted`, highest probability first.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxOmitted = 64;
/**
 * A level that took longer than this caps the walk one level shallower.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const slowLevelMs = 2000;
/**
 * The sources a call may read.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const SourceName: Schema.Literals<readonly ["wiki", "repo", "commits", "facts"]>;
/**
 * What a call asks for.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const Input: Schema.Struct<{
    readonly task: Schema.String;
    readonly query: Schema.optional<Schema.String>;
    readonly paths: Schema.optional<Schema.$Array<Schema.String>>;
    readonly sources: Schema.optional<Schema.$Array<Schema.Literals<readonly ["wiki", "repo", "commits", "facts"]>>>;
    readonly maxBytes: Schema.optional<Schema.Int>;
}>;
/**
 * The decoded form of {@link Input}.
 *
 * @category models
 * @since 1.0.0
 */
export type Input = typeof Input.Type;
/**
 * What one candidate is.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const ItemKind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
/**
 * One candidate, kept or omitted, without its text. `p` is Jev's probability
 * that it is needed (or worth descending into); a seed's is 1. `decided`
 * says what settled it.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const Item: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
    readonly id: Schema.String;
    readonly digest: Schema.String;
    readonly bytes: Schema.Int;
    readonly p: Schema.Number;
    readonly decided: Schema.Literals<readonly ["seed", "jev", "budget", "stale", "unjudged"]>;
}>;
/**
 * The decoded form of {@link Item}.
 *
 * @category models
 * @since 1.0.0
 */
export type Item = typeof Item.Type;
/**
 * What a call returns. `context` is the one fenced block; `omitted` lists at
 * most {@link maxOmitted} ids; `cost` is the Jev spend.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const Output: Schema.Struct<{
    readonly context: Schema.String;
    readonly digest: Schema.String;
    readonly kept: Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
        readonly id: Schema.String;
        readonly digest: Schema.String;
        readonly bytes: Schema.Int;
        readonly p: Schema.Number;
        readonly decided: Schema.Literals<readonly ["seed", "jev", "budget", "stale", "unjudged"]>;
    }>>;
    readonly omitted: Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
        readonly id: Schema.String;
        readonly digest: Schema.String;
        readonly bytes: Schema.Int;
        readonly p: Schema.Number;
        readonly decided: Schema.Literals<readonly ["seed", "jev", "budget", "stale", "unjudged"]>;
    }>>;
    readonly cost: Schema.Struct<{
        readonly jevRequests: Schema.Int;
        readonly jevMs: Schema.Number;
        readonly candidates: Schema.Int;
    }>;
    readonly unjudged: Schema.optional<Schema.Struct<{
        readonly reason: Schema.Literals<readonly ["interrupted", "unconfigured", "unreachable", "refused", "empty", "timeout", "invalid_answer", "invalid_question"]>;
        readonly detail: Schema.String;
    }>>;
}>;
/**
 * The decoded form of {@link Output}.
 *
 * @category models
 * @since 1.0.0
 */
export type Output = typeof Output.Type;
declare const MemoryFailed_base: Schema.Class<MemoryFailed, Schema.TaggedStruct<"@smthrs/agent/Memory/MemoryFailed", {
    readonly code: Schema.Literals<readonly ["judge_failed", "facts_failed", "read_failed", "thresholds_invalid"]>;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * A call that could not decide: Jev failed other than by being unavailable
 * (`judge_failed`), the facts store failed (`facts_failed`), the host refused
 * a read of the repository (`read_failed`), or the repository's thresholds
 * file does not decode (`thresholds_invalid`). A path that is not there, and
 * a file or walked directory the host will not let it read, is skipped; a
 * denied seed fails, so a call never silently drops a path the task named.
 *
 * @category errors
 * @since 1.0.0
 */
export declare class MemoryFailed extends MemoryFailed_base {
}
/**
 * What `memory` reads: every file. A host opens with the workspace only for a
 * launch whose capabilities allow this, so the opening and a later call are
 * refused alike.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const reads: Capability.Capability;
/**
 * The `memory` declaration.
 *
 * `sealed` is honest: a call that reads the live tree is re-keyed by the
 * frame's write count and tree digest, so a call after an edit is a new
 * question, and a resumed run replays the recorded block byte for byte.
 *
 * @category flows
 * @since 1.0.0
 */
export declare const flow: Flow.Flow<Schema.Struct<{
    readonly task: Schema.String;
    readonly query: Schema.optional<Schema.String>;
    readonly paths: Schema.optional<Schema.$Array<Schema.String>>;
    readonly sources: Schema.optional<Schema.$Array<Schema.Literals<readonly ["wiki", "repo", "commits", "facts"]>>>;
    readonly maxBytes: Schema.optional<Schema.Int>;
}>, Schema.Struct<{
    readonly context: Schema.String;
    readonly digest: Schema.String;
    readonly kept: Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
        readonly id: Schema.String;
        readonly digest: Schema.String;
        readonly bytes: Schema.Int;
        readonly p: Schema.Number;
        readonly decided: Schema.Literals<readonly ["seed", "jev", "budget", "stale", "unjudged"]>;
    }>>;
    readonly omitted: Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["page", "skill", "dep", "dir", "file", "commit", "fact"]>;
        readonly id: Schema.String;
        readonly digest: Schema.String;
        readonly bytes: Schema.Int;
        readonly p: Schema.Number;
        readonly decided: Schema.Literals<readonly ["seed", "jev", "budget", "stale", "unjudged"]>;
    }>>;
    readonly cost: Schema.Struct<{
        readonly jevRequests: Schema.Int;
        readonly jevMs: Schema.Number;
        readonly candidates: Schema.Int;
    }>;
    readonly unjudged: Schema.optional<Schema.Struct<{
        readonly reason: Schema.Literals<readonly ["interrupted", "unconfigured", "unreachable", "refused", "empty", "timeout", "invalid_answer", "invalid_question"]>;
        readonly detail: Schema.String;
    }>>;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * What a host binds memory to.
 *
 * - `root` is the repository.
 * - `pages` replaces the wiki catalog, for a host that already holds fresh
 *   pages (planning passes its verified snapshot).
 * - `facts` reads remembered rows from these banks through these services.
 * - `thresholds` replaces the repository's own ({@link thresholds}).
 *
 * @category models
 * @since 1.0.0
 */
export interface Options {
    readonly root: string;
    readonly pages?: ReadonlyArray<Wiki.Page> | undefined;
    readonly facts?: {
        readonly services: Context.Context<MemoryStore.MemoryStore | Recall.Recall>;
        readonly banks: ReadonlyArray<string>;
    } | undefined;
    readonly thresholds?: MemoryCalibration.Thresholds | undefined;
}
/**
 * One wiki candidate a host supplies in `Options.pages`.
 *
 * @category models
 * @since 1.0.0
 */
export type Page = Wiki.Page;
/**
 * One kept item with the text the block carries for it (a head when it did
 * not fit whole).
 *
 * @category models
 * @since 1.0.0
 */
export interface Kept extends Item {
    readonly text: string;
}
/**
 * A selection: the call's output, the kept items with their text, every item
 * that cleared its threshold before the byte budget (`needed`, in pack order),
 * and every Jev request it took.
 *
 * @category models
 * @since 1.0.0
 */
export interface Selection {
    readonly output: Output;
    readonly kept: ReadonlyArray<Kept>;
    readonly needed: ReadonlyArray<Item>;
    readonly asked: ReadonlyArray<Judgement.Asked>;
    readonly unjudged?: Unjudged | undefined;
}
/**
 * The services a selection reads through.
 *
 * @category models
 * @since 1.0.0
 */
export type Requirements = FileSystem.FileSystem | Path.Path | ChildProcessSpawner;
/**
 * A repository-relative path, normalized, or `null` for an absolute or
 * escaping path and for private or runtime trees.
 *
 * @category paths
 * @since 1.0.0
 */
export declare const normalizePath: (value: string) => string | null;
/**
 * Path-like tokens named by prose, oldest mention first and deduplicated.
 * Only tokens with a source-file extension count, so "e.g." is not a path.
 *
 * @category paths
 * @since 1.0.0
 */
export declare const extractPaths: (...texts: ReadonlyArray<string>) => ReadonlyArray<string>;
/**
 * The state one memory reading sends, in UTF-8 bytes of its JSON. Below
 * `Judgement.maxStateBytes`: on 2026-09-28 the Jev gateway answered 400 to a
 * 256 KB state of repository text and accepted 120 KB, so memory packs its
 * items into requests of at most 64 KiB and sends them in parallel.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const maxStateBytes: number;
/**
 * `memory/needed`: would an agent doing the task need to read this item
 * before acting?
 *
 * @category readings
 * @since 1.0.0
 */
export declare const needed: Judgement.PerItem<{
    readonly task: string;
    readonly query?: string;
}, {
    readonly kind: string;
    readonly id: string;
    readonly head: string;
}, {
    readonly needed: (i: number) => Evaluator.BooleanQuestion;
}>;
/**
 * `memory/descend`: could what the task touches live under this directory?
 *
 * @category readings
 * @since 1.0.0
 */
export declare const descend: Judgement.PerItem<{
    readonly task: string;
    readonly query?: string;
}, {
    readonly path: string;
    readonly about: string;
}, {
    readonly descend: (i: number) => Evaluator.BooleanQuestion;
}>;
/**
 * The reading Jev did not answer: why, and the classifier and item count it
 * asked, as the `decision-unjudged` row journals them.
 *
 * @category models
 * @since 1.0.0
 */
export interface Unjudged extends Judgement.Unjudged {
    readonly classifier: string;
    readonly items: number;
}
/**
 * `root`'s own thresholds: {@link MemoryCalibration.file} when present, else
 * `MemoryCalibration.initial`. A present file that does not decode fails as
 * `thresholds_invalid`, never silently replaced by the defaults.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const thresholds: (root: string) => Effect.Effect<MemoryCalibration.Thresholds, MemoryFailed, FileSystem.FileSystem | Path.Path>;
/**
 * Selects the context for `input` in `options.root`.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const select: (input: Input, options: Options) => Effect.Effect<Selection, MemoryFailed, Requirements>;
/**
 * The version of the selection rules. It joins the step key beside the
 * thresholds digest, so a changed rule never replays an old selection.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const version = "memory/v1";
/**
 * `memory` bound to `services`, reading `options.root`.
 *
 * The step key carries {@link version}, the root and the thresholds digest.
 * It selects with `options.thresholds`, `MemoryCalibration.initial` when
 * absent; {@link source} binds the repository's own.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const binding: (services: Context.Context<Requirements | Evaluator.Evaluator>, options: Options) => FlowBinding.Binding;
/**
 * The `memory` flows source: {@link binding} with the repository's
 * {@link thresholds}, read each time a run resolves its flows with authority
 * for {@link reads}; otherwise `MemoryCalibration.initial` is pinned without
 * reading the repository. An authorized thresholds file that does not decode
 * fails the run's assembly.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const source: (services: Context.Context<Requirements | Evaluator.Evaluator>, options: Options) => FlowBinding.Source;
/**
 * The memory plugin: {@link binding} contributed through
 * `CellPlugin.fromBindings`. Pass it in `Agent.Options.plugins`.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const plugin: (services: Context.Context<Requirements | Evaluator.Evaluator>, options: Options) => FlowsPlugin<FlowsHooks>;
/**
 * A selection as `Agent.Options.memory`: one row per kept item, keyed
 * `<kind>/<id>`, so the run-start relevance reading can still withhold any
 * row at `Relevance.withholdAt`.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const declared: (selection: Selection) => MemorySource.Declared;
/**
 * The host's frame-0 call: the same selection for `task`, packed to
 * {@link openingMaxBytes}, as `Agent.Options.memory`, with the reading Jev
 * did not answer for the host to log.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const opening: (task: string, options: Options) => Effect.Effect<{
    readonly memory: MemorySource.Declared;
    readonly selection: Selection;
    readonly unjudged: Unjudged | undefined;
}, MemoryFailed, Requirements>;
export {};
