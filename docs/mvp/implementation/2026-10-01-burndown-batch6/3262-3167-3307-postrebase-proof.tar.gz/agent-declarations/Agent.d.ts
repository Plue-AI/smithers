/**
 * The Smithers agent.
 *
 * This module is the production composition of the durable cell loop, and it is
 * the one the whole package is named for. Everything the loop needs already
 * existed as a separate piece — the controller in `@smthrs/harness/CellTurn`,
 * registry-backed call resolution in `@smthrs/harness/CellCalls`, the sandbox in
 * `@smthrs/harness/QuickJSSandbox`, the durable engine port in
 * `./FlowEngineLike.ts` — and what did not exist was one place that wires them
 * together. This is that place.
 *
 * One agent, one implementation, two ways to run it. {@link module:AgentSession}
 * runs it as a whole control-plane run: the launch is a durable flow execution,
 * the events go to the journal, an operator steers and approves it.
 * {@link module:AgentAction} runs it as one typed step inside a larger flow:
 * the same loop, bounded by a declared output schema, replayed like any other
 * action. Neither adapter reimplements the loop, and a future agent that drives
 * a foreign CLI is another implementation of {@link Service} rather than a
 * second loop next to this one.
 *
 * What {@link Service.run} returns is the framework-neutral
 * `Stream<AgentEvent>` the controller emits — no callbacks, no event emitter, no
 * host-shaped result type. A caller renders it, journals it, or ignores it.
 *
 * Composition boundaries are deliberate:
 *
 * - The stream's requirements are `FlowEngine` and `FlowInstance` (a run must be
 *   started inside a running flow body, because the port is per-execution) plus
 *   `Sandbox` and `Steering.Source`, which the host supplies.
 *   {@link layerDefaults} provides browser-safe defaults for the latter two.
 * - Nothing here imports a Node built-in or a platform layer. The QuickJS
 *   sandbox is the browser single-file build, so this composition is the same
 *   in both environments; only the engine's storage layer differs.
 * - The catalog shown to the model is `registry.visible()` narrowed to
 *   model-invocable flows, and the *same* registry answers the calls, so the
 *   declaration digest a cell was written against is the one checked at the
 *   boundary.
 *
 * @since 0.1.0
 */
import * as Capability from "@smthrs/capability/Capability";
import { FlowRuntime } from "@smthrs/flow";
import * as AgentEvent from "@smthrs/harness/AgentEvent";
import * as Cell from "@smthrs/harness/Cell";
import * as CellCalls from "@smthrs/harness/CellCalls";
import * as CellTurn from "@smthrs/harness/CellTurn";
import * as FlowBinding from "@smthrs/harness/FlowBinding";
import { HarnessError } from "@smthrs/harness/HarnessError";
import * as Monitor from "@smthrs/harness/Monitor";
import * as QuickJSSandbox from "@smthrs/harness/QuickJSSandbox";
import type * as Sandbox from "@smthrs/harness/Sandbox";
import * as Steering from "@smthrs/harness/Steering";
import * as MemorySource from "@smthrs/memory/Source";
import type * as Evaluator from "@smthrs/model/Evaluator";
import type * as Model from "@smthrs/model/Model";
import * as ModelRequest from "@smthrs/model/ModelRequest";
import type { FlowsHooks, PluginInput } from "@smthrs/plugin";
import type { FlowsConfig } from "@smthrs/plugin/Config";
import type { PluginError } from "@smthrs/plugin/PluginError";
import type * as Descriptor from "@smthrs/registry/Descriptor";
import type * as Registry from "@smthrs/registry/Registry";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import type * as Schedule from "effect/Schedule";
import * as Stream from "effect/Stream";
import type * as Budget from "./Budget.ts";
import * as QuotaPolicy from "./QuotaPolicy.ts";
import type * as Seat from "./Seat.ts";
/**
 * Everything one assembled cell run declares.
 *
 * The required half is the run itself — who is running, on what seat, against
 * which registry and model. The optional half is authority and budget, and every
 * default is the conservative one: no capabilities, no placement, no
 * compaction, and a host that implements nothing until it says so.
 *
 * @category models
 * @since 0.1.0
 */
export interface Options {
    /** The durable session or lineage every call identity is scoped to. */
    readonly session: string;
    /** Overrides the bounded transport retry schedule at the model boundary. */
    readonly modelRetryPolicy?: Schedule.Schedule<unknown, Model.ModelFailure> | undefined;
    /**
     * The resolved seat this run streams from.
     *
     * A `SeatResolver` produced it, so the model, the route, and the context
     * window arrive together and the composition never parses a seat string or
     * holds a credential of its own.
     */
    readonly seat: Seat.Seat;
    /** Resolved seats attempted in order after `seat` on a capacity refusal. */
    readonly fallbackSeats?: ReadonlyArray<Seat.Seat>;
    /**
     * Capacity policy for this run; parking is enabled by default.
     *
     * `maxParks` bounds the parks one run takes, `QuotaPolicy.defaultMaxParks`
     * when absent, as for a flow `Agent.action`. The refusal that finds the
     * budget spent fails the run with the provider's typed `ModelError`.
     */
    readonly capacity?: {
        readonly park: boolean;
        readonly maxParkMillis?: number;
        readonly maxParks?: number;
    } | undefined;
    /** Resolves context budgets after a steer, using the host seat vocabulary. */
    readonly contextWindowTokensFor?: CellTurn.Input["contextWindowTokensFor"];
    /** The task the run was admitted with. */
    readonly prompt: string;
    /** Stable system teaching placed ahead of the cell contract. */
    readonly system?: ReadonlyArray<string> | undefined;
    readonly registry: Registry.Registry;
    /** Shared-kernel plugins resolved for the harness target. */
    readonly plugins?: PluginInput<FlowsHooks> | undefined;
    /** Raw config threaded through the plugin kernel's config waterfall. */
    readonly config?: FlowsConfig | undefined;
    /**
     * One explicitly selected memory snapshot.
     *
     * The host obtains this value from `memory/Source.declared`, which reads
     * `Source.readRows` and freezes the rows with the snapshot recorder;
     * omitting it injects no memory. The opening context renders every row
     * with `Source.render`, and when {@link judged} the run-start relevance
     * reading judges each row beside the catalog and the instructions. The
     * composition never reads a memory store or worldview on its own.
     */
    readonly memory?: MemorySource.Declared | undefined;
    /**
     * Ordered executable-flow sources composed into the run's catalog.
     *
     * This is how a capability becomes reachable from a cell: standard
     * filesystem and shell flows, memory flows, a durable wait, an incoming MCP
     * server, a child agent — each is a `FlowBinding.Source`, and each ends up as
     * one more entry in `ctx.flows` invoked with `ctx.call`. Plugin `cellFlows`
     * handlers run after these, in resolution order.
     */
    readonly flows?: ReadonlyArray<FlowBinding.Source> | undefined;
    /** Host implementations for module-backed flows, keyed by flow name. */
    readonly implementations?: ReadonlyMap<string, CellCalls.Implementation> | undefined;
    /** Runs a rendered markdown flow. A host with none refuses them catchably. */
    readonly promptRunner?: CellCalls.PromptRunner | undefined;
    /**
     * Decides whether a call may proceed, before its durable boundary opens.
     *
     * Kept outside the activity on purpose: a permission requirement raised
     * inside one would be journaled and replayed forever, and no later grant
     * could unblock it.
     */
    readonly authorize?: ((call: Cell.Call) => Effect.Effect<void, HarnessError>) | undefined;
    readonly modelParams?: ModelRequest.GenerationParams | undefined;
    readonly layers?: ReadonlyArray<string> | undefined;
    readonly capabilityEnvelope?: ReadonlyArray<Capability.CapabilityPattern> | undefined;
    readonly placement?: Option.Option<Descriptor.Placement> | undefined;
    readonly maxFrames?: number | undefined;
    /**
     * Caps consecutive read-only frames; see `CellTurn.make`.
     *
     * Armed for task runs only: a task run's frames are supposed to change
     * something, and a run that only reads is the failure mode a flat frame
     * budget cannot see. A run that is meant to answer rather than act leaves it
     * unset.
     *
     * @since 1.0.0-rc.0
     */
    readonly readOnlyCap?: number | undefined;
    /**
     * Caps the wall-clock one model call may spend, in milliseconds; see
     * `CellTurn.defaultModelCallMs` for the default and the evidence behind it.
     *
     * Armed by default, unlike `readOnlyCap`, because it bounds a failure that
     * has nothing to do with what the run is for: a call that answers slowly
     * enough to eat the run's whole wall clock costs a conversational run
     * exactly what it costs a task run. Zero disarms it.
     */
    readonly modelCallMs?: number | undefined;
    /**
     * Caps consecutive repeat-observation frames; see
     * `CellTurn.defaultRepeatFrames` for the default and the evidence behind it.
     *
     * Armed by default like `modelCallMs`, and exposed here for the same reason
     * `readOnlyCap` is: the demand it issues names a code task's evidence — the
     * failing check, the history of the symbol, the callers — so a run whose
     * repetition is not a stall passes zero and takes it off. Whatever this says
     * is what `discipline-armed` journals, so a grader reads the host's choice
     * and not a constant.
     */
    readonly repeatCap?: number | undefined;
    /**
     * Caps how many completions may be bounced for narrowed evidence; see
     * `CellTurn.defaultNarrowingDemands` for the default and the run it was read
     * off.
     *
     * Armed by default like `repeatCap`. The demand costs a run that verified
     * properly nothing at all — it is computed from calls the run already made
     * and fires only where the tree moved under a check that was never repeated
     * — so the only caller with a reason to pass zero is one whose completions
     * are not evidence claims at all.
     */
    readonly narrowingCap?: number | undefined;
    /**
     * Caps how many completions may be bounced for an unmoved tree; see
     * `CellTurn.defaultUnmovedDemands` for the default and the run it was read
     * off.
     *
     * Armed by default. A run that changed something never reaches it, and a run
     * whose task genuinely needs no change answers it in one sentence, so the
     * only caller with a reason to pass zero is one whose completions are not
     * claims about a workspace at all — a question, a review, a summary.
     */
    readonly unmovedCap?: number | undefined;
    /**
     * Caps how many completions may be bounced for a failing check the run
     * replaced rather than answered; see `CellTurn.defaultUnresolvedDemands`.
     *
     * Armed by default, and computed entirely from calls the run already made:
     * it fires only where a check reported a failing exit status over the tree
     * being completed on and a later call went back to the same subject with a
     * different command.
     */
    readonly unresolvedCap?: number | undefined;
    /**
     * Caps how many completions may be bounced for a claim the run's record does
     * not support; see `CellTurn.make`. Armed by default; zero disarms the one
     * brake that asks the `Evaluator`, which is what an interactive host whose
     * human reads every answer passes when it binds no judge.
     */
    readonly claimCap?: number | undefined;
    /**
     * The shape the run's final output must fit, corrected in the same session;
     * see `CellTurn.OutputCheck`. Omitted accepts any output.
     */
    readonly output?: CellTurn.OutputCheck | undefined;
    /**
     * Provider-run tools every model call of this run may use, such as the
     * provider's own web search; see `CellTurn.make`. Omitted declares none.
     */
    readonly serverTools?: ReadonlyArray<ModelRequest.ServerTool> | undefined;
    /**
     * Whether a human can answer this run; see `CellTurn.make`.
     *
     * The default is false, because the default run is unattended. Only a caller
     * that has somewhere for an answer to come from — an operator on the other
     * end of `smithers approve`, an interactive session — may claim true, and a
     * caller that claims it wrongly buys a run that waits forever.
     */
    readonly approvalChannel?: boolean | undefined;
    readonly limits?: Sandbox.Limits | undefined;
    /**
     * What the supervisor may do with its readings; see `Supervisor`.
     *
     * Verdicts are journaled whenever an `Evaluator` is bound, whatever this
     * says; {@link judged} arms nudges and memory insertion. `remember` mines
     * the run's transcript once, at run end, and writes the facts Jev accepts
     * to the bound memory store through `MemoryMine.write`; it is off unless
     * the host opts in, and a host with no store or no writable bank asks and
     * writes nothing. `banks` are the memory banks read from and written to,
     * one per project or repository. With no bank the run reads and writes no
     * memory at all: there is no global bank a run of one repository could
     * share with another's. `monitors` follow
     * `Monitor.defaults()` into the `cellMonitors` plugin hook. `stance` is the
     * static stance a {@link judged} run is taught, `careful` when omitted; an
     * unjudged run is taught none.
     */
    readonly supervisor?: {
        readonly remember?: boolean | undefined;
        readonly banks?: ReadonlyArray<string> | undefined;
        readonly monitors?: ReadonlyArray<Monitor.Monitor> | undefined;
        readonly stance?: "careful" | "paranoid" | undefined;
    } | undefined;
    /**
     * Whether the host's `Evaluator` is a real judge, which arms Jev's features
     * on this run; see `CellTurn.Input.judged`. Omitted is false.
     */
    readonly judged?: boolean | undefined;
    /**
     * Human-provided instruction files, such as a repository's `AGENTS.md`.
     * They are shown after `system`; a judged run drops the chunks Jev is
     * confident the task does not need. See `CellTurn.Input.instructions`.
     *
     * @since 1.0.0-rc.0
     */
    readonly instructions?: ReadonlyArray<{
        readonly path: string;
        readonly text: string;
    }> | undefined;
    /**
     * Names of `flows` sources whose flows a judged run never withholds, beside
     * `StandardFlows.coreSources`.
     *
     * @since 1.0.0-rc.0
     */
    readonly pinnedSources?: ReadonlyArray<string> | undefined;
}
/**
 * The agent: one method that runs one whole agent loop.
 *
 * A run must be started from inside a running flow body. The engine port is
 * built per execution, which is what makes `suspend` a real durable park rather
 * than a failure, and it is why `FlowInstance` is in the stream's requirements
 * rather than in the service's construction.
 *
 * @category services
 * @since 0.1.0
 */
export interface Service {
    readonly run: (options: Options) => Stream.Stream<AgentEvent.AgentEvent, HarnessError | PluginError, FlowRuntime.FlowRuntime | FlowRuntime.FlowInstance | Sandbox.Sandbox | Steering.Source | Budget.Budget | QuotaPolicy.QuotaClassifier | Evaluator.Evaluator>;
}
declare const Agent_base: Context.ServiceClass<Agent, "@smthrs/agent/Agent", Service>;
/**
 * The {@link Service} tag.
 *
 * @category services
 * @since 0.1.0
 */
export declare class Agent extends Agent_base {
}
/**
 * Builds a {@link Service} from an implementation of its one method.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const make: (implementation: Service) => Service;
/**
 * A {@link Service} that emits nothing and runs no model.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeNoop: (overrides?: Partial<Service>) => Service;
/**
 * Provides the production agent.
 *
 * The policy services are requirements of the layer so a composition cannot
 * erase them before {@link Service.run} reaches the model boundary.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layer: Layer.Layer<Agent, never, QuotaPolicy.QuotaClassifier | Budget.Budget>;
/**
 * Provides {@link makeNoop}.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerNoop: (overrides?: Partial<Service>) => Layer.Layer<Agent>;
/**
 * The browser-safe defaults for the two services a run leaves to the host.
 *
 * The sandbox is the QuickJS single-file build, which runs unchanged in Node and
 * in a browser. Steering defaults to an empty source: a host that accepts
 * mid-run messages provides its own `Steering.layer` instead, and the loop
 * drains it at exactly the same boundaries either way.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerDefaults: Layer.Layer<Sandbox.Sandbox | Steering.Source, Sandbox.SandboxError>;
/**
 * {@link layerDefaults} over the QuickJS build the host names.
 *
 * The steering default is unchanged; only the sandbox differs. A host whose
 * runtime refuses to compile WebAssembly from bytes, such as Cloudflare's
 * workerd, provides `QuickJSSandbox.layerVariant(variant)` beneath this and
 * builds that variant from a `.wasm` module import.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerDefaultsWithVariant: Layer.Layer<Sandbox.Sandbox | Steering.Source, Sandbox.SandboxError, QuickJSSandbox.Variant>;
export {};
