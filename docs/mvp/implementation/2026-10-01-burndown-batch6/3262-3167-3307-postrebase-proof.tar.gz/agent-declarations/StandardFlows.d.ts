/**
 * The built-in host capabilities, expressed as ordinary executable flows.
 *
 * There is no `ctx.fs`, no `ctx.shell`, no `ctx.memory`, and no `ctx.wait`. A
 * cell that reads a file and a cell that calls a remote MCP tool run the same
 * two lines — look the flow up in `ctx.flows`, invoke it with `ctx.call` — and
 * both boundaries are the same keyed, journaled, permission-gated activity.
 * This module is what makes that true for the standard capabilities: each
 * helper pairs a declaration that already exists (`@smthrs/std`,
 * `@smthrs/memory/Flows`) with the handler that already exists, through the
 * one binding contract in `@smthrs/harness/FlowBinding`.
 *
 * Each helper takes the `Context` the host built, because a handler's
 * requirements are the host's to supply — a browser host provides a different
 * `FileSystem` than a Node host, and neither of them changes what the cell
 * sees.
 *
 * Two capabilities cannot be written generically, and both take a narrow
 * injected port rather than a fake:
 *
 * - {@link approval} needs a human. The port is one `ask`. A host with nobody to
 *   ask refuses with {@link ApprovalUnavailable}, which the cell may catch; a
 *   host that wants the run to *wait* fails with a `HarnessError` carrying a
 *   `Permission.PermissionRequired`, or gates the call in
 *   `Agent.Options.authorize` — either way the park stays in the typed error
 *   channel where the cell can neither see nor swallow it.
 * - {@link clock} needs the durable engine, so it is the one helper here whose
 *   context is `FlowEngine`. It is not part of the browser-safe core, and
 *   nothing in `Agent` imports it. A durable sleep past the in-memory
 *   threshold awaits a `DurableDeferred`, whose key is hashed, so the host
 *   supplies `Crypto` alongside the runtime — the same three services
 *   `FlowEngineLike.make` captures from the flow it is built inside.
 *
 * @since 0.1.0
 */
import * as Flow from "@smthrs/core/Flow";
import type { FlowRuntime } from "@smthrs/flow";
import * as FlowBinding from "@smthrs/harness/FlowBinding";
import { HarnessError } from "@smthrs/harness/HarnessError";
import type * as ChildProcessSpawner from "@smthrs/kernel/ChildProcessSpawner";
import type * as Path from "@smthrs/kernel/Path";
import type * as MemoryStore from "@smthrs/memory/MemoryStore";
import * as Recall from "@smthrs/memory/Recall";
import * as WithMemory from "@smthrs/memory/WithMemory";
import * as Evaluator from "@smthrs/model/Evaluator";
import * as Container from "@smthrs/std/Container";
import * as Search from "@smthrs/std/Search";
import type * as TestRunner from "@smthrs/std/TestRunner";
import * as Context from "effect/Context";
import type * as Crypto from "effect/Crypto";
import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import * as Schema from "effect/Schema";
/**
 * The default longest wait a cell may request, in seconds.
 *
 * One hour is long enough for an intentional backoff but short enough that a
 * parked run remains distinguishable from one that hung. Hosts may lower this
 * ceiling when they construct {@link clock}.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const defaultMaxWaitSeconds = 3600;
/**
 * The standard filesystem capabilities, as ordinary flows.
 *
 * All seven are bound, not just `read` and `write`. A host that offers whole-
 * file writes and nothing else forces every edit through "read the file, then
 * write the whole file back", and a model that has an editing tool in its
 * training reaches for one it does not have instead: on SWE-bench instances the
 * built-in harness would emit `apply_patch` heredocs into `bash`, watch the
 * shell report `apply_patch: command not found`, and finish the run claiming a
 * fix it never applied. `@smthrs/std` already declares and implements every one
 * of these; the production composition simply was not offering them.
 *
 * Each handler needs only `FileSystem` and `Path`, which is why they compose
 * from the one context the host already built for `read`.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const filesystem: (services: Context.Context<FileSystem.FileSystem | Path.Path>, search?: Search.Search) => FlowBinding.Source;
/**
 * Shell execution, as one ordinary flow.
 *
 * `container` is what makes `bash`'s `container` field mean anything. The flow
 * reads the transport optionally, so a composition that supplies none simply
 * refuses a containerised call — which is the same thing as not offering the
 * affordance at all. A task whose interpreter and test runner live in a
 * container is the ordinary SWE-bench shape, and without a transport the only
 * way in is the agent typing `docker exec c bash -lc '…'` itself: twelve failed
 * probes and one instance's most expensive frame across the measured 45. So the
 * default is the docker/podman CLI rather than `undefined`, because a host with
 * neither fails the spawn with the shell's own "not found" — which is honest —
 * while a host with docker gets the transport it plainly has.
 *
 * `sealedTo` names the one container `bash` may reach; every other call,
 * including one with no container that would run on this host, is refused
 * with `outside_container` (`Bash.sealed`).
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const shell: (services: Context.Context<ChildProcessSpawner.ChildProcessSpawner | Path.Path>, container?: Container.Container, options?: {
    readonly sealedTo?: string | undefined;
}) => FlowBinding.Source;
/**
 * The repository's own test runner, as one ordinary flow.
 *
 * Separate from {@link shell} because it needs one thing a shell does not: the
 * host's declaration of how this repository runs its tests. A host that has one
 * binds `TestRunner`; a host that does not binds `TestRunner.layerNoop` and the
 * flow says so when it is called. A host whose runner lives in a container adds
 * `Container` to the same context, which is also what `bash` reads it from.
 *
 * It needs the `Evaluator` too: the flow asks Jev whether a non-zero exit is
 * the tree's failure or the command failing to resolve a name, and a host
 * whose evaluator is `Evaluator.layerUnavailable()` gets that refusal as the
 * call's own typed failure rather than an unjudged result.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const tests: (services: Context.Context<ChildProcessSpawner.ChildProcessSpawner | Evaluator.Evaluator | TestRunner.TestRunner>) => FlowBinding.Source;
/**
/**
 * Output for the agent's `recall` flow: the rows kept, and the rows Jev
 * withheld as unneeded.
 *
 * `unjudged` is present when Jev could not answer. Every row is then kept, and
 * this field, journaled with the call's settled result, is the receipt.
 *
 * @category schemas
 * @since 1.0.0-rc.0
 */
export declare const JudgedRecallOutput: Schema.Struct<{
    readonly rows: Schema.$Array<Schema.Struct<{
        readonly bank: Schema.String;
        readonly key: Schema.String;
        readonly text: Schema.String;
        readonly score: Schema.Number;
        readonly updatedAtMs: Schema.optional<Schema.Number>;
    }>>;
    readonly withheld: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly digest: Schema.String;
        readonly p: Schema.Number;
    }>>;
    readonly unjudged: Schema.optional<Schema.Struct<{
        readonly reason: Schema.Literals<readonly ["interrupted", "unconfigured", "unreachable", "refused", "empty", "timeout", "invalid_answer", "invalid_question"]>;
        readonly detail: Schema.String;
    }>>;
}>;
/**
 * The agent's `recall` declaration: `@smthrs/memory`'s recall, filtered by
 * `Relevance`.
 *
 * @category flows
 * @since 1.0.0-rc.0
 */
export declare const recallFlow: Flow.Flow<Schema.Struct<{
    readonly banks: Schema.$Array<Schema.NonEmptyString>;
    readonly query: Schema.String;
    readonly tagGroups: Schema.optional<Schema.$Array<Schema.compose<Schema.Codec<import("@smthrs/memory/Namespace").TagGroup, import("@smthrs/memory/Namespace").TagGroup, never, never>, Schema.declare<import("@smthrs/memory/Namespace").TagGroup, import("@smthrs/memory/Namespace").TagGroup>>>>;
    readonly maxTokens: Schema.optional<Schema.Int>;
    readonly budget: Schema.optional<Schema.Literals<readonly ["low", "mid", "high"]>>;
}>, Schema.Struct<{
    readonly rows: Schema.$Array<Schema.Struct<{
        readonly bank: Schema.String;
        readonly key: Schema.String;
        readonly text: Schema.String;
        readonly score: Schema.Number;
        readonly updatedAtMs: Schema.optional<Schema.Number>;
    }>>;
    readonly withheld: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly digest: Schema.String;
        readonly p: Schema.Number;
    }>>;
    readonly unjudged: Schema.optional<Schema.Struct<{
        readonly reason: Schema.Literals<readonly ["interrupted", "unconfigured", "unreachable", "refused", "empty", "timeout", "invalid_answer", "invalid_question"]>;
        readonly detail: Schema.String;
    }>>;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * The one memory namespace a run's model-facing `remember` and `recall` may
 * reach.
 *
 * `policy` is `WithMemory.Policy` exactly as `@smthrs/memory` defines it: the
 * namespace, whether recall answers at all (`"none"` answers no rows), the
 * default recall budget, and whether writes are kept (`"never"` drops them).
 * `provenance` is recorded on every fact the bound `remember` writes and is
 * part of the scope's identity, so a host binds the run coordinates it knows
 * when it composes the run.
 *
 * @category models
 * @since 0.1.0
 */
export interface MemoryScope {
    readonly policy: WithMemory.Policy;
    readonly provenance?: MemoryStore.Provenance | undefined;
}
/**
 * The explicit unscoped memory composition: `remember` and `recall` reach any
 * bank a call names. A host passes it to {@link memory} only when no flow in
 * the run declares a memory policy and the operator owns the whole store.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const hostWide: "host-wide";
/**
 * The type of {@link hostWide}.
 *
 * @category models
 * @since 1.0.0
 */
export type HostWide = typeof hostWide;
/**
 * Durable memory, as two ordinary flows.
 *
 * With a `judge`, `recall` asks it which recalled rows the query does not
 * need, as `memory` items with the query as the task, and returns the rest. A
 * row is withheld only at `Relevance.withholdAt`; a reading Jev cannot make
 * keeps every row and says so in `unjudged`. Either way the reading is
 * journaled into the calling run through `AgentEvent.Journal`: its
 * `decision-settled` rows and a `relevance-settled` row with source `recall`,
 * or its `decision-unjudged` row. Without one, `recall` answers the rows
 * `@smthrs/memory` recalls.
 *
 * Every composition states its scope. {@link hostWide} is the deliberate
 * unscoped case: the two flows reach any bank a call names, for a host whose
 * operator owns the whole memory database. A {@link MemoryScope} binds them the way `@smthrs/memory` binds model-facing memory,
 * `WithMemory.withMemory` then `Flows.handlersFor`, so the policy namespace
 * is enforced before any I/O: a call naming a bank outside it fails with
 * `invalid_namespace`, a recall naming no bank reads the policy namespace, and
 * `recall: "none"` and `retain: "never"` behave as the memory package defines
 * them. A scope's policy and provenance are its declaration identity, so a
 * sealed recall recorded under one scope never answers a call under another;
 * give each run its own `provenance.runId` and keep it across that run's
 * resumes. A policy that does not decode binds nothing: composing the source
 * fails with `assembly_failed`.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare function memory(services: Context.Context<MemoryStore.MemoryStore | Recall.Recall>, scope: MemoryScope | HostWide): FlowBinding.Source;
export declare function memory(services: Context.Context<MemoryStore.MemoryStore | Recall.Recall>, judge: Context.Context<Evaluator.Evaluator>, scope: MemoryScope | HostWide): FlowBinding.Source;
/**
 * The largest `state` one `jev` call sends, in UTF-8 bytes of its JSON, when
 * a host names no ceiling.
 *
 * Jev reads the whole state for every question, so the ceiling is what keeps
 * one call's latency and cost bounded; a cell with more to judge splits the
 * items across calls.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const defaultMaxJevStateBytes = 262144;
/**
 * Input for the `jev` flow.
 *
 * `questions` decodes model-authored questions through `Classifier.Question`,
 * the same ad-hoc path a typed classifier's declaration goes through, so a
 * choice with one option or a score with a repeated rung is refused before any
 * transport is asked.
 *
 * @category schemas
 * @since 1.0.0-rc.0
 */
export declare const JevInput: Schema.Struct<{
    readonly state: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly questions: Schema.$Record<Schema.String, Schema.Union<readonly [typeof Evaluator.BooleanQuestion, typeof Evaluator.ChoiceQuestion, typeof Evaluator.ScoreQuestion]>>;
}>;
/**
 * Output for the `jev` flow.
 *
 * `usage` and `latencyMs` are the metered cost of the call, journaled with the
 * call's recorded result so a run's Jev spend is read back from the same
 * record its other calls are.
 *
 * @category schemas
 * @since 1.0.0-rc.0
 */
export declare const JevOutput: Schema.Struct<{
    readonly answers: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.Struct<{
        readonly value: Schema.Number;
        readonly label: Schema.String;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>, Schema.Struct<{
        readonly value: Schema.Boolean;
        readonly probability: Schema.Number;
    }>, Schema.Struct<{
        readonly value: Schema.String;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>]>>;
    readonly confidence: Schema.optional<Schema.$Record<Schema.String, Schema.Number>>;
    readonly usage: Schema.optional<Schema.Struct<{
        readonly inputTokens: Schema.Number;
        readonly outputTokens: Schema.Number;
    }>>;
    readonly latencyMs: Schema.Number;
}>;
/**
 * The `jev` declaration.
 *
 * The description carries the details the doctrine only points at: what Jev
 * is for, that fan-out belongs inside one call, and what it never does. The
 * host settles a cell's calls one at a time and caps a cell at a fixed number
 * of calls, so a call per item is both slow and finite; one call with one
 * question per item is the shape that scales.
 *
 * `sealed` is the honest tier: the answer is a function of the state and the
 * questions, holds nothing open, and writes nothing, so a replayed cell
 * returns the recorded answers rather than asking again.
 *
 * @category flows
 * @since 1.0.0-rc.0
 */
export declare const jevFlow: Flow.Flow<Schema.Struct<{
    readonly state: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly questions: Schema.$Record<Schema.String, Schema.Union<readonly [typeof Evaluator.BooleanQuestion, typeof Evaluator.ChoiceQuestion, typeof Evaluator.ScoreQuestion]>>;
}>, Schema.Struct<{
    readonly answers: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.Struct<{
        readonly value: Schema.Number;
        readonly label: Schema.String;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>, Schema.Struct<{
        readonly value: Schema.Boolean;
        readonly probability: Schema.Number;
    }>, Schema.Struct<{
        readonly value: Schema.String;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>]>>;
    readonly confidence: Schema.optional<Schema.$Record<Schema.String, Schema.Number>>;
    readonly usage: Schema.optional<Schema.Struct<{
        readonly inputTokens: Schema.Number;
        readonly outputTokens: Schema.Number;
    }>>;
    readonly latencyMs: Schema.Number;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * Jev, as one ordinary flow.
 *
 * Bound only by a host that holds an `Evaluator`: the context is the whole
 * requirement, so a composition without a judge cannot call this and the
 * catalog it shows a cell has no `jev` in it. A judge that fails is the call's
 * own typed failure, with the `EvaluatorError` code first in the message;
 * nothing here falls back to another model or answers a default.
 *
 * `options.maxStateBytes` may only LOWER {@link defaultMaxJevStateBytes}, for
 * the same reason `clock` clamps its ceiling: a non-finite or larger value
 * would remove the bound without saying so.
 *
 * @category constructors
 * @since 1.0.0-rc.0
 */
export declare const jev: (services: Context.Context<Evaluator.Evaluator>, options?: {
    readonly maxStateBytes?: number | undefined;
}) => FlowBinding.Source;
/**
 * Input for the durable wait flow.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const WaitInput: Schema.Struct<{
    readonly seconds: Schema.Number;
    readonly reason: Schema.optional<Schema.String>;
}>;
/**
 * Output for the durable wait flow.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const WaitOutput: Schema.Struct<{
    readonly waitedSeconds: Schema.Number;
}>;
/**
 * The durable wait declaration.
 *
 * `irreversible` is the honest tier: waiting is not content-addressable, so the
 * boundary is run-scoped on the cell identity and a replayed cell returns the
 * recorded completion instead of sleeping again.
 *
 * @category flows
 * @since 0.1.0
 */
export declare const waitFlow: Flow.Flow<Schema.Struct<{
    readonly seconds: Schema.Number;
    readonly reason: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly waitedSeconds: Schema.Number;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * A durable wait, as one ordinary flow.
 *
 * The sleep itself is the engine's `DurableClock`, so a short wait runs in
 * memory and a long one is scheduled by the engine. Either way the enclosing
 * cell call is the durable boundary, which is what makes the wait replay rather
 * than repeat.
 *
 * The clock's name is the call identity, not the duration. A durable clock is
 * identified by name — the deferred it awaits is `DurableClock/<name>` — so
 * naming it after the duration would make a cell that waits twice for the same
 * number of seconds await one already-settled deferred and return from the
 * second wait immediately. The call identity is both unique per call and stable
 * across replay, which is exactly what the name has to be.
 *
 * `options.maxSeconds` may only LOWER {@link defaultMaxWaitSeconds}. The
 * ceiling is the one thing keeping a parked run distinguishable from a hung
 * one, and a configuration read straight into the comparison could remove it
 * without saying so: `NaN` makes every `seconds > maxSeconds` test false, and
 * `Infinity` or an enormous finite value admits a wait no operator will
 * outlive. Both are clamped to the default rather than refused, because the
 * host has already been composed by the time this runs and a throw here would
 * take down a composition over a wait it has not been asked to make yet. A
 * value at or below zero is a host that means "no waiting", which is a
 * coherent thing to ask for and is kept.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const clock: (services: Context.Context<Crypto.Crypto | FlowRuntime.FlowRuntime | FlowRuntime.FlowInstance>, options?: {
    readonly maxSeconds?: number | undefined;
}) => FlowBinding.Source;
/**
 * Input for the approval flow.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const AskInput: Schema.Struct<{
    readonly question: Schema.String;
    readonly options: Schema.optional<Schema.$Array<Schema.String>>;
    readonly to: Schema.optional<Schema.Literals<readonly ["parent", "person"]>>;
}>;
/**
 * Output for the approval flow.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const AskOutput: Schema.Struct<{
    readonly answer: Schema.String;
    readonly approved: Schema.Boolean;
}>;
/**
 * The approval declaration.
 *
 * @category flows
 * @since 0.1.0
 */
export declare const askFlow: Flow.Flow<Schema.Struct<{
    readonly question: Schema.String;
    readonly options: Schema.optional<Schema.$Array<Schema.String>>;
    readonly to: Schema.optional<Schema.Literals<readonly ["parent", "person"]>>;
}>, Schema.Struct<{
    readonly answer: Schema.String;
    readonly approved: Schema.Boolean;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
declare const ApprovalUnavailable_base: Schema.Class<ApprovalUnavailable, Schema.TaggedStruct<"@smthrs/agent/StandardFlows/ApprovalUnavailable", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * A host that has nobody to ask.
 *
 * Separate from `HarnessError` on purpose: this is a refusal the agent can see
 * and route around, and the binding contract turns it into an ordinary
 * catchable call failure. Parking is the other seam — a host that wants the run
 * to wait for a person fails with a `HarnessError` carrying a
 * `Permission.PermissionRequired`, or gates the call in `Agent.Options.authorize`,
 * which is where a park can be re-decided against a later grant instead of
 * being journaled forever.
 *
 * @category errors
 * @since 0.1.0
 */
export declare class ApprovalUnavailable extends ApprovalUnavailable_base {
}
/**
 * The narrow host port an approval flow needs.
 *
 * @category models
 * @since 0.1.0
 */
export interface Asker {
    readonly ask: (input: typeof AskInput.Type) => Effect.Effect<typeof AskOutput.Type, HarnessError | ApprovalUnavailable>;
}
/**
 * Human approval, as one ordinary flow.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const approval: (asker: Asker) => FlowBinding.Source;
/**
 * An approval port for a host with nobody to ask.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const askerNoop: () => Asker;
/**
 * The source names of every helper here and of `ChildFlows.source`: the
 * sources whose flows a run cannot do without. A host pins their flows, so
 * the run-start relevance reading never withholds them.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const coreSources: ReadonlyArray<string>;
export {};
