/**
 * Source checkpoints for one native agent dispatch.
 * @since 1.0.0
 */
import { FlowRuntime } from "@smthrs/flow";
import type * as AgentEvent from "@smthrs/harness/AgentEvent";
import { type Journal, StepFact } from "@smthrs/journal";
import * as Crypto from "effect/Crypto";
import * as Effect from "effect/Effect";
/**
 * Every source event owns a small durable checkpoint. Its saved outcome and
 * public fact commit together in ActionPersistence. No writer outlives the
 * event, and the enclosing agent dispatch cannot settle ahead of its facts.
 * @category constructors
 * @since 1.0.0
 */
export declare const make: (journal: Journal.Service) => Effect.Effect<{
    emit: (event: AgentEvent.AgentEvent, step?: StepFact.Step) => Effect.Effect<void>;
    atSource: true;
}, never, Crypto.Crypto | FlowRuntime.FlowRuntime | FlowRuntime.FlowInstance>;
