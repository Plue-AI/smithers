/**
 * Commits that touched the paths a task needs, with the mythical note each
 * carries.
 *
 * History comes from `jj log`; notes come from `refs/notes/mythical`, which
 * only the stack service writes. A repository with neither answers no
 * commits.

 *
 * @since 1.0.0
 */
import * as Effect from "effect/Effect";
/**
 * One candidate commit. `text` is what Jev reads and what a pack renders.
 *
 * @since 1.0.0
 * @private
 */
export interface Commit {
    readonly commitId: string;
    readonly changeId: string;
    readonly text: string;
}
/**
 * The most commits one call reads.
 *
 * @since 1.0.0
 * @private
 */
export declare const maxCommits = 60;
/**
 * The most of one commit's description and note a candidate carries.
 *
 * @since 1.0.0
 * @private
 */
export declare const commitBytes = 1024;
/**
 * The notes ref the mythical stack service writes.
 *
 * @since 1.0.0
 * @private
 */
export declare const notesRef = "refs/notes/mythical";
/**
 * Commit ids named in free text: 12 to 40 lowercase hex characters.
 *
 * @since 1.0.0
 * @private
 */
export declare const commitIds: (text: string) => ReadonlyArray<string>;
/**
 * Commits that touched `paths` (newest first, at most {@link maxCommits}),
 * then any `seeds` the task named by id, each with its mythical note.
 *
 * @since 1.0.0
 * @private
 */
export declare const read: (root: string, paths: ReadonlyArray<string>, seeds: ReadonlyArray<string>) => Effect.Effect<{
    commitId: string;
    changeId: string;
    text: string;
}[], never, import("@smthrs/kernel/ChildProcessSpawner").ChildProcessSpawner>;
