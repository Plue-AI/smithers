/**
 * One control-plane launch, run as one durable agent session.
 *
 * This is the production `ControlExecutor`. `ControlLive.run` resolves the
 * executor through `Effect.serviceOption`, and until this module existed
 * nothing provided one, so every accepted run stayed `pending` forever. What it
 * does is take a stored plan, find the flow's descriptor and prompt body in the
 * registry, resolve the flow's declared seat through {@link SeatResolver}, and
 * run {@link module:Agent} as the body of one durable flow execution whose id
 * is the control run id.
 *
 * The session is the adapter, not the agent. Everything about how a frame is
 * built, sealed, and replayed belongs to `Agent`; what belongs here is the
 * control-plane half — status fencing, the resume bridge, the approval gate,
 * and the journal trail.
 *
 * What the composition declares, because the spec says a host must:
 *
 * - **Explicit sandbox limits.** `Options.limits` is required; an unlimited
 *   QuickJS cell can hang the frame, so there is no default-unlimited path.
 * - **A resolved context window.** `Seat.contextWindowTokens` comes back from
 *   the host's `SeatResolver`, so compaction is armed instead of silently
 *   disabled at zero. `SeatResolver.contextWindowTokensFor` is the catalog for
 *   known models.
 * - **Steering from the durable queue.** The `Steering.Source` is
 *   `@smthrs/harness/Notifications` over the same journal-backed queue
 *   `Control.steer` admits into, so an operator steer reaches the loop at the
 *   next frame boundary.
 * - **Approval through control.** The `ask` flow is gated in the `authorize`
 *   hook — before the durable boundary opens — by registering an in-run
 *   approval token (`ControlRuntime.registerApproval`) and failing with an
 *   encoded `Permission.PermissionRequired`, which the controller turns into
 *   a real durable park. `Control.approve` resolves the token and installs
 *   the grant; the resumed attempt re-asks against the grant store as it now
 *   stands and proceeds. The park is decided outside the activity on purpose:
 *   a requirement raised inside one would be journaled and replayed forever.
 *
 * Run-status writes stay fenced: the executor waits for the control plane's
 * own `running` transition before the engine starts, writes
 * `waiting-approval` when the execution parks, and writes the terminal status
 * when it settles. Resumption is event-driven — the executor follows the
 * journal for the control plane's resume events and re-drives the parked
 * engine execution.
 *
 * Prior art: Effect's workflow runtime (register/execute/poll/resume), adapted
 * by `@smthrs/engine`, and OpenCode's scope-owned background session driver.
 * These are upstream designs, not paths in this repository.
 *
 * @since 0.1.0
 */
import * as Capability from "@smthrs/capability/Capability";
import { LaunchFailed, PersistenceError } from "@smthrs/control/ControlError";
import * as ControlExecutor from "@smthrs/control/ControlExecutor";
import { ControlRuntime } from "@smthrs/control/ControlRuntime";
import { Envelope, type RunStatus } from "@smthrs/control/ControlSchema";
import * as DurableEngineState from "@smthrs/engine-store/DurableEngineState";
import { Flow, FlowRuntime } from "@smthrs/flow";
import type * as AgentEvent from "@smthrs/harness/AgentEvent";
import type * as CellCalls from "@smthrs/harness/CellCalls";
import type * as FlowBinding from "@smthrs/harness/FlowBinding";
import type * as Sandbox from "@smthrs/harness/Sandbox";
import * as Transcript from "@smthrs/harness/Transcript";
import { Journal, JournalEvent } from "@smthrs/journal";
import type * as MemorySource from "@smthrs/memory/Source";
import * as ModelRequest from "@smthrs/model/ModelRequest";
import type { NotificationQueue } from "@smthrs/notifications";
import * as Descriptor from "@smthrs/registry/Descriptor";
import * as Registry from "@smthrs/registry/Registry";
import { RunStore } from "@smthrs/run-store";
import * as Cause from "effect/Cause";
import type * as Crypto from "effect/Crypto";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import * as Option from "effect/Option";
import * as Schema from "effect/Schema";
import * as Scope from "effect/Scope";
import { Agent, type Options as AgentOptions } from "./Agent.ts";
import * as Budget from "./Budget.ts";
import type * as QuotaPolicy from "./QuotaPolicy.ts";
import { SeatResolver } from "./SeatResolver.ts";
declare const SandboxRefused_base: Schema.Class<SandboxRefused, Schema.TaggedStruct<"@smthrs/agent/AgentSession/SandboxRefused", {
    readonly provider: Schema.String;
    readonly reason: Schema.Literals<readonly ["unconfigured", "module", "options"]>;
    readonly message: Schema.String;
}>, Cause.YieldableError>;
/**
 * Why a run whose flow selects a sandbox cannot execute on this host.
 *
 * `unconfigured`: the host holds no provider for the name the flow selected.
 * `module`: only prompt flows run their tools on a sandbox machine.
 * `options`: the configured provider refused the selection's network or limits.
 *
 * @category errors
 * @since 1.0.0
 */
export declare class SandboxRefused extends SandboxRefused_base {
}
/**
 * What a sandbox-selected run executes with: its tool sources, bound to the
 * machine its session acquired. They replace {@link Options.flows} for that run.
 *
 * @category models
 * @since 1.0.0
 */
export interface SandboxedRun {
    readonly flows: ReadonlyArray<FlowBinding.Source>;
}
/**
 * Acquires the machine for one run under `session`, a key stable across the
 * run's parks and restarts. The scope is the machine's lifetime: the session
 * holds it until the run settles terminally or the executor closes.
 *
 * @category models
 * @since 1.0.0
 */
export type SandboxOpener = (session: string) => Effect.Effect<SandboxedRun, unknown, Scope.Scope>;
/**
 * Everything the host decides about the composition.
 *
 * `limits` is required on purpose: the composition never runs a cell without
 * an explicit memory and step budget. `flows` is the host's executable
 * catalog — filesystem, shell, memory — while the durable wait and the
 * control-wired approval are composed here, because they belong to the
 * engine and the control plane rather than to the host.
 *
 * @category models
 * @since 0.1.0
 */
export interface Options {
    /**
     * The host's sandbox providers: the opener for a flow's `sandbox:`
     * selection, `SandboxRefused` when the configured provider cannot honor it,
     * or `undefined` when none is configured for its name. Without it every
     * sandbox-selected flow is refused at launch.
     */
    readonly sandbox?: ((selection: Descriptor.SandboxSelection) => Effect.Effect<SandboxOpener, SandboxRefused> | undefined) | undefined;
    /** Workspace AGENTS.md files sent to the relevance gate. */
    readonly workspaceInstructions?: AgentOptions["instructions"];
    /** Host flow sources a judged run must always offer. */
    readonly pinnedSources?: AgentOptions["pinnedSources"];
    /** Host-selected profile instructions, sealed before the first model call. */
    readonly instructions?: ((launch: {
        readonly descriptor: Descriptor.FlowDescriptor;
        readonly text: string;
        readonly capabilities: ReadonlyArray<string>;
    }) => Effect.Effect<ReadonlyArray<string>, unknown>) | undefined;
    /** Host-selected opening context, frozen in this run before the first model call. */
    readonly memory?: ((launch: {
        readonly runId: string;
        readonly prompt: string;
        readonly history: ReadonlyArray<string>;
        readonly capabilities: ReadonlyArray<string>;
    }) => Effect.Effect<MemorySource.Declared, unknown>) | undefined;
    /** Native host callback commits intent and facts to its captured engine journal.
     * Standalone legacy compositions without it retain row-only cancellation.
     */
    readonly requestNativeCancel?: ControlExecutor.Service["requestCancel"] | undefined;
    /**
     * Age at which an unanswered resume delegation may be adopted by another
     * host. Defaults to `Ownership.heartbeatStaleAfter`; the cutoff is inclusive.
     */
    readonly abandonedParkAfter?: Duration.Duration | undefined;
    /** Refuse resume delegation for a run routed to another workspace host. */
    readonly canExecute?: ((runId: string) => Effect.Effect<boolean>) | undefined;
    /** Binds an explicit resume to the currently released native children before driving. */
    readonly authorizeReleasedChildren?: ((runId: string, sequence: number) => Effect.Effect<void, unknown>) | undefined;
    /**
     * Holds a terminal control status until the host has copied this run's
     * native evidence into the control journal.
     *
     * The two writes are independent: this executor journals
     * `control.run.completed` from the flow body's exit, while the
     * `flows.engine.run-decision` carrying the run's output is committed by the
     * engine after the handler returns and copied afterwards. A reader folding
     * the control journal between them saw `completed` with no output. A host
     * that runs a native journal supervisor supplies its wait here.
     *
     * Absent, the terminal status is written from the body's exit exactly as it
     * was, which is what every composition with nothing to copy wants.
     *
     * @since 1.0.0-rc.0
     */
    readonly orderTerminalStatus?: ((runId: string) => Effect.Effect<void>) | undefined;
    /** Host executable-flow sources composed into every run's catalog. */
    readonly flows?: ReadonlyArray<FlowBinding.Source> | undefined;
    /** Runs rendered markdown children; the host closes over their runtime dependencies. */
    readonly promptRunner?: CellCalls.PromptRunner | undefined;
    /** The explicit sandbox budget every cell runs under. Never unlimited. */
    readonly limits: Sandbox.Limits;
    /** Required quota park/retry policy for every model call in the run. */
    readonly quotaPolicy: Layer.Layer<QuotaPolicy.QuotaClassifier>;
    /** Whether the seat-capacity controller may park after a provider refusal. */
    readonly capacity?: AgentOptions["capacity"];
    /** Builds the run-local spending policy from the plan that was approved. */
    readonly budget: (envelope: Envelope) => Layer.Layer<Budget.Budget, Budget.ConfigurationError>;
    /** Stable system teaching placed ahead of the cell contract. */
    readonly system?: ReadonlyArray<string> | undefined;
    readonly maxFrames?: number | undefined;
    /**
     * Consecutive read-only frames a task run may spend before the controller
     * demands an edit or a justification, and twice that before it stops the
     * run. Defaults to `CellTurn.defaultReadOnlyFrames`.
     *
     * @since 1.0.0-rc.0
     */
    readonly readOnlyCap?: number | undefined;
    /** What the supervisor may do with its readings; see `Agent.Options.supervisor`. */
    readonly supervisor?: AgentOptions["supervisor"];
    /** Whether the host's `Evaluator` is a real judge; see `Agent.Options.judged`. */
    readonly judged?: boolean | undefined;
    /**
     * Wall-clock milliseconds one model call may spend before the boundary
     * interrupts it and re-issues it. Defaults to `CellTurn.defaultModelCallMs`;
     * zero disarms it.
     */
    readonly modelCallMs?: number | undefined;
    /**
     * Consecutive repeat-observation frames a run may spend before the
     * controller names the repetition and redirects it. Defaults to
     * `CellTurn.defaultRepeatFrames`; zero disarms it.
     */
    readonly repeatCap?: number | undefined;
    /**
     * Completions a run may have bounced for narrowed evidence before the
     * controller stops naming the check it skipped. Defaults to
     * `CellTurn.defaultNarrowingDemands`; zero disarms it.
     */
    readonly narrowingCap?: number | undefined;
    /**
     * Completions a run may have bounced for an unmoved tree before the
     * controller stops naming it. Defaults to `CellTurn.defaultUnmovedDemands`;
     * zero disarms it.
     */
    readonly unmovedCap?: number | undefined;
    /**
     * Completions a run may have bounced for a failing check it replaced rather
     * than answered. Defaults to `CellTurn.defaultUnresolvedDemands`; zero
     * disarms it.
     */
    readonly unresolvedCap?: number | undefined;
    /**
     * Whether a human answers this executor's runs, which is what makes a cell's
     * `park` transition honorable.
     *
     * The executor wires an approval gate on every run, but a gate is not an
     * answerer: a benchmark, a cron, and a CI lane all register approvals that
     * nobody will ever decide. So the host says. It defaults to false, and a run
     * that claims false has its `park` transitions refused and answered in-frame
     * rather than left waiting on an operator who is not there.
     */
    readonly approvalChannel?: boolean | undefined;
    /**
     * What an in-run `ask` does.
     *
     * `park`, the default, parks the run on an approval an operator answers
     * with `smithers approve`. `refuse` is for a host nobody answers: the ask
     * fails at once with `StandardFlows.ApprovalUnavailable`, which the cell
     * reads and routes around, so the run never waits on a decision that will
     * not come and nothing is approved on anyone's behalf.
     */
    readonly asks?: "park" | "refuse" | undefined;
    /**
     * The reasoning effort agent seats run at when their flow declares none.
     *
     * The flow's own `effort:` frontmatter wins; this is the host's default
     * beneath it, and the built-in default is `high` — an unset effort is not
     * neutral, it is near-zero thinking (the first SWE-bench runs recorded ~20
     * reasoning tokens per call while the same model under the Codex CLI ran
     * at medium and resolved four times as many instances).
     *
     * @since 1.0.0-rc.0
     */
    readonly reasoningEffort?: ModelRequest.ReasoningEffort | undefined;
}
/**
 * The OpenTelemetry trace id every span of one run is exported under.
 *
 * Derived from the run id alone, so `runs status` names the trace without a
 * stored column and every attempt of the run joins the same trace.
 *
 * @category tracing
 * @since 1.0.0
 */
export declare const traceId: (runId: string) => string;
/**
 * The durable child a control run executes its registered module in.
 *
 * The approved plan's execution digest keeps that child stable across an
 * adopted-code resume; a fork's own run id gives it a separate child.
 *
 * @category execution
 * @since 1.0.0
 */
export declare const moduleExecutionId: (runId: string, executionDigest: string) => string;
/**
 * The producer identity of one journaled agent event.
 *
 * A resumed attempt replays its whole prefix and re-publishes every event in
 * it, so without an identity of their own those events were journaled again:
 * the auto-allocated sequence never collided, the dedup index never fired, and
 * a projection summing `control.agent.model-settled` usage over-counted a
 * run's tokens once per park. This is the identity that lets
 * `UNIQUE (run_id, source_id, source_seq)` answer, and it has to hold for a
 * resumed attempt that DIVERGES rather than only for one that repeats.
 *
 * The material is where the event sits and what it says: the frame, its
 * ordinal within that frame, the cell that frame produced, the event type, and
 * the event's own payload minus {@link observationOnly} and minus whatever
 * {@link lateFields} records this event type as having gained after journals
 * of it already existed. A replayed event
 * regenerates all five, so it regenerates the identity and the index refuses
 * it. An event produced after divergence differs in at least one of them, so
 * it derives a different identity and is admitted normally: the approved
 * `ask` writes `cell-call-settled` where the parked attempt wrote
 * `permission-required`, at the same ordinal of the same frame, and the two
 * do not collide. A running count across the incarnation cannot make that
 * distinction, which is why one was tried and rejected.
 *
 * The identity hashes the payload that is journaled. When {@link trace}
 * replaces an oversized field, the deterministic marker carries the digest of
 * the full value, so two different omitted values still produce different
 * identity material without canonicalizing the full value a second time here.
 *
 * Truncation is to 48 bits, comfortably inside the safe-integer range the
 * journal allocates in, and the birthday bound over a run's thousands of
 * events is around 1e-9. The failure it bounds is a dropped duplicate, never a
 * rewritten row: the first observation of an identity is the one that stands.
 *
 * @category projections
 * @since 0.1.0
 */
export declare const traceIdentity: (frame: number, ordinal: number, cell: string, eventType: string, payload: Readonly<Record<string, unknown>>) => JournalEvent.SourceSeq;
/**
 * The durable identity shared by a cell call's start and settlement.
 *
 * CellTurn constructs the identity before dispatch and carries that exact
 * value into both events. Hash those coordinates, never emission order or the
 * flow name: concurrent calls may settle in any order, and replay must name
 * the same call. The prefix versions this contract without changing the
 * durable engine's activity keys.
 *
 * @category projections
 * @since 1.0.0
 */
export { callId } from "./internal/CallIdentity.ts";
/**
 * The largest free-text or value field one trail record carries.
 *
 * Completion outputs are bounded inside both cell settlements and applied
 * transitions, preserving the containing outcome and transition tags.
 *
 * The trail is a durable journal row, and a cell may read a multi-megabyte
 * file into one result. Bounding the field limits both that row's storage and
 * the canonicalization and hashing work paid for every event identity.
 *
 * @category projections
 * @since 1.0.0-rc.0
 */
export declare const maxTracedBytes = 65536;
/**
 * What the last `model-requested` of one scope and purpose said, as digests.
 *
 * The next record of the same scope and purpose is written against this: the
 * system text is left out while its digest stands, and the messages the two
 * calls share are counted rather than repeated. Digests only, so holding it
 * for the length of a run holds no transcript.
 *
 * @category projections
 * @since 1.0.0-rc.0
 */
export interface RequestTrail {
    /** The digest of the system text the last record of this scope and purpose named. */
    readonly systemDigest: string;
    /** One digest per message of that record's whole transcript, in order. */
    readonly messageDigests: ReadonlyArray<string>;
}
/**
 * The journal projection of one agent event.
 *
 * The executor consumes the harness stream itself, so without this the whole
 * transcript — what the model said, the cell it produced, the flows that cell
 * called, and why a frame was rejected — existed only for the duration of the
 * run and a settled run could not be read back at all. Model deltas are the
 * one omission: they are the token-by-token prefix of `model-settled`, and
 * journaling them would multiply a run's event count by its token count for
 * no information the settlement does not already carry.
 *
 * `undefined` means "not journaled".
 *
 * `previous` is what the last `model-requested` of the same scope and purpose
 * said, and only that record reads it: see {@link RequestTrail}. Without one
 * the request is written whole, which is what a caller projecting one event on
 * its own wants. A caller projecting a run's events in order uses
 * {@link tracer}, which keeps it.
 *
 * @category projections
 * @since 0.1.0
 */
export declare const trace: (event: AgentEvent.AgentEvent, previous?: RequestTrail) => {
    readonly eventType: Transcript.ControlEventType;
    readonly payload: unknown;
} | undefined;
/**
 * {@link trace} over one run's events in order.
 *
 * `model-requested` is the one record written against the record before it,
 * and this is where "before it" is kept: one {@link RequestTrail} per scope
 * and purpose, so a compaction call and a frame call, or two steps sharing a
 * sink, never count each other's messages. Every other event projects exactly
 * as {@link trace} projects it.
 *
 * One per incarnation, made where the events are consumed and never shared or
 * kept across a restart. A resumed attempt replays its events from the first
 * frame, so a fold that starts empty regenerates the payloads the first
 * attempt wrote and the journal's unique index refuses them; one that carried
 * the last attempt's trail over would write the replayed prefix as new rows.
 *
 * @category projections
 * @since 1.0.0-rc.0
 */
export declare const tracer: () => (event: AgentEvent.AgentEvent) => ReturnType<typeof trace>;
/**
 * The envelope one run spends against: its approved card's, with every budget
 * raise an operator approved in the run's control journal applied.
 *
 * A native module handler reads it on each entry, so a park approved in this
 * process or before a restart reaches the resumed module as it reaches a
 * resumed prompt run.
 *
 * @category budget
 * @since 1.0.0
 */
export declare const approvedEnvelope: (journal: Journal.Service, runId: string, envelope: Envelope) => Effect.Effect<Envelope, Journal.JournalError>;
/**
 * Parks a run whose `park` budget refused a call, or one of whose operations
 * ran past its time limit: registers the request in the run's control journal
 * with the guard's exact {@link RunawayGuard.incident} facts, and answers with
 * the `budget` wait and the requirement that suspends the frame. Approving the
 * request is Continue: a raised ceiling the resumed attempt spends against, or
 * one more run of the timed-out operation. Denying it is Stop: the resumed
 * attempt fails the run.
 *
 * `envelope` is the one the attempt spends against, with approved raises
 * applied. A request already made against that ceiling is reused as it was
 * recorded, proposal and facts included, so a re-driven run finds the
 * operator's decision on it rather than asking a new question. A concurrent
 * park that registered the same request first wins: this one parks on its
 * proposal. Timeouts are guarded only when the envelope's budget parks.
 *
 * @category budget
 * @since 1.0.0
 */
export declare const budgetParking: (journal: Journal.Service, runtime: Pick<ControlRuntime["Service"], "registerApproval">) => (runId: string, envelope: Envelope) => Budget.Parking["Service"];
/**
 * Parses a run envelope's formatted capabilities, dropping every entry the
 * capability grammar cannot name. Dropping an unparseable entry narrows
 * authority — the fail-closed direction — because an empty envelope grants
 * nothing.
 *
 * The bare `*` a markdown-declared flow carries when its frontmatter names no
 * `capabilities:` is part of the grammar itself: `Capability.parsePattern`
 * expands it to `*:**`, so nothing here special-cases it.
 *
 * @category conversions
 * @since 0.1.0
 */
export declare const patterns: (capabilities: ReadonlyArray<string>) => ReadonlyArray<Capability.CapabilityPattern>;
/**
 * A prompt flow's body and its launch input, rendered into one task.
 *
 * @category models
 * @since 1.0.0
 */
export interface RenderedPrompt {
    /** The task the run is admitted with: the body, then the arguments. */
    readonly text: string;
    /** The argument names the body can cite, in declaration order. */
    readonly fields: ReadonlyArray<string>;
    /** The arguments section alone, as it appears inside {@link RenderedPrompt.text}. */
    readonly arguments: string;
}
/**
 * Renders the prompt-flow body and its decoded input into the task the run is
 * admitted with.
 *
 * Every declared field becomes its own `## <field>` heading with its value
 * verbatim beneath it, so a body that says "the line given in the arguments"
 * resolves to one value in one place. The previous rendering appended
 * `Input:` and the pretty-printed JSON object, and a production run
 * (`plan:28e015f8`) asked to append the marker from its arguments appended the
 * invented line `unknown-marker` instead and reported success.
 *
 * An absent or empty input adds nothing at all: the task is the trimmed body,
 * byte for byte, so a flow that carries no input keeps the prompt it was
 * already cached under.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const prompt: (text: string, input: unknown) => RenderedPrompt;
/**
 * The journal record of what a launch input was rendered into.
 *
 * Without it an ignored argument is only visible in the diff of whatever the
 * run was asked to change, which is exactly the evidence a run that ignored
 * its argument does not produce. The record is bounded like every other trail
 * field, and it is written whether or not the flow declared an input, so an
 * empty `fields` is the positive statement that there was nothing to ignore.
 *
 * @category projections
 * @since 1.0.0
 */
export declare const promptRendered: (rendered: RenderedPrompt) => {
    readonly eventType: Transcript.ControlEventType;
    readonly payload: unknown;
};
/**
 * The failure the engine persists as this flow's settlement.
 *
 * `agent/run` declares `error: Schema.Unknown`, and `Schema.toCodecJson`
 * reads that as "any JSON value". Every real agent failure is an `Error`
 * instance instead — a `HarnessError` wrapping a `ModelError`, a
 * `SeatUnresolved` — so the codec rejected every one of them, `engine-store`
 * degraded the settlement into a projection, and it said so in a second WARN
 * stack beside the run's own `An agent run failed` (release validation observation
 * N1: two stack traces for one billing refusal).
 *
 * The rendering is the package's one failure serializer, shared with the
 * action and the budget boundaries so a nested `Error` reads the same in every
 * durable record rather than only in this one.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const settlementFailure: (error: unknown) => unknown;
/**
 * The one durable flow every agent run executes. Its plan-time body is inert;
 * the behaviour is the `execute` registered by {@link make}, and the
 * execution id is the control run id. A host re-drives a run by resuming it
 * under this address, which is also how an unrequested round reaches the
 * registered handler.
 *
 * @category flows
 * @since 1.0.0
 */
export declare const agentFlow: Flow.Flow<"agent/run", Schema.Struct<{
    runId: Schema.String;
    planId: Schema.String;
}>, Schema.Unknown, Schema.Unknown, never>;
/**
 * Waits for ControlLive to publish its running transition before a driver
 * starts the engine. Keeping the bounded retry here makes the publication race
 * deterministic to exercise without coupling it to a particular scheduler.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const waitForRunning: (status: (runId: string) => Effect.Effect<RunStatus, unknown>, runId: string, attempts: number, retryDelay?: Effect.Effect<void>) => Effect.Effect<boolean, unknown>;
/**
 * Polls a durable execution until it is published as parked. A missing poll is
 * a still-live execution, so retries are bounded before a resume is attempted.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const waitForParked: (poll: () => Effect.Effect<Option.Option<{
    readonly _tag: string;
}>, unknown>, attempts: number) => Effect.Effect<boolean, unknown>;
/**
 * Keeps a control cancellation durable even when its engine interrupt fails.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const preserveDriverInterrupt: <R>(interrupt: () => Effect.Effect<void, unknown, R>) => Effect.Effect<void, never, R>;
/**
 * Translates a failed driver registration into the executor's launch error.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const registerDriver: (register: () => Effect.Effect<void, unknown>, runId: string) => Effect.Effect<void, LaunchFailed>;
/**
 * Re-throws a cancelled driver while logging a non-interrupt engine failure.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const settleDriverFailure: <E, R>(cause: Cause.Cause<unknown>, runId: string, writeFailed: (detail: string) => Effect.Effect<void, E, R>) => Effect.Effect<void, E, R>;
/**
 * Records a cancellation on the engine row, whichever process owns the run.
 *
 * This is the durable half of `Control.cancel`. Interruption is a fiber
 * operation and fibers are process-local, so a cancel that only interrupted
 * would reach nothing when a second `flows` process, the UI, or a gateway asked
 * — the engine row's `cancel_requested_at_ms` is what the owning driver's
 * cancel poll reads, and it is first-writer-wins, so a repeat is harmless.
 *
 * `NotFound` is `unknown` rather than a failure: an engine that never heard of
 * the run has nothing to record, and the control plane's own interrupt and
 * journal entry are still the whole answer for a run this composition launched
 * nothing for.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const requestCancel: (input: ControlExecutor.CancelRequest) => Effect.Effect<ControlExecutor.CancelRecord, PersistenceError, RunStore.RunStore>;
/**
 * Reads current-round lifecycle and the requested run's ancestry from the
 * engine services captured by the host. The existing engine transaction keeps
 * these reads coherent; the SQLite adapter holds a writer lock only for the
 * scoped reads, without executing or waiting on the run.
 *
 * Control metadata is read separately. This is not a cross-database snapshot
 * or a revisioned read projection. A later trampoline round supplies lifecycle
 * and waiting state, while parent and round ordinal still name `runId`.
 *
 * @category queries
 * @since 0.1.0
 */
export declare const readExecution: (runId: string) => Effect.Effect<ControlExecutor.ExecutionObservation, PersistenceError, RunStore.RunStore | DurableEngineState.DurableEngineState>;
/**
 * Completes the `WaitFor` wait point a run is parked on with a signal's
 * payload.
 *
 * The wait point is read off the run's own waiting row rather than derived from
 * the flow, because the engine writes the deferred's token there when it parks
 * (`WaitFor.layer` annotates `reason: "event"` with the token). That makes the
 * bridge flow-agnostic: it completes whatever wait point the parked run
 * actually declared, through the ordinary `DurableDeferred.succeed` path every
 * other resolver uses, and the engine's own `scheduleResume` re-drives the run.
 *
 * The three answers are distinct on purpose. `delivered` completed a wait
 * point. `no-match` means the run IS parked and is waiting for something else —
 * a different signal name, an approval, a timer — which `Control.signal`
 * refuses rather than recording a delivery nothing consumes. `unknown` means
 * this executor can see no open wait point at all, which is not the same as
 * knowing there is none: another process may own the run, or it may not have
 * parked yet, and the recorded message is what a later start replays.
 *
 * A `delivered` answer also records the resume it is owed, through
 * `ControlRuntime.requestResume`. Completing the wait point is not on its own
 * enough to restart the run: {@link make}'s round guard re-enters a parked run
 * only for a delegation somebody recorded, and the only other caller of
 * `requestResume` is `ControlLive.decide`, which records one for an approval
 * TOKEN. Every ask answered by completing a wait point instead — each
 * `HumanTask` and `WaitFor` park, which is how the repository flows ask and how
 * the gateway routes `Approval.Submit` on a human wait — would otherwise settle
 * its deferred and leave the run parked on the question it had just answered.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const deliverSignal: (input: ControlExecutor.Signal) => Effect.Effect<ControlExecutor.SignalDelivery, PersistenceError, DurableEngineState.DurableEngineState | FlowRuntime.FlowRuntime>;
/**
 * Reconciles a bounded rotating page of admitted signal commands.
 *
 * The host runs this at startup and every 250 ms. A command without a
 * concrete wait stays pending; a bound command always retries its original
 * token, including after the run has settled but acknowledgment was lost.
 * Legacy payload-only messages are not replayed because their application
 * identity cannot be recovered safely.
 *
 * @category helpers
 * @since 0.1.0
 */
export declare const drainRecordedSignals: Effect.Effect<void, never, ControlRuntime | DurableEngineState.DurableEngineState | FlowRuntime.FlowRuntime>;
/** Everything the executor captures at construction and re-provides per run. */
type Services = Agent | ControlRuntime | Crypto.Crypto | DurableEngineState.DurableEngineState | FlowRuntime.FlowRuntime | Journal.Journal | NotificationQueue.NotificationQueue | Registry.Registry | RunStore.RunStore | SeatResolver;
/**
 * Constructs the production executor.
 *
 * Must be built in a scope: the scope owns the registered agent flow, every
 * forked run driver, and the resume bridge that follows the journal.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const make: (options: Options) => Effect.Effect<ControlExecutor.Service, never, Services | Scope.Scope>;
/**
 * Provides the production {@link ControlExecutor.ControlExecutor}.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layer: (options: Options) => Layer.Layer<ControlExecutor.ControlExecutor, never, Services>;
