/**
 * What a finished run leaves behind for the next one.
 *
 * A run's transcript is mined once, at run end. Two things come out of it
 * deterministically: candidate facts, the paragraphs of prose the model wrote
 * around its cells, and decisions, the messages a person typed as steering.
 * One Jev reading, `memory/mine`, asks two booleans per candidate: whether it
 * is a durable fact about the repository a later run needs, and whether it
 * names factory work a person should track. Both accept at the calibrated
 * fact bar, `MemoryCalibration.initial.decisions.fact`.
 *
 * {@link write} is the one writer of a mined fact: redacted, keyed by
 * {@link noteId}, accepted, with the run as provenance. `Agent.run` calls
 * {@link settle} when `supervisor.remember` is on and a `Supervisor.Memory`
 * that can write is bound; the `memory/mine` file flow reads a finished run's
 * journal through {@link extract} and {@link judge}.
 *
 * @since 1.0.0
 */
import * as AgentEvent from "@smthrs/harness/AgentEvent";
import type * as EngineLike from "@smthrs/harness/EngineLike";
import * as Judgement from "@smthrs/harness/Judgement";
import * as Supervisor from "@smthrs/harness/Supervisor";
import type * as MemoryError from "@smthrs/memory/MemoryError";
import type * as MemoryStore from "@smthrs/memory/MemoryStore";
import type * as Evaluator from "@smthrs/model/Evaluator";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
/**
 * The most paragraphs one reply offers as candidates.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const paragraphLimit = 4;
/**
 * The most candidates one run offers Jev, first seen first.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const candidateLimit = 64;
/**
 * The most decisions one run keeps, first seen first.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const decisionLimit = 64;
/**
 * The most characters one candidate carries.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const candidateChars = 400;
/**
 * The most characters one decision carries.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const decisionChars = 500;
/**
 * Where a run's decisions are appended, one `<item>.md` page per item, and
 * where `memory`'s wiki source reads them back as pages.
 *
 * @category constants
 * @since 1.0.0
 */
export declare const decisionsDirectory = "factory/wiki/decisions";
/**
 * One transcript row: its sequence, its event type and its payload.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const Row: Schema.Struct<{
    readonly seq: Schema.Int;
    readonly eventType: Schema.String;
    readonly payload: Schema.Unknown;
}>;
/**
 * The decoded form of {@link Row}.
 *
 * @category models
 * @since 1.0.0
 */
export type Row = typeof Row.Type;
/**
 * A sentence and the sequence of the row it came from.
 *
 * @category schemas
 * @since 1.0.0
 */
export declare const Cited: Schema.Struct<{
    readonly text: Schema.String;
    readonly seq: Schema.Int;
}>;
/**
 * The decoded form of {@link Cited}.
 *
 * @category models
 * @since 1.0.0
 */
export type Cited = typeof Cited.Type;
/**
 * The candidate paragraphs of one reply's prose. The whole text is redacted
 * first, so a secret is never cut in two by a clip, and every fenced block is
 * removed before the text is split on blank lines, so a blank line inside one
 * never frees its code as prose. Then the first {@link paragraphLimit}
 * paragraphs, each clipped to {@link candidateChars}.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const sentences: (prose: string) => ReadonlyArray<string>;
/**
 * The text a note id keys on: case, width and whitespace folded.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const normalize: (text: string) => string;
/**
 * The note id of `text` in `bank`.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const noteId: (bank: string, text: string) => string;
/**
 * A run's transcript as it is read: candidates distinct by normalized text,
 * and decisions, each bounded.
 *
 * @category models
 * @since 1.0.0
 */
export interface Transcript {
    readonly candidates: Array<Cited>;
    readonly decisions: Array<Cited>;
    readonly seen: Set<string>;
}
/**
 * An empty {@link Transcript}.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const transcript: () => Transcript;
/**
 * Reads one row into `into`: a settled reply's prose paragraphs as
 * candidates, a drained user message as a decision clipped to
 * {@link decisionChars}, anything else not at all. Both are redacted as the
 * journal redacts, whole, before anything is clipped.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const add: (into: Transcript, row: Row) => void;
/**
 * The candidates and decisions of a whole journal, in sequence order.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const extract: (rows: ReadonlyArray<Row>) => {
    readonly candidates: ReadonlyArray<Cited>;
    readonly decisions: ReadonlyArray<Cited>;
};
/**
 * The `memory/mine` reading: two booleans per candidate.
 *
 * @category classifiers
 * @since 1.0.0
 */
export declare const reading: Judgement.PerItem<{
    readonly task: string;
}, {
    readonly text: string;
}, {
    readonly durable: (index: number) => Evaluator.BooleanQuestion;
    readonly issue: (index: number) => Evaluator.BooleanQuestion;
}>;
/**
 * Whether a probability clears the calibrated fact bar.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const accepts: (p: number) => boolean;
/**
 * What one reading accepted.
 *
 * @category models
 * @since 1.0.0
 */
export interface Judged {
    readonly facts: ReadonlyArray<Cited>;
    readonly issues: ReadonlyArray<Cited>;
    readonly asked: ReadonlyArray<Judgement.Asked>;
}
/**
 * Asks Jev about every candidate, whole or failed. No candidates ask nothing.
 *
 * @category conversions
 * @since 1.0.0
 */
export declare const judge: (task: string, candidates: ReadonlyArray<Cited>) => Effect.Effect<Judged, Judgement.Unjudged, Evaluator.Evaluator>;
/**
 * Writes one fact to `bank`: redacted, keyed by {@link noteId}, accepted,
 * tagged `source:transcript`, with `runId` as provenance. A fact already
 * stored, however it was cased or spaced, is returned as it stands and never
 * written again: the store refuses a second note under one id with other
 * creation data, and the first run to learn a fact keeps it.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const write: (store: MemoryStore.Service, input: {
    readonly bank: string;
    readonly runId: string;
    readonly text: string;
}) => Effect.Effect<MemoryStore.Note, MemoryError.MemoryError>;
/**
 * Mines a run's transcript at run end and writes what Jev accepts through
 * `memory`.
 *
 * The reading is a durable boundary, `memory-mine` at `frame`, so a replayed
 * run is served the recorded reading and never asks again. It returns the
 * rows to journal: the reading's `decision-settled` rows, or one
 * `decision-unjudged` row when Jev could not answer, in which case nothing is
 * written; then a `supervisor-memory-failed` row for each fact the store
 * refused. An engine that cannot record the reading writes nothing and
 * journals one `supervisor-memory-failed` row with the engine's account.
 * None of it fails the run, which has already resolved.
 *
 * @category constructors
 * @since 1.0.0
 */
export declare const settle: (input: {
    readonly engine: EngineLike.EngineLike;
    readonly session: string;
    readonly frame: number;
    readonly task: string;
    readonly candidates: ReadonlyArray<Cited>;
    readonly memory: Supervisor.Memory;
}) => Effect.Effect<ReadonlyArray<AgentEvent.AgentEvent>, never, Evaluator.Evaluator>;
