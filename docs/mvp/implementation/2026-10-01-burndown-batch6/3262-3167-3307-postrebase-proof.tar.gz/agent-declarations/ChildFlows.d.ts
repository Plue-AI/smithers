/**
 * Subagents, expressed as ordinary executable flows.
 *
 * There is no `ctx.spawn`, no `ctx.send`, and no `ctx.await`. A cell delegates
 * the way it does anything else: it finds a flow in `ctx.flows` and calls it.
 *
 * Two shapes cover the ground:
 *
 * - **Attached children** need nothing in this module. A dynamic flow (a
 *   `Flow.make` with a `model`) or a discovered markdown flow is already a
 *   subagent, and `ctx.call("review", { args })` already runs it inside its own
 *   durable boundary — `CellCalls` resolves the markdown body and hands it to
 *   the host's prompt runner, and `FlowEngineLike.call` keys the whole thing on
 *   the cell identity. That is the common case, and it needed no new API.
 * - **Detached children** — spawn now, collect later — need lifecycle
 *   operations, and those are ordinary flow *names*: `agent/spawn`,
 *   `agent/send`, `agent/await`. They are bound here through the same
 *   {@link FlowBinding} contract as a filesystem read, so they get the same
 *   `CellCallStarted` / `CellCallSettled` trail and the same replay identity.
 *
 * The lifecycle is behind a narrow injected {@link Children} port rather than
 * implemented here. Nothing in a browser-safe package can honestly claim to
 * persist a detached run, and pretending otherwise would produce a child that
 * silently restarts on resume; a host that has a durable run store supplies one,
 * and a host that does not gets {@link makeNoop}, whose refusal the cell can see
 * and route around.
 *
 * @since 0.1.0
 */
import * as Flow from "@smthrs/core/Flow";
import * as FlowBinding from "@smthrs/harness/FlowBinding";
import type { HarnessError } from "@smthrs/harness/HarnessError";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
/**
 * Input for `agent/spawn`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const SpawnInput: Schema.Struct<{
    readonly flow: Schema.String;
    readonly input: Schema.optional<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly label: Schema.optional<Schema.String>;
}>;
/**
 * Output for `agent/spawn`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const SpawnOutput: Schema.Struct<{
    readonly child: Schema.String;
}>;
/**
 * Input for `agent/send`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const SendInput: Schema.Struct<{
    readonly child: Schema.String;
    readonly message: Schema.String;
}>;
/**
 * Output for `agent/send`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const SendOutput: Schema.Struct<{
    readonly delivered: Schema.Boolean;
}>;
/**
 * Input for `agent/await`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const AwaitInput: Schema.Struct<{
    readonly child: Schema.String;
    readonly timeoutSeconds: Schema.optional<Schema.Int>;
}>;
/**
 * Output for `agent/await`.
 *
 * @category schemas
 * @since 0.1.0
 */
export declare const AwaitOutput: Schema.Struct<{
    readonly child: Schema.String;
    readonly output: Schema.String;
}>;
/**
 * The `agent/spawn` declaration.
 *
 * @category flows
 * @since 0.1.0
 */
export declare const spawnFlow: Flow.Flow<Schema.Struct<{
    readonly flow: Schema.String;
    readonly input: Schema.optional<Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly label: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly child: Schema.String;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * The `agent/send` declaration.
 *
 * @category flows
 * @since 0.1.0
 */
export declare const sendFlow: Flow.Flow<Schema.Struct<{
    readonly child: Schema.String;
    readonly message: Schema.String;
}>, Schema.Struct<{
    readonly delivered: Schema.Boolean;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
/**
 * The `agent/await` declaration.
 *
 * @category flows
 * @since 0.1.0
 */
export declare const awaitFlow: Flow.Flow<Schema.Struct<{
    readonly child: Schema.String;
    readonly timeoutSeconds: Schema.optional<Schema.Int>;
}>, Schema.Struct<{
    readonly child: Schema.String;
    readonly output: Schema.String;
}>, Schema.Never, import("@smthrs/flow/Action").Requirement<string>>;
declare const ChildError_base: Schema.Class<ChildError, Schema.TaggedStruct<"@smthrs/agent/ChildFlows/ChildError", {
    readonly code: Schema.Literals<readonly ["unsupported", "not_found", "failed", "still_running"]>;
    readonly message: Schema.String;
    /** How long a `still_running` await waited, in milliseconds. */
    readonly limitMillis: Schema.optional<Schema.Number>;
}>, import("effect/Cause").YieldableError>;
/**
 * A child lifecycle refusal the agent can see and route around.
 *
 * Separate from `HarnessError` on purpose: an unsupported operation or a child
 * that failed is data the cell may catch, while a `HarnessError` is a park or an
 * abort the cell must never swallow. A host that needs to park a lifecycle
 * operation fails with the latter, or gates it in `Agent.Options.authorize`.
 *
 * @category errors
 * @since 0.1.0
 */
export declare class ChildError extends ChildError_base {
}
/**
 * The narrow child-run port a host supplies.
 *
 * @category services
 * @since 0.1.0
 */
export interface Children {
    readonly spawn: (input: typeof SpawnInput.Type) => Effect.Effect<typeof SpawnOutput.Type, HarnessError | ChildError>;
    readonly send: (input: typeof SendInput.Type) => Effect.Effect<typeof SendOutput.Type, HarnessError | ChildError>;
    readonly await: (input: typeof AwaitInput.Type) => Effect.Effect<typeof AwaitOutput.Type, HarnessError | ChildError>;
}
/**
 * Context service for the child-run port.
 *
 * @category services
 * @since 0.1.0
 */
export declare const Children: Context.Service<Children, Children>;
/**
 * Constructs a child port that refuses every operation.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeNoop: (overrides?: Partial<Children>) => Children;
/**
 * The name of the {@link source} that binds the lifecycle flows.
 *
 * @category constants
 * @since 1.0.0-rc.0
 */
export declare const sourceName = "agent/children";
/**
 * Detached child lifecycle, as three ordinary flows.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const source: (children: Children) => FlowBinding.Source;
export {};
