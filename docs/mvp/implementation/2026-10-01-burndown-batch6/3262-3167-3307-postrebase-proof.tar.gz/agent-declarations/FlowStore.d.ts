/**
 * Where a saved flow's files land.
 *
 * A model that promotes the script it just ran produces three ordinary files —
 * the flow, its end-to-end test, and the fixture that test replays — and they
 * have to be written somewhere the next run can discover them. That "somewhere"
 * is not one thing: a checkout writes into the working tree, a browser host
 * writes into session storage it owns, and a test writes into a map it can
 * inspect. This module is the one contract all three satisfy, so
 * `PromoteFlows` never learns which one it is talking to.
 *
 * The store is also the last place an id is still just text. Every path a write
 * builds comes from it, so {@link validateId} runs before any of them are built
 * rather than after: `../escape` is refused as a bad id, not caught as a
 * surprising write outside the root.
 *
 * @since 0.1.0
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Layer from "effect/Layer";
import * as Path from "effect/Path";
import * as Schema from "effect/Schema";
/**
 * Stable error codes returned by saved-flow storage.
 *
 * @category models
 * @since 0.1.0
 */
export declare const FlowStoreErrorCode: Schema.Literals<readonly ["invalid_id", "invalid_path", "write_failed", "unsupported"]>;
/**
 * Stable error codes returned by saved-flow storage.
 *
 * @category models
 * @since 0.1.0
 */
export type FlowStoreErrorCode = typeof FlowStoreErrorCode.Type;
declare const FlowStoreError_base: Schema.Class<FlowStoreError, Schema.TaggedStruct<"@smthrs/agent/FlowStore/FlowStoreError", {
    readonly code: Schema.Literals<readonly ["invalid_id", "invalid_path", "write_failed", "unsupported"]>;
    readonly message: Schema.String;
    readonly cause: Schema.optional<Schema.Unknown>;
}>, import("effect/Cause").YieldableError>;
/**
 * Error raised by saved-flow storage.
 *
 * Every message is written for the model that will read it back as a call
 * failure, because the cell that asked to save a flow is the only thing that
 * can correct the id or reissue the write.
 *
 * @category errors
 * @since 0.1.0
 */
export declare class FlowStoreError extends FlowStoreError_base {
}
/**
 * The flow ids a router can route.
 *
 * One directory name, lowercase, and no separators: a saved flow is discovered
 * as `flows/<id>/flow.ts`, so an id is exactly what may stand between those two
 * slashes.
 *
 * @category models
 * @since 0.1.0
 */
export declare const idPattern: RegExp;
/**
 * Refuses an id no flow directory could be named.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const validateId: (id: string) => Effect.Effect<void, FlowStoreError>;
/**
 * One flow the store already holds.
 *
 * @category models
 * @since 0.1.0
 */
export interface SavedFlow {
    /** The flow's id, which is also its directory name. */
    readonly id: string;
    /** Every file the store holds for it, root-relative and sorted. */
    readonly files: ReadonlyArray<string>;
}
/**
 * What one write recorded.
 *
 * @category models
 * @since 0.1.0
 */
export interface WriteResult {
    /** The paths that were written, in the order they were given. */
    readonly files: ReadonlyArray<string>;
}
/**
 * Saved-flow storage operations.
 *
 * @category models
 * @since 0.1.0
 */
export interface Service {
    /**
     * Writes one flow's files, keyed by their root-relative paths.
     *
     * The keys are the caller's own paths and are reported back unchanged, so a
     * host that mounts its flows somewhere else still tells the model where the
     * files went in terms the model gave it.
     */
    readonly write: (id: string, files: Record<string, string>) => Effect.Effect<WriteResult, FlowStoreError>;
    /** Every flow the store holds, by id. */
    readonly list: () => Effect.Effect<ReadonlyArray<SavedFlow>, FlowStoreError>;
}
declare const FlowStore_base: Context.ServiceClass<FlowStore, "@smthrs/agent/FlowStore", Service>;
/**
 * Service tag for saved-flow storage.
 *
 * @category services
 * @since 0.1.0
 */
export declare class FlowStore extends FlowStore_base {
}
/**
 * Constructs a store over an in-memory map, keyed by path.
 *
 * The map is the caller's, so a test writes through the store and reads the
 * bytes back without a filesystem. The listing is derived from the keys rather
 * than tracked separately, which is what lets a host hand in a map it populated
 * itself and still have the flows in it be listable. Every key must be a file
 * path under `flows/<id>/`; the whole write is refused before any key is stored
 * otherwise.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeMemory: (written?: Map<string, string>) => Service;
/**
 * Constructs a store over a directory on the host filesystem.
 *
 * Validates every path with the injected Path semantics and rejects symbolic
 * links below the root before staging. Writes to the same resolved root are
 * serialized within this process, including across store instances.
 * The entire file set and backups are staged inside the root before targets
 * are replaced by individual atomic renames. Publication failures restore the
 * previous files; interruption cleans staging or waits for publication to finish.
 * If recovery itself fails, backups remain at the location in the error.
 * Readers outside the store can observe publication in progress. This is not a
 * crash-durable transaction or a lock against other processes changing the tree.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeFileSystem: (fs: FileSystem.FileSystem, path: Path.Path, root: string) => Service;
/**
 * Constructs a store that saves nothing, optionally overriding operations.
 *
 * @category constructors
 * @since 0.1.0
 */
export declare const makeNoop: (overrides?: Partial<Service>) => Service;
/**
 * Provides a store over an in-memory map.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerMemory: (written?: Map<string, string>) => Layer.Layer<FlowStore>;
/**
 * Provides a store over a directory on the host filesystem.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerFileSystem: (root: string) => Layer.Layer<FlowStore, never, FileSystem.FileSystem | Path.Path>;
/**
 * Provides a store that saves nothing.
 *
 * @category layers
 * @since 0.1.0
 */
export declare const layerNoop: (overrides?: Partial<Service>) => Layer.Layer<FlowStore>;
export {};
