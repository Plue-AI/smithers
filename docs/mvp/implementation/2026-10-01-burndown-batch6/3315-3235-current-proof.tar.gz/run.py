import concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/smithers-burndown-20260930');out=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/3235-postrebase-f0b2b2c0e');old=json.loads(pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/3235-named-final-92a94c7b36/inputs-after.json').read_text());paths=set(old['files']);paths.update(p for p in subprocess.check_output(['rg','--files','packages','-g','*.ts'],cwd=root,text=True).splitlines() if 'src' in pathlib.Path(p).parts)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def capture(n):
 d={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(root/p) if (root/p).is_file() else None for p in sorted(paths)}};(out/n).write_text(json.dumps(d,indent=2)+'\n');return d
before=capture('inputs-before.json');env=dict(os.environ,PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+os.environ['PATH'],TMPDIR='/private/tmp',SMITHERS_WORKSPACE_JJ_EXPORT_BINARY='/Users/williamcory/smithers/target/debug/smithers-jj-export')
checks=[('actual-end-to-end16',['pnpm','exec','vitest','run','test/EndToEnd.test.ts','--coverage.enabled=false']),('affected-bin-lifecycle',['pnpm','exec','vitest','run','test/Bin.test.ts','-t',"keyless host startup|an attached launch's exit status|the smthrs init scaffold, launched as written|the signal exit codes|smthrs signal against a run parked on something else|refuses `--mcp` on a legacy verb",'--coverage.enabled=false']),('source-types',['pnpm','exec','tsc','-p','tsconfig.json','--noEmit']),('test-types',['pnpm','exec','tsc','-p','tsconfig.test.json','--noEmit'])]
def run(c):
 n,a=c;s=time.monotonic();log=out/(n+'.log')
 with log.open('w') as f:r=subprocess.run(a,cwd=root/'packages/smithers',env=env,stdout=f,stderr=subprocess.STDOUT)
 d={'name':n,'argv':a,'cwd':str(root/'packages/smithers'),'exitCode':r.returncode,'seconds':round(time.monotonic()-s,2),'receipt':str(log),'sha256':sha(log)};(out/(n+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:result=list(pool.map(run,checks))
after=capture('inputs-after.json');(out/'result.json').write_text(json.dumps({'checks':result,'checkedCandidate':before['head'],'headAfterChecks':after['head'],'changedDuringChecks':[p for p in paths if before['files'][p]!=after['files'][p]]},indent=2)+'\n')
