import { defineConfig } from "vitest/config"
export default defineConfig({test:{include:["StepKeyGolden.external.test.ts"],testTimeout:30000,coverage:{enabled:false}}})
