import concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/smithers-burndown-20260930');out=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/mcp-3315/green')
prior=json.loads(pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/settlement-final-4ac6469f6e/inputs-after.json').read_text());paths=set(prior['files']);paths.update(['packages/smithers/test/McpModeCli.test.ts','packages/smithers/test/Argv.test.ts','packages/smithers/vitest.config.ts','packages/smithers/eslint.config.js','packages/smithers/dprint.json'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def capture(name):
 d={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(root/p) if (root/p).is_file() else None for p in sorted(paths)}};(out/name).write_text(json.dumps(d,indent=2)+'\n');return d
before=capture('inputs-before.json')
env=dict(os.environ,PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+os.environ['PATH'],TMPDIR='/private/tmp',SMITHERS_WORKSPACE_JJ_EXPORT_BINARY='/Users/williamcory/smithers/target/debug/smithers-jj-export')
checks=[('legacy-mcp-refusal',['pnpm','exec','vitest','run','test/Bin.test.ts','-t','refuses `--mcp` on a legacy verb','--coverage.enabled=false']),('canonical-argument-and-real-mcp',['pnpm','exec','vitest','run','test/Argv.test.ts','test/McpModeCli.test.ts','--coverage.enabled=false']),('source-types',['pnpm','exec','tsc','-p','tsconfig.json','--noEmit']),('test-types',['pnpm','exec','tsc','-p','tsconfig.test.json','--noEmit']),('lint',['pnpm','exec','eslint','src/cli/LegacyBin.ts','--max-warnings=0']),('format',['pnpm','exec','dprint','check','src/cli/LegacyBin.ts'])]
def run(check):
 n,a=check;s=time.monotonic();log=out/(n+'.log')
 with log.open('w') as f:r=subprocess.run(a,cwd=root/'packages/smithers',env=env,stdout=f,stderr=subprocess.STDOUT)
 d={'name':n,'argv':a,'cwd':str(root/'packages/smithers'),'exitCode':r.returncode,'seconds':round(time.monotonic()-s,2),'receipt':str(log),'sha256':sha(log)};(out/(n+'-result.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,checks))
after=capture('inputs-after.json');(out/'result.json').write_text(json.dumps({'checks':results,'changedDuringChecks':[p for p in before['files'] if before['files'][p]!=after['files'][p]]},indent=2)+'\n')
