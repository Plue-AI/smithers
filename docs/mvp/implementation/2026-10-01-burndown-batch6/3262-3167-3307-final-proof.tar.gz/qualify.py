import concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/private/tmp/smithers-burndown-20260930')
out=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/settlement-final-4ac6469f6e')
prior=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch4/settlement-postrebase-49230e7543')
old=json.loads((prior/'inputs-before.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=set(old['files'])
changed=subprocess.check_output(['git','diff','--name-only',old['head'],'HEAD'],cwd=root,text=True).splitlines()
paths.update(p for p in changed if (root/p).is_file())
def capture(name):
 data={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p:sha(root/p) if (root/p).is_file() else None for p in sorted(paths)}}
 (out/name).write_text(json.dumps(data,indent=2)+'\n');return data
before=capture('inputs-before.json')
delta=[{'path':p,'before':old['files'].get(p),'after':before['files'].get(p)} for p in sorted(paths) if old['files'].get(p)!=before['files'].get(p)]
(out/'incoming-input-deltas.json').write_text(json.dumps({'oldHead':old['head'],'newHead':before['head'],'deltas':delta},indent=2)+'\n')
env=dict(os.environ,PATH='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:'+os.environ['PATH'],TMPDIR='/private/tmp',SMITHERS_WORKSPACE_JJ_EXPORT_BINARY='/Users/williamcory/smithers/target/debug/smithers-jj-export')
checks=[('actual-cli-and-cloud7',['pnpm','exec','vitest','run','test/Bin.test.ts','test/CloudSandboxCommand.integration.test.ts','-t','exits 1 for a run that settled failed|settles a failed launch with one terminal write|prints one operator-facing warning for one refusal|prints one operator-facing warning for one canonical agent refusal|CloudSandbox guarded command transport','--coverage.enabled=false']),('cli-test-types',['pnpm','exec','tsc','-p','tsconfig.test.json','--noEmit'])]
def run(check):
 name,argv=check;start=time.monotonic(); log=out/(name+'.log')
 with log.open('w') as f:r=subprocess.run(argv,cwd=root/'packages/smithers',env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'name':name,'argv':argv,'cwd':str(root/'packages/smithers'),'exitCode':r.returncode,'seconds':round(time.monotonic()-start,2),'receipt':str(log),'sha256':sha(log)}
 (out/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,checks))
after=capture('inputs-after.json')
(out/'result.json').write_text(json.dumps({'checks':results,'changedDuringChecks':[p for p in before['files'] if before['files'][p]!=after['files'][p]],'incomingDeltas':delta},indent=2)+'\n')
