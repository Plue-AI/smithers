import { spawn } from 'node:child_process'
import { createServer } from 'node:http'
import { mkdtemp, rm } from 'node:fs/promises'
const bin='/private/tmp/smithers-burndown-20260930/packages/smithers/src/bin.ts'
const home=await mkdtemp('/private/tmp/smithers-mcp-role-red-')
const requests=[]
const server=createServer(async(req,res)=>{let body='';for await(const chunk of req)body+=chunk;requests.push({method:req.method,url:req.url,body});res.setHeader('content-type','application/json');res.end(JSON.stringify({id:1,title:'--mcp'}))})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve))
try {
 for(const argv of [['runs','list','--format=json','--message','--mcp'],['runs','list','--format=json','--','--mcp'],['issue','create','--format=json','--repo','owner/repo','--title','--mcp']]){
  const child=spawn(process.execPath,['--no-warnings',bin,...argv],{cwd:home,env:{PATH:process.env.PATH,HOME:home,XDG_CONFIG_HOME:home,XDG_DATA_HOME:home,SMITHERS_API_ORIGIN:`http://127.0.0.1:${server.address().port}`,SMITHERS_TOKEN:'synthetic-mcp-role',SMITHERS_DISABLE_SYSTEM_KEYRING:'1'},stdio:['pipe','pipe','pipe']})
  let stdout='',stderr=''
  child.stdout.on('data',bytes=>{stdout+=bytes;if(stdout.includes('"id":1')||stdout.includes('"id": 1'))child.stdin.end()})
  child.stderr.on('data',bytes=>stderr+=bytes)
  child.stdin.on('error',()=>{})
  const timer=setTimeout(()=>child.kill('SIGKILL'),30000)
  child.stdin.write(JSON.stringify({jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:'2025-03-26',capabilities:{},clientInfo:{name:'mcp-role-counterexample',version:'1'}}})+'\n')
  const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}))})
  clearTimeout(timer)
  console.log(JSON.stringify({argv,...result,requests:[...requests],stdout,stderr}))
 }
} finally {
 server.closeAllConnections()
 await new Promise(resolve=>server.close(resolve))
 await rm(home,{recursive:true,force:true})
}
