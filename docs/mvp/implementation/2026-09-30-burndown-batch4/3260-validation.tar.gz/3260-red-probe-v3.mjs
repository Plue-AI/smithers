import { execFile } from 'node:child_process'
import { mkdtemp,mkdir,symlink,writeFile,readFile,rm } from 'node:fs/promises'
import { join } from 'node:path'
import { promisify } from 'node:util'
const execute=promisify(execFile),root=await mkdtemp('/private/tmp/smithers-fork-resume-3260-')
const bin='/private/tmp/smithers-burndown-20260930/packages/smithers/src/bin.ts'
const env={PATH:process.env.PATH,HOME:join(root,'home'),XDG_CONFIG_HOME:join(root,'config'),SMITHERS_WORKSPACE_JJ_EXPORT_BINARY:'/Users/williamcory/smithers/target/debug/smithers-jj-export',SMITHERS_DISABLE_SYSTEM_KEYRING:'1'}
const run=async(args)=>{const r=await execute(process.execPath,['--no-warnings',bin,...args,'--root',root,'--json'],{cwd:root,env,timeout:60000}).then(r=>({...r,code:0}),e=>({code:e.code,stdout:e.stdout,stderr:e.stderr}));let json;try{json=JSON.parse(r.stdout)}catch{}console.log(JSON.stringify({args,...r,json}));return {...r,json}}
try{
 await mkdir(join(root,'flows','steps'),{recursive:true});await symlink('/private/tmp/smithers-burndown-20260930/packages/smithers/node_modules',join(root,'node_modules'),'dir')
 await writeFile(join(root,'.gitignore'),'.flows/\nnode_modules\nhome/\nconfig/\n')
 await writeFile(join(root,'flows','steps','flow.ts'),`
import { Action, DurableClock, Flow } from '@smthrs/flow'
import { Node } from '@smthrs/plan'
import { Effect, Layer, Schema } from 'effect'
import { appendFileSync } from 'node:fs'
const marker = new URL('../../executed.jsonl', import.meta.url)
const First = Action.make('steps/First', { implementationVersion:'first/v1', payload:{}, success:Schema.String, tier:'irreversible', idempotencyKey:'first' })
const Finish = Action.make('steps/Finish', { implementationVersion:'finish/v1', payload:{}, success:Schema.String, tier:'irreversible', idempotencyKey:'finish' })
export const layer = Layer.merge(
 First.toLayer(()=>Effect.sync(()=>{appendFileSync(marker, 'first\\n');return 'first'}),{implementationVersion:'first/v1'}),
 Finish.toLayer(()=>Effect.gen(function*(){yield* DurableClock.sleep({name:'park',duration:'20 seconds',inMemoryThreshold:0});appendFileSync(marker,'finish\\n');return 'done'}),{implementationVersion:'finish/v1'})
)
export default Flow.make('steps', {
 description:'Recorded steps across a retained fork', capabilities:['fs:write:**'],
 effects:{reads:[],writes:['executed.jsonl'],mode:'expected',onConflict:'serialize',tier:'irreversible'},
 payload:{},success:Schema.String,
 body: Node.capture({action:First.name,implementationVersion:'first/v1'},()=>First.call({}).pipe(Node.bindPlanned(Node.capture({action:Finish.name,implementationVersion:'finish/v1'},()=>Finish.call({})))))
})
`)
 await execute('jj',['git','init',root],{env,cwd:root})
 const start=await run(['flow','start','steps','--data','{}','--wait'])
 if(start.code!==0||!start.json?.runId)throw new Error('actual module start did not reach admission')
 const original=await run(['runs','show',start.json.runId]);console.log(JSON.stringify({root,originalMarker:await readFile(join(root,'executed.jsonl'),'utf8').catch(()=>undefined)}))
 const fork=await run(['runs','fork',start.json.runId]);if(fork.code!==0||!fork.json?.runId)throw new Error('fork did not exist')
 const resume=await run(['runs','resume',fork.json.runId]);const shown=await run(['runs','show',fork.json.runId])
 console.log(JSON.stringify({root,original:start.json.runId,fork:fork.json,resume:resume.json,shown:shown.json,originalMarker:await readFile(join(root,'executed.jsonl'),'utf8').catch(()=>undefined),forkMarker:await readFile(join(fork.json.workspace,'executed.jsonl'),'utf8').catch(()=>undefined)}))
}catch(cause){console.log(JSON.stringify({failure:String(cause),root}));process.exitCode=1}finally{await rm(root,{recursive:true,force:true})}
