import { plugin } from "bun"
import { readFileSync } from "node:fs"
import { createHash } from "node:crypto"
const source = readFileSync(new URL("./3277-before-auth-billing.ts.txt", import.meta.url), "utf8")
if (createHash("sha256").update(source).digest("hex") !== "ffe3af11d814d7c22379add73fb2ef86a4415e4185161d15563f7a632728b094") throw Error("Frozen source changed")
plugin({name:"frozen-before-grant-contract",setup(build){build.onLoad({filter:/\/controller\/auth-billing\.ts$/},()=>({contents:source,loader:"ts"}))}})
