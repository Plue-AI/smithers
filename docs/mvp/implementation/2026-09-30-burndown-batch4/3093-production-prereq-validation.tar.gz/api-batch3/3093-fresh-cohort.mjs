import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readdir, readFile, mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { join, relative } from 'node:path'
import { readWorkspaceManifests, workspaceDependencies, dependencyOrder, assertBuilt, stagePackage, packResultFilename } from '/private/tmp/smithers-burndown-20260930/scripts/pack-release.mjs'
import { releaseRegistry } from '/private/tmp/smithers-burndown-20260930/scripts/release-registry.mjs'
import { runCliMcpConsumer } from '/private/tmp/smithers-burndown-20260930/scripts/release-consumers.mjs'
const root='/private/tmp/smithers-burndown-20260930'
const receipts='/tmp/smithers-burndown-20260930-receipts/api-batch3'
const packs=join(receipts,'3093-fresh-packs')
const hash=bytes=>createHash('sha256').update(bytes).digest('hex')
const all=readWorkspaceManifests(root)
const graph=workspaceDependencies(all)
const directories=[...all.keys()]
const cli=directories.find(directory=>all.get(directory).name==='@smthrs/cli')
const selected=new Set()
function visit(directory){if(selected.has(directory))return;selected.add(directory);for(const dep of graph.get(directory))visit(dep)}
visit(cli)
const order=dependencyOrder(new Map([...graph].filter(([directory])=>selected.has(directory))))
const tracked=execFileSync('git',['ls-files','-z'],{cwd:root,encoding:'utf8'}).split('\0').filter(Boolean)
const shared=tracked.filter(file=>file.startsWith('scripts/')||file.startsWith('packages/repo-targets/scripts/')||file.startsWith('packages/smithers/scripts/')||['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.json','tsconfig.base.json'].includes(file))
const authored=directory=>tracked.filter(file=>file.startsWith(directory+'/')&&!directories.some(other=>other!==directory&&other.startsWith(directory+'/')&&file.startsWith(other+'/')))
async function inputs(directory){const values={};for(const file of [...new Set([...shared,...authored(directory)])].sort())values[file]=hash(await readFile(join(root,file)));return values}
async function tree(directory){const values={};async function walk(current){for(const entry of await readdir(current,{withFileTypes:true})){const file=join(current,entry.name);if(entry.isDirectory())await walk(file);else if(entry.isFile())values[relative(directory,file)]=hash(await readFile(file));else throw new Error('Unexpected artifact symlink: '+file)}}await walk(directory);return values}
const provenance={head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),node:process.version,pnpm:execFileSync('pnpm',['--version'],{cwd:root,encoding:'utf8'}).trim(),scope:'fresh mandatory CLI dependency closure; no reused tarballs or consumer overrides',order:order.map(directory=>({directory,name:all.get(directory).name})),packages:[],results:[]}
const save=()=>writeFile(join(receipts,'3093-fresh-cohort.json'),JSON.stringify(provenance,null,2)+'\n')
const staging=await mkdtemp('/private/tmp/smithers-fresh-cli-packs-')
let registry
try {
 await mkdir(packs,{recursive:true})
 assert.equal((await readdir(packs)).length,0,'Fresh pack destination must be empty')
 for(const directory of order){
  const manifest=all.get(directory)
  console.log(JSON.stringify({event:'build-pack',name:manifest.name,directory}))
  const before=await inputs(directory)
  await assertBuilt(join(root,directory),manifest)
  assert.deepEqual(await inputs(directory),before,'Authored build inputs changed during '+manifest.name)
  const staged=join(staging,manifest.name.replaceAll('/','_'))
  await stagePackage(join(root,directory),staged,manifest)
  const output=JSON.parse(execFileSync('pnpm',['--dir',staged,'pack','--json','--config.ignore-scripts=true','--pack-destination',packs],{encoding:'utf8',maxBuffer:32*1024*1024}))
  const filename=packResultFilename(Array.isArray(output)?output[0]:output,manifest.name)
  const bytes=await readFile(join(packs,filename))
  const entry={name:manifest.name,version:manifest.version,filename,integrity:'sha512-'+createHash('sha512').update(bytes).digest('base64')}
  provenance.packages.push({...entry,directory,sourceInputs:before,artifacts:await tree(join(root,directory,'dist')),tarballSha256:hash(bytes)})
  await save()
  await rm(staged,{recursive:true,force:true})
 }
 const entries=provenance.packages.map(({name,version,filename,integrity})=>({name,version,filename,integrity}))
 await writeFile(join(packs,'manifest.json'),JSON.stringify(entries,null,2)+'\n')
 // Recheck the entire producer cohort after all clean builds, before serving it.
 for(const entry of provenance.packages)assert.deepEqual(await inputs(entry.directory),entry.sourceInputs,'Cohort input drift: '+entry.name)
 registry=await releaseRegistry(packs,entries)
 for(const manager of ['npm','pnpm']){
  console.log(JSON.stringify({event:'fresh-cli-consumer',manager}))
  provenance.results.push(await runCliMcpConsumer(manager,registry.url,all.get(cli).version,{env:{PATH:process.env.PATH,TMPDIR:'/private/tmp',SMITHERS_DISABLE_SYSTEM_KEYRING:'1'}}))
  await save()
 }
 provenance.completed=true
 await save()
} catch(error) {
 provenance.error={message:error.message,stack:error.stack}
 await save()
 throw error
} finally {
 await registry?.close()
 await rm(staging,{recursive:true,force:true})
 console.log(JSON.stringify({event:'cleanup',stagingRemoved:true,registryClosed:true}))
}
