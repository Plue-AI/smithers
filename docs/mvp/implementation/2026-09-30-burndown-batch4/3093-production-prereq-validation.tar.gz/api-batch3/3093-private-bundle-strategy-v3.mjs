import { execFile } from 'node:child_process'
import { mkdtemp,mkdir,readFile,writeFile,rm,readdir,cp,rename,realpath } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { dirname,join,relative } from 'node:path'
import { promisify } from 'node:util'
import assert from 'node:assert/strict'
import {releaseRegistry} from '/private/tmp/smithers-burndown-20260930/scripts/release-registry.mjs'
import {installedEffectFamily} from '/private/tmp/smithers-burndown-20260930/scripts/release-mcp-handshake.mjs'
const execute=promisify(execFile),root=await mkdtemp('/private/tmp/smithers-private-bundle-3093-'),version='4.0.0-rc.115'
const require=createRequire('/private/tmp/smithers-burndown-20260930/packages/smithers/package.json'),{build}=require('esbuild')
const adapters=new Map(['node','node-shared','bun'].map(key=>['@effect/platform-'+key,{key,root:dirname(require.resolve('@effect/platform-'+key+'/package.json'))}]))
const files=async(directory)=>{const entries=await readdir(directory,{withFileTypes:true});return(await Promise.all(entries.map(e=>e.isDirectory()?files(join(directory,e.name)):[join(directory,e.name)]))).flat()}
let registry
try{
 const pkg=join(root,'publish'),vendor=join(pkg,'dist/vendor'),entryPoints={}
 await mkdir(vendor,{recursive:true})
 const ordinary=new Map()
 for(const [name,adapter]of adapters){
  const m=JSON.parse(await readFile(join(adapter.root,'package.json'),'utf8'));assert.equal(m.version,version)
  for(const name of Object.keys({...m.dependencies,...m.peerDependencies}))if(!adapters.has(name)&&name!=='effect'&&!m.peerDependenciesMeta?.[name]?.optional){const own=createRequire(join(adapter.root,'package.json'));ordinary.set(name,own(name+'/package.json').version)}
  for(const file of await files(join(adapter.root,'dist'))){
   const out=join(vendor,adapter.key,relative(join(adapter.root,'dist'),file));
   if(file.endsWith('.js'))entryPoints[relative(vendor,out).slice(0,-3)]=file
   if(file.endsWith('.d.ts')){
    await mkdir(dirname(out),{recursive:true});let text=await readFile(file,'utf8')
    text=text.replace(/(["'])(@effect\/platform-(?:node-shared|node|bun))(\/[^"']*)?\1/g,(_all,quote,name,suffix)=>{
     const target=join(vendor,adapters.get(name).key,(suffix?suffix.slice(1):'index')+'.js');let path=relative(dirname(out),target);if(!path.startsWith('.'))path='./'+path;return quote+path+quote
    });await writeFile(out,text)
   }
  }
  for(const entry of await readdir(adapter.root))if(/license/i.test(entry)){await mkdir(join(vendor,adapter.key),{recursive:true});await cp(join(adapter.root,entry),join(vendor,adapter.key,entry))}
  await writeFile(join(vendor,adapter.key,'source-identity.json'),JSON.stringify({name,version:m.version}))
 }
 const result=await build({entryPoints,outdir:vendor,format:'esm',splitting:true,bundle:true,platform:'node',target:'node26',metafile:true,external:['effect','effect/*',...ordinary.keys(),'bun','bun:*'],logLevel:'silent'})
 for(const file of Object.keys(result.metafile.inputs))if(file.includes('/@effect/'))assert.ok([...adapters.values()].some(a=>join(process.cwd(),file).startsWith(a.root+'/')||file.startsWith(a.root+'/')),'unapproved adapter input '+file)
 console.log(JSON.stringify({bundleInputCount:Object.keys(result.metafile.inputs).length,privateAdapterSources:[...adapters].map(([name,a])=>({name,root:a.root,version})),externalEffect:true,ordinary:[...ordinary]}))
 const manifest={name:'@smthrs/probe-cli-private-adapters',version:'1.0.0',packageManager:'pnpm@11.25.0',type:'module',files:['dist'],dependencies:{effect:version,typescript:'7.0.2',...Object.fromEntries(ordinary)},exports:{'.':{import:{types:'./dist/index.d.ts',default:'./dist/index.js'},require:{types:'./dist/index.d.cts',default:'./dist/index.cjs'}},'./package.json':'./package.json'}}
 await writeFile(join(pkg,'package.json'),JSON.stringify(manifest))
 await writeFile(join(pkg,'dist/index.js'),`import * as Fs from './vendor/node/NodeFileSystem.js';import * as Http from './vendor/node/NodeHttpClient.js';import * as Effect from 'effect/Effect';export const layer=Fs.layer;export const http=Http.layer;export const core=Effect;`)
 await writeFile(join(pkg,'dist/index.cjs'),`const Fs=require('./vendor/node/NodeFileSystem.js');const Http=require('./vendor/node/NodeHttpClient.js');exports.layer=Fs.layer;exports.http=Http.layer;exports.core=require('effect/Effect');`)
 const d=`export {layer} from './vendor/node/NodeFileSystem.js';export {layer as http} from './vendor/node/NodeHttpClient.js';export * as core from 'effect/Effect';\n`
 await writeFile(join(pkg,'dist/index.d.ts'),d);await writeFile(join(pkg,'dist/index.d.cts'),d)
 const packed=await execute('pnpm',['pack','--pack-destination',root,'--json'],{cwd:pkg,env:process.env,timeout:30000});console.log(JSON.stringify({canonicalPack:packed}))
 const packedFile=(await readdir(root)).find(name=>name.endsWith('.tgz'));assert.ok(packedFile)
 registry=await releaseRegistry(root,[{name:manifest.name,version:manifest.version,filename:packedFile}])
 console.log(JSON.stringify({scope:'external strategy proof: real pinned adapters built by esbuild, synthetic CLI export, canonical pnpm pack; not the product cohort/MCP',published:manifest}))
 for(const manager of ['npm','pnpm']){
  const consumer=join(root,'consumer-'+manager);await mkdir(consumer);await writeFile(join(consumer,'package.json'),JSON.stringify({private:true,packageManager:'pnpm@11.25.0',dependencies:{[manifest.name]:manifest.version}}));await writeFile(join(consumer,'.npmrc'),'@smthrs:registry='+registry.url+'\n')
  const args=manager==='npm'?['install','--ignore-scripts','--cache',join(consumer,'cache'),'--no-audit','--no-fund']:['install','--ignore-scripts','--store-dir',join(consumer,'store'),'--cache-dir',join(consumer,'cache'),'--package-import-method=hardlink','--reporter=append-only']
  console.log(JSON.stringify({manager,args,...await execute(manager,args,{cwd:consumer,env:process.env,timeout:180000,maxBuffer:16*1024*1024})}))
  const code=`import assert from 'node:assert/strict';import {createRequire} from 'node:module';import * as a from '@smthrs/probe-cli-private-adapters';const r=createRequire(process.cwd()+'/package.json');const b=r('@smthrs/probe-cli-private-adapters');const q=createRequire(r.resolve('@smthrs/probe-cli-private-adapters/package.json'));assert.equal(a.layer,b.layer);assert.equal(a.http,b.http);assert.equal(a.core,b.core);assert.equal(a.core.succeed,q('effect/Effect').succeed);assert.throws(()=>q.resolve('@effect/platform-node/package.json'));console.log(JSON.stringify({esmCjsLayerIdentity:true,singleCore:true,noExternalAdapter:true}));`
  console.log((await execute(process.execPath,['--input-type=module','-e',code],{cwd:consumer,timeout:30000})).stdout)
  for(const ext of ['mts','cts'])await writeFile(join(consumer,'proof.'+ext),`import {layer,http,core} from '@smthrs/probe-cli-private-adapters';const value: core.Effect<number> = core.succeed(1);void layer;void http;void value;\n// @ts-expect-error negative any control\ncore.missingConsumerField;\n// @ts-expect-error layer is not any\nlayer.missingConsumerField;\n`)
  const own=createRequire(await realpath(join(consumer,'node_modules/@smthrs/probe-cli-private-adapters/package.json'))),tsc=join(dirname(own.resolve('typescript/package.json')),'bin/tsc')
  for(const module of ['Node16','NodeNext'])console.log(JSON.stringify({manager,module,...await execute(process.execPath,[tsc,'--noEmit','--strict','--skipLibCheck','--target','ES2022','--module',module,'--moduleResolution',module,'proof.mts','proof.cts'],{cwd:consumer,timeout:30000})}))
  const family=installedEffectFamily(consumer);assert.deepEqual(family.map(item=>[item.name,item.version]),[['effect',version]]);console.log(JSON.stringify({manager,family,typedEsmCjs:true}))
 }
}finally{await registry?.close();await rm(root,{recursive:true,force:true});console.log(JSON.stringify({cleanup:true}))}
