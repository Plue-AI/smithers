import assert from 'node:assert/strict'
import { execFile } from 'node:child_process'
import { mkdtemp,mkdir,writeFile,rm,readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { promisify } from 'node:util'
import { createHash } from 'node:crypto'
import { releaseRegistry } from '/private/tmp/smithers-burndown-20260930/scripts/release-registry.mjs'
import { installedEffectFamily } from '/private/tmp/smithers-burndown-20260930/scripts/release-mcp-handshake.mjs'
const execute=promisify(execFile),root=await mkdtemp('/private/tmp/smithers-peer-strategy-3093-'),version='4.0.0-rc.115'
const evidence={scope:'real external Effect adapters, synthetic published CLI/leaf dependency manifests; graph strategy proof, not packed product qualification',cases:[]}
let registry
try {
 const entries=[]
 for (const leaf of [false,true]) for (const peer of [false,true]) {
  const name='@smthrs/probe-'+(leaf?'leaf-':'cli-')+(peer?'peer':'sibling'),directory=join(root,name.replaceAll('/','_'))
  await mkdir(join(directory,'package'),{recursive:true})
  const manifest={name,version:'1.0.0',type:'module',main:'index.js',dependencies:{effect:version,'@effect/platform-node':version,'@effect/platform-bun':version,'@effect/platform-node-shared':version,...(!leaf?{'@smthrs/probe-leaf-sibling':'1.0.0'}:{})},...(peer?{peerDependencies:{'@effect/platform-node-shared':version}}:{})}
  await writeFile(join(directory,'package','package.json'),JSON.stringify(manifest));await writeFile(join(directory,'package','index.js'),'export const probe=true\n')
  const filename=name.replaceAll('/','_')+'.tgz';await execute('tar',['-czf',join(root,filename),'-C',directory,'package'])
  entries.push({name,version:'1.0.0',filename});console.log(JSON.stringify({publishedFixture:manifest,tarballSha256:createHash('sha256').update(await readFile(join(root,filename))).digest('hex')}))
 }
 registry=await releaseRegistry(root,entries)
 for(const peer of [false,true]) {
  const consumer=join(root,peer?'consumer-peer':'consumer-sibling');await mkdir(consumer)
  await writeFile(join(consumer,'package.json'),JSON.stringify({private:true,dependencies:{['@smthrs/probe-cli-'+(peer?'peer':'sibling')]:'1.0.0'}}))
  await writeFile(join(consumer,'.npmrc'),'@smthrs:registry='+registry.url+'\n')
  const args=['install','--ignore-scripts','--store-dir',join(consumer,'.fresh-store'),'--cache-dir',join(consumer,'.fresh-cache'),'--package-import-method=hardlink','--reporter=append-only']
  console.log(JSON.stringify({event:'install',peer,command:'pnpm',args,cwd:consumer}))
  const result=await execute('pnpm',args,{cwd:consumer,env:{PATH:process.env.PATH,HOME:join(consumer,'home'),XDG_CONFIG_HOME:join(consumer,'config')},timeout:180000,maxBuffer:16*1024*1024})
  console.log(JSON.stringify({peer,...result}));const family=installedEffectFamily(consumer);const off=family.filter(p=>p.version!==version)
  const roots=await execute(process.execPath,['--input-type=module','-e',`import {createRequire} from 'node:module';import {realpathSync} from 'node:fs';const r=createRequire(process.cwd()+'/package.json');for(const name of ['@effect/platform-node','@effect/platform-bun']){const p=r.resolve('@smthrs/probe-cli-${peer?'peer':'sibling'}/package.json');const q=createRequire(p);const a=q.resolve(name+'/package.json');const ar=createRequire(a);console.log(JSON.stringify({adapter:name,path:realpathSync(a),shared:ar('@effect/platform-node-shared/package.json').version,sharedPath:realpathSync(ar.resolve('@effect/platform-node-shared/package.json'))}))}`],{cwd:consumer,timeout:30000})
  console.log(roots.stdout);evidence.cases.push({peer,consumerDependencies:JSON.parse(await readFile(join(consumer,'package.json'),'utf8')).dependencies,family,off,adapterResolution:roots.stdout,lockfile:await readFile(join(consumer,'pnpm-lock.yaml'),'utf8')})
 }
 evidence.peerEnforcesAll=evidence.cases.find(c=>c.peer).off.length===0;evidence.baselineOffPin=evidence.cases.find(c=>!c.peer).off.length>0
 console.log(JSON.stringify(evidence))
} finally {await registry?.close();await rm(root,{recursive:true,force:true});console.log(JSON.stringify({cleanup:true}))}
