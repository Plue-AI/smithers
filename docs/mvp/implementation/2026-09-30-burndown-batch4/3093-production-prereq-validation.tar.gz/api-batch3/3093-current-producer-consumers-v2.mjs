import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {execFile} from 'node:child_process'
import {mkdtemp,mkdir,writeFile,readFile,symlink,realpath,rm,readdir} from 'node:fs/promises'
import {createRequire} from 'node:module'
import {dirname,join} from 'node:path'
import {promisify} from 'node:util'
import {buildPrivateEffectAdapters} from '/private/tmp/smithers-burndown-20260930/packages/repo-targets/scripts/private-effect-adapters.mjs'
import {releaseRegistry} from '/private/tmp/smithers-burndown-20260930/scripts/release-registry.mjs'
import {installedEffectFamily} from '/private/tmp/smithers-burndown-20260930/scripts/release-mcp-handshake.mjs'
const execute=promisify(execFile),root=await mkdtemp('/private/tmp/smithers-current-producer-3093-'),version='4.0.0-rc.115'
const names=['@smthrs/probe-platform','@smthrs/probe-cli-currentproducer'],source='/private/tmp/smithers-burndown-20260930/packages/smithers',adapters=['@effect/platform-node','@effect/platform-node-shared','@effect/platform-bun']
let registry
try{
 const entries=[]
 for(const [index,name]of names.entries()){
  const pkg=join(root,'owner-'+index);await mkdir(join(pkg,'dist/esm'),{recursive:true});await mkdir(join(pkg,'dist/cjs'),{recursive:true});await symlink(join(source,'node_modules'),join(pkg,'node_modules'))
  const manifest={name,version:'1.0.0',type:'module',packageManager:'pnpm@11.25.0',files:['dist'],smthrs:{privateEffectAdapters:adapters},dependencies:{effect:version,typescript:'5.9.3',undici:'8.10.2',redis:'6.2.1',ws:'8.21.3','@types/ws':'8.18.1',...(index?{[names[0]]:'1.0.0'}:{})},devDependencies:Object.fromEntries(adapters.map(name=>[name,version])),exports:{'.':{import:{types:'./dist/esm/index.d.ts',default:'./dist/esm/index.js'},require:{types:'./dist/cjs/index.d.ts',default:'./dist/cjs/index.js'}},'./package.json':'./package.json'}}
  await writeFile(join(pkg,'package.json'),JSON.stringify(manifest));await writeFile(join(pkg,'dist/cjs/package.json'),'{"type":"commonjs"}')
  const code=index?`import {layer} from '${names[0]}';import * as E from 'effect/Effect';import * as F from 'effect/FileSystem';export const read=(p)=>E.runPromise(E.gen(function*(){const f=yield*F.FileSystem;return yield*f.readFileString(p)}).pipe(E.provide(layer)));export {layer as ownLayer} from '@effect/platform-node/NodeFileSystem';export {succeed} from 'effect/Effect';`:`export {layer} from '@effect/platform-node/NodeFileSystem';export {succeed} from 'effect/Effect';`
  const declaration=index?`export declare const read:(path:string)=>Promise<string>;export {layer as ownLayer} from '@effect/platform-node/NodeFileSystem';export {layer as bunLayer} from '@effect/platform-bun/BunServices';export {succeed} from 'effect/Effect';`:`export {layer} from '@effect/platform-node/NodeFileSystem';export {succeed} from 'effect/Effect';`
  await writeFile(join(pkg,'dist/esm/index.js'),code);await writeFile(join(pkg,'dist/cjs/index.js'),`module.exports=require('../esm/index.js');`)
  await writeFile(join(pkg,'dist/esm/index.d.ts'),declaration);await writeFile(join(pkg,'dist/cjs/index.d.ts'),declaration)
  await buildPrivateEffectAdapters(pkg)
  const packed=await execute('pnpm',['pack','--pack-destination',root,'--json'],{cwd:pkg,env:process.env,timeout:30000});const parsed=JSON.parse(packed.stdout);entries.push({name,version:'1.0.0',filename:parsed.filename.split('/').at(-1)});console.log(JSON.stringify({published:manifest,canonicalPack:parsed.filename,packedFileCount:parsed.files.length,sha256:createHash('sha256').update(await readFile(parsed.filename)).digest('hex')}))
 }
 registry=await releaseRegistry(root,entries)
 for(const manager of ['npm','pnpm']){
  const consumer=join(root,'consumer-'+manager);await mkdir(consumer);await writeFile(join(consumer,'package.json'),JSON.stringify({private:true,packageManager:'pnpm@11.25.0',dependencies:{[names[1]]:'1.0.0'}}));await writeFile(join(consumer,'.npmrc'),'@smthrs:registry='+registry.url+'\n')
  const args=manager==='npm'?['install','--ignore-scripts','--cache',join(consumer,'cache'),'--no-audit','--no-fund']:['install','--ignore-scripts','--store-dir',join(consumer,'store'),'--cache-dir',join(consumer,'cache'),'--package-import-method=hardlink','--reporter=append-only'];console.log(JSON.stringify({manager,installer:await execute(manager,args,{cwd:consumer,env:process.env,timeout:180000,maxBuffer:16*1024*1024})}))
  const family=installedEffectFamily(consumer);assert.deepEqual(family.map(p=>[p.name,p.version]),[['effect',version]])
  await writeFile(join(consumer,'actual.txt'),'fresh cross-owner filesystem')
  const code=`import assert from 'node:assert/strict'
import {createHash} from 'node:crypto';import {createRequire} from 'node:module';import * as a from '${names[1]}';const r=createRequire(process.cwd()+'/package.json'),b=r('${names[1]}'),q=createRequire(r.resolve('${names[1]}/package.json'));assert.equal(a.ownLayer,b.ownLayer);assert.equal(a.succeed,b.succeed);assert.equal(a.succeed,q('effect/Effect').succeed);assert.equal(await a.read('./actual.txt'),'fresh cross-owner filesystem');assert.equal(await b.read('./actual.txt'),'fresh cross-owner filesystem');assert.throws(()=>q.resolve('@effect/platform-node/package.json'));console.log('ESM+CJS cross-owner filesystem and core identity PASS');`
  console.log((await execute(process.execPath,['--input-type=module','-e',code],{cwd:consumer,timeout:30000})).stdout)
  for(const ext of ['mts','cts'])await writeFile(join(consumer,'proof.'+ext),`import {read,ownLayer,bunLayer} from '${names[1]}';const value:Promise<string>=read('x');void value;\n// @ts-expect-error Node layer is typed\nownLayer.missingConsumerField;\n// @ts-expect-error Bun layer is typed\nbunLayer.missingConsumerField;\n`)
  const own=createRequire(await realpath(join(consumer,'node_modules',names[1],'package.json'))),tsc=join(dirname(own.resolve('typescript/package.json')),'bin/tsc')
  for(const module of ['Node16','NodeNext'])console.log(JSON.stringify({manager,module,compiler:await execute(process.execPath,[tsc,'--noEmit','--strict','--skipLibCheck','--target','ES2022','--module',module,'--moduleResolution',module,'proof.mts','proof.cts'],{cwd:consumer,timeout:30000})}))
  console.log(JSON.stringify({manager,family,consumerDeclaredOnlyCli:true,overrides:false,scope:'actual shared producer with synthetic public packages; mandatory product cohort/MCP remains unrun'}))
 }
}finally{await registry?.close();await rm(root,{recursive:true,force:true});console.log(JSON.stringify({cleanup:true}))}
