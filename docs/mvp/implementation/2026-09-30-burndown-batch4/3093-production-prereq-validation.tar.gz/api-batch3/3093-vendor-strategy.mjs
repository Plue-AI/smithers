import { execFile } from 'node:child_process'
import { mkdtemp, mkdir, readFile, writeFile, cp, rm, readdir, realpath } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { promisify } from 'node:util'
import assert from 'node:assert/strict'
import { releaseRegistry } from '/private/tmp/smithers-burndown-20260930/scripts/release-registry.mjs'
import { installedEffectFamily } from '/private/tmp/smithers-burndown-20260930/scripts/release-mcp-handshake.mjs'
const execute=promisify(execFile), version='4.0.0-rc.115', root=await mkdtemp('/private/tmp/smithers-vendor-strategy-3093-')
const require=createRequire('/private/tmp/smithers-burndown-20260930/packages/smithers/package.json')
const pinned=new Map(['@effect/platform-node','@effect/platform-bun','@effect/platform-node-shared'].map(name=>[name,require.resolve(name+'/package.json')]))
let registry
try {
 const pkg=join(root,'publish/package'),vendor=join(pkg,'dist/vendor/node_modules'),seen=new Map()
 await mkdir(vendor,{recursive:true})
 const capture=async (path)=>{
  const manifest=JSON.parse(await readFile(path,'utf8'))
  if(manifest.name==='effect') {assert.equal(manifest.version,version);return}
  if(seen.has(manifest.name)){assert.equal(seen.get(manifest.name),manifest.version);return}
  if(manifest.name.startsWith('@effect/'))assert.equal(manifest.version,version)
  seen.set(manifest.name,manifest.version)
  const source=dirname(await realpath(path)),target=join(vendor,manifest.name)
  await cp(source,target,{recursive:true,filter:path=>!path.slice(source.length).split('/').includes('node_modules')})
  const own=createRequire(path)
  for(const name of new Set([...Object.keys(manifest.dependencies??{}),...Object.keys(manifest.peerDependencies??{})])){
   if(manifest.peerDependenciesMeta?.[name]?.optional)continue
   await capture(pinned.get(name)??own.resolve(name+'/package.json'))
  }
 }
 for(const path of pinned.values())await capture(path)
 const manifest={name:'@smthrs/probe-cli-vendored',version:'1.0.0',type:'module',dependencies:{effect:version,typescript:'7.0.2'},exports:{'.':{import:{types:'./dist/index.d.ts',default:'./dist/index.js'},require:{types:'./dist/index.d.cts',default:'./dist/index.cjs'}},'./package.json':'./package.json'}}
 await writeFile(join(pkg,'package.json'),JSON.stringify(manifest))
 await writeFile(join(pkg,'dist/index.js'),`import * as FileSystem from './vendor/node_modules/@effect/platform-node/dist/NodeFileSystem.js';import * as Effect from 'effect/Effect';export const layer=FileSystem.layer;export const core=Effect;`)
 await writeFile(join(pkg,'dist/index.cjs'),`const FileSystem=require('./vendor/node_modules/@effect/platform-node/dist/NodeFileSystem.js');exports.layer=FileSystem.layer;exports.core=require('effect/Effect');`)
 const declaration=`export { layer } from './vendor/node_modules/@effect/platform-node/dist/NodeFileSystem.js'; export * as core from 'effect/Effect';\n`
 await writeFile(join(pkg,'dist/index.d.ts'),declaration);await writeFile(join(pkg,'dist/index.d.cts'),declaration)
 await execute('tar',['-czf',join(root,'vendored.tgz'),'-C',join(root,'publish'),'package'])
 registry=await releaseRegistry(root,[{name:manifest.name,version:manifest.version,filename:'vendored.tgz'}])
 console.log(JSON.stringify({scope:'strategy proof only: actual pinned workspace adapter bytes, synthetic CLI export, no first-party cohort or MCP claim',published:manifest,captured:[...seen],containsEffect:false}))
 for(const manager of ['npm','pnpm']){
  const consumer=join(root,'consumer-'+manager);await mkdir(consumer)
  await writeFile(join(consumer,'package.json'),JSON.stringify({private:true,packageManager:'pnpm@11.25.0',dependencies:{[manifest.name]:manifest.version}}))
  await writeFile(join(consumer,'.npmrc'),'@smthrs:registry='+registry.url+'\n')
  const args=manager==='npm'?['install','--ignore-scripts','--cache',join(consumer,'cache'),'--no-audit','--no-fund']:['install','--ignore-scripts','--store-dir',join(consumer,'store'),'--cache-dir',join(consumer,'cache'),'--package-import-method=hardlink','--reporter=append-only']
  const installed=await execute(manager,args,{cwd:consumer,env:process.env,timeout:180000,maxBuffer:16*1024*1024});console.log(JSON.stringify({manager,args,...installed}))
  const code=`import assert from 'node:assert/strict';import {createRequire} from 'node:module';import * as a from '@smthrs/probe-cli-vendored';const r=createRequire(process.cwd()+'/package.json');const b=r('@smthrs/probe-cli-vendored');assert.equal(a.layer,b.layer);assert.equal(a.core,b.core);const p=r.resolve('@smthrs/probe-cli-vendored/package.json');const q=createRequire(p.replace('package.json','dist/vendor/node_modules/@effect/platform-node/package.json'));assert.equal(q.resolve('effect/package.json'),r.resolve('effect/package.json'));assert.equal(q('@effect/platform-node-shared/package.json').version,'${version}');console.log(JSON.stringify({esmCjsLayerIdentity:true,singleCore:true,sharedVersion:q('@effect/platform-node-shared/package.json').version}));`
  console.log((await execute(process.execPath,['--input-type=module','-e',code],{cwd:consumer,timeout:30000})).stdout)
  for(const ext of ['mts','cts'])await writeFile(join(consumer,'proof.'+ext),`import {layer,core} from '@smthrs/probe-cli-vendored';const value: core.Effect<number> = core.succeed(1);void layer;void value;\n// @ts-expect-error negative any control\ncore.missingConsumerField;\n`)
  const from=createRequire(join(consumer,'node_modules/@smthrs/probe-cli-vendored/package.json'))
  const tsc=join(dirname(from.resolve('typescript/package.json')),'bin/tsc')
  console.log((await execute(process.execPath,[tsc,'--noEmit','--strict','--skipLibCheck','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext','proof.mts','proof.cts'],{cwd:consumer,timeout:30000})).stdout)
  const family=installedEffectFamily(consumer);assert.ok(family.every(item=>item.version===version));assert.equal(family.filter(item=>item.name==='effect').length,1)
  console.log(JSON.stringify({manager,family,typedEsmCjs:true,cleanupPending:true}))
 }
}finally{await registry?.close();await rm(root,{recursive:true,force:true});console.log(JSON.stringify({cleanup:true}))}
