/**
 * The merge queue: every worker that reported READY commits is one member.
 * Members land one at a time on top of each other; a member that conflicts or
 * fails its checks is quarantined, and the next round relaunches it as a fix.
 */
import * as MergeQueue from "@smthrs/patterns/MergeQueue"
import { Data, Effect, type Schema } from "effect"
import { execFile, execFileSync, spawn } from "node:child_process"
import { mkdirSync, mkdtempSync, renameSync, rmSync, unlinkSync, writeFileSync } from "node:fs"
import { chmod, mkdir, readdir, readFile, rm, unlink, writeFile } from "node:fs/promises"
import { homedir, hostname, tmpdir } from "node:os"
import { basename, dirname, join, resolve } from "node:path"
import { promisify } from "node:util"
import { acceptanceReviewPrelude, pushedReceiptProgram, verifiedReceiptProgram } from "./acceptance-program.ts"
import { completeIssueReceipts, validateCurrentAcceptance } from "./acceptance.ts"
import { isPushedFailure, loadAcceptanceRecord, readPushedReceipt, validateLandingReceipt } from "./landing-receipt.ts"
import { buildReviewInput, ReviewInputIncomplete } from "./review-input.ts"
export { hasPushedReceipt, isPushedFailure } from "./landing-receipt.ts"
import type { InFlight, LandReport, WorkerResult } from "./schema.ts"

const run = promisify(execFile)
const lockScript = join(homedir(), "Smithers-Ops/dispatch/vcs_lock.py")
const scriptDir = join(homedir(), "Smithers-Ops/burndown/landings")

export class LandFailed extends Data.TaggedError("LandFailed")<{
  readonly key: string
  readonly log: string
  readonly receiptsPending?: boolean
  readonly disposition?: "park"
  readonly receipt?: Schema.Json
}> {}

/** One landing: the worker's commits in issue order and the claims they carry. */
export interface Member {
  readonly key: string
  readonly repo: string
  readonly notes?: string
  readonly expectedReceipt?: Schema.Json
  readonly commits: ReadonlyArray<{ readonly issue: number; readonly commit: string }>
}

const shellQuote = (value: string) => `'${value.replaceAll("'", `'\\''`)}'`

/** Runs under the VCS lock, with one deadline shared by discovery and all checks. */
export const checksProgram = String.raw`
import { existsSync, readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, resolve, relative, sep } from "node:path";
import { execFileSync, spawn } from "node:child_process";
const [repo, ...changes] = process.argv.slice(1);
const sourceRoot = process.cwd();
let root = sourceRoot;
let snapshot;
let activeChild;
for (const [signal, code] of [["SIGTERM", 143], ["SIGINT", 130], ["SIGHUP", 129]]) {
  process.on(signal, () => {
    if (activeChild?.pid) {
      try { process.kill(-activeChild.pid, "SIGKILL"); } catch (error) { if (error.code !== "ESRCH") console.error(error); }
    }
    if (snapshot) rmSync(snapshot, { recursive: true, force: true });
    console.error("CHECK_CANCELLED " + signal);
    process.exit(code);
  });
}
const deadline = Date.now() + 900_000;
const remaining = () => {
  const ms = deadline - Date.now();
  if (ms <= 0) throw new Error("CHECK_TIMEOUT: overall 15-minute limit");
  return ms;
};
try {
if (process.env.BURNDOWN_CHECK_REVISION) {
  snapshot = mkdtempSync(resolve(process.env.BURNDOWN_VERIFICATION_ROOT ?? tmpdir(), "burndown-check-"));
  root = resolve(snapshot, "tree");
  const gitDirectory = execFileSync("jj", ["git", "root"], { encoding: "utf8", timeout: remaining() }).trim();
  const sha = execFileSync("jj", ["--ignore-working-copy", "log", "--no-graph", "-r", process.env.BURNDOWN_CHECK_REVISION, "-T", "commit_id"], { encoding: "utf8", timeout: remaining() }).trim();
  if (!/^[0-9a-f]{40}$/.test(sha)) throw new Error("Invalid landing commit: " + sha);
  const archive = resolve(snapshot, "tree.tar");
  // Archive exact objects: candidate and host export attributes must not omit or
  // substitute bytes. Borrow only the source object store into private metadata.
  const archiveGit = resolve(snapshot, "archive.git");
  const objects = execFileSync("git", ["--git-dir", gitDirectory, "rev-parse", "--path-format=absolute", "--git-path", "objects"], { encoding: "utf8", timeout: remaining() }).trim();
  execFileSync("git", ["init", "--bare", "--template=", archiveGit], { timeout: remaining() });
  mkdirSync(resolve(archiveGit, "info"), { recursive: true });
  writeFileSync(resolve(archiveGit, "info", "attributes"), "* -export-ignore -export-subst -text -eol -ident -filter -working-tree-encoding\n");
  execFileSync("git", ["--git-dir", archiveGit, "-c", "core.attributesFile=/dev/null", "archive", "--format=tar", "--output", archive, sha], { env: { ...process.env, GIT_OBJECT_DIRECTORY: objects, GIT_ATTR_NOSYSTEM: "1" }, timeout: remaining() });
  execFileSync("mkdir", [root], { timeout: remaining() });
  execFileSync("tar", ["-xf", archive, "-C", root], { timeout: remaining() });
  console.log("CHECK_REVISION " + sha);
}
const paths = [...new Set(changes.flatMap(change =>
  execFileSync("jj", ["--ignore-working-copy", "diff", "--name-only", "-r", change], {
    encoding: "utf8", timeout: remaining(), maxBuffer: 16 << 20
  }).trim().split("\n").filter(Boolean)))].sort();
if (paths.length === 0) throw new Error("NO_VERIFICATION: no changed paths");
const packages = new Map();
const graphPaths = [];
const graph = repo === "smithers" && existsSync(resolve(root, "PACKAGE.ts")) && existsSync(resolve(root, "packages/smithers/build/build-cli/src/main.js"));
const nearest = (absolute, file) => {
  let directory = dirname(absolute);
  while (true) {
    if (existsSync(resolve(directory, file))) return directory;
    if (directory === root) return undefined;
    directory = dirname(directory);
  }
};
for (const path of paths) {
  const absolute = resolve(root, path);
  if (absolute === root || !absolute.startsWith(root + sep)) throw new Error("Unsafe changed path: " + path);
  if (path.endsWith(".go") || ["go.mod", "go.sum"].includes(path.split("/").at(-1))) {
    const module = nearest(absolute, "go.mod");
    if (!module) throw new Error("NO_VERIFICATION: missing Go module for " + path);
    const directory = dirname(path);
    const hasPackage = path.endsWith(".go") && existsSync(dirname(absolute)) && readdirSync(dirname(absolute)).some(file => file.endsWith(".go"));
    const target = hasPackage ? relative(module, resolve(root, directory)).split(sep).join("/") : "";
    const go = target ? "./" + target + "/..." : "./...";
    packages.set("go:" + module + ":" + go, { go, cwd: module });
    continue;
  }
  if (graph) { graphPaths.push(path); continue; }
  const chart = nearest(absolute, "Chart.yaml");
  if (chart) { packages.set("helm:" + chart, { chart }); continue; }
  let directory = dirname(absolute);
  while (true) {
    const manifest = resolve(directory, "package.json");
    if (existsSync(manifest) || existsSync(resolve(directory, "PACKAGE.ts"))) {
      const label = relative(root, directory) || ".";
      if (!existsSync(manifest)) throw new Error("NO_VERIFICATION: " + label + " has no supported checks");
      const pkg = JSON.parse(readFileSync(manifest, "utf8"));
      if (typeof pkg.name !== "string" || !pkg.name) throw new Error("Missing package name: " + label);
      const scripts = pkg.scripts ?? {};
      if (!scripts.typecheck && !scripts.check && !scripts.test && !scripts.lint) throw new Error("NO_VERIFICATION: " + label + " has no supported checks");
      // Root recursive aggregators are not an owning check route.
      if (directory === root) throw new Error("NO_VERIFICATION: root path needs declared affected graph: " + path);
      packages.set(label, { name: pkg.name, scripts });
      break;
    }
    if (directory === root) throw new Error("NO_VERIFICATION: no owning checks for " + path);
    directory = dirname(directory);
  }
}
async function check(command, args, cwd = root, capture = false) {
  let output = "";
  console.log("CHECK " + JSON.stringify([command, ...args]));
  await new Promise((accept, reject) => {
    const budget = remaining();
    const child = spawn(command, args, { cwd, env: { ...process.env, CI: "true" }, stdio: capture ? ["ignore", "pipe", "inherit"] : "inherit", detached: true });
    activeChild = child;
    let stopped = false;
    const kill = () => {
      if (stopped) return;
      stopped = true;
      try { process.kill(-child.pid, "SIGKILL"); } catch (error) { if (error.code !== "ESRCH") console.error(error); }
    };
    child.stdout?.setEncoding("utf8");
    child.stdout?.on("data", bytes => {
      if (stopped) return;
      output += bytes;
      if (Buffer.byteLength(output) > 16 << 20) {
        kill();
        reject(new Error("CHECK_OUTPUT_LIMIT"));
      }
    });
    const timer = setTimeout(() => {
      kill();
      reject(new Error("CHECK_TIMEOUT: overall 15-minute limit"));
    }, budget);
    child.once("error", error => { activeChild = undefined; clearTimeout(timer); reject(error); });
    child.once("close", (code, signal) => {
      activeChild = undefined;
      clearTimeout(timer);
      if (code === 0) accept();
      else reject(new Error("CHECK_FAILED " + command + " exit=" + code + " signal=" + signal));
    });
  });
  return output;
}
const needsNode = graphPaths.length > 0 || [...packages.values()].some(pkg => pkg.scripts);
if (needsNode && existsSync(resolve(root, ".node-version"))) {
  const pinned = readFileSync(resolve(root, ".node-version"), "utf8").trim().replace(/^v/, "");
  if (process.versions.node !== pinned) throw new Error("CHECK_TOOLCHAIN: requires Node " + pinned + ", got " + process.versions.node);
}
if (needsNode && existsSync(resolve(root, "package.json"))) {
  const manager = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8")).packageManager;
  if (manager) {
    if (!/^pnpm@[^+]+(?:\+.*)?$/.test(manager)) throw new Error("CHECK_TOOLCHAIN: unsupported " + manager);
    const version = (await check("pnpm", ["--version"], root, true)).trim();
    if (version !== manager.slice(5).split("+")[0]) throw new Error("CHECK_TOOLCHAIN: requires " + manager + ", got " + version);
  }
}
if (snapshot && needsNode) await check("pnpm", ["install", "--offline", "--frozen-lockfile"]);
if (graphPaths.length > 0) {
  // Inspect every path separately: another changed path must not hide an empty selection.
  const cli = resolve(root, "packages/smithers/build/build-cli/src/main.js");
  for (const path of graphPaths) {
    const selected = JSON.parse(await check(process.execPath, [cli, "affected", "ci", "//...", "--files", path, "--list", "--json"], root, true));
    if (!Array.isArray(selected.targets) || selected.targets.length === 0) throw new Error("NO_VERIFICATION: affected graph selected no checks for " + path);
    console.log("CHECK_SELECTION " + path + " " + selected.targets.map(target => target.label).join(" "));
  }
  await check(process.execPath, [cli, "affected", "ci", "//...", ...graphPaths.flatMap(path => ["--files", path]), "--no-cache", "--jobs", "1"]);
}
  for (const [label, pkg] of [...packages].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) {
    if (pkg.go) {
      await check("go", ["vet", pkg.go], pkg.cwd);
      await check("go", ["test", pkg.go], pkg.cwd);
    } else if (pkg.chart) {
      await check("helm", ["lint", "--strict", pkg.chart]);
      await check("helm", ["template", "burndown-check", pkg.chart]);
    } else {
      const script = pkg.scripts.typecheck ? "typecheck" : pkg.scripts.check ? "check" : undefined;
      if (script) await check("pnpm", ["--fail-if-no-match", "--filter", pkg.name, "run", script]);
      else console.log("SKIP " + label + ": no typecheck/check script");
      if (pkg.scripts.lint) await check("pnpm", ["--fail-if-no-match", "--filter", pkg.name, "run", "lint"]);
      if (pkg.scripts.test) await check("pnpm", ["--fail-if-no-match", "--filter", pkg.name, "run", "test"]);
      else console.log("SKIP " + label + ": no test script");
    }
  }
  console.log("CHECKS_PASSED");
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
} finally {
  if (snapshot) rmSync(snapshot, { recursive: true, force: true });
}
`

/** Review the final rebased diff using a verified non-operator subscription. */
export const reviewProgram = String.raw`
import { execFileSync, spawnSync } from "node:child_process";
import { homedir, tmpdir } from "node:os";
import { join } from "node:path";
import { mkdtempSync, readdirSync, rmSync } from "node:fs";
const ReviewInputIncomplete = ${ReviewInputIncomplete.toString()};
${buildReviewInput.toString()}
const sha = process.env.BURNDOWN_CHECK_REVISION;
if (!/^[0-9a-f]{40}$/.test(sha ?? "")) throw new Error("Invalid review revision");
const deadline = Date.now() + 600_000;
const remaining = () => {
  const ms = deadline - Date.now();
  if (ms <= 0) throw new Error("REVIEW_TIMEOUT: overall ten-minute limit");
  return ms;
};
const reviewBaseSelector = process.env.BURNDOWN_REVIEW_BASE ?? "main@origin";
if (reviewBaseSelector !== "main@origin" && !/^[0-9a-f]{40}$/.test(reviewBaseSelector)) throw new Error("Invalid review base revision");
const reviewBase = reviewBaseSelector === "main@origin" ? execFileSync("jj", ["--ignore-working-copy", "log", "--no-graph", "-r", reviewBaseSelector, "-T", "commit_id"], {encoding:"utf8",timeout:Math.min(60_000,remaining()),maxBuffer:1<<20}).trim() : reviewBaseSelector;
if (!/^[0-9a-f]{40}$/.test(reviewBase)) throw new Error("Invalid resolved review base revision");
let diff;
try { diff = execFileSync("jj", ["--ignore-working-copy", "diff", "--git", "--from", reviewBase, "--to", sha], { encoding: "utf8", timeout: Math.min(60_000, remaining()), maxBuffer: 16 << 20 }); }
catch (error) { if(error.code==="ENOBUFS") throw new ReviewInputIncomplete("diff_capture_limit",Buffer.byteLength(error.stdout??""),16<<20,{revision:sha,base:reviewBase}); throw error; }
${acceptanceReviewPrelude(false)}
const accountRoot = join(homedir(), ".smithers/accounts");
const excluded = new Set(["claude-4", "claude-6", ...(process.env.BURNDOWN_REVIEW_EXCLUDED_ACCOUNTS ?? "").split(/[,\s]+/)]);
const excludedEmails = new Set(["will@codeplane.app", ...(process.env.BURNDOWN_EXCLUDE_EMAILS ?? "").toLowerCase().split(/[,\s]+/)]);
let accounts;
try { accounts = readdirSync(accountRoot, { withFileTypes: true }).filter(entry => entry.isDirectory() && /^claude-[0-9]+$/.test(entry.name) && !excluded.has(entry.name)).map(entry => entry.name).sort((a, b) => a.localeCompare(b, "en", { numeric: true })); }
catch (error) { if (error.code !== "ENOENT") throw error; accounts = []; }
const preferred = process.env.BURNDOWN_REVIEW_ACCOUNT;
if (preferred) {
  if (!/^claude-[0-9]+$/.test(preferred) || excluded.has(preferred) || !accounts.includes(preferred)) throw new Error("REVIEW_ACCOUNT_UNAVAILABLE: preferred account is not allowed or discovered");
  accounts = [preferred, ...accounts.filter(id => id !== preferred)];
}
// Only CLI error metadata can identify capacity. The model can author arbitrary
// result text, including provider-looking messages; that text never triggers retry.
const capacity = response => {
  if (response.is_error !== true || response.terminal_reason !== "api_error" || /VERDICT/i.test(response.result)) return undefined;
  if (response.api_error_status === 429) {
    if (response.api_error === "model_requires_usage_credits") return "model:fable";
    if (["rate_limit_error", "usage_limit_exceeded"].includes(response.api_error)) return "subscription";
  }
  if (response.api_error_status === 503 && response.api_error === "overloaded_error") return "provider";
  return undefined;
};
let passed = false;
const seen = new Set();
const reviewCwd = mkdtempSync(join(tmpdir(), "burndown-review-"));
try {
for (const id of accounts) {
  remaining();
  const env = { ...process.env, CLAUDE_CONFIG_DIR: join(accountRoot, id) };
  for (const key of ["ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "CLAUDE_CODE_OAUTH_TOKEN", "ANTHROPIC_BASE_URL", "CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY"]) delete env[key];
  const status = spawnSync("claude", ["auth", "status"], { env, cwd: reviewCwd, encoding: "utf8", timeout: Math.min(30_000, remaining()), maxBuffer: 1 << 20 });
  if (status.error || status.signal) throw new Error("REVIEW_IDENTITY_FAILED " + (status.error?.message ?? status.signal));
  let identity;
  try { identity = JSON.parse(status.stdout); } catch { throw new Error("REVIEW_IDENTITY_INVALID " + id); }
  if (!identity || typeof identity !== "object" || typeof identity.loggedIn !== "boolean") throw new Error("REVIEW_IDENTITY_INVALID " + id);
  if (!identity.loggedIn) { console.log("REVIEW_LOGIN_UNAVAILABLE " + id); continue; }
  if (status.status !== 0) throw new Error("REVIEW_IDENTITY_FAILED " + status.status);
  if (identity.authMethod !== "claude.ai") { console.log("REVIEW_LOGIN_UNAVAILABLE " + id); continue; }
  if (typeof identity.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identity.email)) throw new Error("REVIEW_IDENTITY_INVALID " + id);
  const email = identity.email.toLowerCase();
  if (excludedEmails.has(email) || identity.apiProvider !== "firstParty") continue;
  if (seen.has(email)) continue;
  seen.add(email);
  console.log("REVIEW_IDENTITY " + id + " " + email);
  const result = spawnSync("claude", ["-p", "--model", "claude-fable-5-1", "--output-format", "json", "--setting-sources", "", "--tools", "", "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}'], {
    env, cwd: reviewCwd, encoding: "utf8", timeout: remaining(), maxBuffer: 16 << 20,
    input: acceptancePrompt
  });
  console.log(result.stdout);
  console.error(result.stderr);
  if (result.error || result.signal) throw new Error("REVIEW_FAILED " + (result.error?.message ?? result.signal));
  remaining();
  let response;
  try { response = JSON.parse(result.stdout); } catch { throw new Error("REVIEW_RESPONSE_INVALID " + id); }
  if (!response || response.type !== "result" || typeof response.is_error !== "boolean" || typeof response.result !== "string") throw new Error("REVIEW_RESPONSE_INVALID " + id);
  const limited = capacity(response);
  if (limited) { console.log("REVIEW_CAPACITY " + id + " " + limited); continue; }
  if (result.status !== 0 || response.is_error || response.terminal_reason !== "completed" || response.subtype !== "success") throw new Error("REVIEW_FAILED " + result.status);
  const models = Object.keys(response.modelUsage ?? {});
  const usage = response.modelUsage?.["claude-fable-5-1"];
  if (models.length !== 1 || models[0] !== "claude-fable-5-1" || !usage || typeof usage !== "object" || (usage.canonicalModel !== undefined && usage.canonicalModel !== "claude-fable-5-1") || (usage.provider !== undefined && usage.provider !== "firstParty")) throw new Error("REVIEW_MODEL_MISMATCH " + id);
  if (!/(?:^|\n)VERDICT: PASS\s*$/.test(response.result) || /(?:^|\n)VERDICT: FAIL(?:\s|$)/.test(response.result)) throw new Error("REVIEW_REJECTED " + sha);
  saveAcceptance(response.result);
  console.log("REVIEW_REVISION " + sha);
  passed = true;
  break;
}
if (!passed) throw new Error("REVIEW_UNAVAILABLE: no allowed distinct subscription completed Fable review; capacity or login recovery remains pending");
} finally { rmSync(reviewCwd, { recursive: true, force: true }); }
`

/** Keep a byte-bounded failure receipt for MergeQueue quarantine and fix relaunch. */
export const landingFailure = (key: string, cause: unknown): LandFailed => {
  const error = cause as { code?: number; stdout?: string; stderr?: string; message?: string }
  const cleanupFailed = /snapshot cleanup|process-tree cleanup|root process exit timeout/.test(error.message ?? "")
  const log = error.code === 6 && error.stderr !== undefined && !cleanupFailed
    ? error.stderr
    : `${error.stdout ?? ""}\n${error.stderr ?? ""}\n${error.message ?? String(cause)}`
  return new LandFailed({
    key,
    log: Buffer.from(log).subarray(-4000).toString("utf8"),
    ...(/REVIEW_INPUT_INCOMPLETE/.test(log) ? { disposition: "park" as const } : {})
  })
}

/**
 * The script run under the repository's VCS lock. It rebases the member's
 * commits onto current `main@origin`, refuses conflicts, moves `main` to the
 * last one, pushes, and prints `LANDED <issue> <commit>` per issue.
 */
export const landingScript = (member: Member, reverify = false): string => {
  const commits = member.commits.map((c) => shellQuote(c.commit)).join(" ")
  const memberPath = join(scriptDir, `${member.key}.member.json`)
  const memberArgument = shellQuote(memberPath)
  return `#!/bin/sh
set -eu
# Keep whole notes and retained facts off subprocess argv/environment limits.
(umask 077; : > ${shellQuote(memberPath)}; chmod 600 ${shellQuote(memberPath)}; printf '%s\\n' ${
    shellQuote(JSON.stringify(member))
  } > ${shellQuote(memberPath)})
query_jj() {
  jj "$@" || { echo "JJ_QUERY_FAILED" >&2; return 7; }
}
assert_working_copy() {
  working_copy=$(query_jj log --no-graph -r @ -T 'commit_id')
  protected=$(query_jj log --no-graph -r '(@:: ~ @) | (@ & bookmarks())' -T 'change_id')
  if [ "$working_copy" != "$1" ] && [ -n "$protected" ]; then
    echo "WORKING_COPY_REALIGNMENT_REQUIRED protected revision"; exit 7
  fi
}
realign_working_copy() {
  assert_working_copy "$1"
  working_copy=$(query_jj log --no-graph -r @ -T 'commit_id')
  if [ "$working_copy" != "$1" ]; then
    jj rebase -r @ -d "$1" || { echo "WORKING_COPY_REALIGNMENT_REQUIRED"; exit 7; }
  fi
}
verify_prechecks() {
prechecks_log=${shellQuote(join(scriptDir, `${member.key}.prechecks.log`))}
if BURNDOWN_CHECK_REVISION="$last" node --input-type=module -e ${shellQuote(checksProgram)} ${
    shellQuote(member.repo.split("/")[1]!)
  } $changes >"$prechecks_log" 2>&1; then
  tail -c 4000 "$prechecks_log" >&2
else
  tail -c 4000 "$prechecks_log" >&2
  exit 6
fi
preverified=$(sed -n 's/^CHECK_REVISION //p' "$prechecks_log" | head -n 1)
current=$(query_jj --ignore-working-copy log --no-graph -r "$last" -T 'commit_id')
if [ -z "$preverified" ] || [ "$current" != "$preverified" ]; then
  echo "PRECHECK_REVISION_CHANGED $preverified != $current" >>"$prechecks_log"
  tail -c 4000 "$prechecks_log" >&2
  exit 6
fi
}
verify_checks() {
checks_log=${shellQuote(join(scriptDir, `${member.key}.checks.log`))}
if BURNDOWN_CHECK_REVISION="$last" node --input-type=module -e ${shellQuote(checksProgram)} ${
    shellQuote(member.repo.split("/")[1]!)
  } $changes >"$checks_log" 2>&1; then
  tail -c 4000 "$checks_log" >&2
else
  tail -c 4000 "$checks_log" >&2
  exit 6
fi
verified=$(sed -n 's/^CHECK_REVISION //p' "$checks_log" | head -n 1)
current=$(query_jj --ignore-working-copy log --no-graph -r "$last" -T 'commit_id')
if [ -z "$verified" ] || [ "$current" != "$verified" ]; then
  echo "CHECK_REVISION_CHANGED $verified != $current" >>"$checks_log"
  tail -c 4000 "$checks_log" >&2
  exit 6
fi
}
verify_review() {
review_log=${shellQuote(join(scriptDir, `${member.key}.review.log`))}
if BURNDOWN_ACCEPTANCE_MEMBER_PATH=${shellQuote(memberPath)} BURNDOWN_ACCEPTANCE_PATH=${
    shellQuote(join(scriptDir, `${member.key}.acceptance.json`))
  } BURNDOWN_REVIEW_BASE="\${review_base:-main@origin}" BURNDOWN_PRECHECKS_LOG="$prechecks_log" BURNDOWN_CHECKS_LOG="$checks_log" BURNDOWN_CHECK_REVISION="$verified" node --input-type=module -e ${
    shellQuote(reviewProgram)
  } >"$review_log" 2>&1; then
  tail -c 4000 "$review_log" >&2
else
  tail -c 4000 "$review_log" >&2
  exit 6
fi
current=$(query_jj --ignore-working-copy log --no-graph -r "$last" -T 'commit_id')
if [ "$current" != "$verified" ]; then
  echo "REVIEW_REVISION_CHANGED $verified != $current" >>"$review_log"
  tail -c 4000 "$review_log" >&2
  exit 6
fi
}
jj git fetch >/dev/null 2>&1 || jj git fetch
# Only main is queue-managed: recover a rejected push or interrupted publication.
jj --ignore-working-copy bookmark set main -r main@origin --allow-backwards || { echo "MAIN_RECONCILIATION_REQUIRED"; exit 5; }
changes=""
for c in ${commits}; do
  changes="$changes $(query_jj --ignore-working-copy log --no-graph -r "$c" -T 'change_id')"
done
last=$(echo $changes | awk '{print $NF}')
# Recovery after an accepted push or failed receipt must never land the bundle twice.
already_landed=true
for ch in $changes; do
  landed=$(query_jj --ignore-working-copy log --no-graph -r "$ch & ::main@origin" -T 'change_id')
  if [ -z "$landed" ]; then already_landed=false; fi
done
if [ "$already_landed" = true ]; then
  verified=$(query_jj --ignore-working-copy log --no-graph -r "$last" -T 'commit_id')
  node --input-type=module -e ${shellQuote(pushedReceiptProgram())} ${
    shellQuote(join(scriptDir, `${member.key}.pushed.json`))
  } -verify ${memberArgument} "$verified" $changes
  if ${reverify ? "true ||" : ""} ! node --input-type=module -e ${shellQuote(verifiedReceiptProgram())} ${
    shellQuote(join(scriptDir, `${member.key}.pushed.json`))
  } ${memberArgument}; then
    first=$(echo $changes | awk '{print $1}')
    for ch in $changes; do
      in_landing=$(query_jj --ignore-working-copy log --no-graph -r "$ch & ::$last" -T 'change_id')
      [ -n "$in_landing" ] || { echo "NOT_IN_LANDING $ch"; exit 4; }
    done
    verified=$(query_jj --ignore-working-copy log --no-graph -r "$last" -T 'commit_id')
    # Remote ancestry established actual landing; persist proof before verification.
    node --input-type=module -e ${shellQuote(pushedReceiptProgram())} ${
    shellQuote(join(scriptDir, `${member.key}.pushed.json`))
  } - ${memberArgument} "$verified" $changes
    review_base=$(query_jj --ignore-working-copy log --no-graph -r "parents($first)" -T 'commit_id')
    verify_prechecks
    verify_checks
    verify_review
    node --input-type=module -e ${shellQuote(pushedReceiptProgram())} ${
    shellQuote(join(scriptDir, `${member.key}.pushed.json`))
  } ${shellQuote(join(scriptDir, `${member.key}.acceptance.json`))} ${memberArgument} "$verified" $changes
  fi
  main_commit=$(query_jj --ignore-working-copy log --no-graph -r main@origin -T 'commit_id')
  realign_working_copy "$main_commit"
  i=0
  for ch in $changes; do
    i=$((i+1))
    landed_commit=$(query_jj --ignore-working-copy log --no-graph -r "$ch" -T 'commit_id')
    echo "LANDED $i $landed_commit"
  done
  exit 0
fi
if [ -f ${shellQuote(join(scriptDir, `${member.key}.pushed.json`))} ] || ${
    member.expectedReceipt === undefined ? "false" : "true"
  }; then
  echo "PUSHED_RECEIPT_REMOTE_MISMATCH" >&2; exit 6
fi
# Rebase must not move any existing bookmark on a member or its descendants.
for ch in $changes; do
  protected=$(query_jj log --no-graph -r "$ch:: & bookmarks()" -T 'change_id')
  if [ -n "$protected" ]; then
    echo "PROTECTED_LANDING_REVISION $ch"; exit 7
  fi
done
# Refuse protected working-copy revisions before member rebase can rewrite them.
protected=$(query_jj log --no-graph -r '(@:: ~ @) | (@ & bookmarks())' -T 'change_id')
if [ -n "$protected" ]; then
  echo "WORKING_COPY_REALIGNMENT_REQUIRED protected revision"; exit 7
fi
verify_prechecks
revs=""
for ch in $changes; do revs="$revs -r $ch"; done
jj rebase $revs -d main@origin
for ch in $changes; do
  conflicts=$(query_jj log --no-graph -r "$ch & conflicts()" -T 'change_id')
  if [ -n "$conflicts" ]; then
    echo "CONFLICT $ch"; exit 3
  fi
  on_main=$(query_jj log --no-graph -r "$ch & main@origin::" -T 'change_id')
  if [ -z "$on_main" ]; then
    echo "NOT_ON_MAIN $ch"; exit 4
  fi
done
last=$(echo $changes | awk '{print $NF}')
for ch in $changes; do
  in_landing=$(query_jj --ignore-working-copy log --no-graph -r "$ch & ::$last" -T 'change_id')
  if [ -z "$in_landing" ]; then
    echo "NOT_IN_LANDING $ch"; exit 4
  fi
done
verify_checks
verify_review
assert_working_copy "$verified"
jj --ignore-working-copy bookmark set main -r "$verified"
if ! jj --ignore-working-copy git push --bookmark main; then
  jj --ignore-working-copy bookmark set main -r main@origin --allow-backwards || { echo "MAIN_RECONCILIATION_REQUIRED"; exit 5; }
  echo "PUSH_REJECTED"; exit 5
fi
echo "PUSH_ACCEPTED $verified"
# Persist the confirmed push before any later operation can fail.
node --input-type=module -e ${shellQuote(pushedReceiptProgram())} ${
    shellQuote(join(scriptDir, `${member.key}.pushed.json`))
  } ${shellQuote(join(scriptDir, `${member.key}.acceptance.json`))} ${memberArgument} "$verified" $changes
if jj git fetch; then
  pushed=$(query_jj --ignore-working-copy log --no-graph -r "$verified & ::main@origin" -T 'commit_id')
  [ "$pushed" = "$verified" ] || { echo "PUSH_NOT_VISIBLE $pushed != $verified"; exit 5; }
else
  # Query the server directly when fetching local tracking refs failed after push.
  git_directory=$(jj git root)
  remote=$(git --git-dir "$git_directory" ls-remote origin refs/heads/main | awk '{print $1}')
  [ "$remote" = "$verified" ] || { echo "PUSH_RECONCILIATION_REQUIRED $remote != $verified"; exit 5; }
  echo "PUSH_RECONCILED $verified"
fi
# Preserve shared edits while making their sole parent the confirmed landed main.
realign_working_copy "$verified"
i=0
for ch in $changes; do
  i=$((i+1))
  landed_commit=$(query_jj log --no-graph -r "$ch" -T 'commit_id')
  echo "LANDED $i $landed_commit"
done
`
}

/**
 * A durable lease for one owned verification snapshot. It is written before the
 * landing process starts and deleted only after the snapshot is really gone, so a
 * cleanup failure, a timed-out removal or a host restart leaves a recoverable record.
 */
interface SnapshotLease {
  readonly version: 1
  readonly path: string
  readonly host: string
  readonly pid: number
  readonly started: string | null
  readonly createdAt: string
  readonly diagnostics: ReadonlyArray<string>
}

const snapshotLedger = (explicit?: string) =>
  explicit ?? process.env.BURNDOWN_SNAPSHOT_LEDGER ?? join(scriptDir, "snapshots")
const snapshotName = /^burndown-verification-[A-Za-z0-9]{6}$/
const leasePath = (ledger: string, snapshot: string) => join(ledger, `${basename(snapshot)}.json`)
/** Snapshots this process still owns; a same-process lease outside this set is retained. */
const activeSnapshots = new Set<string>()

/** Process start identity; a reused pid (for example after a host restart) never matches. */
const processStart = (pid: number): string | null | undefined => {
  try {
    const started = execFileSync("ps", ["-o", "lstart=", "-p", String(pid)], { encoding: "utf8", timeout: 2000 })
      .trim()
    return started === "" ? undefined : started
  } catch (cause) {
    const error = cause as { status?: number; stdout?: string }
    // ps exits 1 with no rows for a missing pid; any other failure proves nothing.
    return error.status === 1 && (error.stdout ?? "").trim() === "" ? undefined : null
  }
}
let ownStart: string | null | undefined

const ownerAlive = (lease: SnapshotLease): boolean => {
  ownStart ??= processStart(process.pid) ?? null
  if (lease.pid === process.pid && lease.started === ownStart) return activeSnapshots.has(lease.path)
  const started = processStart(lease.pid)
  if (started === undefined) return false
  // Without a recorded or readable identity a live pid is assumed to be the owner.
  return started === null || lease.started === null || started === lease.started
}

const writeLease = (ledger: string, lease: SnapshotLease) => {
  mkdirSync(ledger, { recursive: true })
  const path = leasePath(ledger, lease.path)
  writeFileSync(`${path}.tmp`, JSON.stringify(lease))
  // Rename keeps a crash from leaving a torn lease that recovery would have to refuse.
  renameSync(`${path}.tmp`, path)
}

const retainDiagnostic = (ledger: string, lease: SnapshotLease, diagnostic: string) => {
  try {
    writeLease(ledger, {
      ...lease,
      diagnostics: [...lease.diagnostics, `${new Date().toISOString()} ${diagnostic}`].slice(-10)
    })
  } catch {
    // The lease written at creation still records the path for recovery.
  }
}

/** The real removal, and a bounded view of it; removal may finish after the deadline. */
const removeBounded = (path: string, timeout: number) => {
  let timer: ReturnType<typeof setTimeout> | undefined
  const removal = rm(path, { recursive: true, force: true, maxRetries: 0 })
  const bounded = Promise.race([
    removal,
    new Promise<never>((_, fail) => {
      timer = setTimeout(() => fail(new Error("snapshot cleanup timeout")), timeout)
    })
  ]).finally(() => clearTimeout(timer))
  return { removal, bounded }
}

export interface SnapshotRecovery {
  readonly recovered: ReadonlyArray<string>
  readonly retained: ReadonlyArray<{ readonly path: string; readonly diagnostics: ReadonlyArray<string> }>
}

/**
 * Removes verification snapshots whose recorded owner has exited, on this host only.
 * Only paths named by a valid lease are deleted; a live sibling runner's snapshot,
 * another host's lease and an unrecognised path are retained. The whole pass is bounded.
 */
export const recoverRetainedSnapshots = async (
  options: { ledger?: string; timeout?: number } = {}
): Promise<SnapshotRecovery> => {
  const ledger = snapshotLedger(options.ledger)
  const deadline = Date.now() + Math.min(options.timeout ?? 5000, 5000)
  const recovered: Array<string> = []
  const retained: Array<{ path: string; diagnostics: ReadonlyArray<string> }> = []
  let names: Array<string>
  try {
    names = (await readdir(ledger)).filter((name) => name.endsWith(".json")).sort()
  } catch (cause) {
    if ((cause as NodeJS.ErrnoException).code === "ENOENT") return { recovered, retained }
    throw cause
  }
  for (const name of names) {
    let lease: SnapshotLease
    try {
      lease = JSON.parse(await readFile(join(ledger, name), "utf8")) as SnapshotLease
    } catch (cause) {
      retained.push({ path: join(ledger, name), diagnostics: [`unreadable lease: ${String(cause)}`] })
      continue
    }
    const valid = lease.version === 1 && typeof lease.path === "string" && typeof lease.pid === "number" &&
      Array.isArray(lease.diagnostics) && name === `${basename(lease.path)}.json` &&
      snapshotName.test(basename(lease.path)) && resolve(lease.path) === lease.path &&
      resolve(dirname(lease.path)) === resolve(tmpdir())
    if (!valid) {
      retained.push({ path: join(ledger, name), diagnostics: ["invalid lease; never deleted"] })
      continue
    }
    if (lease.host !== hostname() || ownerAlive(lease)) continue
    const remaining = deadline - Date.now()
    if (remaining <= 0) {
      retained.push({ path: lease.path, diagnostics: [...lease.diagnostics, "recovery deadline reached"] })
      continue
    }
    try {
      await removeBounded(lease.path, remaining).bounded
      await unlink(join(ledger, name))
      recovered.push(lease.path)
    } catch (cause) {
      retainDiagnostic(ledger, lease, `recovery: ${String(cause)}`)
      retained.push({ path: lease.path, diagnostics: [...lease.diagnostics, `recovery: ${String(cause)}`] })
    }
  }
  return { recovered, retained }
}

/** Cancel the lock, shell, and detached tool descendants before reporting quarantine. */
export const runLandingProcess = (
  command: string,
  args: ReadonlyArray<string>,
  options: {
    cwd?: string
    env?: NodeJS.ProcessEnv
    timeout?: number
    signal?: AbortSignal
    snapshotCleanupTimeout?: number
    snapshotLedger?: string
  } = {}
): Promise<{ stdout: string; stderr: string }> =>
  new Promise((accept, reject) => {
    if (options.signal?.aborted) {
      reject(new Error("LANDING_CANCELLED"))
      return
    }
    let stdout = ""
    let stderr = ""
    let failure: Error | undefined
    let settled = false
    let drainTimer: ReturnType<typeof setTimeout> | undefined
    const ledger = snapshotLedger(options.snapshotLedger)
    const verificationRoot = mkdtempSync(join(tmpdir(), "burndown-verification-"))
    ownStart ??= processStart(process.pid) ?? null
    const lease: SnapshotLease = {
      version: 1,
      path: verificationRoot,
      host: hostname(),
      pid: process.pid,
      started: ownStart,
      createdAt: new Date().toISOString(),
      diagnostics: []
    }
    try {
      writeLease(ledger, lease)
    } catch (cause) {
      // Never run without a durable record of the snapshot it may leave behind.
      rmSync(verificationRoot, { recursive: true, force: true })
      reject(new Error(`LANDING_FAILED: snapshot lease: ${String(cause)}`))
      return
    }
    activeSnapshots.add(verificationRoot)
    const removeSnapshot = async () => {
      const { removal, bounded } = removeBounded(
        verificationRoot,
        Math.min(options.snapshotCleanupTimeout ?? 5000, 5000)
      )
      // A timed-out removal may still finish; release the lease only when it really does.
      void removal.then(() => {
        try {
          unlinkSync(leasePath(ledger, verificationRoot))
        } catch {
          // Recovery retries retained leases.
        }
      }, () => undefined)
      try {
        await bounded
      } catch (cause) {
        retainDiagnostic(ledger, lease, `snapshot cleanup: ${String(cause)}`)
        failure = new Error(
          `${failure?.message ?? "LANDING_FAILED"}; snapshot cleanup: ${
            String(cause)
          }; cleanup incomplete at ${verificationRoot}`
        )
      } finally {
        activeSnapshots.delete(verificationRoot)
      }
    }
    const spawnChild = () =>
      spawn(command, [...args], {
        ...(options.cwd === undefined ? {} : { cwd: options.cwd }),
        env: { ...(options.env ?? process.env), BURNDOWN_VERIFICATION_ROOT: verificationRoot },
        detached: true,
        stdio: ["ignore", "pipe", "pipe"]
      })
    let child: ReturnType<typeof spawnChild>
    try {
      child = spawnChild()
    } catch (cause) {
      failure = cause instanceof Error ? cause : new Error(String(cause))
      void removeSnapshot().then(() => reject(failure))
      return
    }
    const send = (pid: number, signal: NodeJS.Signals) => {
      try {
        process.kill(pid, signal)
      } catch (cause) {
        if ((cause as NodeJS.ErrnoException).code !== "ESRCH") throw cause
      }
    }
    const stop = (reason: string) => {
      if (failure !== undefined) return
      failure = new Error(reason)
      if (child.pid !== undefined && child.exitCode === null && child.signalCode === null) {
        const descendants = new Set([child.pid])
        const cleanupErrors: Array<string> = []
        try {
          // Freeze before discovery, then rescan after freezing every new child:
          // a detached child can fork between a ps snapshot and its SIGSTOP.
          // Never rely on the lock wrapper forwarding cancellation signals.
          send(-child.pid, "SIGSTOP")
          const deadline = Date.now() + 5000
          while (true) {
            const remaining = deadline - Date.now()
            if (remaining <= 0) throw new Error("process-tree discovery timeout")
            const rows = execFileSync("ps", ["-e", "-o", "pid=", "-o", "ppid="], {
              encoding: "utf8",
              timeout: remaining
            })
              .trim().split("\n").map((line) => line.trim().split(/\s+/).map(Number))
            const previousSize = descendants.size
            for (let size = -1; size !== descendants.size;) {
              size = descendants.size
              for (const [pid, parent] of rows) {
                if (pid !== undefined && parent !== undefined && descendants.has(parent) && !descendants.has(pid)) {
                  descendants.add(pid)
                  send(pid, "SIGSTOP")
                }
              }
            }
            if (descendants.size === previousSize) break
          }
        } catch (cause) {
          cleanupErrors.push(String(cause))
        } finally {
          // Attempt every kill even if inspection or another signal failed.
          for (const pid of [...descendants].reverse().concat(-child.pid)) {
            try {
              send(pid, "SIGKILL")
            } catch (cause) {
              cleanupErrors.push(String(cause))
            }
          }
        }
        if (cleanupErrors.length > 0) {
          failure = new Error(`${reason}; process-tree cleanup: ${cleanupErrors.join("; ")}`)
        }
      }
      // An orphan can hold these pipes after the tracked tree has exited.
      // Settlement must not depend on its eventual close event.
      child.stdout.destroy()
      child.stderr.destroy()
      void finish(null, null)
    }
    const abort = () => stop("LANDING_CANCELLED")
    const timer = setTimeout(() => stop("LANDING_TIMEOUT: overall 45-minute limit"), options.timeout ?? 2_700_000)
    options.signal?.addEventListener("abort", abort, { once: true })
    child.stdout.setEncoding("utf8")
    child.stderr.setEncoding("utf8")
    child.stdout.on("data", (chunk: string) => {
      if (failure !== undefined) return
      stdout += chunk
      if (Buffer.byteLength(stdout) + Buffer.byteLength(stderr) > 16 << 20) stop("LANDING_OUTPUT_LIMIT")
    })
    child.stderr.on("data", (chunk: string) => {
      if (failure !== undefined) return
      stderr += chunk
      if (Buffer.byteLength(stdout) + Buffer.byteLength(stderr) > 16 << 20) stop("LANDING_OUTPUT_LIMIT")
    })
    const cleanup = () => {
      clearTimeout(timer)
      clearTimeout(drainTimer)
      options.signal?.removeEventListener("abort", abort)
    }
    const finish = async (code: number | null, signal: NodeJS.Signals | null) => {
      if (settled) return
      settled = true
      cleanup()
      if (failure !== undefined && child.pid !== undefined && child.exitCode === null && child.signalCode === null) {
        await new Promise<void>((done) => {
          const exited = () => {
            clearTimeout(exitTimer)
            done()
          }
          const exitTimer = setTimeout(() => {
            child.removeListener("exit", exited)
            failure = new Error(`${failure?.message}; root process exit timeout`)
            done()
          }, 1000)
          child.once("exit", exited)
        })
      }
      await removeSnapshot()
      if (failure !== undefined || code !== 0) {
        reject(
          Object.assign(failure ?? new Error(`LANDING_FAILED exit=${code} signal=${signal}`), { code, stdout, stderr })
        )
      } else accept({ stdout, stderr })
    }
    child.once("error", (cause) => {
      failure ??= cause
      void finish(null, null)
    })
    child.once("exit", (code, signal) => {
      if (settled) return
      // Drain ordinary trailing output, but never wait for inherited orphan pipes.
      drainTimer = setTimeout(() => {
        child.stdout.destroy()
        child.stderr.destroy()
        void finish(code, signal)
      }, 1000)
    })
    child.once("close", (code, signal) => {
      void finish(code, signal)
    })
    if (options.signal?.aborted) abort()
  })

const landOne = (member: Member, reverify = false) =>
  Effect.tryPromise({
    try: async (signal) => {
      let confirmedStdout = ""
      try {
        await mkdir(scriptDir, { recursive: true })
        const path = join(scriptDir, `${member.key}.sh`)
        // Empty an existing readable file before writing any private member data.
        await writeFile(path, "", { mode: 0o700 })
        await chmod(path, 0o700)
        await writeFile(path, landingScript(member, reverify))
        const repoName = member.repo.split("/")[1]!
        const { stdout } = await runLandingProcess("python3", [lockScript, repoName, path], { signal })
        confirmedStdout = stdout
        const landed = [...stdout.matchAll(/^LANDED (\d+) ([0-9a-f]{40})$/gm)].map((m) => ({
          issue: member.commits[Number(m[1]) - 1]!.issue,
          sha: m[2]!
        }))
        if (landed.length !== member.commits.length) {
          throw new Error(`landing printed ${landed.length} of ${member.commits.length}:\n${stdout}`)
        }
        const record = loadAcceptanceRecord(member, landed.at(-1)!.sha)
        // Acceptance can change after push. Never close against a stale issue body.
        const currentIssues: Array<{ issue: number; body: string }> = []
        for (const issue of record.context.issues) {
          const { stdout } = await run("gh", [
            "issue",
            "view",
            String(issue.issue),
            "--repo",
            member.repo,
            "--json",
            "title,body"
          ], { timeout: 60_000, maxBuffer: 16 << 20 })
          const current = JSON.parse(stdout) as { title: string; body: string }
          currentIssues.push({ issue: issue.issue, body: `${current.title}\n${current.body}` })
        }
        validateCurrentAcceptance(record, currentIssues)
        await completeIssueReceipts(member, landed, record, (command, args) =>
          run(command, [...args], { timeout: 120_000, maxBuffer: 16 << 20 }))
        return landed
      } catch (cause) {
        if (confirmedStdout) {
          const error = cause instanceof Error ? cause : new Error(String(cause))
          Object.assign(error, { stdout: confirmedStdout })
          throw error
        }
        throw cause
      }
    },
    catch: (cause) => {
      const failure = landingFailure(member.key, cause)
      let receipt = readPushedReceipt(member)
      if (receipt === undefined) {
        try {
          const line = (cause as { stdout?: string }).stdout?.split("\n").find((line) =>
            line.startsWith("LANDING_CONFIRMED ")
          )
          if (line !== undefined) {
            receipt = validateLandingReceipt(JSON.parse(line.slice("LANDING_CONFIRMED ".length)), member)
          }
          if (receipt === undefined && member.expectedReceipt !== undefined) {
            receipt = validateLandingReceipt(member.expectedReceipt, member)
          }
        } catch {
          /* A malformed marker never supplies remote authority. */
        }
      }
      return isPushedFailure(member, cause) || member.expectedReceipt !== undefined
        ? new LandFailed({
          key: member.key,
          log: failure.log,
          receiptsPending: true,
          ...(failure.disposition === undefined ? {} : { disposition: failure.disposition }),
          ...(receipt === undefined ? {} : { receipt: JSON.parse(JSON.stringify(receipt)) })
        })
        : failure
    }
  })

/** Lands every ready worker, serially, quarantining the ones that fail. */
export const landAll = (ready: ReadonlyArray<WorkerResult>, inFlight: ReadonlyArray<InFlight>, options: {
  readonly reverify?: ReadonlyArray<string>
  readonly expectedReceipts?: ReadonlyArray<{ readonly key: string; readonly receipt: Schema.Json }>
} = {}) =>
  Effect.gen(function*() {
    const members: Array<Member> = ready.flatMap((result) => {
      const item = inFlight.find((i) => i.assignment.key === result.key)
      const expected = options.expectedReceipts?.find((receipt) => receipt.key === result.key)
      return item === undefined || result.commits.length === 0
        ? []
        : [{
          key: result.key,
          repo: item.assignment.repo,
          commits: result.commits,
          notes: result.notes,
          ...(expected === undefined ? {} : { expectedReceipt: expected.receipt })
        }]
    })
    // Retry retained snapshots of exited owners before landing creates new ones.
    const snapshots = yield* Effect.promise(() =>
      recoverRetainedSnapshots().catch((cause): SnapshotRecovery => ({
        recovered: [],
        retained: [{ path: snapshotLedger(), diagnostics: [`ledger unreadable: ${String(cause)}`] }]
      }))
    )
    const retainedSnapshots = snapshots.retained.map((item) => ({
      path: item.path,
      error: item.diagnostics.at(-1) ?? "owner running"
    }))
    if (members.length === 0) return { landed: [], quarantined: [], retainedSnapshots } satisfies LandReport
    const outcome = yield* MergeQueue.run(null, {
      failurePolicy: "quarantine",
      concurrency: 1,
      members: members.map((member) => ({
        id: member.key,
        run: () => landOne(member, options.reverify?.includes(member.key))
      }))
    })
    return {
      landed: outcome.landed.map((l) => l.id),
      quarantined: outcome.quarantined.filter((q) => !q.error.receiptsPending && q.error.disposition !== "park").map((
        q
      ) => ({
        key: q.id,
        error: q.error.log
      })),
      receiptsPending: outcome.quarantined.filter((q) => q.error.receiptsPending).map((q) => ({
        key: q.id,
        error: q.error.log,
        ...(q.error.receipt === undefined ? {} : { receipt: q.error.receipt })
      })),
      incomplete: outcome.quarantined.filter((q) => !q.error.receiptsPending && q.error.disposition === "park").map((
        q
      ) => ({ key: q.id, error: q.error.log })),
      retainedSnapshots
    } satisfies LandReport
  }).pipe(Effect.mapError(String))
