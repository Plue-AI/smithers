/**
 * Burns down every open issue in the named repositories with coding agents on
 * subscription accounts, paced per usage window, landed through a merge queue.
 * The body hands off to the first round; `round.ts` is the loop.
 */
import { Flow, Interpreter, Sleep } from "file:///private/tmp/smithers-burndown-20260930/packages/smithers/flows/flow/src/index.ts"
import { Node } from "file:///private/tmp/smithers-burndown-20260930/packages/smithers/flows/plan/src/index.ts"
import { Layer, Schema } from "file:///private/tmp/smithers-burndown-20260930/node_modules/.pnpm/effect@4.0.0-rc.115/node_modules/effect/dist/index.js"
import { layer as roundActions } from "file:///private/tmp/smithers-burndown-20260930/flows/burndown/host.ts"
import { repository } from "file:///private/tmp/smithers-burndown-20260930/flows/burndown/issues.ts"
import { Pace } from "file:///private/tmp/smithers-burndown-20260930/flows/burndown/pace.ts"
import { Round, RoundError } from "file:///private/tmp/smithers-burndown-20260930/flows/burndown/round.ts"
import { Ready } from "file:///private/tmp/smithers-burndown-20260930/flows/burndown/schema.ts"

export default Flow.make("burndown", {
  description: "Burns down every open issue in the named repositories with paced coding agents and a merge queue.",
  capabilities: ["fs:read:**", "fs:write:**", "proc:spawn:*", "net:get:*", "net:post:*", "model:call:*"],
  effects: { reads: ["**"], writes: ["**"], mode: "expected", onConflict: "serialize", tier: "irreversible" },
  modelInvocable: false,
  payload: Schema.Struct({
    repos: Schema.Array(Schema.String),
    ready: Schema.optional(Schema.Array(Ready)),
    placement: Schema.optional(Schema.Literals(["local", "cloud"])),
    startAgents: Schema.optional(Schema.Number),
    maxAgents: Schema.optional(Schema.Number),
    tickMinutes: Schema.optional(Schema.Number)
  }).check(
    Schema.makeFilter(
      ({ repos, ready }) => (ready ?? []).every((member) => repos.map(repository).includes(member.assignment.repo)),
      {
        message: "READY assignment repository must be included in repos"
      }
    )
  ),
  success: Schema.String,
  error: RoundError,
  body: Node.capture({ version: "burndown/v5" }, ({ maxAgents, placement, ready, repos, startAgents, tickMinutes }: {
    readonly repos: ReadonlyArray<string>
    readonly ready?: ReadonlyArray<Ready> | undefined
    readonly placement?: "local" | "cloud" | undefined
    readonly startAgents?: number | undefined
    readonly maxAgents?: number | undefined
    readonly tickMinutes?: number | undefined
  }) =>
    Round.to({
      options: {
        repos,
        placement: placement ?? "local",
        maxAgents: maxAgents ?? 1024,
        tickMinutes: tickMinutes ?? 5
      },
      round: 0,
      target: startAgents ?? 64,
      inFlight: [],
      quarantined: [],
      ready: ready ?? [],
      readings: {},
      rates: {},
      history: {},
      landed: 0
    }))
})

/** The round lineage and its action implementations; `burndown/worker` registers itself. */
export const layer = Layer.mergeAll(Interpreter.layer(Round), roundActions, Pace.layer, Sleep.layer)
