import {compile,type Component,type Content} from '@smthrs/registry/Prompt';
import {Fragment,jsx,jsxs,render,type Props,type Element} from '@smthrs/registry/Prompt/jsx-runtime';
const Greeting:Component<{readonly name:string}>=props=>props.name;
Greeting({name:'Ada'}) satisfies string;
// @ts-expect-error Missing concrete prompt prop.
Greeting({});
// @ts-expect-error Wrong concrete prompt prop.
Greeting({name:42});
// @ts-expect-error Extra concrete prompt prop.
Greeting({name:'Ada',extra:true});
const content:Content=['x',42,false,null,undefined,jsx('strong',{children:'y'})];
const props:Props={children:content,extra:true};
const element:Element={type:Fragment,props};
compile('Hello') satisfies string;
render(jsxs(Fragment,{children:element})) satisfies string;
// @ts-expect-error Plain object is not text JSX content.
const invalid:Content={name:'Ada'};
void invalid;
