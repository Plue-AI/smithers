import * as Kernel from '@smthrs/kernel/ProcessConfinement';
import * as Native from '@smthrs/platform-node/ProcessConfinement';
import * as Sandbox from '@smthrs/platform-node/ProcessSandbox';
import * as ChildProcess from 'effect/unstable/process/ChildProcess';
import type {Layer} from 'effect';
const profile:Kernel.Profile={workspaceRoot:'/workspace',reads:[],writes:[],readOnly:[],network:'none'};
const command=ChildProcess.make('fixture',[]);
Kernel.makeNoop satisfies Kernel.Service;
Native.make({unavailable:'refuse'}) satisfies Kernel.Service;
Native.layer({unavailable:'refuse'}) satisfies Layer.Layer<Kernel.ProcessConfinement>;
Kernel.makeNoop.confine(command,profile);
const request:Sandbox.Request={network:'loopback',reads:[],writes:[],readOnly:[],strict:true,unixSockets:false};
Sandbox.select(request,Sandbox.host());
// @ts-expect-error Kernel network profiles do not claim loopback enforcement.
const invalid:Kernel.Profile={...profile,network:'loopback'};
// @ts-expect-error Only explicit supported fallback policies are valid.
Native.make({unavailable:'warn'});
// @ts-expect-error Sandbox paths are arrays of strings.
const invalidPaths:Sandbox.Request={...request,writes:[42]};
void invalid;void invalidPaths;
