import pathlib,tempfile,subprocess,os,json,hashlib,shutil
repo=pathlib.Path('/private/tmp/smithers-burndown-20260930');rec=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2');pkg=repo/'packages/smithers/agent/registry';root=pathlib.Path(tempfile.mkdtemp(prefix='smithers-public-prompt-',dir='/private/tmp'))
env=os.environ.copy();env['PATH']='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:/Users/williamcory/.bun/bin:'+env['PATH']
runtime="""import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {compile} from '@smthrs/registry/Prompt';
import {Fragment,jsx,jsxs,render} from '@smthrs/registry/Prompt/jsx-runtime';
const program=compile('# Hello {props.name}');
writeFileSync(new URL('./compiled.mjs',import.meta.url),program);
const {default:Prompt}=await import('./compiled.mjs');
assert.equal(Prompt({name:'Ada'}),'# Hello Ada');
assert.equal(jsxs,jsx);
assert.equal(render(jsx(Fragment,{children:[jsx('strong',{children:'evidence'}),42]})),'**evidence**42');
assert.throws(()=>compile('<Unclosed>'));
process.stdout.write(JSON.stringify({assertions:'passed'}));
"""
types="""import {compile,type Component,type Content} from '@smthrs/registry/Prompt';
import {Fragment,jsx,jsxs,render,type Props,type Element} from '@smthrs/registry/Prompt/jsx-runtime';
const Greeting:Component<{readonly name:string}>=props=>props.name;
Greeting({name:'Ada'}) satisfies string;
// @ts-expect-error Missing concrete prompt prop.
Greeting({});
// @ts-expect-error Wrong concrete prompt prop.
Greeting({name:42});
// @ts-expect-error Extra concrete prompt prop.
Greeting({name:'Ada',extra:true});
const content:Content=['x',42,false,null,undefined,jsx('strong',{children:'y'})];
const props:Props={children:content,extra:true};
const element:Element={type:Fragment,props};
compile('Hello') satisfies string;
render(jsxs(Fragment,{children:element})) satisfies string;
// @ts-expect-error Plain object is not text JSX content.
const invalid:Content={name:'Ada'};
void invalid;
"""
results=[]
try:
 (root/'node_modules/@smthrs').mkdir(parents=True);(root/'node_modules/@smthrs/registry').symlink_to(pkg,target_is_directory=True);(root/'package.json').write_text('{"type":"module"}\n');(root/'consumer.mjs').write_text(runtime);(root/'consumer.ts').write_text(types);(rec/'3184-prompt-public-consumer.mjs').write_text(runtime);(rec/'3184-prompt-public-consumer.ts').write_text(types)
 commands=[['node',str(root/'consumer.mjs')],['bun',str(root/'consumer.mjs')],[str(pkg/'node_modules/.bin/tsc'),'--noEmit','--strict','--skipLibCheck','--allowImportingTsExtensions','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext',str(root/'consumer.ts')]]
 for i,cmd in enumerate(commands):
  p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=60);(rec/f'3184-prompt-public-consumer-{i}.log').write_text(p.stdout+p.stderr);results.append({'command':cmd,'cwd':str(root),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 (rec/'3184-prompt-public-consumer-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
finally:shutil.rmtree(root)
