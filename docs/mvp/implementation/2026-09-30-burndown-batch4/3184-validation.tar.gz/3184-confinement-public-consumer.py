import pathlib,tempfile,subprocess,os,json,shutil
repo=pathlib.Path('/private/tmp/smithers-burndown-20260930');rec=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/ui-flow-batch2');platform=repo/'packages/smithers/flows/platform-node';root=pathlib.Path(tempfile.mkdtemp(prefix='smithers-public-confinement-',dir='/private/tmp'))
env=os.environ.copy();env['PATH']='/Users/williamcory/.nvm/versions/node/v26.5.0/bin:/Users/williamcory/.bun/bin:'+env['PATH']
source="""import * as Kernel from '@smthrs/kernel/ProcessConfinement';
import * as Native from '@smthrs/platform-node/ProcessConfinement';
import * as Sandbox from '@smthrs/platform-node/ProcessSandbox';
import * as ChildProcess from 'effect/unstable/process/ChildProcess';
import type {Layer} from 'effect';
const profile:Kernel.Profile={workspaceRoot:'/workspace',reads:[],writes:[],readOnly:[],network:'none'};
const command=ChildProcess.make('fixture',[]);
Kernel.makeNoop satisfies Kernel.Service;
Native.make({unavailable:'refuse'}) satisfies Kernel.Service;
Native.layer({unavailable:'refuse'}) satisfies Layer.Layer<Kernel.ProcessConfinement>;
Kernel.makeNoop.confine(command,profile);
const request:Sandbox.Request={network:'loopback',reads:[],writes:[],readOnly:[],strict:true,unixSockets:false};
Sandbox.select(request,Sandbox.host());
// @ts-expect-error Kernel network profiles do not claim loopback enforcement.
const invalid:Kernel.Profile={...profile,network:'loopback'};
// @ts-expect-error Only explicit supported fallback policies are valid.
Native.make({unavailable:'warn'});
// @ts-expect-error Sandbox paths are arrays of strings.
const invalidPaths:Sandbox.Request={...request,writes:[42]};
void invalid;void invalidPaths;
"""
results=[]
try:
 (root/'node_modules/@smthrs').mkdir(parents=True)
 for name in ['kernel','platform-node']:(root/'node_modules/@smthrs'/name).symlink_to(repo/'packages/smithers/flows'/name,target_is_directory=True)
 (root/'node_modules/@types').mkdir();(root/'node_modules/@types/node').symlink_to(platform/'node_modules/@types/node',target_is_directory=True)
 (root/'node_modules/effect').symlink_to(platform/'node_modules/effect',target_is_directory=True);(root/'package.json').write_text('{"type":"module"}\n');(root/'consumer.ts').write_text(source);(rec/'3184-confinement-public-consumer.ts').write_text(source)
 cmd=[str(platform/'node_modules/.bin/tsc'),'--noEmit','--strict','--exactOptionalPropertyTypes','--skipLibCheck','--allowImportingTsExtensions','--target','ES2022','--module','NodeNext','--moduleResolution','NodeNext',str(root/'consumer.ts')]
 p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=60);(rec/'3184-confinement-public-consumer.log').write_text(p.stdout+p.stderr);results.append({'command':cmd,'cwd':str(root),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(rec/'3184-confinement-public-consumer-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
finally:shutil.rmtree(root)
