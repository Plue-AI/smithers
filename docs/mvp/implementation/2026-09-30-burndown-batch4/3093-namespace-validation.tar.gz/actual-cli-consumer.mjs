import{readFileSync,writeFileSync}from"node:fs";import{join}from"node:path";import{createHash}from"node:crypto";import{execFileSync}from"node:child_process";
const root="/private/tmp/smithers-burndown-20260930",base="/tmp/smithers-burndown-20260930-receipts/api-batch3/final-cohort-ed02fdb594",head="ed02fdb594cfb1f9aa537c11f563b89812bd1136",manager=process.argv[2];
const{releaseRegistry}=await import(root+"/scripts/release-registry.mjs");const{runCliMcpConsumer}=await import(root+"/scripts/release-consumers.mjs");
const entries=JSON.parse(readFileSync(join(base,"packs/manifest.json"))),packIdentity=JSON.parse(readFileSync(join(base,"pack50-result.json"))),inputs=JSON.parse(readFileSync(join(base,"source-inputs-before.json"))).files,sha=b=>createHash("sha256").update(b).digest("hex");
if(execFileSync("git",["rev-parse","HEAD"],{cwd:root,encoding:"utf8"}).trim()!==head)throw Error("Candidate changed");
for(const entry of packIdentity.outputs)if(sha(readFileSync(join(base,"packs",entry.filename)))!==entry.sha256)throw Error("Pack changed: "+entry.filename);
const registry=await releaseRegistry(join(base,"packs"),entries);
let result;
try{
 result={manager,head,registry:registry.url,startedAt:new Date().toISOString(),passed:true,consumer:await runCliMcpConsumer(manager,registry.url,entries.find(e=>e.name==="@smthrs/cli").version)};
}catch(error){result={manager,head,passed:false,error:error.stack};process.exitCode=1;}finally{await registry.close();}
result.finishedAt=new Date().toISOString();result.changedSourceInputs=Object.entries(inputs).filter(([file,before])=>sha(readFileSync(join(root,file)))!==before).map(([file])=>file);if(result.changedSourceInputs.length)process.exitCode=1;
writeFileSync(join(base,"actual-cli-"+manager+"-result.json"),JSON.stringify(result,null,2)+"\n");console.log(JSON.stringify(result));
