import fs from "node:fs";
import cp from "node:child_process";
import {createHash} from "node:crypto";
import {createRequire,syncBuiltinESMExports} from "node:module";
import {dirname,join,relative} from "node:path";
import {gzipSync} from "node:zlib";
const root="/private/tmp/smithers-burndown-20260930", receipts="/tmp/smithers-burndown-20260930-receipts/api-batch3/final-cohort-ed02fdb594";
const sha=bytes=>createHash("sha256").update(bytes).digest("hex"), originalSpawn=cp.spawnSync, originalRm=fs.rmSync;
const head=cp.execFileSync("git",["rev-parse","HEAD"],{cwd:root,encoding:"utf8"}).trim();
if(head!=="ed02fdb594cfb1f9aa537c11f563b89812bd1136")throw Error("Candidate changed");
if(cp.execFileSync("git",["status","--porcelain"],{cwd:root,encoding:"utf8"}).trim())throw Error("Candidate dirty");
const tracked=cp.execFileSync("git",["ls-files","-z"],{cwd:root,encoding:"utf8"}).split("\0").filter(Boolean);
const selected=tracked.filter(f=>!f.includes("/dist/")&&(f.startsWith("scripts/")||f.startsWith("packages/")||f.startsWith("flows/")||/^(package\.json|pnpm-lock\.yaml|pnpm-workspace\.yaml|tsconfig.*\.json|\.node-version|\.npmrc)$/.test(f)));
const files=Object.fromEntries(selected.map(f=>[f,sha(fs.readFileSync(join(root,f)))]));
fs.writeFileSync(join(receipts,"baseline-anchor.json"),fs.readFileSync(join(root,"scripts/fixtures/public-api-baseline.json")));
fs.writeFileSync(join(receipts,"source-inputs-before.json"),JSON.stringify({head,files,node:process.version,startedAt:new Date().toISOString()},null,2)+"\n");
const events=[];
cp.spawnSync=(command,args,options)=>{
 const start=Date.now(),result=originalSpawn(command,args,options);
 const event={command,args,cwd:options?.cwd,startedAt:new Date(start).toISOString(),durationMs:Date.now()-start,status:result.status,signal:result.signal,error:result.error?.message,stdout:result.stdout?.toString(),stderr:result.stderr?.toString()};events.push(event);
 fs.writeFileSync(join(receipts,"declaration-compiler-events.json"),JSON.stringify(events,null,2)+"\n");
 console.log(JSON.stringify({owner:relative(root,options.cwd),status:result.status,durationMs:event.durationMs,completed:events.length}));return result;
};
fs.rmSync=(path,options)=>{
 if(typeof path==="string"&&path.includes("smithers-api-declarations-")&&fs.existsSync(path)){
  fs.cpSync(path,join(receipts,"retained-canonical-output"),{recursive:true});
  fs.writeFileSync(join(receipts,"temporary-output-cleanup.json"),JSON.stringify({canonicalPath:path,retainedAt:join(receipts,"retained-canonical-output"),cleanupUnchanged:true})+"\n");
 }
 return originalRm(path,options);
};
syncBuiltinESMExports();
const {apiSurface,withDeclarationBuild,assertApiBaseline}=await import(root+"/scripts/check-api-baseline.mjs");
const {libraryPackages}=await import(root+"/scripts/workspace-packages.mjs");
const packages=libraryPackages(root).filter(p=>!p.manifest.private),compilerFiles={};
const walk=(dir)=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(dir,e.name)):[join(dir,e.name)]);
const compilers=packages.map(p=>{const req=createRequire(join(root,p.dir,"package.json"));const manifest=req.resolve("typescript/package.json"),base=dirname(manifest),m=JSON.parse(fs.readFileSync(manifest));for(const file of walk(base)){if (!(file in compilerFiles)) compilerFiles[file]=sha(fs.readFileSync(file));}return {name:p.name,dir:p.dir,version:m.version,compiler:join(base,"bin/tsc"),manifestSha256:sha(fs.readFileSync(manifest))};});
fs.writeFileSync(join(receipts,"compiler-input-identities.json"),JSON.stringify({compilers,compilerFiles},null,2)+"\n");
let compiled=false,drift,actual;
try{
 await withDeclarationBuild(root,async output=>{
  compiled=true;actual=apiSurface(root,output);
  fs.writeFileSync(join(receipts,"actual-api-surface.json"),JSON.stringify({format:2,packages:actual},null,2)+"\n");
  const baseline=JSON.parse(fs.readFileSync(join(root,"scripts/fixtures/public-api-baseline.json"))).packages;
  drift=Object.keys(actual).filter(name=>JSON.stringify(actual[name])!==JSON.stringify(baseline[name])).map(name=>({name,addedExports:Object.keys(actual[name].exports).filter(k=>!(k in baseline[name].exports)),removedExports:Object.keys(baseline[name].exports).filter(k=>!(k in actual[name].exports)),changedExports:Object.keys(actual[name].exports).filter(k=>k in baseline[name].exports&&JSON.stringify(actual[name].exports[k])!==JSON.stringify(baseline[name].exports[k])),declarations:[...new Set([...Object.keys(actual[name].declarations),...Object.keys(baseline[name].declarations)])].filter(k=>actual[name].declarations[k]!==baseline[name].declarations[k]).map(file=>({file,before:baseline[name].declarations[file],after:actual[name].declarations[file]}))}));
  fs.writeFileSync(join(receipts,"api-drift-review.json"),JSON.stringify(drift,null,2)+"\n");
  try{assertApiBaseline(baseline,actual);}catch(error){fs.writeFileSync(join(receipts,"expected-baseline-drift.txt"),String(error)+"\n");}
 });
}catch(error){fs.writeFileSync(join(receipts,"declaration-failure.txt"),error.stack+"\n");process.exitCode=1;}
const changed=Object.entries(files).filter(([file,before])=>sha(fs.readFileSync(join(root,file)))!==before).map(([file])=>file);
const compilerChanged=Object.entries(compilerFiles).filter(([file,before])=>sha(fs.readFileSync(file))!==before).map(([file])=>file);
const afterHead=cp.execFileSync("git",["rev-parse","HEAD"],{cwd:root,encoding:"utf8"}).trim();
const result={head,afterHead,compiled,publicPackages:packages.length,compilerRuns:events.length,compilerPasses:events.filter(e=>e.status===0).length,changedSourceInputs:changed,changedCompilerInputs:compilerChanged,changedPackages:drift?.map(d=>d.name),privateDeclarations:actual?Object.values(actual).reduce((n,p)=>n+Object.keys(p.declarations).filter(k=>k.startsWith("../vendor/")).length,0):null,baselineUpdated:false,completedAt:new Date().toISOString(),limitation:"Canonical50 DTS plus private adapterJS sidecars only; no full JS/CJS or releaseSmoke qualification."};
fs.writeFileSync(join(receipts,"declaration-result.json"),JSON.stringify(result,null,2)+"\n");console.log(JSON.stringify(result));
if(changed.length||compilerChanged.length||afterHead!==head)process.exitCode=1;
