The TUI cannot start against a configured Smithers account pool when no local provider credential/login exists. This blocks the live monitor docs recording and the same selfhost/Cloud account-pool startup path.

Reproduction from the claimed #3174 sibling audit:

```
PATH=/Users/williamcory/.nvm/versions/node/v26.5.0/bin:$PATH SMITHERS_WORKSPACE_JJ_EXPORT_BINARY=/Users/williamcory/smithers/target/debug/smithers-jj-export node apps/tui-docs/scripts/record.mjs --only monitor,monitor-refusal
```

The recorder creates a real local HTTP fixture with `/routes` returning `{routes:["chatgpt"]}` and passes `SMITHERS_ACCOUNT_POOL_URL`, `SMITHERS_ACCOUNT_POOL_KEY=docs-fixture`, `SMITHERS_ACCOUNT_POOL_PROVIDERS=chatgpt`, and isolated home/config. Once the monitor scenario correctly omits `SMITHERS_TUI_REPLAY`, actual TUI startup exits `No model is available` before coordinator/judge/Luna HTTP requests or durable monitor observations.

Cause: apps/tui/src/run.tsx selects Models.detect(...).defaultSeat. apps/tui/src/models.ts detect only discovers key/login-backed Providers; it does not resolve reachable account-pool routes. Existing packages/smithers/src/internal/NativeEquipment.ts accountPoolDefaultModel queries and validates actual permitted routes through the shared RequestExecutor. Use the existing shared account-pool capability rather than a recorder-specific fake credential or a second provider implementation.

Acceptance:
- A configured reachable account pool alone offers/selects a usable permitted model through actual HTTP route discovery.
- No model is fabricated for failed discovery, empty/unpermitted routes, or incomplete pool credentials. Existing local-key/login/explicit-seat behavior remains covered.
- Unit regressions and an independent real local HTTP/TUI startup or recording boundary demonstrate success and refusal. The monitor recording must make actual coordinator/judge/Luna requests and retain the required durable stopped-monitor/update receipt; replay cannot satisfy live evidence.

Read-only duplicate search `gh issue list --repo smithersai/smithers --state open --limit 100 --search 'TUI account pool default model' --json number,title,url` returned broad #1757/#1923/#2979/#2271/#2498/#2290/#1651 only; no exact account-pool startup regression owner.

Evidence: /tmp/smithers-burndown-20260930-receipts/api-batch2/3174-recorder-actual.log and six passing independent recorder tests in3174-recorder-tests.log. Secondary cleanup reports macOS PermissionError from terminal_capture.py os.killpg after the child exits; no cleanup success is claimed by this receipt.
