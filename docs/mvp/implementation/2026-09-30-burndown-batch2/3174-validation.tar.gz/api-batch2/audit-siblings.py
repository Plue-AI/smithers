import concurrent.futures, hashlib, json, pathlib, re, subprocess, time
ROOT=pathlib.Path('/private/tmp/smithers-burndown-20260930')
OUT=pathlib.Path('/tmp/smithers-burndown-20260930-receipts/api-batch2')
COMMITS=['a2c407add7','a031cc0fca','526b9bcfce','3eda166dd3','0b720b2318','50009960df']
def git(*a):
 p=subprocess.run(['git',*a],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode: raise RuntimeError((a,p.stderr))
 return p.stdout
hunks=[]; jobs={}
for commit in COMMITS:
 parent=git('rev-parse',commit+'^').strip()
 diff=git('diff','--no-ext-diff','--unified=0',parent,commit)
 (OUT/(commit+'.diff')).write_text(diff)
 file=None; h=None; old=0; new=0
 for line in diff.splitlines():
  if line.startswith('diff --git '): h=None; continue
  if line.startswith('--- a/'): file=line[6:]; continue
  if line.startswith('--- '): continue
  if line.startswith('+++ '):
   if line.startswith('+++ b/'): file=line[6:]
   continue
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(.*)',line)
  if m:
   old=int(m[1]);new=int(m[3]); h={'commit':commit,'parent':parent,'file':file,'header':line,'removed':[],'added':[]};hunks.append(h)
  elif h and line.startswith('-'):
   h['removed'].append({'line':old,'text':line[1:]});old+=1
  elif h and line.startswith('+'):
   h['added'].append({'line':new,'text':line[1:]});new+=1
  elif h and line.startswith(' '):old+=1;new+=1
 for h in [x for x in hunks if x['commit']==commit]:
  if h['removed']:
   start=h['removed'][0]['line'];end=h['removed'][-1]['line']
   blame=git('blame','--line-porcelain','-L',f'{start},{end}',parent,'--',h['file'])
   identities=[];current=None
   for line in blame.splitlines():
    m=re.match(r'^([0-9a-f]{40}) (\d+) (\d+)(?: \d+)?$',line)
    if m: current={'commit':m[1],'originalLine':int(m[2]),'parentLine':int(m[3])}
    elif line.startswith('\t'):
     identities.append({**current,'text':line[1:]})
   h['blame']=identities
  for addition in h['added']:
   key=(parent,h['file'],addition['text']);jobs[key]=None
print('hunks',len(hunks),'removed',sum(len(h['removed']) for h in hunks),'added',sum(len(h['added']) for h in hunks),'unique pickaxes',len(jobs),flush=True)
def pickaxe(key):
 parent,file,line=key
 if line=='': return key,{'blank':True,'commits':[]}
 result=git('log','--format=%H','--no-renames','-S',line,parent,'--',file).splitlines()
 return key,{'commits':result}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for n,(key,value) in enumerate(pool.map(pickaxe,jobs),1):
  jobs[key]=value
  if n%500==0: print('pickaxe',n,'/',len(jobs),flush=True)
for h in hunks:
 for a in h['added']:a['pickaxe']=jobs[(h['parent'],h['file'],a['text'])]
(OUT/'3174-full-hunk-evidence.json').write_text(json.dumps(hunks,ensure_ascii=False,indent=2)+'\n')
print('complete',flush=True)
