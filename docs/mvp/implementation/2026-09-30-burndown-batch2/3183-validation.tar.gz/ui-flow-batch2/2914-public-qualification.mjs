import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import * as Cap from '/private/tmp/smithers-burndown-20260930/packages/smithers/flows/capability/node_modules/@smthrs/capability/CapabilitySet'
