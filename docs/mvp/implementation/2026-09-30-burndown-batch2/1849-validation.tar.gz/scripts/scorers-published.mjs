import assert from 'node:assert/strict'
import { cpSync, mkdtempSync, mkdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
const root = process.cwd()
const packageRoot = join(root, 'packages/smithers/agent/scorers')
const scratch = mkdtempSync(join(tmpdir(), 'scorers-public-'))
try {
  const modules = join(scratch, 'node_modules')
  const target = join(modules, '@smthrs/scorers')
  mkdirSync(target, { recursive: true })
  const manifest = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'))
  writeFileSync(join(target, 'package.json'), JSON.stringify({ ...manifest, exports: manifest.publishConfig.exports }))
  cpSync(join(packageRoot, 'dist'), join(target, 'dist'), { recursive: true })
  symlinkSync(join(packageRoot, 'node_modules'), join(target, 'node_modules'), 'dir')
  symlinkSync(join(root, 'node_modules/effect'), join(modules, 'effect'), 'dir')
  const probe = `
    const assert = await import('node:assert/strict');
    const { createRequire } = await import('node:module');
    const esm = await import('@smthrs/scorers/Scorers');
    const cjs = createRequire(import.meta.url)('@smthrs/scorers/Scorers');
    for (const api of [esm, cjs]) {
      for (const name of ['exact','contains','diffSize','touchedFiles','testsPass','rubric']) assert.equal(typeof api[name], 'function');
      const { Effect } = await import('effect');
      const out = await Effect.runPromise(api.exact().score({ output:' x  y ', groundTruth:'x y' }));
      assert.equal(out.score,1);
      const metadata = 'diff --git a/a b/a\\nold mode 100644\\nnew mode 100755\\n';
      const refused = await Effect.runPromise(Effect.flip(api.touchedFiles({max:0}).score({input:null,output:metadata})));
      assert.equal(refused.code,'inconclusive');
      const untouched = await Effect.runPromise(api.touchedFiles({max:0}).score({input:null,output:''}));
      assert.equal(untouched.score,1);
    }
    assert.equal(typeof (await import('@smthrs/scorers')).Scorers.exact, 'function');
    assert.equal(typeof createRequire(import.meta.url)('@smthrs/scorers').Scorers.exact, 'function');
    console.log('Published conditional ESM/CJS imports and normalized scoring passed');
  `
  writeFileSync(join(scratch, 'probe.mjs'), probe)
  const result = spawnSync(process.execPath, [join(scratch, 'probe.mjs')], { cwd:scratch, encoding:'utf8' })
  process.stdout.write(result.stdout); process.stderr.write(result.stderr)
  assert.equal(result.status, 0)
  for (const mode of ['esm','cjs']) {
    const declarations = readFileSync(join(target, `dist/${mode}/Scorers.d.ts`), 'utf8')
    for (const name of ['exact','contains','diffSize','touchedFiles','testsPass','rubric']) assert.match(declarations, new RegExp(`export declare const ${name}\\b`))
    for (const name of ['TestsPassOptions', 'DiffOptions']) assert.match(declarations, new RegExp(`export interface ${name}\\b`))
  }
  console.log('Both published declaration branches include six scorers and option types')
  for (const extension of ['mts', 'cts']) writeFileSync(join(scratch, `types.${extension}`), `
    import * as Scorers from '@smthrs/scorers/Scorers';
    import { Scorers as RootScorers } from '@smthrs/scorers';
    const budget: Scorers.DiffOptions = { max: 3 };
    const scorer = Scorers.diffSize(budget);
    const root = RootScorers.exact();
    const options: Pick<Scorers.TestsPassOptions, 'command' | 'timeoutMs'> = { command:'check', timeoutMs:1000 };
    void [scorer, root, options];
  `)
  const typecheck = spawnSync(process.execPath, [join(packageRoot, 'node_modules/typescript/bin/tsc'), '--noEmit', '--strict', '--types', 'node', '--typeRoots', join(packageRoot, 'node_modules/@types'), '--allowImportingTsExtensions', '--skipLibCheck', '--module', 'NodeNext', '--moduleResolution', 'NodeNext', '--target', 'ES2022', join(scratch,'types.mts'), join(scratch,'types.cts')], { cwd:scratch, encoding:'utf8' })
  process.stdout.write(typecheck.stdout); process.stderr.write(typecheck.stderr)
  assert.equal(typecheck.status,0)
  console.log('Published ESM and CJS consumer declarations typecheck passed')
} finally { rmSync(scratch, { recursive:true, force:true }) }
