# #1916 polling audit

Current source acceptance is complete; no additional unchanged accepted observation was found. Earlier fixes remain landed, including 2ee034491a. This is an app-source audit, not an aggregate deployment or release claim.

Inventory covers production timer/loop sites under apps/app/src/mainview/state (raw search retained in 1916-production-timers.txt). Classification follows the dispatch path, not timer count.

| Poll or recurring repair | Committed observation check / idle behavior |
| --- | --- |
| controller/workflow-pump.ts run summary, transcript, journal, approvals | changedRuntimeRunObservation compares committed normalized runtime projection; cursor-based journal suffixes; observer patch compares committed observer; reconcileRunApprovals compares committed gates. Physical JournalGrowth full idle and approval tests cover it. |
| controller/repositorySetup.ts queued/running/completion and scheduled registration | Nonterminal upserts compare normalized visible+committed card; await receipt before next poll. Terminal result is saved once and exits. Physical setup running-receipt proof retained. Scheduled timer launches a durable request, not an observation loop. |
| controller/registration.ts imported() | Reads the existing import card while pending, with no dispatch in the wait loop. Dispatches only transitions out of the waiting stage. |
| controller/explain.ts journal catch-up | Cursor-fenced read and new-batch enqueue, awaiting prior commit before cursor acknowledgment; unchanged journal does not enqueue accepted rows. |
| controller/cloud-wiki.ts reconnect and durable edit send | Accepted snapshot checks normalized visible+committed document; same stream failure retained once; sender consumes one persisted pending edit, not repeated unchanged observations. Physical EOF/unavailable reconnect proofs retained. |
| controller/auth-billing.ts native handoff claim | Pending answer / dropped poll / transient errors continue with no dispatcher call; signed-in/failed/expired result exits once. Account generation and abort fence obsolete results. |
| seams/RepoImportSeam.ts import status | Normalized visible+committed/pending receipt equality before status dispatch; changed observations await receipt. Physical idle import proof retained. |
| seams/AgentSessionSeam.ts repair reads and reconnect | Serial observe queue awaits receipt; persistObservation checks schema-normalized visible+committed card. Committed transcript ID sets reconnect cursor. Identical status/transcript or failure does not write. Physical stream repair and retained failure proofs plus reconnect/cursor/account regressions pass. |
| seams/WorkspaceSeam.ts provisioning/readiness and desktop heartbeat | Provisioning equality against committed receipt; desktop display observation equality and own pending receipt token. Physical provisioning/progress/rejection proofs retained. |
| seams/GitHubSeam.ts repository mirror polling | Compare current/committed mirror receipt before dispatch. Physical idle mirror proof retained. |
| seams/IssuesSeam.ts issue comments/status polling | Successful payload equality before card.view.loaded; quiet identical failures check visible+committed/pending toast via failures.quietly. Changed/dismissed failure still durable. Physical quiet poll-failure commit/reject proof retained. |
| seams/StackSeam.ts snapshot/retry | Normalized committed snapshot comparison; debounce/retry timer does not dispatch an unchanged snapshot. Explicit mutations retain command records. |
| seams/CloudSeam.ts browser sign-in | Initial signing-in saved once; while pending no mirror/dispatch. Terminal signed-in/signed-out exits once. |
| seams/SecretsSeam.ts Codex device sign-in | Pending/429/5xx repeats wait without save/publish. Only terminal outcome saves once. |
| CloudLspClient + CodeIntelSeam | Client reconnect/deadline timers deliver transport publications; CodeIntel normalized visible+committed and own pending receipt token dedupe diagnostics/waiting/closed. Physical publication proofs retained. |
| CloudTerminalClient | Reconnect is transport maintenance; this client has no AppStore or transition dispatcher and only keeps bounded connection/runtime buffers. Reconnect itself creates no accepted observation. Workspace desktop progress publication is separately deduped above. |

Not polling: runs.ts four zero-delay timers resume only persisted pending list/open/facet/inbox requests (each read has in-flight identity/generation and receipt fencing); workflow-catalog reload debounce; recommend debounce; backgroundWork debounce and equality-guarded toast reconciliation; AppController first-run deadline; httpTurns/context network deadlines/body reads; ConversationSweep response-body consumption; AppStore draft/compaction/write-drain; health-status expiry dispatch is runtime-only. Algorithm loops in PreparedView/ClientErrors/ConversationArchive/AgentTurnPolicy do not poll. TestFixtures.ts is test support. None warrants an invented idle polling fix.

Validation: actual Bun app boundary suites JournalGrowth, auth-billing, AgentSessionSeam, CloudTerminalClient, Runs: 331 passed, 0 failed, 1858 assertions across 5 files (28.75s). JournalGrowth asserts physical SQLite head/rows/bytes/pages/write-count stability, held/rejected receipts, real changes and valid reopen. Other suites exercise current pending login, account retirement, repair/reconnect, obsolete replies and run request resumption. Source unchanged by this issue.

The first attempt failed toolchain preload because ambient Node was24.4.1; final run explicitly used Node26.5.0 and Bun1.4.2. This audit does not claim a live hosted browser or every platform; issue acceptance does not require either.
