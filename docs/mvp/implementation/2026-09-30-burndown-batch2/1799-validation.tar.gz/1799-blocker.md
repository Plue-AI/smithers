# #1799 current prerequisite receipt

Reviewed shared HEAD 745570ae875f8effb2a3a874406cec76125dbbc4 (2026-09-30). No source changes.

The latest explicit maintainer decision supersedes the alias option in the original body: “delete the `@smthrs/core` `Flow.make({name,...})` form and create-app `defineFlow`; migrate callers and docs to `@smthrs/flow` `Flow.make(tag, ...)`. No deprecated aliases.”

Decision: https://github.com/smithersai/smithers/issues/1799#issuecomment-5847112755
Existing prerequisite: https://github.com/smithersai/smithers/issues/2271 (verified OPEN). Prior same blocker: https://github.com/smithersai/smithers/issues/1799#issuecomment-5897367196

Current canonical make.ts:197 and :343 require graph body; MakeOptions has no prompt/model declaration or lowering. Core Flow.ts:120/132/:421 still accepts model/prompt and the one-object signature. create-app app.ts:307/:332 still exposes prompt-backed defineFlow. Deleting these now has no canonical replacement for prompt declarations and bodyless actions.

Independent current scoped counts: `rg -l defineFlow -g '*.ts' -g '*.mdx' -g '*.md' packages flows` =20 files; `rg 'Flow\.make\(\{' -g '*.ts' -g '*.mdx' packages flows` =261 lines. These narrower current counts are not equated with the older sweep's whole-repository 28/356 counts.

Do not add partial aliases against the explicit decision. Release #1799 open, blocked by existing #2271 prompt lowering; after that lands migrate consumers, remove both constructors, update docs and exercise generated default-export routers plus public authoring identity/type boundaries. No completion claim or new duplicate issue.
